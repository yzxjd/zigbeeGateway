#include "stm32f10x_lib.h"
#include "stm32f10x_api.h"
#include "ff.h"
#include "voiceApp.h"
#include "displayApp.h"
#include "usrApp.h"
#include "display.h"
#include "net.h"
#include "para.h"
#include "cjson.h"
#include "string.h"
#include "stdlib.h"
#include "stdio.h"

static void ParaFileInit(void);
static void DisplayInfoInit(void);
static void VoiceVolInfoInit(void);
static void ModelSettingInfoInit(void);
static void NetInfoInit(NET_CONFIG *pNetConfig);
static void CanInfoInit(unsigned char *CanAddr);
static void DisplayFixedInfoInit(unsigned char *FixedInfo);
static void ReadVoiceVolInfo(VOL_CONFIG *Vol);


/*********************************************************************/
void ParaInit(void)
{
    ParaFileInit();
    DisplayInfoInit();
    DisplayFixedInfoInit(DisplayGetFixedInfoAddr());
    VoiceVolInfoInit();
    ReadVoiceVolInfo(VoiceGetVolConfigAddr());
    ModelSettingInfoInit();
    NetInfoInit(GetNetConfigAddr());
    CanInfoInit(GetCanAddr());
}

void ParaReset(void)
{
    unsigned int res;

    printf("para reset!\r\n");

    res = f_mkfs("0:",0,2048);
    if(res!=0)
    {
        printf("mkfs error:%d\r\n",res);
    }
    else
    {
        Reboot();
    }
}


static void ParaFileInit(void)
{
    FIL fp;
    DIR dir;
    FRESULT res;

    if(f_opendir(&dir,FOLDER_LEGACY )!=FR_OK)
    {
        res=f_mkdir(FOLDER_LEGACY );
        if(res!=FR_OK)
        {
            return ;
        }
    }
    f_open(&fp,FILE_SOUND_TAB,FA_CREATE_NEW);
    f_close(&fp);
    f_open(&fp,FILE_PASS_RECORD,FA_CREATE_NEW);
    f_close(&fp);
    f_open(&fp,FILE_RIQISTER_TAB,FA_CREATE_NEW);
    f_close(&fp);
    f_open(&fp,FILE_WORD_CARD,FA_CREATE_NEW);
    f_close(&fp);
    f_open(&fp,FILE_WIRELESS_ID,FA_CREATE_NEW);
    f_close(&fp);
    f_open(&fp,FILE_RATE_SET,FA_CREATE_NEW);
    f_close(&fp);

    res=f_open(&fp,FILE_SOUND_TAB,FA_READ);
    f_close(&fp);
    res=f_open(&fp,FILE_PASS_RECORD,FA_READ);
    f_close(&fp);
    res=f_open(&fp,FILE_RIQISTER_TAB,FA_READ);
    f_close(&fp);
    res=f_open(&fp,FILE_WORD_CARD,FA_READ);
    f_close(&fp);
    res=f_open(&fp,FILE_WIRELESS_ID,FA_READ);
    f_close(&fp);
    res=f_open(&fp,FILE_RATE_SET,FA_READ);
    f_close(&fp);
}


static void NetInfoInit(NET_CONFIG *pNetConfig)
{
    NET_CONFIG *ip=pNetConfig;
    FIL fp;
    DIR dir;
    FRESULT res;
    unsigned long long macs;

    char temp_net[50];
    int read0,read1,read2,read3;

    char text1[]="{\"MAC\":\"00123456789a\"}\r\n";
    char text2[]="{\"IPv4\":\"192.168.1.204\"}\r\n";
    char text3[]="{\"MASK\":\"255.255.255.0\"}\r\n";
    char text4[]="{\"GateWay\":\"192.168.1.1\"}\r\n";

    char folder_path[]="NetCfg";
    char file_path[]="NetAddr.txt";
    char net_config_path[30]= {0};
    cJSON *root,*item ;

    memset(temp_net,0,50);
    sprintf(text1,"{\"MAC\":\"0011%08x\"}\r\n",McuGetId());
    sprintf(net_config_path,"%s/%s",folder_path,file_path);

    ip->lport = 5000;

    //MAC
    root = cJSON_Parse((const char *)text1);
    if(root != NULL)
    {
        item = cJSON_GetObjectItem(root,"MAC" );
        sscanf(item->valuestring, "%llx", &macs);
    }
    cJSON_Delete(root);
    ip->mac[5]=(macs>>8*0)&0xff;
    ip->mac[4]=(macs>>8*1)&0xff;
    ip->mac[3]=(macs>>8*2)&0xff;
    ip->mac[2]=(macs>>8*3)&0xff;
    ip->mac[1]=(macs>>8*4)&0xff;
    ip->mac[0]=(macs>>8*5)&0xff;

    //IP
    root = cJSON_Parse((const char *)text2);
    if(root != NULL)
    {
        item = cJSON_GetObjectItem(root,"IPv4" );
        sscanf(item->valuestring, "%d.%d.%d.%d", &read0,&read1,&read2,&read3);
    }
    cJSON_Delete(root);
    ip->lip[0]=read0&0xff;
    ip->lip[1]=read1&0xff;
    ip->lip[2]=read2&0xff;
    ip->lip[3]=read3&0xff;

    //MASK
    root = cJSON_Parse((const char *)text3);
    if(root != NULL)
    {
        item = cJSON_GetObjectItem(root,"MASK" );
        sscanf(item->valuestring, "%d.%d.%d.%d", &read0,&read1,&read2,&read3);
    }
    cJSON_Delete(root);
    ip->sub[0]=read0&0xff;
    ip->sub[1]=read1&0xff;
    ip->sub[2]=read2&0xff;
    ip->sub[3]=read3&0xff;

    //GW
    root = cJSON_Parse((const char *)text4);
    if(root != NULL)
    {
        item = cJSON_GetObjectItem(root,"GateWay" );
        sscanf(item->valuestring, "%d.%d.%d.%d", &read0,&read1,&read2,&read3);
    }
    cJSON_Delete(root);
    ip->gw[0]=read0&0xff;
    ip->gw[1]=read1&0xff;
    ip->gw[2]=read2&0xff;
    ip->gw[3]=read3&0xff;

    if(f_opendir(&dir,folder_path)!=FR_OK)  //������������������ļ���
    {
        res=f_mkdir(folder_path);
        if(res!=FR_OK)
        {
            return ;
        }
    }

    if(f_open(&fp,net_config_path, FA_WRITE|FA_READ) != FR_OK)  //FA_OPEN_EXISTING
    {
        if( f_open(&fp, net_config_path, FA_CREATE_NEW|FA_WRITE|FA_READ)==FR_OK)  //�������ļ�
        {
            f_puts(text1,&fp);
            f_puts(text2,&fp);
            f_puts(text3,&fp);
            f_puts(text4,&fp);
            f_close(&fp);
        }
        else
        {
            printf("net config erorr \r\n");
            return ;
        }
    }
    if(f_open(&fp,net_config_path, FA_OPEN_EXISTING|FA_READ)==FR_OK)
    {
        if(f_gets(temp_net,50,&fp))
        {
            root = cJSON_Parse((const char *)text1);
            if(root != NULL)
            {
                item = cJSON_GetObjectItem(root,"MAC" );
                sscanf(item->valuestring, "%llx", &macs);
            }
            cJSON_Delete(root);
            ip->mac[5]=(macs>>8*0)&0xff;
            ip->mac[4]=(macs>>8*1)&0xff;
            ip->mac[3]=(macs>>8*2)&0xff;
            ip->mac[2]=(macs>>8*3)&0xff;
            ip->mac[1]=(macs>>8*4)&0xff;
            ip->mac[0]=(macs>>8*5)&0xff;
        }
        if(f_gets(temp_net,50,&fp))
        {
            root = cJSON_Parse((const char *)temp_net);
            if(root != NULL)
            {
                item = cJSON_GetObjectItem(root,"IPv4" );
                sscanf(item->valuestring, "%d.%d.%d.%d", &read0,&read1,&read2,&read3);
            }
            cJSON_Delete(root);

            ip->lip[0]=read0&0xff;
            ip->lip[1]=read1&0xff;
            ip->lip[2]=read2&0xff;
            ip->lip[3]=read3&0xff;

        }
        if(f_gets(temp_net,50,&fp))
        {
            root = cJSON_Parse((const char *)temp_net);
            if(root != NULL)
            {
                item = cJSON_GetObjectItem(root,"MASK" );
                sscanf(item->valuestring, "%d.%d.%d.%d", &read0,&read1,&read2,&read3);
            }
            cJSON_Delete(root);

            ip->sub[0]=read0&0xff;
            ip->sub[1]=read1&0xff;
            ip->sub[2]=read2&0xff;
            ip->sub[3]=read3&0xff;
        }
        if(f_gets(temp_net,50,&fp))
        {
            root = cJSON_Parse((const char *)temp_net);
            if(root != NULL)
            {
                item = cJSON_GetObjectItem(root,"GateWay" );
                sscanf(item->valuestring, "%d.%d.%d.%d", &read0,&read1,&read2,&read3);
            }
            cJSON_Delete(root);

            ip->gw[0]=read0&0xff;
            ip->gw[1]=read1&0xff;
            ip->gw[2]=read2&0xff;
            ip->gw[3]=read3&0xff;
        }
        f_close(&fp);
    }
}



static void CanInfoInit(unsigned char *CanAddr)
{
    FIL fp;
    DIR dir;
    FRESULT res;
    cJSON *root,*item ;
    int addr;
    char temp_vol[30]= {0};
    char text1[]="{\"CanAddr\":\"4\"}\r\n";
    char text2[]="{\"˵�� \":\"CAN��ַ���õ�����ʾ���ڣ�����˫����ʾ���\"}\r\n";
    char folder_path[]="CanCfg";
    char file_path[]="CanAddr.txt";
    char can_config_path[30]= {0};

    root = cJSON_Parse((const char *)text1);
    if(root != NULL)
    {
        item = cJSON_GetObjectItem(root,"CanAddr" );
        sscanf(item->valuestring, "%d", &addr);
        *CanAddr = (unsigned char)addr;
    }
    cJSON_Delete(root);

    if(f_opendir(&dir,folder_path)!=FR_OK)  //�����ļ���
    {
        res=f_mkdir(folder_path);
        if(res != FR_OK)
        {
            return ;
        }
    }
    sprintf(can_config_path,"%s/%s",folder_path,file_path);
    if(f_open(&fp, can_config_path, FA_WRITE|FA_READ) != FR_OK)  //FA_OPEN_EXISTING
    {
        printf("\r\n������,�������ļ� %s\r\n",FILE_CAN_CFG);
        if( f_open(&fp, can_config_path, FA_CREATE_NEW|FA_WRITE|FA_READ)==FR_OK)
        {
            f_puts(text1,&fp);
            f_puts(text2,&fp);
            f_close(&fp);
        }
        else
        {
            printf("erorr \r\n");
            return ;
        }
    }
    if( f_open(&fp, can_config_path,FA_OPEN_EXISTING|FA_READ)==FR_OK)
    {
        f_gets(temp_vol,30,&fp);
        root = cJSON_Parse((const char *)temp_vol);
        if(root != NULL)
        {
            item = cJSON_GetObjectItem(root,"CanAddr" );
            sscanf(item->valuestring, "%d", &addr);
            *CanAddr = (unsigned char)addr;
        }
        // �ͷ��ڴ�ռ�
        cJSON_Delete(root);
        f_close(&fp);
    }
    else
    {
        printf("erorr \r\n");
        return ;
    }
}



static void DisplayInfoInit(void)
{
    FIL fp;
    DIR dir;
    FRESULT res;
    unsigned char i;

    const char text01[]="{\"STRING\":\"��ʱͣ���밴ťȡ�� \"}\r\n";
    const char text02[]="{\"STRING\":\"��ʱͣ���밴ťȡƱ \"}\r\n";
    const char text03[]="{\"STRING\":\"�ÿ��ѹ���Ч�������� \"}\r\n";
    const char text04[]="{\"STRING\":\"��ͨ�У�ף��һ·ƽ�� \"}\r\n";
    const char text05[]="{\"STRING\":\"��ͨ�� \"}\r\n";
    const char text06[]="{\"STRING\":\"ͣ��ʱ��: \"}\r\n";
    const char text07[]="{\"STRING\":\"�븶��: \"}\r\n";
    const char text08[]="{\"STRING\":\"��ӭ���� \"}\r\n";
    const char text09[]="{\"STRING\":\"�ÿ��޽������� \"}\r\n";
    const char text10[]="{\"STRING\":\"�ÿ��������ڳ��� \"}\r\n";
    const char text11[]="{\"STRING\":\"���������� \"}\r\n";
    const char text13[]="{\"STRING\":\"�ÿ���ͨ��Ȩ�� \"}\r\n";
    const char text14[]="{\"STRING\":\"ʣ������: \"}\r\n";
    const char text15[]="{\"STRING\":\"�ÿ����: \"}\r\n";
    const char text17[]="{\"STRING\":\"���Ʋ��� \"}\r\n";
    const char text22[]="{\"STRING\":\"��ˢ�� \"}\r\n";
    const char text24[]="{\"STRING\":\"�Բ��𣬳�λ���� \"}\r\n";
    const char text25[]="{\"STRING\":\"���⿨ \"}\r\n";
    const char text27[]="{\"STRING\":\"��ֵ�� \"}\r\n";
    const char text29[]="{\"STRING\":\"��ʱ�� \"}\r\n";
    const char text34[]="{\"STRING\":\"��ǰʣ�೵λ: \"}\r\n";
    const char text84[]="{\"STRING\":\"������� \"}\r\n";
    const char text85[]="{\"STRING\":\"�����弽ԥ���ɺ�����³������Ӷ���ʽ����¼���������ش�������ѧʹ�۰����� \"}\r\n";

    char str_path[23][19]= {FLIE_STR,FLIE_STR,FLIE_STR,FLIE_STR,FLIE_STR,FLIE_STR,FLIE_STR,
                            FLIE_STR,FLIE_STR,FLIE_STR,FLIE_STR,FLIE_STR,FLIE_STR,FLIE_STR,FLIE_STR,
                            FLIE_STR,FLIE_STR,FLIE_STR,FLIE_STR,FLIE_STR,FLIE_STR,FLIE_STR,FLIE_STR
                           };
    const char str_path01[23][12]= {"/STR_01.TXT","/STR_02.TXT","/STR_03.TXT","/STR_04.TXT","/STR_05.TXT","/STR_06.TXT",
                                    "/STR_07.TXT","/STR_08.TXT","/STR_09.TXT","/STR_10.TXT","/STR_11.TXT","/STR_13.TXT",
                                    "/STR_14.TXT","/STR_15.TXT","/STR_17.TXT","/STR_22.TXT","/STR_24.TXT","/STR_25.TXT",
                                    "/STR_27.TXT","/STR_29.TXT","/STR_34.TXT","/STR_84.TXT","/STR_85.TXT"
                                   };
    if(f_opendir(&dir,str_path[1])!=FR_OK)
    {
        res=f_mkdir(str_path[1]);
        if(res!=FR_OK)
        {
            return ;
        }
    }
    for(i=0; i<23; i++)
    {
        strcat(str_path[i],str_path01[i]);
        if(f_open(&fp, str_path[i], FA_WRITE|FA_READ) != FR_OK)
        {
            if( f_open(&fp, str_path[i], FA_CREATE_NEW|FA_WRITE|FA_READ)==FR_OK)
            {
                switch(i)
                {
                case 0 :
                    f_puts(text01,&fp);
                    break;
                case 1 :
                    f_puts(text02,&fp);
                    break;
                case 2 :
                    f_puts(text03,&fp);
                    break;
                case 3 :
                    f_puts(text04,&fp);
                    break;
                case 4 :
                    f_puts(text05,&fp);
                    break;
                case 5 :
                    f_puts(text06,&fp);
                    break;
                case 6 :
                    f_puts(text07,&fp);
                    break;
                case 7 :
                    f_puts(text08,&fp);
                    break;
                case 8 :
                    f_puts(text09,&fp);
                    break;
                case 9 :
                    f_puts(text10,&fp);
                    break;
                case 10 :
                    f_puts(text11,&fp);
                    break;
                case 11 :
                    f_puts(text13,&fp);
                    break;
                case 12 :
                    f_puts(text14,&fp);
                    break;
                case 13 :
                    f_puts(text15,&fp);
                    break;
                case 14 :
                    f_puts(text17,&fp);
                    break;
                case 15 :
                    f_puts(text22,&fp);
                    break;
                case 16 :
                    f_puts(text24,&fp);
                    break;

                case 17 :
                    f_puts(text25,&fp);
                    break;
                case 18 :
                    f_puts(text27,&fp);
                    break;
                case 19 :
                    f_puts(text29,&fp);
                    break;
                case 20 :
                    f_puts(text34,&fp);
                    break;
                case 21 :
                    f_puts(text84,&fp);
                    break;
                case 22 :
                    f_puts(text85,&fp);
                    break;
                default :
                    break;
                }
            }
            else
            {
                printf("erro \r\n");
                return ;
            }
            f_close(&fp);
        }
    }
}


static void DisplayFixedInfoInit(unsigned char *FixedInfo)
{
    FIL fp;
    DIR dir;
    FRESULT res;

    char text1[70]="{\"STRING\":\"��ӭ����!\"}\r\n";
    char text2[]="{\"˵��\":\"�̶���Ϣ���ܳ���20������\"}\r\n";

    char folder_path[]="FIXMSG";
    char file_path[]="DISPLAY.TXT";
    char FixedInfomation_path[30]= {0};
    char file_buffer[80]= {0};
    cJSON *root,*item;

    root = cJSON_Parse((const char *)text1);
    if(root != NULL)
    {
        item = cJSON_GetObjectItem(root,"STRING" );
        strcpy((char *)FixedInfo,item->valuestring);
    }
    cJSON_Delete(root);

    if(f_opendir(&dir,folder_path)!=FR_OK)
    {
        res=f_mkdir(folder_path);
        if(res!=FR_OK)
        {
            return ;
        }
    }
    sprintf(FixedInfomation_path,"%s/%s",folder_path,file_path);
    if(f_open(&fp,FixedInfomation_path, FA_WRITE|FA_READ) != FR_OK)
    {
        if( f_open(&fp,FixedInfomation_path, FA_CREATE_NEW|FA_WRITE|FA_READ)==FR_OK)
        {
            f_puts(text1,&fp);
            f_puts(text2,&fp);
            f_close(&fp);
        }
        else
        {
            printf("erorr \n");
            return;
        }
    }
    else
    {
        if(f_gets(file_buffer,70,&fp))
        {
            root = cJSON_Parse((const char *)file_buffer);
            if(root != NULL)
            {
                item = cJSON_GetObjectItem(root,"STRING" );
                strcpy((char *)FixedInfo,item->valuestring);
            }
            cJSON_Delete(root);
        }
        f_close(&fp);
    }
}



static void VoiceVolInfoInit(void)
{
    FIL fp;
    DIR dir;
    FRESULT res;
    const char text1[]="{\"����Сʱ\":\"08\"}\r\n";
    const char text2[]="{\"�������\":\"00\"}\r\n";
    const char text3[]="{\"��������\":\"07\"}\r\n";
    const char text4[]="{\"ҹ��Сʱ\":\"20\"}\r\n";
    const char text5[]="{\"ҹ������\":\"00\"}\r\n";
    const char text6[]="{\"ҹ������\":\"04\"}\r\n";
    const char text7[]="{\"˵��\":\"�����������Ϊ07\"}\r\n";

    char folder_path[]="SysCfg";
    char file_path[]="VolSet.txt";
    char vol_config_path[30]= {0};

    if(f_opendir(&dir,folder_path)!=FR_OK)
    {
        res=f_mkdir(folder_path);
        if(res!=FR_OK)
        {
            return ;
        }
    }
    sprintf(vol_config_path,"%s/%s",folder_path,file_path);

    if(f_open(&fp, vol_config_path, FA_WRITE|FA_READ) != FR_OK)
    {
        printf("\n������,�������ļ�\n");
        if( f_open(&fp, vol_config_path, FA_CREATE_NEW|FA_WRITE|FA_READ)==FR_OK)
        {
            f_puts(text1,&fp);
            f_puts(text2,&fp);
            f_puts(text3,&fp);
            f_puts(text4,&fp);
            f_puts(text5,&fp);
            f_puts(text6,&fp);
            f_puts(text7,&fp);
            f_close(&fp);
        }
        else
        {
            printf("error \n");
            return ;
        }
    }
}


static void ModelSettingInfoInit(void)
{
    FIL fp;
    DIR dir;
    FRESULT res;
    const char text1[]="{\"�Զ���բ����\":\"0\"}\r\n";
    const char text2[]="{\"ͨ���ѻ�����\":\"1\"}\r\n";
    const char text3[]="{\"�г�����\":\"0\"}\r\n";
    const char text4[]="{\"ʹ�ô�Ʊ��\":\"0\"}\r\n";
    const char text5[]="{\"ʹ�÷�����\":\"0\"}\r\n";
    const char text6[]="{\"ȡ����բ\":\"1\"}\r\n";
    const char text7[]="{\"��ӭ����\":\"1\"}\r\n";
    const char text8[]="{\"�ȱ����\":\"1\"}\r\n";
    const char text9[]="{\"˵��\":\"����Ϊ0�رգ�����Ϊ1����\"}\r\n";

    char folder_path[]="SysCfg";
    char file_path[]="ModSet.txt";
    char parameter_config_path[30]= {0};

    if(f_opendir(&dir,folder_path)!=FR_OK) //�������������ļ���
    {
        res=f_mkdir(folder_path);
        if(res!=FR_OK)
        {
            return ;
        }
    }
    sprintf(parameter_config_path,"%s/%s",folder_path,file_path);

    if(f_open(&fp,parameter_config_path, FA_WRITE|FA_READ) != FR_OK)  //FA_OPEN_EXISTING
    {
        printf("\n������,�������ļ�\n");
        if( f_open(&fp,parameter_config_path, FA_CREATE_NEW|FA_WRITE|FA_READ)==FR_OK)
        {
            f_puts(text1,&fp);
            f_puts(text2,&fp);
            f_puts(text3,&fp);
            f_puts(text4,&fp);
            f_puts(text5,&fp);
            f_puts(text6,&fp);
            f_puts(text7,&fp);
            f_puts(text8,&fp);
            f_puts(text9,&fp);
            f_close(&fp);
        }
        else
        {
            printf("error \n");
            return ;
        }
    }
}


void WriteNetConfig(NET_CONFIG *pNetConfig)
{
    FIL fp;
    FRESULT res;

    char text1[40]="{\"MAC\":\"000000000000\"}\r\n";
    char text2[40]="{\"IPv4\":\"192.168.1.204\"}\r\n";
    char text3[40]="{\"MASK\":\"255.255.255.0\"}\r\n";
    char text4[40]="{\"GateWay\":\"192.168.1.1\"}\r\n";
    char text5[20]="{\"CanAddr\":\"4\"}\r\n";
    char text6[]="{\"˵�� \":\"CAN��ַ���õ�����ʾ���ڣ�����˫����ʾ���\"}\r\n";
    char folder_path_net[]="NetCfg";
    char file_path_net[]="NetAddr.txt";
    char net_config_path[30]= {0};
    char folder_path_can[]="CanCfg";
    char file_path_can[]="CanAddr.txt";
    char can_config_path[30]= {0};

    sprintf(text1, "{\"MAC\":\"00CF%08x\"}\r\n",McuGetId());
    sprintf(text2, "{\"IPv4\":\"%d.%d.%d.%d\"}\r\n",pNetConfig->lip[0],pNetConfig->lip[1],pNetConfig->lip[2],pNetConfig->lip[3]);
    sprintf(text3, "{\"MASK\":\"%d.%d.%d.%d\"}\r\n",pNetConfig->sub[0],pNetConfig->sub[1],pNetConfig->sub[2],pNetConfig->sub[3]);
    sprintf(text4, "{\"GateWay\":\"%d.%d.%d.%d\"}\r\n",pNetConfig->gw[0],pNetConfig->gw[1],pNetConfig->gw[2],pNetConfig->gw[3]);
    sprintf(text5, "{\"CanAddr\":\"%d\"}\r\n",pNetConfig->canaddr);

    sprintf(net_config_path,"%s/%s",folder_path_net,file_path_net);
    res=f_unlink(net_config_path);  //���� д����������  ��Ϣ֮ǰ��ɾ����ǰ����Ϣ
    if(res!=FR_OK)
    {
        return ;
    }
    if(f_open(&fp,net_config_path, FA_WRITE|FA_READ) != FR_OK)
    {
        if( f_open(&fp,net_config_path, FA_CREATE_NEW|FA_WRITE|FA_READ)==FR_OK)
        {
            f_puts(text1,&fp);
            f_puts(text2,&fp);
            f_puts(text3,&fp);
            f_puts(text4,&fp);
            f_close(&fp);
        }
        else
        {
            return;
        }
    }

    sprintf(can_config_path,"%s/%s",folder_path_can,file_path_can);
    res=f_unlink(can_config_path);  //���� д��canͨ������  ��Ϣ֮ǰ��ɾ����ǰ����Ϣ
    if(res!=FR_OK)
    {
        return ;
    }
    if(f_open(&fp,can_config_path, FA_WRITE|FA_READ) != FR_OK)
    {
        if( f_open(&fp,can_config_path, FA_CREATE_NEW|FA_WRITE|FA_READ)==FR_OK)
        {
            f_puts(text5,&fp);
            f_puts(text6,&fp);
            f_close(&fp);
        }
        else
        {
            return;
        }
    }
}


void WriteFixedDisplayInfo(unsigned char *FixedInfo)
{
    FIL fp;
    FRESULT res;
    char display_lenth=0;
    char temp_buffer[50]= {0};

    char text1[70]= {0};
    char text2[]="{\"˵��\":\"�̶���Ϣ���ܳ���20������\"}\r\n";
    char folder_path[]="FIXMSG";
    char file_path[]="DISPLAY.TXT";
    char FixedInfomation_path[30]= {0};

    display_lenth=strlen((char *)FixedInfo);   //���ȼ��
    if(display_lenth>=40)                   //����24�������ַ���ֻȡ24��
    {
        memcpy(temp_buffer,FixedInfo,40);
        sprintf(text1, "{\"STRING\":\"%s \"}\r\n",temp_buffer);
    }
    else
    {
        sprintf(text1, "{\"STRING\":\"%s\"}\r\n",FixedInfo);
    }

    sprintf(FixedInfomation_path,"%s/%s",folder_path,file_path);
    res=f_unlink(FixedInfomation_path);  //����д����Ϣ֮ǰ��ɾ����ǰ����Ϣ
    if(res!=FR_OK)
    {
        return ;
    }
    if(f_open(&fp,FixedInfomation_path, FA_WRITE|FA_READ) != FR_OK)
    {
        if( f_open(&fp,FixedInfomation_path, FA_CREATE_NEW|FA_WRITE|FA_READ)==FR_OK)
        {
            f_puts(text1,&fp);
            f_puts(text2,&fp);
            f_close(&fp);
        }
        else
        {
            return;
        }
    }
}

static void ReadVoiceVolInfo(VOL_CONFIG *Vol)
{
    FIL fp;
    cJSON *root,*item ;
    char temp_vol[50]= {0};
    int read0=0;
    char folder_path[]="SysCfg";
    char file_path[]="VolSet.txt";
    char vol_config_path[30]= {0};

    Vol->CurrentDayVol.Hour =8;
    Vol->CurrentDayVol.Minute =0;
    Vol->CurrentDayVol.Value = 7;
    Vol->CurrentNightVol.Hour =20;
    Vol->CurrentNightVol.Minute =0;
    Vol->CurrentNightVol.Value = 4;

    sprintf(vol_config_path,"%s/%s",folder_path,file_path);

    if(f_open(&fp, vol_config_path, FA_WRITE|FA_READ) != FR_OK)  //FA_OPEN_EXISTING
    {
        printf("\n�������ļ�\n");
        return ;
    }

    if(f_gets(temp_vol,50,&fp))
    {
        root = cJSON_Parse((const char *)temp_vol);
        if(root != NULL)
        {
            item = cJSON_GetObjectItem(root,"����Сʱ" );
            sscanf(item->valuestring, "%x", &read0);
        }
        cJSON_Delete(root);

        Vol->CurrentDayVol.Hour = read0;
    }

    if(f_gets(temp_vol,50,&fp))
    {
        root = cJSON_Parse((const char *)temp_vol);
        if(root != NULL)
        {
            item = cJSON_GetObjectItem(root,"�������" );
            sscanf(item->valuestring, "%x", &read0);
        }
        cJSON_Delete(root);
        Vol->CurrentDayVol.Minute = read0;
    }

    if(f_gets(temp_vol,50,&fp))
    {
        root = cJSON_Parse((const char *)temp_vol);
        if(root != NULL)
        {
            item = cJSON_GetObjectItem(root,"��������" );
            sscanf(item->valuestring, "%x", &read0);
        }
        cJSON_Delete(root);
        Vol->CurrentDayVol.Value = read0;
    }

    if(f_gets(temp_vol,50,&fp))
    {
        root = cJSON_Parse((const char *)temp_vol);
        if(root != NULL)
        {
            item = cJSON_GetObjectItem(root,"ҹ��Сʱ" );
            sscanf(item->valuestring, "%x", &read0);
        }
        cJSON_Delete(root);
        Vol->CurrentNightVol.Hour = read0;
    }

    if(f_gets(temp_vol,50,&fp))
    {
        root = cJSON_Parse((const char *)temp_vol);
        if(root != NULL)
        {
            item = cJSON_GetObjectItem(root,"ҹ������" );
            sscanf(item->valuestring, "%x", &read0);
        }
        cJSON_Delete(root);
        Vol->CurrentNightVol.Minute = read0;
    }

    if(f_gets(temp_vol,50,&fp))
    {
        root = cJSON_Parse((const char *)temp_vol);
        if(root != NULL)
        {
            item = cJSON_GetObjectItem(root,"ҹ������" );
            sscanf(item->valuestring, "%x", &read0);
        }
        cJSON_Delete(root);
        Vol->CurrentNightVol.Value = read0;
    }
    f_close(&fp);
}


void WriteVoiceVolInfo(VOL_CONFIG *Vol)
{
    FIL fp;
    char text1[25]= {0};
    char text2[25]= {0};
    char text3[25]= {0};
    char text4[25]= {0};
    char text5[25]= {0};
    char text6[25]= {0};

    char net_path1[30]="SysCfg";
    char net_path2[]="/VolSet.txt";

    sprintf( text1,"%s%02x%s", "{\"����Сʱ\":\"",Vol->CurrentDayVol.Hour,"\"}\r\n");
    sprintf( text2,"%s%02x%s", "{\"�������\":\"",Vol->CurrentDayVol.Minute,"\"}\r\n");
    sprintf( text3,"%s%02x%s", "{\"��������\":\"",Vol->CurrentDayVol.Value,"\"}\r\n");
    sprintf( text4,"%s%02x%s", "{\"ҹ��Сʱ\":\"",Vol->CurrentNightVol.Hour,"\"}\r\n");
    sprintf( text5,"%s%02x%s", "{\"ҹ������\":\"",Vol->CurrentNightVol.Minute,"\"}\r\n");
    sprintf( text6,"%s%02x%s", "{\"ҹ������\":\"",Vol->CurrentNightVol.Value,"\"}\r\n");

    strcat(net_path1,net_path2);
    if(f_open(&fp, net_path1, FA_WRITE|FA_READ) == FR_OK)
    {
        f_puts(text1,&fp);
        f_puts(text2,&fp);
        f_puts(text3,&fp);
        f_puts(text4,&fp);
        f_puts(text5,&fp);
        f_puts(text6,&fp);
        f_close(&fp);
    }
    else
    {
        printf("error \n");
    }
}



//��ʾ������ַ� ����
unsigned short ReadDisplayInfo(unsigned char code,unsigned char *dat)
{
    const char text1[]="��ʱͣ���밴ťȡ�� ";
    const char text2[]="��ʱͣ���밴ťȡƱ ";
    const char text3[]="�ÿ��ѹ���Ч�������� ";
    const char text4[]="��ͨ�У�ף��һ·ƽ�� ";
    const char text5[]="��ͨ�� ";
    const char text6[]="ͣ��ʱ��: ";
    const char text7[]="�븶��: ";
    const char text8[]="��ӭ���� ";
    const char text9[]="�ÿ��޽������� ";
    const char text10[]="�ÿ��������ڳ��� ";
    const char text11[]="���������� ";
    const char text13[]="�ÿ���ͨ��Ȩ�� ";
    const char text14[]="ʣ������: ";
    const char text15[]="�ÿ����: ";
    const char text17[]="���Ʋ��� ";
    const char text22[]="��ˢ�� ";
    const char text24[]="�Բ��𣬳�λ���� ";
    const char text25[]="���⿨ ";
    const char text27[]="��ֵ�� ";
    const char text29[]="��ʱ�� ";
    const char text34[]="��ǰʣ�೵λ: ";
    const char text84[]="������� ";
    const char text85[]="�����弽ԥ���ɺ�����³������Ӷ���ʽ����¼���������ش�������ѧʹ�۰����� ";

    switch(code)
    {
    case 1:
        strcpy(dat,text1);
        break;
    case 2:
        strcpy(dat,text2);
        break;
    case 3:
        strcpy(dat,text3);
        break;
    case 4:
        strcpy(dat,text4);
        break;
    case 5:
        strcpy(dat,text5);
        break;
    case 6:
        strcpy(dat,text6);
        break;
    case 7:
        strcpy(dat,text7);
        break;
    case 8:
        strcpy(dat,text8);
        break;
    case 9:
        strcpy(dat,text9);
        break;
    case 10:
        strcpy(dat,text10);
        break;
    case 11:
        strcpy(dat,text11);
        break;
    case 13:
        strcpy(dat,text13);
        break;
    case 14:
        strcpy(dat,text14);
        break;
    case 15:
        strcpy(dat,text15);
        break;
    case 17:
        strcpy(dat,text17);
        break;
    case 22:
        strcpy(dat,text22);
        break;
    case 24:
        strcpy(dat,text24);
        break;
    case 25:
        strcpy(dat,text25);
        break;
    case 27:
        strcpy(dat,text27);
        break;
    case 29:
        strcpy(dat,text29);
        break;
    case 34:
        strcpy(dat,text34);
        break;
    case 84:
        strcpy(dat,text84);
        break;
    case 85:
        strcpy(dat,text85);
        break;
    }
    return strlen((char *)dat)-1;    //ȥ�����һ���ո�
}

#if 0
//��ʾ������ַ� ����
unsigned short ReadDisplayInfo(unsigned char code,unsigned char *dat)
{
    FIL fp;
    FRESULT res;
    char file_buffer[100]= {0};
    DIR mydir;
    char data_buf[100] = {0} ;
    char folder_path[]="STRCFG";
    char file_path[]="STR_01.TXT";
    char str_config_path[20]= {0};
    cJSON *root,*item ;

    sprintf(file_path,"STR_%02d.TXT",code);	         //�ϳ��ļ���
    sprintf(str_config_path,"%s/%s",folder_path,file_path);  //�ϳ��ļ�������·��

    res=f_opendir(&mydir,folder_path);
    if(res!=FR_OK)
    {
        return  0;
    }
    res=f_open(&fp, str_config_path,FA_READ);
    if(res!=FR_OK)
    {
        return  0;
    }
    if(f_gets(file_buffer,100,&fp))
    {
        strcpy((char *)data_buf,file_buffer);
        root = cJSON_Parse((const char *)data_buf);
        if(root != NULL)
        {
            item = cJSON_GetObjectItem(root,"STRING" );
            strcpy((char *)dat,item->valuestring);
        }
        cJSON_Delete(root);
    }
    f_close(&fp);

    return strlen((char *)dat)-1;    //ȥ�����һ���ո�
}
#endif

