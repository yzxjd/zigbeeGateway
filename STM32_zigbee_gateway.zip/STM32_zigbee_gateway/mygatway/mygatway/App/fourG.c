#include "stdio.h"
#include "string.h"
#include "stm32f10x_api.h"
#include "feeprom.h"
#include "feepromApp.h"
#include "fourG.h"
#include "TCP232.h"
#include "cmsis_os.h"
#include "usrApp.h"
#include "cyclebuffer.h"
#include <stdlib.h>
#define TIMEOUTD  500

unsigned char DmaTxBuffer[1024];
extern unsigned char serverIp[];
extern unsigned short serverPort;
extern unsigned int myID;
unsigned char GSM_ReplyFlag = 0,_tcpStatus = 0, _tcpStatusPrev = 0, tcpATerrorcount = 0;
unsigned char GSM_Response = 0;

void FourGSendBytes(unsigned char *dat,unsigned short len);
void FourGSendByte(unsigned char dat);

long ATFunc_Net(int argc,char **argv)
{
    char buf[50];

    if(!strcmp(argv[0],"AT"))
    {
        if(NetMode == 0x01)
        {
            sprintf(buf,"123456#AT+%s\r\n",argv[1]);
            FourGSendBytes((unsigned char *)buf,strlen(buf));
        }
        else
        {
            sprintf(buf,"AT+%s\r\n",argv[1]);
            TCP232SendBytes((unsigned char *)buf,strlen(buf));
        }

    }
    else if(!strcmp(argv[0],"OPEN"))
    {
        FourGSocketOpen();
    }
    else if(!strcmp(argv[0],"CLOSE"))
    {
        FourGSocketClose();
    }
    else if(!strcmp(argv[0],"STATUS"))
    {
        sprintf(buf,"123456#AT+SOCKALK\r\n");
        FourGSendBytes((unsigned char *)buf,strlen(buf));
    }
//	else if(!strcmp(argv[0],"CONNECT"))
//	{
//		FourGSocketConnect("123",3,20);
//	}
    else
    {
        FourGSendBytes((unsigned char *)argv[0],strlen(argv[0]));
    }

    return 0;
}

/*
 LINK����״ָ̬ʾ��D3
*/
void MQTTLed(unsigned char status)
{
    if(!status)
    {
        GPIO_ResetBits(GPIOE,GPIO_Pin_4);  //����
    }
    else
    {
        GPIO_SetBits(GPIOE,GPIO_Pin_4);    //�Ͽ�
    }
}

void InNetLed(unsigned char status)   //�ڲ�����������״ָ̬ʾ��
{
    if(!status)
    {
        GPIO_ResetBits(GPIOE,GPIO_Pin_2);  //����
    }
    else
    {
        GPIO_SetBits(GPIOE,GPIO_Pin_2);    //�Ͽ�
    }
}

/*
 RECEIVE����״ָ̬ʾ��D4
*/
void MQTTSocketLed(unsigned char status)
{
    if(!status)
    {
        GPIO_ResetBits(GPIOE,GPIO_Pin_3);  //����
    }
    else
    {
        GPIO_SetBits(GPIOE,GPIO_Pin_3);    //�Ͽ�
    }
}

/*
 ����1����   ������SIM800ͨ�ŵĴ���
*/
void Uart1Config(unsigned int eBandRate,unsigned char eDataBit,unsigned char eParity,unsigned char eStopBit)
{
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    USART_ClockInitTypeDef  USART_ClockInitStructure;
    unsigned short DataBit;
    unsigned short Parity;
    unsigned short StopBit;

    /////////////////////////////////////////////////////////////////////
    DMA_InitTypeDef   DMA_InitStructure;									//uart1��tx   DMA1_Channel4
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
    DMA_DeInit(DMA1_Channel4);
    DMA_InitStructure.DMA_PeripheralBaseAddr = (unsigned int)(&(USART1->DR));
    DMA_InitStructure.DMA_MemoryBaseAddr = (unsigned int)DmaTxBuffer;
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
    DMA_InitStructure.DMA_BufferSize = 0;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
    DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;

    DMA_Init(DMA1_Channel4, &DMA_InitStructure);
    DMA_ITConfig(DMA1_Channel4, DMA_IT_TC | DMA_IT_TE, ENABLE);
    DMA_Cmd(DMA1_Channel4, DISABLE);

    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQChannel;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    if(eDataBit==9)	 DataBit =  USART_WordLength_9b;
    else DataBit = USART_WordLength_8b;

    if(eParity=='e') Parity = USART_Parity_Even;
    else if(eParity=='o') Parity = USART_Parity_Odd;
    else Parity =  USART_Parity_No;

    if(eStopBit==2) StopBit = USART_StopBits_2;
    else StopBit =  USART_StopBits_1;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);

    USART_DeInit(USART1);

    USART_ClockInitStructure.USART_Clock = USART_Clock_Disable;
    USART_ClockInitStructure.USART_CPOL = USART_CPOL_Low;
    USART_ClockInitStructure.USART_CPHA = USART_CPHA_2Edge;
    USART_ClockInitStructure.USART_LastBit = USART_LastBit_Disable;
    // Configure the USART synchronous paramters ����ͬ������
    USART_ClockInit(USART1, &USART_ClockInitStructure);

    USART_InitStructure.USART_BaudRate = eBandRate;
    USART_InitStructure.USART_WordLength = DataBit;
    USART_InitStructure.USART_StopBits = StopBit;
    USART_InitStructure.USART_Parity = Parity;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx |USART_Mode_Tx;
    // Configure USART basic and asynchronous paramters �����첽����
    USART_Init(USART1, &USART_InitStructure);

    USART_ITConfig(USART1,USART_IT_RXNE, ENABLE);
    USART_DMACmd(USART1,USART_DMAReq_Tx,ENABLE);

    USART_Cmd(USART1, ENABLE);
    USART_ClearFlag(USART1, USART_FLAG_TC);

}

/*
	����SIM800ģ��
*/
void ActivateGSM(void)
{
    GpioConfig(GPIOD,GPIO_Pin_7,GPIO_Mode_Out_PP,GPIO_Speed_10MHz);

    GPIO_SetBits(GPIOD,GPIO_Pin_7);    //sim800����
    delay_n100ms(10);  //�������

    GPIO_ResetBits(GPIOD,GPIO_Pin_7);
}

/*
 4gģ��ͨ���������ó�ʼ��PC10��PC11
*/
void SIM800UartInit(void)
{
    GpioConfig(GPIOA,GPIO_Pin_9,GPIO_Mode_AF_PP,GPIO_Speed_50MHz);
    GpioConfig(GPIOA,GPIO_Pin_10,GPIO_Mode_IN_FLOATING,GPIO_Speed_50MHz);
    Uart1Config(115200,8,0,1);
    CycleBufferInit(0);	//ѭ����������ʼ��

    GpioConfig(GPIOB,GPIO_Pin_3,GPIO_Mode_Out_PP,GPIO_Speed_10MHz);   //GSM_ON
    GPIO_ResetBits(GPIOB,GPIO_Pin_3);
    delay_n100ms(10);

    GPIO_SetBits(GPIOB,GPIO_Pin_3);

    ActivateGSM();
}

unsigned short FourGAtStringTimeOut(unsigned char *str,unsigned short TimeOut)
{
    unsigned short cnt=0;
    unsigned char flag=0,temp,strbuf[96];
    char *ptr=NULL;

    memset(strbuf,0,sizeof(strbuf));

    while((TimeOut!=0))
    {
        while(CycleBufferPop(0,&temp)==0)
        {
            TimeOut = 10;
            strbuf[cnt++]=temp;
            ptr=strstr((char *)strbuf,(char *)str);
            if(ptr)
            {
                flag = 1;
                continue ;
            }
        }
        TimeOut--;
        osDelay(10);
    }

    if(flag)
    {
        printf("�ҵ���%s\r\n",str);
        return cnt;
    }
    //printf("û�ҵ�%s\r\n",str);
    return 0;
}


unsigned short sendATreply(unsigned char *replyStr,unsigned short TimeOut)
{
    unsigned short cnt=0,cnt1=0;
    unsigned char flag=0,temp,strbuf[128];
    unsigned char statusStr[24]= {0};
    char *ptr=NULL;
//	char *statusPtr = NULL;

    memset(strbuf,0,sizeof(strbuf));

    while((TimeOut!=0))
    {
        while(CycleBufferPop(0,&temp)==0)
        {
            TimeOut = 10;
            strbuf[cnt++]=temp;
            if(flag == 1)
            {
                statusStr[cnt1++] = temp;
            }

            ptr=strstr((char *)strbuf,(char *)replyStr);
            if(ptr)
            {
                flag = 1;
                continue ;
            }

        }
        TimeOut--;
        osDelay(10);
    }

    if(strstr((char *)statusStr," INITIAL") != NULL)
    {
        GSM_ReplyFlag = 2;
    }
    else if(NULL != strstr((char *)statusStr, " START"))
    {
        GSM_ReplyFlag = 3;
    }
    else if(NULL != strstr((char *)statusStr, "IP CONFIG"))
    {
        GSM_ReplyFlag = 4;
    }
    else if(NULL != strstr((char *)statusStr, " GPRSACT"))
    {
        GSM_ReplyFlag = 4;
    }
    else if(NULL != strstr((char *)statusStr, " STATUS"))
    {
        GSM_ReplyFlag = 5;
    }
    else if(NULL != strstr((char *)statusStr, " TCP CONNECTING"))
    {
        GSM_ReplyFlag = 6;
    }
    else if(NULL != strstr((char *)statusStr, " CONNECT OK"))
    {
        GSM_ReplyFlag = 7;
    }

    if(NULL != strstr((char *)strbuf, "OK"))
    {
        GSM_Response = 1;
    }
    else if(NULL != strstr((char *)strbuf, "ERROR"))
    {
        GSM_Response = 2;
    }
    else if(NULL != strstr((char *)strbuf, "CONNECT FAIL"))
    {
        GSM_Response = 5;
    }
    else if(NULL != strstr((char *)strbuf, "CONNECT"))
    {
        GSM_Response = 4;
    }
    else if(NULL != strstr((char *)strbuf, "CLOSED"))
    {
        GSM_Response = 4;
    }

    return GSM_ReplyFlag;
}


/*
 4GӦ�ó����ʼ����������GSMģʽ������ģʽ
*/
//#define delayTimeforME 10
//unsigned char  FourGAppInit(void)
//{
//	char buf[50];
//
//	sprintf(buf,"AT+CPIN?\r\n");					//���SIM��״̬
//	FourGSendBytes((unsigned char*)buf,strlen(buf));
//	if(0 == FourGAtStringTimeOut((unsigned char*)"READY",TIMEOUTD))//300
//	{
////		Reboot();
//	}
//
//	sprintf(buf,"AT+CREG?\r\n");					//GSMע��״̬
//	FourGSendBytes((unsigned char*)buf,strlen(buf));
//	if(0 == FourGAtStringTimeOut((unsigned char*)"0,1",TIMEOUTD))//300
//	{
//		delay_n100ms(5);
//		return (0); //ע��ʧ�ܺ���������
//	}
//
//	sprintf(buf,"AT+CGREG?\r\n");					//GPRSע��״̬
//	FourGSendBytes((unsigned char*)buf,strlen(buf));
//	if(0 == FourGAtStringTimeOut((unsigned char*)"0,1",TIMEOUTD))//300
//	{
//		delay_n100ms(5);
//		return (0); //ע��ʧ�ܺ���������
//	}
//	delay_n100ms(delayTimeforME);
//
//	sprintf(buf,"AT+CGATT=1\r\n");					//ʹģ�鸽��GPRS��
//	FourGSendBytes((unsigned char*)buf,strlen(buf));
//	FourGAtStringTimeOut((unsigned char*)"OK",TIMEOUTD);//300
//	delay_n100ms(delayTimeforME);
//
//	sprintf(buf,"AT+CIPMODE=1\r\n");					//����GPRSģ���TCP/IP͸��ģʽ
//	FourGSendBytes((unsigned char*)buf,strlen(buf));
//	if(0 == FourGAtStringTimeOut((unsigned char*)"OK",TIMEOUTD))//300
//	{
//		delay_n100ms(5);
//		return (0); //ע��ʧ�ܺ���������
//	}
//	delay_n100ms(delayTimeforME);
//
//	for(int i=0;i<10;i++)
//	{
//		printf("������������:");
//		sprintf(buf,"AT+CIPSTART=\"TCP\",\"%d.%d.%d.%d\",%d\r\n",
//									serverIp[0],serverIp[1],serverIp[2],serverIp[3],serverPort);					//
//		FourGSendBytes((unsigned char*)buf,strlen(buf));
//		if(0 != FourGAtStringTimeOut((unsigned char*)"CONNECT",1500))
//		{
//				printf("�Ѿ�����TCP\n");
//				return (1);
//		}
//		delay_n100ms(10);
//	}
//
//	return (1);
//}

char _sendAT(char * command,unsigned int waitms)
{
    unsigned short cnt=0,cnt1=0;
    unsigned char flag=0,temp,strbuf[128];
    unsigned char statusStr[24]= {0};
    char *ptr=NULL;
//	char *statusPtr = NULL;
    FourGSendBytes((unsigned char*)command,strlen(command));
    memset(strbuf,0,sizeof(strbuf));

    while((waitms!=0))
    {
        while(CycleBufferPop(0,&temp)==0)
        {
            strbuf[cnt++]=temp;
            if(flag == 1)
            {
                strbuf[cnt1++] = temp;
            }

            ptr=strstr((char *)strbuf,(char *)command);
            if(ptr)
            {
                flag = 1;
                continue ;
            }
            waitms = 20;
        }
        waitms--;
        osDelay(10);
    }

    if(strstr((char *)statusStr," INITIAL") != NULL)
    {
        GSM_ReplyFlag = 2;
    }
    else if(NULL != strstr((char *)statusStr, " START"))
    {
        GSM_ReplyFlag = 3;
    }
    else if(NULL != strstr((char *)statusStr, "IP CONFIG"))
    {
        GSM_ReplyFlag = 4;
    }
    else if(NULL != strstr((char *)statusStr, " GPRSACT"))
    {
        GSM_ReplyFlag = 4;
    }
    else if(NULL != strstr((char *)statusStr, " STATUS"))
    {
        GSM_ReplyFlag = 5;
    }
    else if(NULL != strstr((char *)statusStr, " TCP CONNECTING"))
    {
        GSM_ReplyFlag = 6;
    }
    else if(NULL != strstr((char *)statusStr, " CONNECT OK"))
    {
        GSM_ReplyFlag = 7;
    }

    if(NULL != strstr((char *)strbuf, "OK"))
    {
        GSM_Response = 1;
    }
    else if(NULL != strstr((char *)strbuf, "ERROR"))
    {
        GSM_Response = 2;
    }
    else if(NULL != strstr((char *)strbuf, "CONNECT FAIL"))
    {
        GSM_Response = 5;
    }
    else if(NULL != strstr((char *)strbuf, "CONNECT"))
    {
        GSM_Response = 4;
    }
    else if(NULL != strstr((char *)strbuf, "CLOSED"))
    {
        GSM_Response = 4;
    }

    return GSM_Response;
//	printf("û�ҵ�%s\r\n",str);
}

/*************************************************
  Function:    TCP_IP_init����
  Description: SIM800����tcp/ip����
*************************************************/
int _SIM800ConnectTcpInit(void)
{
    static unsigned char modeStatus = 0;//, wrongTimes = 0;
    char buf[50];
    switch(modeStatus)
    {
    case 0:
        sprintf(buf,"AT+CPIN?\r\n");					//���SIM��״̬
        FourGSendBytes((unsigned char*)buf,strlen(buf));
        if(0 != FourGAtStringTimeOut((unsigned char*)"READY",1000))
        {
            modeStatus = 1;
//				wrongTimes = 0;
        }
        else if(0 != FourGAtStringTimeOut((unsigned char*)"ERROR",1000))
        {
            printf("û��SIM��\r\n");
//				wrongTimes++;
            modeStatus = 0;
            break;
        }

    case 1:
        sprintf(buf,"AT+CREG?\r\n");					//GSMע��״̬
        FourGSendBytes((unsigned char*)buf,strlen(buf));
        if(0 != FourGAtStringTimeOut((unsigned char*)"0,1",2000))
        {
            sprintf(buf,"AT+CGREG?\r\n");					//GPRSע��״̬
            FourGSendBytes((unsigned char*)buf,strlen(buf));
            if(0 == FourGAtStringTimeOut((unsigned char*)"0,1",TIMEOUTD))//300
                break;

            FourGSocketSignalStrength(300);

            sprintf(buf,"AT+CIPMUX=0\r\n");
            FourGSendBytes((unsigned char*)buf,strlen(buf));
            FourGAtStringTimeOut((unsigned char*)"OK",1000);

            sprintf(buf,"AT+CIPMODE=1\r\n");					//����GPRSģ���TCP/IP͸��ģʽ
            FourGSendBytes((unsigned char*)buf,strlen(buf));
            if(0 != FourGAtStringTimeOut((unsigned char*)"OK",TIMEOUTD))//300
            {
                sprintf(buf,"AT+CGATT?\r\n");					//ʹģ�鸽��GPRS��
                FourGSendBytes((unsigned char*)buf,strlen(buf));
                if(0 != FourGAtStringTimeOut((unsigned char*)": 1",4000))
                {
                    sprintf(buf,"AT+CGATT=1\r\n");					//ʹģ�鸽��GPRS��
                    FourGSendBytes((unsigned char*)buf,strlen(buf));
                }
            }
            modeStatus = 2;
        }
        else
        {
            modeStatus = 1;
            break;
        }

    case 2:
        if(GSM_ReplyFlag != 7)
        {
            _tcpStatus = _tcpStatusJudge();
            if ( _tcpStatusPrev == _tcpStatus )
            {
                tcpATerrorcount++;
                if (tcpATerrorcount >= 10)
                {
                    tcpATerrorcount = 0;
                    _tcpStatus = 7;
                }
            }
            else
            {
                _tcpStatusPrev = _tcpStatus;
                tcpATerrorcount = 0;
            }
        }
        _tcpStatusPrev = _tcpStatus;

        switch(_tcpStatus)
        {
        case 2:
        {
            _sendAT("AT+CSTT=\"AIRTELGPRS.COM\"\r\n", 1000);
            break;
        }
        case 3:
        {
            _sendAT("AT+CIICR\r\n", 1000)  ;
            break;
        }
        case 4:
        {
            sprintf(buf,"AT+CIFSR\r\n");					//ʹģ�鸽��GPRS��
            FourGSendBytes((unsigned char*)buf,strlen(buf));
            break;
        }
        case 5:
        {
            printf("������������:");
            sprintf(buf,"AT+CIPSTART=\"TCP\",\"%d.%d.%d.%d\",%d\r\n",
                    serverIp[0],serverIp[1],serverIp[2],serverIp[3],serverPort);					//
            FourGSendBytes((unsigned char*)buf,strlen(buf));
            if(0 != sendATreply((unsigned char*)"CONNECT",2000))
            {
                printf("�Ѿ�����TCP\n");
                modeStatus = 3;
                _tcpStatus = 8;
            }
            break;
        }

        case 6:
        {
            sendATreply((unsigned char*)"CONNECT",2000);
            break;
        }
        case 7:
        {
            sprintf(buf,"AT+CIPSHUT\r\n");					//GPRSע��״̬
            FourGSendBytes((unsigned char*)buf,strlen(buf));
            sendATreply((unsigned char *)"OK", 4000) ;
            modeStatus = 0;
            _tcpStatus = 2;

            break;
        }
        }
    }

//	if(wrongTimes > 10) return 1; //����10Sû���յ�READY���쳣�˳�SIM800����tcp���ӣ���ֹ����һֱ�����⡣

    if(modeStatus == 3 && _tcpStatus == 8)
        return 0xff;
    else
        return 0;
}

unsigned char _tcpStatusJudge(void)
{
    char buf[50]= {0};
    int res=0;
    sprintf(buf,"AT+CIPSTATUS\r\n");					//ʹģ�鸽��GPRS��
    FourGSendBytes((unsigned char*)buf,strlen(buf));
    res = sendATreply((unsigned char*)"STATE",4000);
    return res;
}

int toConnectTCP_IP(void)
{
    char buf[64]= {0};
//	if(0 != FourGAtStringTimeOut((unsigned char*)"CLOSED",5000))
//	{
    sprintf(buf,"AT+CIPSTART=\"TCP\",\"%d.%d.%d.%d\",%d\r\n",
            serverIp[0],serverIp[1],serverIp[2],serverIp[3],serverPort);					//
    FourGSendBytes((unsigned char*)buf,strlen(buf));
    if(0 != FourGAtStringTimeOut((unsigned char*)"CONNECT",2000))
    {
        printf("�Ѿ�����TCP\n");
        return (1);
    }
//		else
//		{
//			Reboot();
//		}
//	}
    return 0;
}

void shutGSM(void)
{
    char buf[64]= {0};
    sprintf(buf,"AT+CIPSHUT\r\n");
    FourGSendBytes((unsigned char*)buf,strlen(buf));
    if(0 != FourGAtStringTimeOut((unsigned char*)"SHUT OK",2000))
    {
        printf("shut GPRS OK\n");
    }
}

void FourGSocketOpen(void)
{
    if(NetMode == 0x01)
    {
        char buf[50];
        sprintf(buf,"123456#AT+SOCKAEN=\"on\"\r");
        FourGSendBytes((unsigned char *)buf,strlen(buf));
        FourGAtStringTimeOut((unsigned char *)"OK",200);
    }
}

void FourGSocketClose(void)
{
    if(NetMode == 0x01)
    {
        char buf[50];
        sprintf(buf,"AT+CIPCLOSE=?\r");
        FourGSendBytes((unsigned char *)buf,strlen(buf));
        if(0 != FourGAtStringTimeOut((unsigned char *)"OK",200))
            printf("ȷ��TCP���ӹر�\n");
        else
        {
            sprintf(buf,"AT+CIPCLOSE\r");
            FourGSendBytes((unsigned char *)buf,strlen(buf));
            FourGAtStringTimeOut((unsigned char *)"OK",200);
        }
    }
}

//unsigned char FourGSocketConnect(unsigned char *ip,unsigned short port,unsigned char cnt)
//{
//	printf("4G SocketA connect...\r\n");
//	#ifdef WUXIAN
//	unsigned char strbuf[100];
//	FourGSocketOpen();
//
//	while(1)
//	{
//		sprintf(strbuf,"123456#AT+SOCKALK\r\n");
//		FourGSocketSend(strbuf,strlen(strbuf));
//		if(FourGAtStringTimeOut("SOCKALK:connected",100))      //�ҵ��˶Ͽ���
//		{
//			printf("4G SocketA Connect OK\r\n");
//			break;
//		}
//		else if((cnt--) == 0)
//		{
//			return 0xff;
//		}
//		else
//			osDelay(1000);
//	}
//	#endif
//	return 0;
//}

/*************************************************
  Function:   4gģ���ָ��ģʽ
  Description:
*************************************************/
void FourGATmodeOpen(void)
{
    unsigned char buf[10]= {0};
    delay_n100ms(10);
    sprintf((char *)buf,"+");					//����������+���˳�͸��ģʽ����ATģʽ
    FourGSendBytes(buf,strlen((char *)buf));

    sprintf((char *)buf,"+");
    FourGSendBytes(buf,strlen((char *)buf));

    sprintf((char *)buf,"+");
    FourGSendBytes(buf,strlen((char *)buf));

    if(0 != FourGAtStringTimeOut((unsigned char*)"OK",1500))
    {
        printf("����AT����ģʽ\n");
    }
}

/*************************************************
  Function:    4gģ��ر�ָ��ģʽ������͸��ģʽ
  Description:
*************************************************/
int FourGATmodeClose(void)
{
    int myret=0;
    unsigned char buf[30]= {0};
    sprintf((char *)buf,"ATO\n");					//����ģ���˳�����ģʽ
    FourGSendBytes(buf,strlen((char *)buf));
    myret = FourGAtStringTimeOut((unsigned char *)"CONNECT",200);
    if (myret == 0)		//GM3ģ�鷵������ģʽ�쳣
        return 1;
    printf("�ָ�͸��ģʽ\n");
    return 0;
}

/*************************************************
  Function:   ��ȡ4gģ���ź�ǿ��
  Description:
*************************************************/
uint8_t SignalStrength=0;
void FourGSocketSignalStrength(unsigned short TimeOut)
{
    unsigned short cnt=0;
    uint8_t i = 15;
    char strbuf[50],buf[4]= {0};
    unsigned char temp;
    sprintf(strbuf,"AT+CSQ\r\n");
    FourGSendBytes((unsigned char*)strbuf,strlen(strbuf));
    while((TimeOut!=0))
    {
        while(CycleBufferPop(0,&temp)==0)
        {
            TimeOut = 10;
            strbuf[cnt++]=temp;
        }
        TimeOut--;
        osDelay(10);
    }
//	printf("%s",strbuf);

    for(i = 15; ((i<17) && (strbuf[i]!=',')); i++ )
    {
        buf[i-15] = strbuf[i];
    }
//	printf("SignalStrength buf=%s\n",buf);
    SignalStrength = 114-(2*atoi(buf));  //SIM800�ź�ǿ�������-52dbm��Ӧ�����ֵ��31

    printf("SignalStrength:-%d dbm\n",SignalStrength);

}


void FourGSocketSend(unsigned char *dat,unsigned short len)
{
    FourGSendBytes(dat,len);
}

/*
 4g����ӿڽ��գ����ؽ����ֽ���
*/
//unsigned short FourGSocketRev(unsigned char *dat,unsigned short TimeOut)
//{
//	unsigned short cnt=0;
//	unsigned char temp;
//
//	while((TimeOut!=0))
//	{
//		while(CycleBufferPop(0,&temp)==0)
//		{
//			TimeOut = 5;
//			dat[cnt++]=temp;
//		}
//		TimeOut--;
//		osDelay(10);
//	}
//
//	return cnt;
//
//}

//unsigned short FourGSocketRevCnt(unsigned char *dat,unsigned short len,unsigned short TimeOut)
//{
//	unsigned short cnt=0;
//	unsigned char temp;
////	unsigned char buf[10];
//
//	while((TimeOut!=0))
//	{
//		while(CycleBufferPop(0,&temp)==0)
//		{
//			TimeOut = 5;
//			dat[cnt++]=temp;
//			//sprintf(buf,"%x[%c] ",temp,temp);
//			//printf(buf);
//			if(cnt>=len)
//			{
//				return len;
//			}
//		}
//		TimeOut--;
//		osDelay(10);
//	}
//
//	return cnt;
//}


/*************************************************
  Function:    ��4gģ�鷢���ֽڴ�����
  Description:
*************************************************/
void FourGSendBytes(unsigned char *dat,unsigned short len)
{
    unsigned int cnt=3;

    if(len==0)   return ;
    while(DMA_GetFlagStatus(DMA1_FLAG_TC4) == RESET)
    {
        if(cnt--<=1)
        {
            if(DMA_GetFlagStatus(DMA1_FLAG_TE4) == SET)     // DMA ���ͳ���
            {
                printf("[ERROR]DMA FourG send error!\r\n");
                break;
            }
            else
            {
                printf("[ERROR]DMA FourG outtime!\r\n");
                break;
            }
        }
        osDelay(10);
    }
    DMA_Cmd(DMA1_Channel4,DISABLE);//����1�����ڻ�4Gģ��ͨ�ŵķ����ŵ�(uart1��Tx)
    DMA_ClearFlag(DMA1_FLAG_TC4);
    DMA_ClearFlag(DMA1_FLAG_TE4);
    if(len>=sizeof(DmaTxBuffer))
        return ;
    DMA1_Channel4->CNDTR = len;
    memcpy(DmaTxBuffer,dat,len);
    DMA_Cmd(DMA1_Channel4,ENABLE);
}


void FourGSendByte(unsigned char dat)
{
    FourGSendBytes(&dat,1);
}


void USART1_IRQHandler(void)
{
    unsigned char cByte;

    if (USART_GetFlagStatus(USART1, USART_FLAG_ORE) != RESET)
    {
        USART_ReceiveData(USART1);
    }
    else if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
    {
        USART_ClearFlag(USART1,USART_IT_RXNE);
        cByte=USART_ReceiveData(USART1);

        CycleBufferPush(0,cByte);
    }
}

