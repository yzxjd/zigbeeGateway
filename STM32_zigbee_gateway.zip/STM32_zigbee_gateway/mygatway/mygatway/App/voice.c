#include "voice.h"
#include "kt603.h"
#include "cmsis_os.h"
#include "stdlib.h"
#include "stdio.h"
#include "string.h"
#include "displayApp.h"
#include "voiceApp.h"

static osMessageQId Msgsobj;
extern volatile unsigned char VoiceEndFlag;


void VoiceInit(void)
{
    Kt603Init();
}


/*
vol: [0-10]
*/
void VoiceVolSet(unsigned char vol)
{
    SetKt603Vol(vol*3);
}


void VoicePlay(unsigned char cmd,PLAY *pPlayQueue)
{
    VoiceSend(cmd,pPlayQueue);
}


void VoiceContinue(void)
{
    Kt603ContinuePlay();
}


void VoicePause(void)
{
    Kt603PausePlay();
}


void voiceTask(void const * argument)
{
    unsigned int i=0,len,timeout=0;
    VOICE_MSG VoiceMsg;
    unsigned char codes[VOICE_BUFF_MAX];

    VoiceCreateQueue();

    while(1)
    {
        if(VoicePendQueue(&VoiceMsg))
        {
            if(VoiceMsg.cmd!=0xff)  //��ʼ����
            {
                DisplayVoiceSends(&VoiceMsg);
                len = VoiceMsgConvertPlays(&VoiceMsg,codes);
                for(i=0; i<len; i++)
                {
                    timeout =1000;
                    osDelay(20);
                    VoiceEndFlag=0;
                    //printf("codes[%d]=%d\r\n",i,codes[i]);
                    Kt603StartPlay(codes[i]);
                    while(VoiceEndFlag==0)
                    {
                        if(timeout--)
                            osDelay(10);
                        else
                            break;
                    }
                }
            }
            else   //ֹͣ
            {
                VoiceFlushQueue();    //�������
                Kt603StopPlay();
            }
        }
    }
}


static void VoiceSend(unsigned char cmd,PLAY *pPlay)
{
    VOICE_MSG VoiceMsg;

    VoiceMsg.cmd = cmd;
    memcpy(&VoiceMsg.play,pPlay,sizeof(PLAY));
    VoicePostQueue(&VoiceMsg);
}



int VoiceCreateQueue(void)
{
    int ret;

    osMessageQDef(VOICE,10,VOICE_MSG);
    Msgsobj = osMessageCreate(osMessageQ(VOICE),0);
    ret = (Msgsobj != NULL);
    if(Msgsobj==NULL)
    {
        printf("create voice queue fail!\r\n");
    }
    return ret;
}


void VoiceFlushQueue(void)
{
    xQueueReset(Msgsobj);
}


int VoicePendQueue (VOICE_MSG *pVoiceMsg)
{
    int ret = 0;

    if (xQueueReceive(Msgsobj,pVoiceMsg, osWaitForever) == pdTRUE)
    {
        ret = 1;
    }

    return ret;
}



void VoicePostQueue(VOICE_MSG *pVoiceMsg)
{
    if(Msgsobj==NULL)  return ;
    if(xQueueSend(Msgsobj,pVoiceMsg,10)==errQUEUE_FULL)
    {
        printf("QUEUE_FULL!\r\n");
    }
}



long volFunc_Voice(int argc,char **argv)
{
    if(argc ==1)
        VoiceVolSet(atoi(argv[0]));

    return 0;
}


