#include "stm32f10x_lib.h"
#include "net.h"
#include "httpUtil.h"
#include "tcp_app.h"
#include "circleBuffer.h"
#include "cmsis_os.h"
#include "wizchip_conf.h"
#include "webpge.h"
#include "feepromApp.h"
#include "stdio.h"
#include "string.h"
#include "socket.h"
#include "tftp.h"
#include "updata.h"
#include "feeprom.h"

static NetProCallBack pNetProCb;
static NET_CONFIG NetConfig;
static CircleBuffer *pCircleBuf1;
static osMutexId Semsobj;
static unsigned char buf[2048];
static unsigned char buf1[2048];
unsigned char ip[4]= {192,168,1,200};

long downFunc_Net(int argc,char **argv)
{
    HEAD head;
    char flag;

    if(!strcmp(argv[0],"HEAD"))
    {
        if(!strcmp(argv[1],"A"))
        {
            flag ='A';
            EE_WriteData(EE_KEY_UPDATA,(unsigned char*)&flag,1);
        }
        else if(!strcmp(argv[1],"B"))
        {
            flag ='B';
            EE_WriteData(EE_KEY_UPDATA,(unsigned char*)&flag,1);
        }

        memset(&head,0,sizeof(head));
        head.CompanyName[0]='L';
        head.CompanyName[1]='B';
        memcpy(head.ProductType,"ZJKZQ",sizeof(head.ProductType));
        memcpy(head.HardwareVer,"3.0",sizeof(head.HardwareVer));
        head.FunctionFlag='A';
        memcpy(head.FirmwareVer,"3.0",sizeof(head.FirmwareVer));
        EE_WriteData(EE_KEY_HEAD,(unsigned char *)&head,sizeof(HEAD));

    }
    else if(!strcmp(argv[0],"A"))
    {
        DoAppA();
    }
    else if(!strcmp(argv[0],"B"))
    {
        DoAppB();
    }
    return 0;
}
#if 0
const char peer0_0[] = { /* Packet 109 */
    0x50, 0x4f, 0x53, 0x54, 0x20, 0x2f, 0x61, 0x70,
    0x69, 0x2f, 0x76, 0x61, 0x63, 0x63, 0x65, 0x73,
    0x73, 0x65, 0x73, 0x2f, 0x20, 0x48, 0x54, 0x54,
    0x50, 0x2f, 0x31, 0x2e, 0x31, 0x0d, 0x0a, 0x48,
    0x6f, 0x73, 0x74, 0x3a, 0x20, 0x31, 0x31, 0x32,
    0x2e, 0x37, 0x34, 0x2e, 0x31, 0x33, 0x32, 0x2e,
    0x31, 0x3a, 0x33, 0x30, 0x30, 0x30, 0x0d, 0x0a,
    0x55, 0x73, 0x65, 0x72, 0x2d, 0x41, 0x67, 0x65,
    0x6e, 0x74, 0x3a, 0x20, 0x4d, 0x6f, 0x7a, 0x69,
    0x6c, 0x6c, 0x61, 0x2f, 0x35, 0x2e, 0x30, 0x20,
    0x28, 0x57, 0x69, 0x6e, 0x64, 0x6f, 0x77, 0x73,
    0x20, 0x4e, 0x54, 0x20, 0x36, 0x2e, 0x31, 0x3b,
    0x20, 0x57, 0x4f, 0x57, 0x36, 0x34, 0x3b, 0x20,
    0x72, 0x76, 0x3a, 0x34, 0x36, 0x2e, 0x30, 0x29,
    0x20, 0x47, 0x65, 0x63, 0x6b, 0x6f, 0x2f, 0x32,
    0x30, 0x31, 0x30, 0x30, 0x31, 0x30, 0x31, 0x20,
    0x46, 0x69, 0x72, 0x65, 0x66, 0x6f, 0x78, 0x2f,
    0x34, 0x36, 0x2e, 0x30, 0x0d, 0x0a, 0x41, 0x63,
    0x63, 0x65, 0x70, 0x74, 0x3a, 0x20, 0x74, 0x65,
    0x78, 0x74, 0x2f, 0x68, 0x74, 0x6d, 0x6c, 0x2c,
    0x61, 0x70, 0x70, 0x6c, 0x69, 0x63, 0x61, 0x74,
    0x69, 0x6f, 0x6e, 0x2f, 0x78, 0x68, 0x74, 0x6d,
    0x6c, 0x2b, 0x78, 0x6d, 0x6c, 0x2c, 0x61, 0x70,
    0x70, 0x6c, 0x69, 0x63, 0x61, 0x74, 0x69, 0x6f,
    0x6e, 0x2f, 0x78, 0x6d, 0x6c, 0x3b, 0x71, 0x3d,
    0x30, 0x2e, 0x39, 0x2c, 0x2a, 0x2f, 0x2a, 0x3b,
    0x71, 0x3d, 0x30, 0x2e, 0x38, 0x0d, 0x0a, 0x41,
    0x63, 0x63, 0x65, 0x70, 0x74, 0x2d, 0x4c, 0x61,
    0x6e, 0x67, 0x75, 0x61, 0x67, 0x65, 0x3a, 0x20,
    0x7a, 0x68, 0x2d, 0x43, 0x4e, 0x2c, 0x7a, 0x68,
    0x3b, 0x71, 0x3d, 0x30, 0x2e, 0x38, 0x2c, 0x65,
    0x6e, 0x2d, 0x55, 0x53, 0x3b, 0x71, 0x3d, 0x30,
    0x2e, 0x35, 0x2c, 0x65, 0x6e, 0x3b, 0x71, 0x3d,
    0x30, 0x2e, 0x33, 0x0d, 0x0a, 0x41, 0x63, 0x63,
    0x65, 0x70, 0x74, 0x2d, 0x45, 0x6e, 0x63, 0x6f,
    0x64, 0x69, 0x6e, 0x67, 0x3a, 0x20, 0x67, 0x7a,
    0x69, 0x70, 0x2c, 0x20, 0x64, 0x65, 0x66, 0x6c,
    0x61, 0x74, 0x65, 0x0d, 0x0a, 0x43, 0x6f, 0x6e,
    0x74, 0x65, 0x6e, 0x74, 0x2d, 0x54, 0x79, 0x70,
    0x65, 0x3a, 0x20, 0x61, 0x70, 0x70, 0x6c, 0x69,
    0x63, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x2f, 0x6a,
    0x73, 0x6f, 0x6e, 0x0d, 0x0a, 0x43, 0x6f, 0x6e,
    0x74, 0x65, 0x6e, 0x74, 0x2d, 0x4c, 0x65, 0x6e,
    0x67, 0x74, 0x68, 0x3a, 0x20, 0x32, 0x32, 0x38,
    0x0d, 0x0a, 0x43, 0x6f, 0x6e, 0x6e, 0x65, 0x63,
    0x74, 0x69, 0x6f, 0x6e, 0x3a, 0x20, 0x6b, 0x65,
    0x65, 0x70, 0x2d, 0x61, 0x6c, 0x69, 0x76, 0x65,
    0x0d, 0x0a, 0x0d, 0x0a, 0x7b, 0x0a, 0x20, 0x20,
    0x22, 0x76, 0x6e, 0x6f, 0x22, 0x3a, 0x20, 0x22,
    0xe6, 0xb9, 0x98, 0x41, 0x31, 0x31, 0x56, 0x32,
    0x30, 0x22, 0x2c, 0x0a, 0x20, 0x20, 0x22, 0x70,
    0x6e, 0x61, 0x6d, 0x65, 0x22, 0x3a, 0x20, 0x22,
    0xe9, 0x95, 0xbf, 0xe6, 0xb2, 0x99, 0xe5, 0xbc,
    0x80, 0xe7, 0xa6, 0x8f, 0xe4, 0xb8, 0x87, 0xe8,
    0xbe, 0xbe, 0xe5, 0xb9, 0xbf, 0xe5, 0x9c, 0xba,
    0xe5, 0x9c, 0xb0, 0xe4, 0xb8, 0x8b, 0xe5, 0x81,
    0x9c, 0xe8, 0xbd, 0xa6, 0xe5, 0x9c, 0xba, 0x22,
    0x2c, 0x0a, 0x20, 0x20, 0x22, 0x70, 0x69, 0x64,
    0x22, 0x3a, 0x22, 0x35, 0x36, 0x30, 0x38, 0x64,
    0x64, 0x35, 0x32, 0x32, 0x64, 0x62, 0x66, 0x37,
    0x35, 0x32, 0x63, 0x33, 0x37, 0x63, 0x63, 0x62,
    0x32, 0x30, 0x61, 0x22, 0x2c, 0x0a, 0x20, 0x20,
    0x22, 0x65, 0x6e, 0x74, 0x65, 0x72, 0x74, 0x69,
    0x6d, 0x65, 0x22, 0x3a, 0x20, 0x22, 0x32, 0x30,
    0x31, 0x36, 0x2d, 0x30, 0x35, 0x2d, 0x32, 0x34,
    0x20, 0x31, 0x36, 0x3a, 0x33, 0x34, 0x3a, 0x31,
    0x32, 0x22, 0x2c, 0x0a, 0x20, 0x20, 0x22, 0x65,
    0x6e, 0x74, 0x72, 0x22, 0x3a, 0x20, 0x22, 0xe5,
    0x8c, 0x97, 0xe9, 0x97, 0xa8, 0x22, 0x2c, 0x0a,
    0x20, 0x20, 0x22, 0x65, 0x78, 0x69, 0x74, 0x74,
    0x69, 0x6d, 0x65, 0x22, 0x3a, 0x20, 0x22, 0x31,
    0x39, 0x30, 0x30, 0x2d, 0x30, 0x31, 0x2d, 0x30,
    0x31, 0x22, 0x2c, 0x0a, 0x20, 0x20, 0x22, 0x63,
    0x61, 0x72, 0x64, 0x74, 0x79, 0x70, 0x65, 0x22,
    0x3a, 0x20, 0x22, 0xe8, 0xae, 0xa1, 0xe6, 0x97,
    0xb6, 0xe5, 0x8d, 0xa1, 0x22, 0x0a, 0x7d, 0x0a
};


uint32_t loopback_tcpc(uint8_t sn, uint8_t* buf,uint8_t* destip, uint16_t destport)
{
    uint32_t size,ret; // return value for SOCK_ERRORs
    uint16_t any_port = 	50000;

    // Socket Status Transitions
    // Check the W5500 Socket n status register (Sn_SR, The 'Sn_SR' controlled by Sn_CR command or Packet send/recv status)
    switch(getSn_SR(sn))
    {
    case SOCK_ESTABLISHED :
        if(getSn_IR(sn) & Sn_IR_CON)	// Socket n interrupt register mask; TCP CON interrupt = connection with peer is successful
        {
            printf("%d:Connected to - %d.%d.%d.%d : %d\r\n",sn, destip[0], destip[1], destip[2], destip[3], destport);
            setSn_IR(sn, Sn_IR_CON);  // this interrupt should be write the bit cleared to '1'
        }
        ret = send(sn, (unsigned char *)peer0_0, sizeof(peer0_0)); // Data send process (User's buffer -> Destination through H/W Tx socket buffer)
        //printf("[send data]\r\n%s\r\n[end]",peer0_0);
        if(ret < 0) // Send Error occurred (sent data length < 0)
        {
            close(sn); // socket close
            return ret;
        }
        tim_cnts=0;
        TIM_Cmd(TIM3, ENABLE);
        while(1)
        {
            if((size = getSn_RX_RSR(sn)) > 0) // Sn_RX_RSR: Socket n Received Size Register, Receiving data length
            {
                TIM_Cmd(TIM3, DISABLE);
                if(size > 2048) size = 2048; // DATA_BUF_SIZE means user defined buffer size (array)
                ret = recv(sn, buf, size); // Data Receive process (H/W Rx socket buffer -> User's buffer)
                printf("\r\n[rev data]\r\n%s\r\n[end]\r\n[time]:%dms\r\n",buf,tim_cnts);
                if(ret <= 0) return ret; // If the received data length <= 0, receive failed and process end
                break;
            }
        }
        break;

    case SOCK_CLOSE_WAIT :
        if((ret=disconnect(sn)) != SOCK_OK) return ret;
        printf("%d:Socket Closed\r\n", sn);
        break;

    case SOCK_INIT :
        printf("%d:Try to connect to the %d.%d.%d.%d : %d\r\n", sn, destip[0], destip[1], destip[2], destip[3], destport);
        if( (ret = connect(sn, destip, destport)) != SOCK_OK) return ret;	//	Try to TCP connect to the TCP server (destination)
        break;

    case SOCK_CLOSED:
        close(sn);
        if((ret=socket(sn, Sn_MR_TCP, any_port++, 0x00)) != sn) return ret; // TCP socket open with 'any_port' port number
        break;
    default:
        break;
    }
    return 1;
}


void Test4G(void)
{
    unsigned char ip[4]= {112,74,132,1};
    memset(buf1,0,2048);

    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQChannel;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    // 1ms��ʱ
    TIM_DeInit(TIM3); //��ʼ��TIM2Ϊȱʡֵ
    TIM_TimeBaseInitStruct.TIM_Period = (10 - 1); //����ARR�Զ����ؼĴ���
    TIM_TimeBaseInitStruct.TIM_Prescaler = (72000 - 1); //����PSCʱ��Ԥ��Ƶ
    TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1; //����ʱ��ָ�ֵ
    TIM_TimeBaseInitStruct.TIM_CounterMode = 0x0000; //���ü��������ϼ���
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseInitStruct); //��ʼ��
    TIM_ClearFlag(TIM3, TIM_FLAG_Update); //�������жϱ�־
    TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE); //���ж����

    loopback_tcpc(5,buf1,ip,3000);
}

void TIM3_IRQHandler(void)
{
    TIM_ClearFlag(TIM3, TIM_FLAG_Update); //�������жϱ�־
    tim_cnts++;
}

#endif

void NetInit(void)
{
    wiz_NetInfo NetInfo;
    wiz_NetTimeout NetTimeout;
    unsigned char KeepTime=2;
    unsigned char bufsize[16] = {2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2};
    unsigned char httpsocklist[1]= {SOCK_HTTPS};


    wizchip_bspinit();

    ctlwizchip(CW_INIT_WIZCHIP,bufsize);
    memcpy(NetInfo.mac,NetConfig.mac,sizeof(NetInfo.mac));
    memcpy(NetInfo.ip,NetConfig.lip,sizeof(NetInfo.ip));
    memcpy(NetInfo.sn,NetConfig.sub,sizeof(NetInfo.sn));
    memcpy(NetInfo.gw,NetConfig.gw,sizeof(NetInfo.gw));
    memcpy(NetInfo.dns,NetConfig.gw,sizeof(NetInfo.gw));
    NetInfo.dhcp = NETINFO_STATIC;
    ctlnetwork(CN_SET_NETINFO,(wiz_NetInfo*)&NetInfo);
    NetTimeout.retry_cnt = 9;
    NetTimeout.time_100us = 2000;     // 200ms
    ctlnetwork(CN_SET_TIMEOUT,(wiz_NetTimeout*)&NetTimeout);
    setSn_KPALVTR(SOCK_TCPC1,KeepTime);
    HttpSetCallBack(HttpCgiCallBack);
    httpServer_init(buf,buf1,1,httpsocklist);
    reg_httpServer_webContent((unsigned char*)"index.html",(unsigned char*)INDEX_HTML);

    TFTP_init(SOCK_TFTPC,buf1);

    pCircleBuf1=CircleBufferCreate(2048);
    TcpsSetCallBack(TcpsCallBack);
    NetCreateMutex();

    NetLedInit();
    NetAddrLedSet(NetConfig.lip[3]%100);
}


NET_CONFIG *GetNetConfigAddr(void)
{
    return &NetConfig;
}

unsigned char *GetCanAddr(void)
{
    return &NetConfig.canaddr;
}

void NetSetProcessCb(NetProCallBack pNetProcb)
{
    pNetProCb = pNetProcb;
}

void NetStatusCheck(void)
{
    unsigned char flag=0;
    static unsigned char flagbak=0xff;

    flag=getPHYCFGR()&0x01;
    if(flag^flagbak)
    {
        flagbak = flag;
        if(!flag)
        {
            close(SOCK_TCPC1);
            printf("�������������ѶϿ�\r\n");
        }
    }
}

void NetScan(void)
{
    TFTP_run();
    httpServer_run(0);
    do_mqtt_client(SOCK_TCPC1,ip,61613);
    NetStatusCheck();
}


void net1ProcessTask(void const * argument)
{
    unsigned char dat;
    unsigned short cnt=0;
    char *ptr=0;
    unsigned int len;
    unsigned char netbuf[128];

    while(1)
    {
        if(CircleBufferRead(pCircleBuf1,&dat,1,&len)!=0)  //�ʼ��REV\r\n
        {
            netbuf[cnt++]=dat;
            if(cnt>=sizeof(netbuf))      //ͻȻ��һ���ܴ����Ч���ݰ����������Ϊ��Ч����
            {
                memset(netbuf,0,sizeof(netbuf));
                cnt =0;
                osDelay(10);
                continue;
            }
            ptr=strstr((char *)netbuf,"REV\r\n");
            if(ptr)     //�ҵ���֡ͷ
            {
                vPortEnterCritical();
                //SocketFlag=1;
                vPortExitCritical();
                cnt=0;
                memset(netbuf,0,sizeof(netbuf));
                while(1)   //ȡ��֡���� 12 ���ֽ�
                {
                    if(CircleBufferRead(pCircleBuf1,&dat,1,&len)!=0)
                    {
                        netbuf[cnt++]=dat;
                        ptr=strstr((char *)netbuf,"REV\r\n");
                        if(ptr)     //�������ҵ����  :  REV\r\n12REV\r\n
                        {
                            cnt=0;
                            memset(netbuf,0,sizeof(netbuf));
                            continue ;
                        }
                        if(cnt>=12)    //��Ч����
                        {
                            NetPendMutex();
                            //(*pNetProCb)(netbuf);
                            NetPostMutex();
                            break;   //������ɣ��˳�
                        }
                    }
                    else
                        break;  //��ʱ�˳�,������Ч
                }
                cnt =0;
                memset(netbuf,0,sizeof(netbuf));     //���ݴ�����ɻ���Ч���������������
            }
            ptr=strstr((char *)netbuf,"SED\r\n");
            if(ptr)
            {
                vPortEnterCritical();
                //SocketFlag=0;
                vPortExitCritical();
                cnt =0;
                memset(netbuf,0,sizeof(netbuf));
            }
        }
        else      //����100msû���յ���Ч���������������
        {
            memset(netbuf,0,sizeof(netbuf));
            cnt =0;
        }
    }
}


void HttpCgiCallBack(unsigned char para)
{
    NET_CONFIG *pNetConfig = GetNetConfigAddr();

    if(para==1)
    {
        WriteNetConfig(pNetConfig);
    }
    else if(para==2)
    {
        FeepromAppReset();
    }
}


static int TcpsCallBack(unsigned char s,unsigned char *buf,unsigned short len)
{
    if(s==SOCK_TCPC1)
    {
        CircleBufferWrite(pCircleBuf1,buf,len);
    }

    return 0;
}



int NetCreateMutex(void)
{
    int ret;

    osMutexDef(NET_M);
    Semsobj = osMutexCreate(osMutex(NET_M));
    ret = (Semsobj != NULL);

    return ret;
}


int NetPendMutex (void)
{
    int ret = 0;

    if(osMutexWait(Semsobj, osWaitForever) == osOK)
    {
        ret = 1;
    }

    return ret;
}


void NetPostMutex(void)
{
    if(Semsobj!=NULL)
        osMutexRelease(Semsobj);
}


long netFunc_Net(int argc,char **argv)
{
    if(!strcmp(argv[0],"config"))
    {
        printf("mac:%02x%02x%02x%02x%02x%02x\r\n",NetConfig.mac[0],NetConfig.mac[1],NetConfig.mac[2],NetConfig.mac[3],NetConfig.mac[4],NetConfig.mac[5]);
        printf("ip:%d.%d.%d.%d\r\n",NetConfig.lip[0],NetConfig.lip[1],NetConfig.lip[2],NetConfig.lip[3]);
        printf("sub:%d.%d.%d.%d\r\n",NetConfig.sub[0],NetConfig.sub[1],NetConfig.sub[2],NetConfig.sub[3]);
        printf("gw:%d.%d.%d.%d\r\n",NetConfig.gw[0],NetConfig.gw[1],NetConfig.gw[2],NetConfig.gw[3]);
        printf("port:%d\r\n",NetConfig.lport);
    }
    else if(!strcmp(argv[0],"4g"))
    {
        //Test4G();
    }
    return 0;
}



////////////////////////////////////////////////////////////////////////////////////

#define NET_ADRSS_SET32(a)   {if(a){GPIO_ResetBits(ADDR32PORT,ADDR32PIN);}  else {GPIO_SetBits(ADDR32PORT,ADDR32PIN);}}
#define NET_ADRSS_SET16(a)   {if(a){GPIO_ResetBits(ADDR16PORT,ADDR16PIN);}  else {GPIO_SetBits(ADDR16PORT,ADDR16PIN);}}
#define NET_ADRSS_SET8(a)   {if(a){GPIO_ResetBits(ADDR8PORT,ADDR8PIN);}  else {GPIO_SetBits(ADDR8PORT,ADDR8PIN);}}
#define NET_ADRSS_SET4(a)   {if(a){GPIO_ResetBits(ADDR4PORT,ADDR4PIN);}  else {GPIO_SetBits(ADDR4PORT,ADDR4PIN);}}
#define NET_ADRSS_SET2(a)   {if(a){GPIO_ResetBits(ADDR2PORT,ADDR2PIN);}  else {GPIO_SetBits(ADDR2PORT,ADDR2PIN);}}
#define NET_ADRSS_SET1(a)   {if(a){GPIO_ResetBits(ADDR1PORT,ADDR1PIN);}  else {GPIO_SetBits(ADDR1PORT,ADDR1PIN);}}

void NetLedInit(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    /*����IP��ַ������*/
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Pin = ADDR32PIN;
    GPIO_Init(ADDR32PORT, &GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin = ADDR16PIN;
    GPIO_Init(ADDR16PORT, &GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin = ADDR8PIN;
    GPIO_Init(ADDR8PORT, &GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin = ADDR4PIN;
    GPIO_Init(ADDR4PORT, &GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin = ADDR2PIN;
    GPIO_Init(ADDR2PORT, &GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin = ADDR1PIN;
    GPIO_Init(ADDR1PORT, &GPIO_InitStructure);
    /*������������״̬������*/
    GPIO_InitStructure.GPIO_Pin = NETLEDPIN;
    GPIO_Init(NETLEDPORT, &GPIO_InitStructure);
}


void NetStatusLed(unsigned char status)
{
    static unsigned char bak=0xff;

    if(status>0)  status=1;

    if(bak^status)
    {
        bak = status;
        if(!status)
        {
            GPIO_ResetBits(NETLEDPORT,NETLEDPIN);  //�ѻ�
        }
        else
        {
            GPIO_SetBits(NETLEDPORT,NETLEDPIN);    //����
        }
    }
}

void NetAddrLedSet(unsigned char IpEnd)
{
    unsigned char number;

    number=(IpEnd>>0)&0x01;
    NET_ADRSS_SET1(number);
    number=(IpEnd>>1)&0x01;
    NET_ADRSS_SET2(number);
    number=(IpEnd>>2)&0x01;
    NET_ADRSS_SET4(number);
    number=(IpEnd>>3)&0x01;
    NET_ADRSS_SET8(number);
    number=(IpEnd>>4)&0x01;
    NET_ADRSS_SET16(number);
    number=(IpEnd>>5)&0x01;
    NET_ADRSS_SET32(number);
}


