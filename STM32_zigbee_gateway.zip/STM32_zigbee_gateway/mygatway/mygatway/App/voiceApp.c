#include "usrApp.h"
#include "voice.h"
#include "rtc.h"
#include "voiceApp.h"
#include "math.h"
#include "string.h"
#include "stdio.h"
#include "stdlib.h"
#include "cmsis_os.h"
#include "kt603.h"

static VOICE Voice;

long playFunc_Voice(int argc,char **argv)
{
    unsigned char cmd;
    PLAY PlayQueue;

    cmd=atoi(argv[0]);

    if(cmd==0)
    {
        Kt603StartPlay(atoi(argv[1]));
    }
    if(cmd==4)
    {
        Voice.pStopInfo->CarNumber[0] = 119;
        strcpy((char *)&Voice.pStopInfo->CarNumber[1],"AF3W93 ");
        Voice.pStopInfo->RemanDays =atoi(argv[1]);

        memcpy(&PlayQueue.StopInfo,Voice.pStopInfo,sizeof(PlayQueue.StopInfo));
        VoicePlay(CMD_VOICE_CARNUMBER,&PlayQueue);
        VoicePlay(CMD_VOICE_REMAINDAY,&PlayQueue);
    }
    else if(cmd==5)
    {
        Voice.pStopInfo->Balance = atoi(argv[1]);
        memcpy(&PlayQueue.StopInfo,Voice.pStopInfo,sizeof(PlayQueue.StopInfo));
        VoicePlay(CMD_VOICE_BALANCE,&PlayQueue);
    }
    else if(cmd==6)
    {
        Voice.pStopInfo->CarNumber[0] = 119;
        strcpy((char *)&Voice.pStopInfo->CarNumber[1],"AF3W93 ");
        Voice.pStopInfo->StopTime.Days = 10;
        Voice.pStopInfo->StopTime.Hour = 20;
        Voice.pStopInfo->StopTime.Min = 30;
        Voice.pStopInfo->Fee = 30;
        memcpy(&PlayQueue.StopInfo,Voice.pStopInfo,sizeof(PlayQueue.StopInfo));
        VoicePlay(CMD_VOICE_TIME_FEE,&PlayQueue);
    }

    return 0;
}


//�ڹ涨ʱ����������������
static void VoiceVolCheck(VOL_CONFIG *pVolConfig)
{
    TIME CurrentTime;
    unsigned short DayTime,NightTime,TempTime;
    unsigned char UpFlag=0;
    static unsigned char UpFlagBak=0;

    DayTime = pVolConfig->CurrentDayVol.Hour;
    DayTime = DayTime<<8;
    DayTime+=pVolConfig->CurrentDayVol.Minute;
    printf("DAY TIME:%04x VOL:%d\r\n",DayTime,pVolConfig->CurrentDayVol.Value);

    NightTime = pVolConfig->CurrentNightVol.Hour;
    NightTime = NightTime<<8;
    NightTime+=pVolConfig->CurrentNightVol.Minute;
    printf("NIGHT TIME:%04x VOL:%d\r\n",NightTime,pVolConfig->CurrentNightVol.Value);

    RtcReadTime(&CurrentTime);
    printf("TIME:%02x-%02x-%02x %02x:%02x:%02x\r\n",CurrentTime.Year,CurrentTime.Month,CurrentTime.Day,CurrentTime.Hour,CurrentTime.Minute,CurrentTime.Second);
    TempTime = CurrentTime.Hour <<8;
    TempTime+=CurrentTime.Minute;

    if((TempTime>=DayTime)&&(TempTime<=NightTime))
        UpFlag=1;
    else
        UpFlag=2;
    if(UpFlagBak^UpFlag)
    {
        UpFlagBak = UpFlag;
        if(UpFlag==1)
        {
            printf("DAY VALUE:%d\r\n",pVolConfig->CurrentDayVol.Value);
            VoiceVolSet(pVolConfig->CurrentDayVol.Value);
            osDelay(50);
        }
        else if(UpFlag==2)
        {
            printf("NIGHT VALUE:%d\r\n",pVolConfig->CurrentNightVol.Value);
            VoiceVolSet(pVolConfig->CurrentNightVol.Value);
            osDelay(50);
        }
    }
}


static unsigned char VoicePlayConvertCarNumber(unsigned char *car,unsigned char *codes)
{
    unsigned char i=0,conut;

    for(conut = 0; conut < 8; conut++)
    {
        if(car[conut] == ' ')  break;
        if((conut == 7) && (car[ 0 ] >= 110 && car[ 0 ] <= 147))  break;
        if((car[conut] >= 110) && (car[conut] <= 147))    //��������,�Ƕ�Ӧ��Ƶ����
        {
            codes[i++]=car[conut];
        }
        if((car[conut] >= 'A' )&& (car[conut] <= 'Z'))
        {
            codes[i++]=(car[conut] - 'A') + VOICE_A;
        }
        else if((car[conut] >= '0') && (car[conut] <= '9'))
        {
            codes[i++]=(car[conut] - '0') + VOICE_0;
        }
        //printf("%c ",car[conut]);
    }

    return i;
}


//ʱ������ת���ɿɲ��ŵ���Ƶ��
static unsigned char VoicePlayTimeConv(STOP_TIME *pStopTime,unsigned char *codes)
{
    unsigned char count=0,len=0;
    char buf[20];
    unsigned char *ptr=codes;
    unsigned int value,temp;
    unsigned int bak,valuebak;

    temp = pStopTime->Days;
    if(temp!=0)
    {
        sprintf(buf,"%d",temp);
        len = strlen(buf);
        for(count=len; count>0; count--)
        {
            temp=temp%(int)pow(10,count);
            value= temp/(int)pow(10,count-1);
            if((count==1)&&(value==0))       //��Ϊ0����ֻ���죬����0
            {
                *codes++ =VOICE_DAY;
                continue;
            }
            else if((count>1)&&(value==0))  //�����ǰΪ0�����ж���һ���Ƿ�Ϊ0
            {
                bak=temp%(int)pow(10,count-1);
                valuebak= bak/(int)pow(10,count-2);
                if(valuebak!=0)  //�����һ����Ϊ0����ֻ��0
                {
                    *codes++ = value+VOICE_0;
                }
                continue;
            }
            else  //��Ϊ0�Ķ�Ҫ��
            {
                *codes++ = value+VOICE_0;
                if(count==3) *codes++ =VOICE_BAI;
                if(count==2) *codes++ =VOICE_SHI;
                if(count==1) *codes++ =VOICE_DAY;
            }
        }
    }

    temp = pStopTime->Hour;
    if(temp!=0)
    {
        sprintf(buf,"%d",temp);
        len = strlen(buf);
        for(count=len; count>0; count--)
        {
            temp=temp%(int)pow(10,count);
            value= temp/(int)pow(10,count-1);
            if((count==1)&&(value==0))       //СʱΪ0����ֻ��Сʱ������0
            {
                *codes++ =VOICE_HOUR;
                continue;
            }
            else if((count>1)&&(value==0))  //�����ǰΪ0�����ж���һ���Ƿ�Ϊ0
            {
                bak=temp%(int)pow(10,count-1);
                valuebak= bak/(int)pow(10,count-2);
                if(valuebak!=0)  //�����һ����Ϊ0����ֻ��0
                {
                    *codes++ = value+VOICE_0;
                }
                continue;
            }
            else  //��Ϊ0�Ķ�Ҫ��
            {
                *codes++ = value+VOICE_0;
                if(count==2) *codes++ =VOICE_SHI;
                if(count==1) *codes++ =VOICE_HOUR;
            }
        }
    }
    temp = pStopTime->Min;
    if(temp!=0)
    {
        sprintf(buf,"%d",temp);
        len = strlen(buf);
        for(count=len; count>0; count--)
        {
            temp=temp%(int)pow(10,count);
            value= temp/(int)pow(10,count-1);
            if((count==1)&&(value==0))       //����Ϊ0����ֻ�����ӣ�����0
            {
                *codes++ =VOICE_MINUTE;
                continue;
            }
            else if((count>1)&&(value==0))  //�����ǰΪ0�����ж���һ���Ƿ�Ϊ0
            {
                bak=temp%(int)pow(10,count-1);
                valuebak= bak/(int)pow(10,count-2);
                if(valuebak!=0)  //�����һ����Ϊ0����ֻ��0
                {
                    *codes++ = value+VOICE_0;
                }
                continue;
            }
            else  //��Ϊ0�Ķ�Ҫ��
            {
                *codes++ = value+VOICE_0;
                if(count==2) *codes++ =VOICE_SHI;
                if(count==1) *codes++ =VOICE_MINUTE;
            }
        }
    }
    if((pStopTime->Days==0)&&(pStopTime->Hour==0)&&(pStopTime->Min==0))
    {
        *codes++=VOICE_0;
        *codes++=VOICE_HOUR;
        *codes++=VOICE_0;
        *codes++=VOICE_MINUTE;
    }

    return codes-ptr;
}


static unsigned char  VoicePlayConvertRemanDays(unsigned short days,unsigned char *codes)
{
    unsigned char i=0;
    STOP_TIME StopTime;

    memset(&StopTime,0,sizeof(StopTime));
    StopTime.Days = days;
    codes[i++]=14;
    i+=VoicePlayTimeConv(&StopTime,&codes[i]);

    return i;
}


//�������ת���ɿɲ��ŵ���Ƶ��
static unsigned char VoicePlayAmountConv(unsigned int Amount,unsigned char *codes)
{
    unsigned char count=0,len=0;
    char buf[20];
    unsigned char *ptr=codes;
    unsigned int value,temp;
    unsigned int bak,valuebak;

    temp = Amount;
    if(temp!=0)
    {
        sprintf(buf,"%d",temp);
        len = strlen(buf);
        for(count=len; count>0; count--)
        {
            temp=temp%(int)pow(10,count);
            value= temp/(int)pow(10,count-1);
            if((count==2)&&(value==0))       //ԪΪ0����ֻ��Ԫ������0
            {
                *codes++ =VOICE_YUAN;
                continue;
            }
            else if((count==1)&&(value==0))  //��Ϊ0��0�ͽǶ�����
            {
                continue;
            }
            else if((count>2)&&(value==0))  //�����ǰΪ0�����ж���һ���Ƿ�Ϊ0
            {
                bak=temp%(int)pow(10,count-1);
                valuebak= bak/(int)pow(10,count-2);
                if(valuebak!=0)  //�����һ����Ϊ0����ֻ��0
                {
                    *codes++ = value+VOICE_0;
                }
                continue;
            }
            else  //��Ϊ0�Ķ�Ҫ��
            {
                *codes++ = value+VOICE_0;
                if(count==6) *codes++ =VOICE_WAN;
                if(count==5) *codes++ =VOICE_QIAN;
                if(count==4) *codes++ =VOICE_BAI;
                if(count==3) *codes++ =VOICE_SHI;
                if(count==2) *codes++ =VOICE_YUAN;
                if(count==1) *codes++ =VOICE_JIAO;
            }
        }
    }
    else
    {
        *codes++ =VOICE_0;
        *codes++ =VOICE_YUAN;
    }
    return codes-ptr;
}


static unsigned char VoicePlayConvertBalance(unsigned int balance,unsigned char *codes)
{
    unsigned char i=0;

    codes[i++]=15;
    i+=VoicePlayAmountConv(balance,&codes[i]);

    return i;
}


static unsigned char VoicePlayConvertStopTime(STOP_INFO *pStopInfo,unsigned char *codes)
{
    unsigned char i=0;

    codes[i++]=6;
    i+=VoicePlayTimeConv(&pStopInfo->StopTime,&codes[i]);
    codes[i++]=7;
    i+=VoicePlayAmountConv(pStopInfo->Fee,&codes[i]);

    return i;
}




void VoiceAppInit(VOICE **ppUsrVoice)
{
    *ppUsrVoice=(VOICE *)&Voice;
    //VoiceVolCheck(&Voice.VolConfig);
}

VOL_CONFIG *VoiceGetVolConfigAddr(void)
{
    return &Voice.VolConfig;
}


unsigned char VoiceMsgConvertPlays(VOICE_MSG *pVoiceMsg,unsigned char *dat)
{
    unsigned char len=0;

    VoiceVolCheck(&Voice.VolConfig);

    switch(pVoiceMsg->cmd)
    {
    case CMD_VOICE_SINGLE:
        dat[0]=pVoiceMsg->play.Code;
        len =1;
        break;
    case CMD_VOICE_CARNUMBER:
        len = VoicePlayConvertCarNumber(pVoiceMsg->play.StopInfo.CarNumber,dat);
        break;
    case CMD_VOICE_REMAINDAY:
        len = VoicePlayConvertRemanDays(pVoiceMsg->play.StopInfo.RemanDays,dat);
        break;
    case CMD_VOICE_BALANCE:
        len = VoicePlayConvertBalance(pVoiceMsg->play.StopInfo.Balance,dat);
        break;
    case CMD_VOICE_TIME_FEE:
        len = VoicePlayConvertStopTime(&pVoiceMsg->play.StopInfo,dat);
        break;
    default:
        break;
    }

    return len;
}



