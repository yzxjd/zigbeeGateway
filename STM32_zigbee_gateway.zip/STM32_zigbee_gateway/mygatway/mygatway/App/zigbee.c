#include <stdio.h>
#include <stdlib.h>
#include "string.h"
#include "stm32f10x_api.h"
#include "feeprom.h"
#include "feepromApp.h"
#include "zigbee.h"
#include "cmsis_os.h"
#include "usrApp.h"
#include "MQTTEcho.h"
#include "queue.h"

#define UART_RX_LEN 24

ZIGBEEADDR ZigbeeStopAddr[STOP_MAX];
ZIGBEEADDR ZigbeeGuideAddr[GUIDE_MAX];
ZIGBEEADDR ZigbeeLampAddr[LAMP_MAX];
ZIGBEEADDR ZigbeeChpAddr[CHP_MAX];

MAGNETIC_VAL magneticTemp;
BASELINE_VAL baselineTemp;


static unsigned char ZigbeeRevHead,ChooseRXbuf,ChooseRXbuf1;
static unsigned char loraRevHead;
static unsigned char ZigbeeRevBuf1[UART_RX_LEN];
static unsigned char ZigbeeRevBuf2[UART_RX_LEN];
static unsigned char ZigbeeRevBuf3[UART_RX_LEN];

static unsigned char LoRaRevBuf1[UART_RX_LEN];
static unsigned char LoRaRevBuf2[UART_RX_LEN];
static unsigned char LoRaRevBuf3[UART_RX_LEN];
//static unsigned char ZigbeeBufNo=0,ZigbeeRevMode=0;
//static unsigned char loraBufNo=0,loraRevMode=0;
static unsigned char DmaTxBuffer[36];
unsigned char InNetLED = 0;
unsigned char magnetDataFlag = 0;


long zigbeeFunc_Net(int argc,char **argv)
{
    static unsigned char flag=0;

    if(!strcmp(argv[0],"lamp"))
    {
        //LampScan();
    }
    else if(!strcmp(argv[0],"guide"))
    {
        //GuideScan();
    }
    else if(!strcmp(argv[0],"yuyue"))    //zigbee yuyue 1 1
    {
        sendyuyue(atoi(argv[1]),atoi(argv[2]));
    }
    else if(!strcmp(argv[0],"yuyues"))
    {
        while(1)
        {
            sendyuyue(4,flag);
            flag=~flag;
            osDelay(5000);
        }
    }
    return 0;
}

long GatewaySetFunc(int argc,char **argv)
{
    if(!strcmp(argv[0],"setzigbee"))			//����������ZigBeeЭ������Ƶ�κ�panid
    {
        sendSetZiegbee(atoi(argv[1]),atoi(argv[2]));
        printf("set pan id work!\n");
    }
    else if(!strcmp(argv[0],"setgatewayid"))	//��������ID
    {
        sendSetGatewayID(atoi(argv[1]));
        printf("set gateway id work\n");
    }
    else if(!strcmp(argv[0],"setnetwm"))		//��������ģʽ
    {
        sendSetNetWorkMode(atoi(argv[1]));
        printf("set networking mode work\n");
    }
	else if(!strcmp(argv[0],"setmqtt"))			//����MQTT����
    {
        SaveMqttParameters((uint8_t*)argv[1],atoi(argv[2]),(uint8_t*)argv[3],(uint8_t*)argv[4]);
        printf("set mqtt work\n");
    }
	else if(!strcmp(argv[0],"pararead"))		//���ز�����ȡ
    {
		parameterReadAndShow();
        printf("para read work\n");
    }
    else if(!strcmp(argv[0],"restart"))			//��������
    {
        Reboot();
        printf("set restart work\n");
    }
    return 0;
}

/*************************************************
  Function:    ����3��ʼ����������ZigBeeģ��ͨ��
  Description: �������ƴ���������
*************************************************/
void Uart3Config(INT32U eBandRate,INT8U eDataBit,INT8U eParity,INT8U eStopBit)
{
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    USART_ClockInitTypeDef  USART_ClockInitStructure;
    DMA_InitTypeDef DMA_InitStructure;									//DMA���ýṹ��
    INT16U DataBit;
    INT16U Parity;
    INT16U StopBit;

    NVIC_InitStructure.NVIC_IRQChannel = DMA1_Channel3_IRQChannel;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 7;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

    DMA_DeInit(DMA1_Channel3);																										//����3��DMA����ͨ����DMA1_Channel3
    DMA_InitStructure.DMA_PeripheralBaseAddr =  (unsigned int)(&(USART3->DR));		//������ʼ��ַ
    DMA_InitStructure.DMA_MemoryBaseAddr = (unsigned int)&ZigbeeRevHead;					//�ڴ��ַ
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;														//����DMA���䷽��Ϊ������		DMA_DIR_PeripheralDSTΪ˫����
    DMA_InitStructure.DMA_BufferSize = 1; 																				//����ʱ�������ĳ���
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;							//����DMA�������ģʽ��
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;												//����DMA�ڴ����ģʽ
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;				//����DMAÿ�β��������ݳ���1�ֽ�
    DMA_InitStructure.DMA_MemoryDataSize = DMA_PeripheralDataSize_Byte;						//����һ����ͬ
    DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;					//���ô���ģʽΪ�������ϵ�ѭ��ģʽ
    DMA_InitStructure.DMA_Priority = DMA_Priority_High;			//����DMA�����ȼ���	��4���ȼ�VeryHigh,High,Medium,Low
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;						//DMA����memory�еı����Ƿ������
    DMA_Init(DMA1_Channel3, &DMA_InitStructure);  					//�ٴζ�DMA����ģ���ʼ����ʹDMA��Ա���������һ��

    /////////////////////////////////////////////////////////////////////

    DMA_DeInit(DMA1_Channel2);
    DMA_InitStructure.DMA_PeripheralBaseAddr = (unsigned int)(&(USART3->DR));
    DMA_InitStructure.DMA_MemoryBaseAddr = (unsigned int)DmaTxBuffer;
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
    DMA_InitStructure.DMA_BufferSize = 0;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
    DMA_InitStructure.DMA_Priority = DMA_Priority_Low;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA1_Channel2, &DMA_InitStructure);

    if(eDataBit==9)	 DataBit =  USART_WordLength_9b;
    else DataBit = USART_WordLength_8b;

    if(eParity=='e') Parity = USART_Parity_Even;
    else if(eParity=='o') Parity = USART_Parity_Odd;
    else Parity =  USART_Parity_No;

    if(eStopBit==2) StopBit = USART_StopBits_2;
    else StopBit =  USART_StopBits_1;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3,ENABLE);

    USART_DeInit(USART3);
    USART_ClockInitStructure.USART_Clock = USART_Clock_Disable;
    USART_ClockInitStructure.USART_CPOL = USART_CPOL_Low;
    USART_ClockInitStructure.USART_CPHA = USART_CPHA_2Edge;
    USART_ClockInitStructure.USART_LastBit = USART_LastBit_Disable;
    // Configure the USART synchronous paramters
    USART_ClockInit(USART3, &USART_ClockInitStructure);

    USART_InitStructure.USART_BaudRate = eBandRate;
    USART_InitStructure.USART_WordLength = DataBit;
    USART_InitStructure.USART_StopBits = StopBit;
    USART_InitStructure.USART_Parity = Parity;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    // Configure USART basic and asynchronous paramters
    USART_Init(USART3, &USART_InitStructure);
    USART_ITConfig(USART3,USART_IT_RXNE, DISABLE);

    DMA_ITConfig(DMA1_Channel2, DMA_IT_TC | DMA_IT_TE, ENABLE);
    DMA_ITConfig(DMA1_Channel3, DMA_IT_TC | DMA_IT_TE, ENABLE);

    USART_DMACmd(USART3,USART_DMAReq_Rx,ENABLE);
    USART_DMACmd(USART3,USART_DMAReq_Tx,ENABLE);
    DMA_Cmd(DMA1_Channel3, DISABLE);
    DMA_Cmd(DMA1_Channel2, ENABLE);
    USART_Cmd(USART3, DISABLE);
}

void uart3Config(INT32U DEFAULT_BAUD)
{
    USART_InitTypeDef USART_InitStructure;
    DMA_InitTypeDef DMA_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    //USART����
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_InitStructure.USART_BaudRate = DEFAULT_BAUD;
    USART_Init(USART3,&USART_InitStructure);
    USART_ITConfig(USART3,USART_IT_IDLE,ENABLE);
    USART_Cmd(USART3, DISABLE);
    USART_ClearFlag(USART3, USART_FLAG_TC);

    //DMA����   ����
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
    DMA_DeInit(DMA1_Channel3);																										//����2��DMA����ͨ����DMA1_Channel6
    DMA_InitStructure.DMA_PeripheralBaseAddr =  (unsigned int)(&(USART3->DR));		//������ʼ��ַ
    DMA_InitStructure.DMA_MemoryBaseAddr = (unsigned int)&ZigbeeRevBuf1;
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;														//����DMA���䷽��Ϊ������		DMA_DIR_PeripheralDSTΪ˫����
    DMA_InitStructure.DMA_BufferSize = UART_RX_LEN; 																				//����ʱ�������ĳ���
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;							//����DMA�������ģʽ��
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;												//����DMA�ڴ����ģʽ
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;				//����DMAÿ�β��������ݳ���1�ֽ�
    DMA_InitStructure.DMA_MemoryDataSize = DMA_PeripheralDataSize_Byte;						//����һ����ͬ
    DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;					//���ô���ģʽΪ�������ϵ�ѭ��ģʽ
    DMA_InitStructure.DMA_Priority = DMA_Priority_High;			//����DMA�����ȼ���	��4���ȼ�VeryHigh,High,Medium,Low
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;						//DMA����memory�еı����Ƿ������
    DMA_Init(DMA1_Channel3, &DMA_InitStructure);  					//�ٴζ�DMA����ģ���ʼ����ʹDMA��Ա���������һ��

    /////////////////////////////////////////////////////////////////////
    //DMA����   ����
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
    DMA_DeInit(DMA1_Channel2);
    DMA_InitStructure.DMA_PeripheralBaseAddr = (unsigned int)(&(USART3->DR));
    DMA_InitStructure.DMA_MemoryBaseAddr = (unsigned int)DmaTxBuffer;
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
    DMA_InitStructure.DMA_BufferSize = 0;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
    DMA_InitStructure.DMA_Priority = DMA_Priority_Low;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA1_Channel2, &DMA_InitStructure);

    DMA_ITConfig(DMA1_Channel2, DMA_IT_TC | DMA_IT_TE, ENABLE);
    DMA_ITConfig(DMA1_Channel3, DMA_IT_TC | DMA_IT_TE, ENABLE);

    USART_DMACmd(USART3,USART_DMAReq_Tx,ENABLE);
    USART_DMACmd(USART3,USART_DMAReq_Rx,ENABLE);

    DMA_Cmd(DMA1_Channel3, DISABLE);
    DMA_Cmd(DMA1_Channel2, ENABLE);

    //�ж����ȼ�����
//	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
    NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQChannel;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 7;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    NVIC_InitStructure.NVIC_IRQChannel = DMA1_Channel3_IRQChannel;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 7;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

/*************************************************
  Function:    ����4��ʼ����������LoRaģ��ͨ��
  Description: �������ƴ���������
*************************************************/
void Uart4Config(INT32U eBandRate,INT8U eDataBit,INT8U eParity,INT8U eStopBit)
{
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    USART_ClockInitTypeDef  USART_ClockInitStructure;
    DMA_InitTypeDef DMA_InitStructure;									//DMA���ýṹ��
    INT16U DataBit;
    INT16U Parity;
    INT16U StopBit;

    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA2, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4,ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel = DMA2_Channel3_IRQChannel;   //RX
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 7;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    //RX dma
    DMA_DeInit(DMA2_Channel3);																										//����4��DMA����ͨ����DMA2_Channel3
    DMA_InitStructure.DMA_PeripheralBaseAddr =  (unsigned int)(&(UART4->DR));		//������ʼ��ַ
    DMA_InitStructure.DMA_MemoryBaseAddr = (unsigned int)&loraRevHead;					//�ڴ��ַ
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;														//����DMA���䷽��Ϊ������		DMA_DIR_PeripheralDSTΪ˫����
    DMA_InitStructure.DMA_BufferSize = 1; 																				//����ʱ�������ĳ���
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;							//����DMA�������ģʽ��
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;												//����DMA�ڴ����ģʽ
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;				//����DMAÿ�β��������ݳ���1�ֽ�
    DMA_InitStructure.DMA_MemoryDataSize = DMA_PeripheralDataSize_Byte;						//����һ����ͬ
    DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;					//���ô���ģʽΪ�������ϵ�ѭ��ģʽ
    DMA_InitStructure.DMA_Priority = DMA_Priority_High;			//����DMA�����ȼ���	��4���ȼ�VeryHigh,High,Medium,Low
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;						//DMA����memory�еı����Ƿ������
    DMA_Init(DMA2_Channel3, &DMA_InitStructure);  					//�ٴζ�DMA����ģ���ʼ����ʹDMA��Ա���������һ��

    /////////////////////////////////////////////////////////////////////
    //TX	dma
    DMA_DeInit(DMA2_Channel5);
    DMA_InitStructure.DMA_PeripheralBaseAddr = (unsigned int)(&(UART4->DR));
    DMA_InitStructure.DMA_MemoryBaseAddr = (unsigned int)DmaTxBuffer;
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
    DMA_InitStructure.DMA_BufferSize = 0;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
    DMA_InitStructure.DMA_Priority = DMA_Priority_Low;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA2_Channel5, &DMA_InitStructure);


    if(eDataBit==9)	 DataBit =  USART_WordLength_9b;
    else DataBit = USART_WordLength_8b;

    if(eParity=='e') Parity = USART_Parity_Even;
    else if(eParity=='o') Parity = USART_Parity_Odd;
    else Parity =  USART_Parity_No;

    if(eStopBit==2) StopBit = USART_StopBits_2;
    else StopBit =  USART_StopBits_1;


    USART_DeInit(UART4);
    USART_ClockInitStructure.USART_Clock = USART_Clock_Disable;
    USART_ClockInitStructure.USART_CPOL = USART_CPOL_Low;
    USART_ClockInitStructure.USART_CPHA = USART_CPHA_2Edge;
    USART_ClockInitStructure.USART_LastBit = USART_LastBit_Disable;
    // Configure the USART synchronous paramters
    USART_ClockInit(UART4, &USART_ClockInitStructure);

    USART_InitStructure.USART_BaudRate = eBandRate;
    USART_InitStructure.USART_WordLength = DataBit;
    USART_InitStructure.USART_StopBits = StopBit;
    USART_InitStructure.USART_Parity = Parity;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    // Configure USART basic and asynchronous paramters
    USART_Init(UART4, &USART_InitStructure);
    USART_ITConfig(UART4,USART_IT_RXNE, DISABLE);

    DMA_ITConfig(DMA2_Channel5, DMA_IT_TC | DMA_IT_TE, ENABLE);		//TX
    DMA_ITConfig(DMA2_Channel3, DMA_IT_TC | DMA_IT_TE, ENABLE);   //RX

    USART_DMACmd(UART4,USART_DMAReq_Rx,ENABLE);
    USART_DMACmd(UART4,USART_DMAReq_Tx,ENABLE);
    DMA_Cmd(DMA2_Channel3, DISABLE);
    DMA_Cmd(DMA2_Channel5, ENABLE);
    USART_Cmd(UART4, DISABLE);
}

void uart4Config(INT32U DEFAULT_BAUD)
{
    USART_InitTypeDef USART_InitStructure;
    DMA_InitTypeDef DMA_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    //USART����
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, ENABLE);

    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_InitStructure.USART_BaudRate = DEFAULT_BAUD;
    USART_Init(UART4,&USART_InitStructure);
    USART_ITConfig(UART4,USART_IT_IDLE,ENABLE);
    USART_Cmd(UART4, DISABLE);
    USART_ClearFlag(UART4, USART_FLAG_TC);

    //DMA����   ����
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA2, ENABLE);
    DMA_DeInit(DMA2_Channel3);
    DMA_InitStructure.DMA_PeripheralBaseAddr =  (unsigned int)(&(UART4->DR));		//������ʼ��ַ
    DMA_InitStructure.DMA_MemoryBaseAddr = (unsigned int)&ZigbeeRevBuf1;
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;														//����DMA���䷽��Ϊ������		DMA_DIR_PeripheralDSTΪ˫����
    DMA_InitStructure.DMA_BufferSize = UART_RX_LEN; 																				//����ʱ�������ĳ���
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;							//����DMA�������ģʽ��
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;												//����DMA�ڴ����ģʽ
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;				//����DMAÿ�β��������ݳ���1�ֽ�
    DMA_InitStructure.DMA_MemoryDataSize = DMA_PeripheralDataSize_Byte;						//����һ����ͬ
    DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;					//���ô���ģʽΪ�������ϵ�ѭ��ģʽ
    DMA_InitStructure.DMA_Priority = DMA_Priority_High;			//����DMA�����ȼ���	��4���ȼ�VeryHigh,High,Medium,Low
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;						//DMA����memory�еı����Ƿ������
    DMA_Init(DMA2_Channel3, &DMA_InitStructure);  					//�ٴζ�DMA����ģ���ʼ����ʹDMA��Ա���������һ��

    /////////////////////////////////////////////////////////////////////
    //DMA����   ����
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA2, ENABLE);
    DMA_DeInit(DMA2_Channel5);
    DMA_InitStructure.DMA_PeripheralBaseAddr = (unsigned int)(&(UART4->DR));
    DMA_InitStructure.DMA_MemoryBaseAddr = (unsigned int)DmaTxBuffer;
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
    DMA_InitStructure.DMA_BufferSize = 0;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
    DMA_InitStructure.DMA_Priority = DMA_Priority_Low;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA2_Channel5, &DMA_InitStructure);

    DMA_ITConfig(DMA2_Channel5, DMA_IT_TC | DMA_IT_TE, ENABLE);
    DMA_ITConfig(DMA2_Channel3, DMA_IT_TC | DMA_IT_TE, ENABLE);

    USART_DMACmd(UART4,USART_DMAReq_Tx,ENABLE);
    USART_DMACmd(UART4,USART_DMAReq_Rx,ENABLE);

    DMA_Cmd(DMA2_Channel3, DISABLE);
    DMA_Cmd(DMA2_Channel5, ENABLE);

    //�ж����ȼ�����
//	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
    NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQChannel;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 7;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    NVIC_InitStructure.NVIC_IRQChannel = DMA2_Channel3_IRQChannel;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 7;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}


void ZigbeeProcessStart(void)
{
    DMA_Cmd(DMA1_Channel3, ENABLE);
    USART_Cmd(USART3, ENABLE);
}

void LoRaProcessStart(void)
{
    DMA_Cmd(DMA2_Channel3, ENABLE);
    USART_Cmd(UART4, ENABLE);
}

/*
 STM32��ZigBee�������ӵ�io���ã�����3
*/
void ZigbeeInit(void)
{
    GpioConfig(GPIOB,GPIO_Pin_10,GPIO_Mode_AF_PP,GPIO_Speed_50MHz);
    GpioConfig(GPIOB,GPIO_Pin_11,GPIO_Mode_IN_FLOATING,GPIO_Speed_50MHz);
//	Uart3Config(115200,8,0,1);
    uart3Config(115200);
}

/*
 STM32��LoRa�������ӵ�io���ã�����3
*/
void LoRaInit(void)
{
    GpioConfig(GPIOC,GPIO_Pin_10,GPIO_Mode_AF_PP,GPIO_Speed_50MHz);
    GpioConfig(GPIOC,GPIO_Pin_11,GPIO_Mode_IN_FLOATING,GPIO_Speed_50MHz);
//	Uart4Config(115200,8,0,1);
    uart4Config(115200);
}

/*
 STM32��ZigBee�������ӵ�io���ã�����2 ʧ�ܣ�
������������ʱ��ֹ������Ϣ���ŵ��µ�����ʧ��
*/
void ZigbeeDleInit(void)
{
    USART_Cmd(USART3, DISABLE);
}


void ZigbeeSendBytes(unsigned char *dat,unsigned short len)
{
    unsigned int cnt=3;
    if(len==0)   return ;
    while(DMA_GetFlagStatus(DMA1_FLAG_TC2) == RESET)
    {
        if(cnt--<=1)
        {
            if(DMA_GetFlagStatus(DMA1_FLAG_TE2) == SET)     // DMA ���ͳ���
            {
                printf("[ERROR]DMA Zigbee send error!\r\n");
                break;
            }
            else
            {
                printf("[ERROR]DMA Zigbee outtime!\r\n");
                break;
            }
        }
        osDelay(10);
    }
    DMA_Cmd(DMA1_Channel2,DISABLE);
    DMA_ClearFlag(DMA1_FLAG_TC2);
    DMA_ClearFlag(DMA1_FLAG_TE2);
    if(len>=sizeof(DmaTxBuffer))
        return ;
    DMA1_Channel2->CNDTR = len;
    memcpy(DmaTxBuffer,dat,len);
    DMA_Cmd(DMA1_Channel2,ENABLE);
}

void LoRaSendBytes(unsigned char *dat,unsigned short len)
{
    unsigned int cnt=3;
    if(len==0)   return ;
    while(DMA_GetFlagStatus(DMA2_FLAG_TC5) == RESET)
    {
        if(cnt--<=1)
        {
            if(DMA_GetFlagStatus(DMA2_FLAG_TE5) == SET)     // DMA ���ͳ���
            {
                printf("[ERROR]DMA LoRa send error!\r\n");
                break;
            }
            else
            {
                printf("[ERROR]DMA LoRa outtime!\r\n");
                break;
            }
        }
        osDelay(10);
    }
    DMA_Cmd(DMA2_Channel5,DISABLE);
    DMA_ClearFlag(DMA2_FLAG_TC5);
    DMA_ClearFlag(DMA2_FLAG_TE5);
    if(len>=sizeof(DmaTxBuffer))
        return ;
    DMA2_Channel5->CNDTR = len;
    memcpy(DmaTxBuffer,dat,len);
    DMA_Cmd(DMA2_Channel5,ENABLE);
}

void ZigbeeSendByte(unsigned char dat)
{
    ZigbeeSendBytes(&dat,1);
}

void LoRaSendByte(unsigned char dat)
{
    LoRaSendBytes(&dat,1);
}

/*************************************************
  Function:    ZigBee����֡У��λУ��
  Description:
*************************************************/
unsigned char ZigbeeDataCheck(unsigned char *buf,uint8_t type)
{
    unsigned short i;
    unsigned char xxor=0;
//	ZIGBEE_HEAD *pZigbeeHead;
//
//	pZigbeeHead = (ZIGBEE_HEAD *)buf;

    //if(pZigbeeHead->ver==0x01)
    {
        xxor ^= 0x55;//��λ���
        xxor ^= 0xaa;
        for(i=0; i<type; i++)
        {
            xxor ^= buf[i];
        }
        if(xxor==buf[i])
        {
            return 1;
        }
        else
        {
//			printf("xxor error %x != %x ZigbeeBufNo=%d\r\n",xxor,buf[i],ZigbeeBufNo);
        }
    }

    return 0;

}

/*************************************************
  Function:    LoRa����֡У��λУ��
  Description:
*************************************************/
unsigned char LoRaDataCheck(unsigned char *buf, uint8_t type)
{
    unsigned short i;
    unsigned char xxor=0;

    xxor ^= 0x55;//��λ���
    xxor ^= 0xaa;
    for(i=0; i<type; i++)
    {
        xxor ^= buf[i];
    }
    if(xxor==buf[i])
    {
        return 1;
    }
    else
    {
        //printf("xxor error %x != %x\r\n",xxor,buf[i]);
    }

    return 0;
}


void ZigbeeAddrPrintf(void)
{
    unsigned short i;
    unsigned short ZigbeeCnt=0;

    ZigbeeCnt=0;
    for(i=0; i<CHP_MAX; i++)
    {
        if(ZigbeeChpAddr[i].ShortAddr!=0)
        {
            ZigbeeCnt++;
            printf("ZigbeeChpAddr[%d]:0x%x cnt:%d\r\n",i,ZigbeeChpAddr[i].ShortAddr,ZigbeeCnt);
        }
    }

    ZigbeeCnt=0;
    for(i=0; i<STOP_MAX; i++)
    {
        if(ZigbeeStopAddr[i].ShortAddr!=0)
        {
            ZigbeeCnt++;
            printf("ZigbeeStopAddr[%d]:0x%x cnt:%d\r\n",i,ZigbeeStopAddr[i].ShortAddr,ZigbeeCnt);
        }
    }
    ZigbeeCnt=0;
    for(i=0; i<GUIDE_MAX; i++)
    {
        if(ZigbeeGuideAddr[i].ShortAddr!=0)
        {
            ZigbeeCnt++;
            printf("ZigbeeGuideAddr[%d]:0x%x cnt:%d\r\n",i,ZigbeeGuideAddr[i].ShortAddr,ZigbeeCnt);
        }
    }
    ZigbeeCnt=0;
    for(i=0; i<LAMP_MAX; i++)
    {
        if(ZigbeeLampAddr[i].ShortAddr!=0)
        {
            ZigbeeCnt++;
            printf("ZigbeeLampAddr[%d]:0x%x cnt:%d\r\n",i,ZigbeeLampAddr[i].ShortAddr,ZigbeeCnt);
        }
    }
}

/*************************************************
  Function:    ZigBee��ID�б�
  Description: �����б�ZigBee�ڵ�����ͣ���λ��������������������ָʾ�ƣ��ͽڵ�ID
*************************************************/
unsigned char ZigbeeIDCheck(unsigned int ZigbeeID)
{
    unsigned int ZigbeeType = ZigbeeID&0xf0000000;
    unsigned int NodeID = ZigbeeID&0x00000fff;

    if((ZigbeeType==TYPE_STOP)&&(NodeID<STOP_MAX))  return 0;
    else if((ZigbeeType==TYPE_LAMP)&&(NodeID<LAMP_MAX))  return 0;
    else if((ZigbeeType==TYPE_GUIDE)&&(NodeID<GUIDE_MAX))  return 0;
    else if((ZigbeeType==TYPE_CHP)&&(NodeID<CHP_MAX))  return 0;

    return 0xff;
}

/*************************************************
  Function:    LoRa��ID�б�
  Description: �����б�ZigBee�ڵ�����ͣ���λ��������������������ָʾ�ƣ��ͽڵ�ID
*************************************************/
unsigned char LoRaMsgCheck(REVPRO_MSG loraMsg)
{

    unsigned int LoRaType = loraMsg.srcID&0xf0000000;
    unsigned int NodeID = loraMsg.srcID&0x00000fff;

    if((LoRaType==TYPE_STOP)&&(NodeID<STOP_MAX))  return 0;
    else if((LoRaType==TYPE_LAMP)&&(NodeID<LAMP_MAX))  return 0;
    else if((LoRaType==TYPE_GUIDE)&&(NodeID<GUIDE_MAX))  return 0;
    else if((LoRaType==TYPE_CHP)&&(NodeID<CHP_MAX))  return 0;

    return 0xff;
}

/*************************************************
  Function:    ZigBee���ݰ���������
  Description: �����ݰ�������������������ȡ�����浽��Ӧ�ڵ�Ĳ���������
*************************************************/
unsigned int ZigbeePacketProcess(unsigned char *buf)
{
    ZIGBEE_HEAD *pZigbeeHead=(ZIGBEE_HEAD *)buf;
    unsigned int ZigbeeType = pZigbeeHead->srcID&0xf0000000;
    unsigned int NodeID = pZigbeeHead->srcID&0x00000fff;
    unsigned int ShortAddr = pZigbeeHead->dstID&0x0000ffff;
	unsigned char tempzbCh = 0;
	unsigned short tempzbPanID = 0;
    if(ZigbeeIDCheck(pZigbeeHead->srcID))  return 0xff;

    if(ZigbeeType==TYPE_STOP)
        ZigbeeStopAddr[NodeID].ShortAddr=ShortAddr;
    else if(ZigbeeType==TYPE_LAMP)
        ZigbeeLampAddr[NodeID].ShortAddr=ShortAddr;
    else if(ZigbeeType==TYPE_GUIDE)
        ZigbeeGuideAddr[NodeID].ShortAddr=ShortAddr;
    else if(ZigbeeType==TYPE_CHP)
        ZigbeeChpAddr[NodeID].ShortAddr=ShortAddr;

    if(pZigbeeHead->len == 2)
    {
		switch(pZigbeeHead->cmd)
		{
			case 0x45:
				printf("Э�������û�Ӧ\r\n");
				break;
			case 0x66:
				printf("Э������ѯ��Ӧ:");
				tempzbCh = buf[12];
				tempzbPanID = ((unsigned short)buf[14]<<8)+buf[13];
				printf("ch=0x%02x,panid=0x%02x\n",tempzbCh,tempzbPanID);
				if(tempzbCh!=zigbeeCh || tempzbPanID!=zigbeePanID)
				{
					zigbeeCh = tempzbCh;
					zigbeePanID = tempzbPanID;
					if(WriteZigbeeParaToFlash(tempzbCh,tempzbPanID)>0)
						printf("zigbee ����MCU FLASH ʧ��\n");
				}
				break;
			default:
				break;
		}
        return 0;
    }
    else if(pZigbeeHead->len == 3)
    {
        REVPRO_MSG RevProMsg;
        RevProMsg.ver = (pZigbeeHead->ver) & 0x00;
        printf("zigbee node=%x %x\r\n",pZigbeeHead->ver,RevProMsg.ver);
        RevProMsg.cmd = pZigbeeHead->cmd;
        RevProMsg.srcID = pZigbeeHead->srcID;
        memcpy(RevProMsg.dat,buf+sizeof(ZIGBEE_HEAD),pZigbeeHead->len);
        RevProSend(&RevProMsg);
        return 0;
    }
    else if(pZigbeeHead->len == 6)		//�ų���ǰֵ
    {
//		printf("�ӵ��ش���\n");
        magneticTemp.nmagneticPubFlag = 1;
        magneticTemp.lockID = pZigbeeHead->srcID;
        magneticTemp.nx_val =  (unsigned short)(buf[13] << 8) + buf[12];
        magneticTemp.ny_val =  (unsigned short)(buf[15] << 8) + buf[14];
        magneticTemp.nz_val =  (unsigned short)(buf[17] << 8) + buf[16];
        printf("magnetic:%d %d %d\r\n",magneticTemp.nx_val,magneticTemp.ny_val,magneticTemp.nz_val);
        return 0;
    }
    else if(pZigbeeHead->len == 7)		//���ߺ���ֵ
    {
//		printf("�ӵ����ߺ���ֵ\n");
        baselineTemp.baselinePubFlag = 1;
        baselineTemp.lockID = pZigbeeHead->srcID;
        baselineTemp.threshold = buf[12];
        baselineTemp.bx_val =  (unsigned short)(buf[14] << 8) + buf[13];
        baselineTemp.by_val =  (unsigned short)(buf[16] << 8) + buf[15];
        baselineTemp.bz_val =  (unsigned short)(buf[18] << 8) + buf[17];
        printf("baseline:%d %d %d %d\r\n",baselineTemp.bx_val,baselineTemp.by_val,
               baselineTemp.bz_val,baselineTemp.threshold);
        return 0;
    }
    else
    {
        return 0xff;
    }
}

/*************************************************
  Function:    LoRa���ݰ���������
  Description: �����ݰ�������������������ȡ����,
							 �浽��Ӧ�ڵ�Ĳ���������.
*************************************************/
unsigned int LoRaPacketProcess(unsigned char *buf)
{
    REVPRO_MSG RevProMsg;
    //LoRaģʽ�µĴ������ݴ��������������ݽ������ṹ���У������͵���Ϣ�ж�
    revMsg_t *LoRaMessageRev = (revMsg_t *)buf;
//	printf("\r\nDveID=%x  len=%d cmd=%d\n",LoRaMessageRev->DveID,LoRaMessageRev->len,LoRaMessageRev->cmd);
    unsigned int LoRaType = LoRaMessageRev->DveID&0xf0000000;
    unsigned int NodeID = LoRaMessageRev->DveID&0x00000fff;
    unsigned int ShortAddr = LoRaMessageRev->DveID&0x0000ffff;

    if(ZigbeeIDCheck(LoRaMessageRev->DveID))  return 0xff;  //lora�ڵ������ж�����ZigBee��

    if(LoRaType==TYPE_STOP)
        ZigbeeStopAddr[NodeID].ShortAddr=ShortAddr;
    else if(LoRaType==TYPE_LAMP)
        ZigbeeLampAddr[NodeID].ShortAddr=ShortAddr;
    else if(LoRaType==TYPE_GUIDE)
        ZigbeeGuideAddr[NodeID].ShortAddr=ShortAddr;
    else if(LoRaType==TYPE_CHP)
        ZigbeeChpAddr[NodeID].ShortAddr=ShortAddr;

    if(LoRaMessageRev->len!=9)  return 0xff;
    RevProMsg.ver = LoRaMessageRev->ver;//��ʱ�Ѱ汾�Ÿĳ�1��������lora��ZigBee
    printf("\r\nlora node=%x %x\r\n",RevProMsg.ver,LoRaMessageRev->ver);
    RevProMsg.cmd = LoRaMessageRev->cmd;
    RevProMsg.srcID = LoRaMessageRev->DveID;
//	printf("RevProMsg.srcID=%x\n",RevProMsg.srcID);
//	buf[8] = 0x01; //��ʱ�Ѱ汾�Ÿĳ�1��������lora��ZigBee
    memcpy(RevProMsg.dat,buf+8,3);

    RevProSend(&RevProMsg);	 														 //��������������ݷ��͵���Ϣ�ж�

    return 0;
}


void ZigbeeSend(unsigned int dstID,unsigned char cmd,unsigned char *dat,unsigned short len)
{
    printf("get ZigBee message send\n");
    unsigned char buf[50],xxor=0;
    unsigned short i;
    ZIGBEE_HEAD ZigbeeHead;
    unsigned int ZigbeeType = dstID&0xf0000000;
    unsigned int DstID = dstID&0x00000fff;

    ZigbeeHead.cmd = cmd;
    ZigbeeHead.ver =0x01;
    ZigbeeHead.srcID = dstID;

    if(ZigbeeType==TYPE_STOP)
        ZigbeeHead.dstID = ZigbeeStopAddr[DstID].ShortAddr;
    else if(ZigbeeType==TYPE_LAMP)
        ZigbeeHead.dstID = ZigbeeLampAddr[DstID].ShortAddr;
    else if(ZigbeeType==TYPE_GUIDE)
        ZigbeeHead.dstID = ZigbeeGuideAddr[DstID].ShortAddr;
    else if(ZigbeeType==TYPE_CHP)
        ZigbeeHead.dstID = ZigbeeChpAddr[DstID].ShortAddr;

    if(ZigbeeHead.dstID==0) return ;
    ZigbeeHead.len = len;

    buf[0]=0xaa;
    buf[1]=0x55;
    memcpy(&buf[2],&ZigbeeHead,sizeof(ZIGBEE_HEAD));

    if(dat==NULL)
    {
        for(i=0; i<len; i++)
        {
            buf[2+sizeof(ZIGBEE_HEAD)+i] =0;
        }
    }
    else
    {
        for(i=0; i<len; i++)
        {
            buf[2+sizeof(ZIGBEE_HEAD)+i] = dat[i];
        }
    }
    for(i=0; i<2+sizeof(ZIGBEE_HEAD)+len; i++)
    {
        xxor ^=buf[i];
    }
    buf[i] = xxor;
    ZigbeeSendBytes(buf,2+sizeof(ZIGBEE_HEAD)+len+1);
    osDelay(50);
}

//lenΪappdata�ĳ���
void LoRaSend(unsigned int dstID,unsigned char cmd,unsigned char *dat,unsigned short len)
{
    printf("get lora message send\n");
    unsigned char buf[50],xxor=0;
    unsigned short i;
    revMsg_t loraMsg;
    unsigned int LoRaType = dstID&0xf0000000;
    unsigned int DstID = dstID&0x00000fff;

    if(LoRaType==TYPE_STOP)
        loraMsg.DveID = ZigbeeStopAddr[DstID].ShortAddr;
    else if(LoRaType==TYPE_LAMP)
        loraMsg.DveID = ZigbeeLampAddr[DstID].ShortAddr;
    else if(LoRaType==TYPE_GUIDE)
        loraMsg.DveID = ZigbeeGuideAddr[DstID].ShortAddr;
    else if(LoRaType==TYPE_CHP)
        loraMsg.DveID = ZigbeeChpAddr[DstID].ShortAddr;

    if(loraMsg.DveID==0) return ;
    printf("judge ok\n");

    /*Э�����������ݵ�ͷ����*/
    buf[0]=0xaa;
    buf[1]=0x55;

    loraMsg.len = len+6;  //DveID(4byte)+ver(1byte)+cmd(1byte)
    loraMsg.cmd = cmd;
    loraMsg.ver =0x01;
    loraMsg.DveID = dstID;

    if(dat==NULL)
    {
        for(i=0; i<len; i++)
        {
            buf[2+8+i] =0;
        }
    }
    else
    {
        for(i=0; i<len; i++)
        {
            loraMsg.appData[i] = dat[i];
        }
    }

    memcpy(&buf[2],&loraMsg,sizeof(revMsg_t)-1); //�ѷ������ݽṹ�����ݿ�����buf,������У��λ

    for(i=0; i<2+sizeof(loraMsg)-1; i++)
    {
        xxor ^=buf[i];
    }
    buf[i++] = xxor;  //���У��λ

    /*Э���������ն˽ڵ�����ݼ�β*/
    buf[i++] = 0xff;
    buf[i++] = 0xfd;
    buf[i++] = 0xff;
    buf[i++] = 0xff;

    LoRaSendBytes(buf,2+sizeof(revMsg_t)+4);
    printf("lora send succeed\n");
//	for(int k=0;k<2+sizeof(revMsg_t)+4;k++)
//		printf("%x ",buf[k]);
    osDelay(50);
}

/*************************************************
  Function:    ZigBee����DMA�жϽ���
  Description: ZigbeeRevMode==0���ʾ���ֽ��գZigbeeRevMode==1��ʾ���ֽڽ���
*************************************************/
//void ZigbeeDmaRev(void)
//{
//	static unsigned char buffer[60],length=0,flag=0;
//	static uint32_t myTikTime;
//
//	if(ZigbeeRevMode==0)
//	{
//		buffer[length++]=ZigbeeRevHead;
//		if(length>=sizeof(buffer))
//		{
//			length=0;
//			flag=0;
//		}
//		if((length>=2)&&(buffer[length-2]==0x55)&&(buffer[length-1]==0xaa))
//		{
//			length=0;
//			flag=1;
//			myTikTime = SysTick_GetCurrent();
//		}
//		else if(flag==1)    //���յ���Ч��������
//		{
//			if( SysTick_GetLapse(myTikTime) > 1)
//			{
//				length=0;
//				flag=0;
//			}
//			if(length == (buffer[10]+13))
//			{
//				if(ZigbeeDataCheck(buffer,(buffer[10]+12)))       //У��Ҳû����Ļ�
//				{
//					DMA_Cmd(DMA1_Channel3, DISABLE);
//					if(ZigbeeBufNo==0)
//					{
//						DMA1_Channel3->CMAR =(unsigned int)ZigbeeRevBuf2;
//						ZigbeeBufNo =1;
//					}
//					else
//					{
//						printf("into buff1\n");
//						DMA1_Channel3->CMAR =(unsigned int)ZigbeeRevBuf1;
//						ZigbeeBufNo = 0;
//					}
//					DMA1_Channel3->CNDTR = 18;
//					ZigbeeRevMode =1;     //���½�����ֽڽ���ģʽ
//					DMA_Cmd(DMA1_Channel3, ENABLE);
//					printf("mode:%d BufNo:%d buf:\r\n",ZigbeeRevMode,ZigbeeBufNo);
//					for(int i=0; i<length; i++)
//						printf("%x ",buffer[i]);
//					ZigbeePacketProcess(buffer);
//				}
//				memset(buffer,0,sizeof(buffer));
//
//				flag=0;
//				length=0;
//			}
//		}
//	}
//	else
//	{
//		if(ZigbeeBufNo==0)
//		{
//			if((ZigbeeRevBuf1[0]==0x55)&&(ZigbeeRevBuf1[1]==0xaa))
//			{
//				DMA_Cmd(DMA1_Channel3, DISABLE);
//				DMA1_Channel3->CMAR = (unsigned int)ZigbeeRevBuf2;
//				DMA1_Channel3->CNDTR = 18;
//				DMA_Cmd(DMA1_Channel3, ENABLE);
//
//				ZigbeeBufNo =1;
//				if(ZigbeeDataCheck(&ZigbeeRevBuf1[2],(12+ZigbeeRevBuf1[12])))
//				{
//					printf("mode:%d BufNo:%d ZigbeeRevBuf1:\r\n",ZigbeeRevMode,ZigbeeBufNo);
//					for(int i=0; i<(15+ZigbeeRevBuf1[12]); i++)
//						printf("%x ",ZigbeeRevBuf1[i]);
//					InNetLED = 1;
//					ZigbeePacketProcess(&ZigbeeRevBuf1[2]);
//				}
//				else
//				{
////					printf("mode:%d BufNo:%d\r\n",ZigbeeRevMode,ZigbeeBufNo);
//					DMA_Cmd(DMA1_Channel3, DISABLE);
//					DMA1_Channel3->CMAR = (unsigned int)&ZigbeeRevHead;
//					DMA1_Channel3->CNDTR = 1;
//					DMA_Cmd(DMA1_Channel3, ENABLE);
////					printf("[ERROR]zigbee Check1 error!\r\n");
//					ZigbeeRevMode =0;      //���ֽڽ���ģʽ
//				}
//				memset(ZigbeeRevBuf1,0,sizeof(ZigbeeRevBuf1));
//			}
//			else   //�����Ч��������ǰ��Ч���ݣ��ָ��������ֽڽ�����һ��ͷ
//			{
//				DMA_Cmd(DMA1_Channel3, DISABLE);
//				DMA1_Channel3->CMAR = (unsigned int)&ZigbeeRevHead;
//				DMA1_Channel3->CNDTR = 1;
//				DMA_Cmd(DMA1_Channel3, ENABLE);
//				//printf("[ERROR]zigbee rev1 error!\r\n");
//				ZigbeeRevMode =0;      //���ֽڽ���ģʽ
//			}
//		}
//		else
//		{
//			if((ZigbeeRevBuf2[0]==0x55)&&(ZigbeeRevBuf2[1]==0xaa))
//			{
//				DMA_Cmd(DMA1_Channel3, DISABLE);
//				DMA1_Channel3->CMAR = (unsigned int)ZigbeeRevBuf1;
//				DMA1_Channel3->CNDTR = 18;
//				DMA_Cmd(DMA1_Channel3, ENABLE);
//
//				ZigbeeBufNo =0;
//				if(ZigbeeDataCheck(&ZigbeeRevBuf2[2],12+ZigbeeRevBuf2[12]))
//				{
//					printf("mode:%d BufNo:%d ZigbeeRevBuf2:\r\n",ZigbeeRevMode,ZigbeeBufNo);
//					for(int i=0; i<(15+ZigbeeRevBuf2[12]); i++)
//						printf("%x ",ZigbeeRevBuf2[i]);
//					InNetLED = 1;
//					ZigbeePacketProcess(&ZigbeeRevBuf2[2]);
//
//				}
//				else
//				{
//					DMA_Cmd(DMA1_Channel3, DISABLE);
//					DMA1_Channel3->CMAR = (unsigned int)&ZigbeeRevHead;
//					DMA1_Channel3->CNDTR = 1;
//					DMA_Cmd(DMA1_Channel3, ENABLE);
//					//printf("[ERROR]zigbee Check2 error!\r\n");
//					ZigbeeRevMode =0;      //���ֽڽ���ģʽ
//				}
//				memset(ZigbeeRevBuf2,0,sizeof(ZigbeeRevBuf2));
//			}
//			else   //�����Ч��������ǰ��Ч���ݣ��ָ��������ֽڽ�����һ��ͷ
//			{
//				DMA_Cmd(DMA1_Channel3, DISABLE);
//				DMA1_Channel3->CMAR = (unsigned int)&ZigbeeRevHead;
//				DMA1_Channel3->CNDTR = 1;
//				DMA_Cmd(DMA1_Channel3, ENABLE);
//				//printf("[ERROR]zigbee rev2 error!\r\n");
//				ZigbeeRevMode =0;      //���ֽڽ���ģʽ
//			}
//		}
//	}
//}

//-------------------------LoRaDmaRev-----------------------------------
//void LoRaDmaRev(void)
//{
//	static unsigned char buffer[60],length=0,flag=0;

//	if(loraRevMode==0)      //���ڵ��ֽڽ���
//	{
//		buffer[length++]=loraRevHead;
//		if(length>=sizeof(buffer))
//		{
//			length=0;
//		}
//		if((length>=2)&&(buffer[length-2]==0x55)&&(buffer[length-1]==0xaa))
//		{
//
//			length=0;
//			flag=1;
//		}
//		else if((flag==1)&&(length>=12))    //���յ���Ч��������
//		{
//			if(LoRaDataCheck(buffer))       //У��Ҳû����Ļ�
//			{
//				DMA_Cmd(DMA2_Channel3, DISABLE);
//				if(loraBufNo==0)
//				{
//					DMA2_Channel3->CMAR =(unsigned int)ZigbeeRevBuf2;
//					loraBufNo =1;
//				}
//				else
//				{
//					DMA2_Channel3->CMAR =(unsigned int)ZigbeeRevBuf1;
//					loraBufNo =0;
//				}
//				DMA2_Channel3->CNDTR = 14;
//				loraRevMode =1;     //���½�����ֽڽ���ģʽ
//				DMA_Cmd(DMA2_Channel3, ENABLE);
//				LoRaPacketProcess(buffer);
//			}
//			flag=0;
//			length=0;
//		}
//	}
//	else   									//���ڶ��ֽڽ���
//	{
//		if(loraBufNo==0)
//		{
//			if((ZigbeeRevBuf1[0]==0x55)&&(ZigbeeRevBuf1[1]==0xaa))
//			{
//				DMA_Cmd(DMA2_Channel3, DISABLE);
//				DMA2_Channel3->CMAR = (unsigned int)ZigbeeRevBuf2;
//				DMA2_Channel3->CNDTR = 14;
//				DMA_Cmd(DMA2_Channel3, ENABLE);
//
//				loraBufNo =1;
//				if(LoRaDataCheck(&ZigbeeRevBuf1[2]))
////				if(ZigbeeRevBuf2[13]==0x00)
//				{
////					printf("ZigbeeRevBuf1:");
////					for(int i=0;i<14;i++)
////						printf("%02x ",(unsigned char)ZigbeeRevBuf1[i]);
//					LoRaPacketProcess(&ZigbeeRevBuf1[2]);
//				}
//				else
//				{
//					DMA_Cmd(DMA2_Channel3, DISABLE);
//					DMA2_Channel3->CMAR = (unsigned int)&loraRevHead;
//					DMA2_Channel3->CNDTR = 1;
//					DMA_Cmd(DMA2_Channel3, ENABLE);
//					//printf("[ERROR]zigbee Check1 error!\r\n");
//					loraRevMode =0;      //���ֽڽ���ģʽ
//				}
//			}
//			else   //�����Ч��������ǰ��Ч���ݣ��ָ��������ֽڽ�����һ��ͷ
//			{
//				DMA_Cmd(DMA2_Channel3, DISABLE);
//				DMA2_Channel3->CMAR = (unsigned int)&loraRevHead;
//				DMA2_Channel3->CNDTR = 1;
//				DMA_Cmd(DMA2_Channel3, ENABLE);
//				//printf("[ERROR]zigbee rev1 error!\r\n");
//				loraRevMode =0;      //���ֽڽ���ģʽ
//			}
//		}
//		else
//		{
//			if((ZigbeeRevBuf2[0]==0x55)&&(ZigbeeRevBuf2[1]==0xaa))
//			{
//				DMA_Cmd(DMA2_Channel3, DISABLE);
//				DMA2_Channel3->CMAR = (unsigned int)ZigbeeRevBuf1;
//				DMA2_Channel3->CNDTR = 14;
//				DMA_Cmd(DMA2_Channel3, ENABLE);
//
//				loraBufNo =0;
//				if(LoRaDataCheck(&ZigbeeRevBuf2[2]))
////				if(ZigbeeRevBuf2[13]==0x00)
//				{
////					printf("ZigbeeRevBuf2:");
////					for(int j=0;j<14;j++)
////						printf("%02x ",(unsigned char)ZigbeeRevBuf2[j]);
//					LoRaPacketProcess(&ZigbeeRevBuf2[2]);
//				}
//				else
//				{
//					DMA_Cmd(DMA2_Channel3, DISABLE);
//					DMA2_Channel3->CMAR = (unsigned int)&loraRevHead;
//					DMA2_Channel3->CNDTR = 1;
//					DMA_Cmd(DMA2_Channel3, ENABLE);
//					//printf("[ERROR]zigbee Check2 error!\r\n");
//					loraRevMode =0;      //���ֽڽ���ģʽ
//				}
//			}
//			else   //�����Ч��������ǰ��Ч���ݣ��ָ��������ֽڽ�����һ��ͷ
//			{
//				DMA_Cmd(DMA2_Channel3, DISABLE);
//				DMA2_Channel3->CMAR = (unsigned int)&loraRevHead;
//				DMA2_Channel3->CNDTR = 1;
//				DMA_Cmd(DMA2_Channel3, ENABLE);
//				//printf("[ERROR]zigbee rev2 error!\r\n");
//				loraRevMode =0;      //���ֽڽ���ģʽ
//			}
//		}
//	}
//}

void myLoRaDmaRev(uint16_t rxLen, uint8_t bufNum)
{
    switch(bufNum)
    {
    case 1:
        if((LoRaRevBuf3[0]==0x55)&&(LoRaRevBuf3[1]==0xaa))
        {
            if(LoRaDataCheck(&LoRaRevBuf3[2],rxLen-3) || LoRaDataCheck(&LoRaRevBuf3[2],rxLen-7))
            {
                printf("LoRaRevBuf3:%d\n",rxLen);
                InNetLED = 1;				//zigbee���糩ָͨʾ�Ƶ���

//					for(int j=0;j<rxLen;j++)
//						printf("%02x ",(unsigned char)ZigbeeRevBuf3[j]);

                LoRaPacketProcess(&LoRaRevBuf3[2]);
                memset(LoRaRevBuf3,0,sizeof(LoRaRevBuf3));
            }
        }
        else
        {
            memset(LoRaRevBuf3,0,sizeof(LoRaRevBuf3));
        }
        break;

    case 2:
        if((LoRaRevBuf1[0]==0x55)&&(LoRaRevBuf1[1]==0xaa))
        {
            if(LoRaDataCheck(&LoRaRevBuf1[2],rxLen-3) || LoRaDataCheck(&LoRaRevBuf1[2],rxLen-7))
            {
                printf("LoRaRevBuf1:%d\n",rxLen);
                InNetLED = 1;				//zigbee���糩ָͨʾ�Ƶ���

//					for(int j=0;j<rxLen;j++)
//						printf("%02x ",(unsigned char)ZigbeeRevBuf1[j]);

                LoRaPacketProcess(&LoRaRevBuf1[2]);
                memset(LoRaRevBuf1,0,sizeof(LoRaRevBuf1));
            }
        }
        else
        {
            memset(LoRaRevBuf1,0,sizeof(LoRaRevBuf1));
        }
        break;

    case 3:
        if((LoRaRevBuf2[0]==0x55)&&(LoRaRevBuf2[1]==0xaa))
        {
            if(LoRaDataCheck(&LoRaRevBuf2[2],rxLen-3) || LoRaDataCheck(&LoRaRevBuf2[2],rxLen-7))
            {
                printf("ZigbeeRevBuf2:%d\n",rxLen);
                InNetLED = 1;				//zigbee���糩ָͨʾ�Ƶ���

//					for(int j=0;j<rxLen;j++)
//						printf("%02x ",(unsigned char)ZigbeeRevBuf2[j]);

                LoRaPacketProcess(&LoRaRevBuf2[2]);
                memset(LoRaRevBuf2,0,sizeof(LoRaRevBuf2));
            }
        }
        else
        {
            memset(LoRaRevBuf2,0,sizeof(LoRaRevBuf2));
        }
        ChooseRXbuf1 = 0;		//ѭ��
        break;

    default :
        break;

    }
}


/*************************************************
  Function:    ZigBee��DMA�����жϴ�������
  Description:
*************************************************/
void DMA1_Channel3_IRQHandler(void)
{
//	if(DMA_GetITStatus(DMA1_IT_TC3))
// 	{
//		DMA_ClearITPendingBit(DMA1_IT_TC3);
//		ZigbeeDmaRev();
// 	}
//	else if(DMA_GetITStatus(DMA1_IT_TE3))
//	{
//		DMA_ClearITPendingBit(DMA1_IT_TE3);
//		printf("[ERROR]zigbee DMA error!\r\n");
//		InNetLED = 0;
//	}
    DMA_ClearITPendingBit(DMA1_IT_TC3);
    DMA_ClearITPendingBit(DMA1_IT_TE3);
    DMA_Cmd(DMA1_Channel3, DISABLE);
    DMA1_Channel3->CNDTR = UART_RX_LEN;
    DMA_Cmd(DMA1_Channel3, ENABLE);

}

/*************************************************
  Function:    LoRa��DMA�����жϴ�������
  Description:
*************************************************/
void DMA2_Channel3_IRQHandler(void)
{
//	if(DMA_GetITStatus(DMA2_IT_TC3))
// 	{
//		DMA_ClearITPendingBit(DMA2_IT_TC3);
//		LoRaDmaRev();
// 	}
//	else if(DMA_GetITStatus(DMA2_IT_TE3))
//	{
//		DMA_ClearITPendingBit(DMA2_IT_TE3);
//		printf("[ERROR]LoRa DMA error!\r\n");
//		InNetLED = 0;
//	}
    DMA_ClearITPendingBit(DMA2_IT_TC3);
    DMA_ClearITPendingBit(DMA2_IT_TE3);
    DMA_Cmd(DMA2_Channel3, DISABLE);
    DMA2_Channel3->CNDTR = UART_RX_LEN;
    DMA_Cmd(DMA2_Channel3, ENABLE);
}


void myZigbeeDMAreceive(uint16_t rxLen, uint8_t bufNum)
{
    switch(bufNum)
    {
    case 1:
        if((ZigbeeRevBuf3[0]==0x55)&&(ZigbeeRevBuf3[1]==0xaa))
        {
            if(ZigbeeDataCheck(&ZigbeeRevBuf3[2],rxLen-3))
            {
                printf("ZigbeeRevBuf3:%d\n",rxLen);
                InNetLED = 1;				//zigbee���糩ָͨʾ�Ƶ���
                ZigbeePacketProcess(&ZigbeeRevBuf3[2]);
                memset(ZigbeeRevBuf3,0,sizeof(ZigbeeRevBuf3));
            }
        }
        else
        {
            memset(ZigbeeRevBuf3,0,sizeof(ZigbeeRevBuf3));
        }
        break;

    case 2:
        if((ZigbeeRevBuf1[0]==0x55)&&(ZigbeeRevBuf1[1]==0xaa))
        {
            if(ZigbeeDataCheck(&ZigbeeRevBuf1[2],rxLen-3))
            {
                printf("ZigbeeRevBuf1:%d\n",rxLen);
                InNetLED = 1;				//zigbee���糩ָͨʾ�Ƶ���
                ZigbeePacketProcess(&ZigbeeRevBuf1[2]);
                memset(ZigbeeRevBuf1,0,sizeof(ZigbeeRevBuf1));
            }
        }
        else
        {
            memset(ZigbeeRevBuf1,0,sizeof(ZigbeeRevBuf1));
        }
        break;

    case 3:
        if((ZigbeeRevBuf2[0]==0x55)&&(ZigbeeRevBuf2[1]==0xaa))
        {
            if(ZigbeeDataCheck(&ZigbeeRevBuf2[2],rxLen-3))
            {
                printf("ZigbeeRevBuf2:%d\n",rxLen);
                InNetLED = 1;				//zigbee���糩ָͨʾ�Ƶ���
                ZigbeePacketProcess(&ZigbeeRevBuf2[2]);
                memset(ZigbeeRevBuf2,0,sizeof(ZigbeeRevBuf2));
            }
        }
        else
        {
            memset(ZigbeeRevBuf2,0,sizeof(ZigbeeRevBuf2));
        }
        ChooseRXbuf = 0;		//ѭ��
        break;

    default :
        break;

    }
}

void USART3_IRQHandler(void)
{
    uint16_t Length = 0;//���ݳ���
    if(USART_GetITStatus(USART3, USART_IT_IDLE) != RESET)
    {
        DMA_Cmd(DMA1_Channel3,DISABLE);
        Length = USART3->SR;
        Length = USART3->DR; //���USART_IT_IDLE��־
        Length = UART_RX_LEN - DMA_GetCurrDataCounter(DMA1_Channel3); //�����֡���ݽ��ճ���

        //���ô������ݳ���
        if(Length >= 18)
        {
            ChooseRXbuf++;
        }

        switch(ChooseRXbuf)
        {
        case 1:
            DMA1_Channel3->CMAR = (unsigned int)ZigbeeRevBuf1;
            break;

        case 2:
            DMA1_Channel3->CMAR = (unsigned int)ZigbeeRevBuf2;
            break;

        case 3:
            DMA1_Channel3->CMAR = (unsigned int)ZigbeeRevBuf3;
            break;

        default :
            break;
        }
        DMA1_Channel3->CNDTR = UART_RX_LEN;//����װ�����ý��յ�ַ��0��ʼ
        DMA_Cmd(DMA1_Channel3, ENABLE);//�������ؿ�DMA
        if(Length >= 18)
        {
            myZigbeeDMAreceive(Length,ChooseRXbuf);
        }
    }
    __nop();
}

void UART4_IRQHandler(void)
{
    uint16_t Length = 0;//���ݳ���
    if(USART_GetITStatus(UART4, USART_IT_IDLE) != RESET)
    {
        DMA_Cmd(DMA2_Channel3,DISABLE);
        Length = UART4->SR;
        Length = UART4->DR; //���USART_IT_IDLE��־
        Length = UART_RX_LEN - DMA_GetCurrDataCounter(DMA2_Channel3); //�����֡���ݽ��ճ���

        //���ô������ݳ���
        if(Length >= 14)
        {
            ChooseRXbuf1++;
        }

        switch(ChooseRXbuf1)
        {
        case 1:
            DMA2_Channel3->CMAR = (unsigned int)LoRaRevBuf1;
            break;

        case 2:
            DMA2_Channel3->CMAR = (unsigned int)LoRaRevBuf2;
            break;

        case 3:
            DMA2_Channel3->CMAR = (unsigned int)LoRaRevBuf3;
            break;

        default :
            break;
        }
        DMA2_Channel3->CNDTR = UART_RX_LEN;//����װ�����ý��յ�ַ��0��ʼ
        DMA_Cmd(DMA2_Channel3, ENABLE);//�������ؿ�DMA
        if(Length >= 14)
        {
            myLoRaDmaRev(Length,ChooseRXbuf1);
        }
    }
    __nop();
}

