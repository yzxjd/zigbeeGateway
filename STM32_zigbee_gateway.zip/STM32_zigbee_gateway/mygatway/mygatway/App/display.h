#ifndef DISPLAY_H
#define DISPLAY_H

#include "led.h"

void DisplayInit(void);
void DisplaySend(unsigned char *dat,unsigned short len,unsigned short mode);

int DisplayCreateMutex(void);
int DisplayPendMutex (void);
void DisplayPostMutex(void);


#endif


