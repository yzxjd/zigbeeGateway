#ifndef FOURG_H
#define FOURG_H

#pragma pack(push)//�������״̬ 
#pragma pack(1)  //����Ϊ1�ֽڶ���
typedef struct _FOURG_HEAD
{
    unsigned char ver;
    unsigned int devID;
    unsigned char cmd;
    unsigned short len;
} FOURG_HEAD;
#pragma pack(pop)

void SIM800UartInit(void);
void ModeTCP232Reset(void);
unsigned char  FourGAppInit(void);
void FourGSocketOpen(void);
void FourGSocketClose(void);
long ATFunc_Net(int argc,char **argv);
void FourGProcessTask(void const * argument);
void FourGSendToDstIDCmd(unsigned int dstID,unsigned char cmd,unsigned char *dat,unsigned short len);
void FourGSocketSend(unsigned char *dat,unsigned short len);
unsigned short FourGSocketRev(unsigned char *dat,unsigned short timeout);
unsigned short FourGAtString(unsigned char *str);
unsigned char FourGSocketConnect(unsigned char *ip,unsigned short port,unsigned char cnt);
unsigned short FourGSocketRevCnt(unsigned char *dat,unsigned short len,unsigned short timeout);

unsigned short FourGAtStringTimeOut(unsigned char *str,unsigned short TimeOut);
//unsigned short FourGAtStringTimeOuts(unsigned char *str,unsigned short offset,unsigned short TimeOut);

//----------------------------------
void MQTTSocketLed(unsigned char status);
void MQTTLed(unsigned char status);
void InNetLed(unsigned char status);

/*����3���������ڶ�ȡ����ʱ4Gģ����ź�ǿ��*/
void FourGATmodeOpen(void);
int FourGATmodeClose(void);
void FourGSocketSignalStrength(unsigned short TimeOut);

//4Gģ�麯��
void Module4GRestart(void);
extern int toConnectTCP_IP(void);
unsigned char _tcpStatusJudge(void);

int _SIM800ConnectTcpInit(void);
void ActivateGSM(void);
void shutGSM(void);


#endif



