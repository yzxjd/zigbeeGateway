#ifndef WGAPP_H
#define WGAPP_H

#ifdef HV20
#define WGLEDPORT	GPIOC
#define WGLEDPIN 	GPIO_Pin_2
#else
#define WGLEDPORT	GPIOD
#define WGLEDPIN 	GPIO_Pin_1
#endif


void WgInit(void);
void WgStatusLedInit(void);
void WgAppInit(void);
unsigned char WgCardScan(unsigned long *lcard);
void WgStatusLedSet(unsigned char status);

#endif


