#include "usrApp.h"
#include "net.h"
#include "rtc.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include "stm32f10x_api.h"
#include "feeprom.h"
#include "feepromApp.h"
#include "cmsis_os.h"
#include "zigbee.h"
#include "cjson.h"
#include "ff.h"
#include "MQTTFreeRTOS.h"
#include "fourG.h"
#include "MQTTEcho.h"
#include "adc.h"
#define CHPFLOW 0

uint8_t sendqueueFlag = 0;				 //���ڱ�־��Ϣ�ж��Ƿ���
uint8_t queueMsgCnt = 0;					 //���ڼ�¼��Ϣ�жӵ���Ϣ����
unsigned char ch_datacache[20];    //��౸��4��ͨ��������
extern uint8_t TCP232ReloadFlag;
extern unsigned char NetMode;
extern SIGNAL_QUALITY signalQuality;
extern ChpZdMsg ChpZdMSG;
extern unsigned char upgradeReack;
extern UPGRADE_STATUS NexUpgradeResume;
extern unsigned char SignalStrength;

extern ZIGBEEADDR ZigbeeStopAddr[];
extern ZIGBEEADDR ZigbeeGuideAddr[];
extern ZIGBEEADDR ZigbeeLampAddr[];
extern ZIGBEEADDR ZigbeeChpAddr[];

extern MAGNETIC_VAL magneticTemp;
extern BASELINE_VAL baselineTemp;

CTRL_SET controlerSetTemp;					//ң����ʹ������Ӧ��ṹ��
LOCKTIME_SET timeLockTemp;					//�Զ�����ʱ������Ӧ��ṹ��
FAULT_TIME_SET faultTimeTemp;				//����ʱ������Ӧ��ṹ��
LOCKING_TIME_SET lockparkTimeTemp;	//�Զ������г�ʱ�����ýṹ��
BEEP_SET beepVoiceTemp;							//����������ʹ�ܺ�ʱ������Ӧ��ṹ��
LOCK_POWER_DOWN lockPowerSetTemp;		//��λ������ϵ����÷���
PARAMETER_RESET ParameterResetTemp; //��λ����������Ӧ��ṹ��

static osMessageQId Msgsobj;

/*������Ϣ���о� :������λ�شš���������ָʾ�ơ�ͨ����ͨ���ش�5����Ϣ�жӾ��*/
static osMessageQId MsgsStopList,MsgsGuideList,MsgsLampList,MsgsChpList,MsgsChList;

struct list_head stophead;   //��  λ����ͷ
struct list_head guidehead;  //����������ͷ
struct list_head lamphead;   //ָʾ������ͷ
struct list_head chphead;    //ͨ��������ͷ
struct list_head chhead;     //����������ͷ
struct list_head magnethead; //�ش���������ͷ

static FATFS fs;

unsigned char serverIp[4];
unsigned short serverPort;
unsigned char userName[16];
unsigned char Passwd[16];
unsigned int myID;
unsigned char binPidJudge;
unsigned char zigbeeCh = 0;
unsigned short zigbeePanID = 0;


void StopNodeListInit(void)
{
    StopListMutexLock();

    INIT_LIST_HEAD(&stophead);
    StopListMutexUnlock();
}


void GuideNodeListInit(void)
{
    GuideListMutexLock();
    INIT_LIST_HEAD(&guidehead);
    GuideListMutexUnlock();
}

void LampNodeListInit(void)
{
    LampListMutexLock();
    INIT_LIST_HEAD(&lamphead);
    LampListMutexUnlock();
}

void ChpNodeListInit(void)
{
    ChpListMutexLock();
    INIT_LIST_HEAD(&chphead);
    ChpListMutexUnlock();
}

void ChNodeListInit(void)
{
    ChListMutexLock();
    INIT_LIST_HEAD(&chhead);
    ChListMutexUnlock();
}

//�ͷ����г�λ�ڵ� ��ʱ��Ӧ���������������ʴ�����
unsigned char  FreeStopNode(void)
{
    PARK_STOP_NODE *tmp;
    unsigned short i;

    StopListMutexLock();
    for(i=0; i<STOP_MAX; i++)
    {
        tmp=(PARK_STOP_NODE *)ZigbeeStopAddr[i].NodeAddr;
        if(tmp!=NULL)
        {
            list_del(&tmp->list);
            free(tmp);
            ZigbeeStopAddr[i].NodeAddr =0;
        }
    }
    StopListMutexUnlock();

    return 0;
}


unsigned char  FreeGuideNode(void)
{
    PARK_GUIDE_NODE *tmp;
    unsigned short i;

    GuideListMutexLock();
    for(i=0; i<GUIDE_MAX; i++)
    {
        tmp=(PARK_GUIDE_NODE *)ZigbeeGuideAddr[i].NodeAddr;
        if(tmp!=NULL)
        {
            list_del(&tmp->list);
            free(tmp);
            ZigbeeGuideAddr[i].NodeAddr =0;

        }
    }
    GuideListMutexUnlock();

    return 0;
}


unsigned char  FreeLampNode(void)
{
    PARK_LAMP_NODE *tmp;
    unsigned short i;

    LampListMutexLock();
    for(i=0; i<LAMP_MAX; i++)
    {
        tmp=(PARK_LAMP_NODE *)ZigbeeLampAddr[i].NodeAddr;
        if(tmp!=NULL)
        {
            list_del(&tmp->list);
            free(tmp);
            ZigbeeLampAddr[i].NodeAddr =0;
        }
    }
    LampListMutexUnlock();

    return 0;
}

unsigned char  FreeChpNode(void)
{
    PARK_CHP_NODE *tmp;
    unsigned short i;

    ChpListMutexLock();
    for(i=0; i<CHP_MAX; i++)
    {
        tmp=(PARK_CHP_NODE *)ZigbeeChpAddr[i].NodeAddr;
        if(tmp!=NULL)
        {
            list_del(&tmp->list);
            free(tmp);
            ZigbeeChpAddr[i].NodeAddr =0;
        }
    }
    ChpListMutexUnlock();

    return 0;
}

unsigned char  FreeChNode(void)
{
    struct list_head *node;
    PARK_CH_NODE *tmp;

    ChListMutexLock();
    __list_for_each(node, &chhead)
    {
        tmp = list_entry(node,PARK_CH_NODE, list);
        list_del(&tmp->list);
        free(tmp);

    }
    ChListMutexUnlock();

    return 0;
}

// ���������ڵ㣬��ʱ��Ӧ���������������ʴ�����
unsigned char  AddStopNode(PARK_STOP_NODE *pStopNode)
{

    unsigned int NodeID=pStopNode->ParkTableNode.StopID&0x00000fff;

    if(NodeID>=STOP_MAX)
        return 0xff;

    StopListMutexLock();
    ZigbeeStopAddr[NodeID].NodeAddr =(unsigned int)pStopNode;
    pStopNode->Status =0x81;  //Ҫ��ʼ��Ϊ�г�����ΪҪ����ͳ�ƿճ�λ���������ֵҪ��ʼ��Ϊ1
    pStopNode->UpFlag =0xff; //�����������ڵ��ʱ��Ҫ�ϴ����½ڵ�״̬���ƶ�
    pStopNode->KeepCnt =0;
    list_add(&pStopNode->list,&stophead);
    StopListMutexUnlock();

    printf("����λ0x%x\r\n",pStopNode->ParkTableNode.StopID);

    return 0;
}

unsigned char  AddChpNode(PARK_CHP_NODE *pChpNode)
{
    unsigned int NodeID=pChpNode->ChpTableNode.ChpID&0x00000fff;

    if(NodeID>=CHP_MAX)
        return 0xff;

    ChpListMutexLock();
    ZigbeeChpAddr[NodeID].NodeAddr =(unsigned int)pChpNode;
    pChpNode->ChpTableNode.ChpID |= 0x20000000;
    pChpNode->Status =0x80;    //ͨ����ԪĬ���������޳���
    pChpNode->UpFlag =0xff;
    pChpNode->KeepCnt =0;
    list_add(&pChpNode->list,&chphead);
    ChpListMutexUnlock();
    printf("��ͨ����Ԫ0x%x\r\n",pChpNode->ChpTableNode.ChpID);

    return 0;
}

unsigned char  AddChNode(PARK_CH_NODE *pChNode)
{
    ChListMutexLock();
    pChNode->Status =1;   //�ʼӦ��Ϊͨ��û�г�
    list_add(&pChNode->list,&chhead);
    ChListMutexUnlock();
    printf("��ͨ��0x%x\r\n",pChNode->ChTableNode.ChID);

    return 0;
}

unsigned char  AddGuideNode(PARK_GUIDE_NODE *pGuideNode)
{

    unsigned int NodeID=pGuideNode->GuideTableNode.GuideID&0x00000fff;

    if(NodeID>=GUIDE_MAX)
        return 0xff;
    GuideListMutexLock();
    ZigbeeGuideAddr[NodeID].NodeAddr =(unsigned int)pGuideNode;
    pGuideNode->GuideTableNode.GuideID |=0x40000000;
    pGuideNode->Status =0x01;  //Ĭ��Ϊ����
    pGuideNode->UpFlag =0xff;
    pGuideNode->EmptyCnt=0;
    pGuideNode->KeepCnt=0;
    list_add(&pGuideNode->list,&guidehead);
    GuideListMutexUnlock();
    printf("��ָʾ��0x%x\r\n",pGuideNode->GuideTableNode.GuideID);

    return 0;
}

unsigned char  AddLampNode(PARK_LAMP_NODE *pLampNode)
{
    unsigned int NodeID=pLampNode->LampTableNode.LampID&0x00000fff;

    if(NodeID>=LAMP_MAX)
        return 0xff;

    LampListMutexLock();
    ZigbeeLampAddr[NodeID].NodeAddr =(unsigned int)pLampNode;
    pLampNode->LampTableNode.LampID |=0x80000000;
    pLampNode->Status =0x81;  //Ĭ��Ϊ�����г�
    pLampNode->UpFlag =0xff;
    pLampNode->EmptyCnt = 0;   // �ʼ��Ϊ�г�
    pLampNode->KeepCnt=0;
    list_add(&pLampNode->list,&lamphead);
    LampListMutexUnlock();
    printf("����0x%x\r\n",pLampNode->LampTableNode.LampID);

    return 0;
}

PARK_CH_NODE *GetChNodeByChID(unsigned int ChID)
{
    struct list_head *chnode;
    PARK_CH_NODE *tmp;

    __list_for_each(chnode, &chhead)
    {
        tmp = list_entry(chnode,PARK_CH_NODE, list);
        if(tmp->ChTableNode.ChID == ChID)
        {
            return tmp;
        }
    }

    return NULL;
}

PARK_CH_NODE *GetChNodeByChpID(unsigned int ChpID)
{
    PARK_CHP_NODE *tmp;

    unsigned int NodeID=ChpID&0x00000fff;

    if(NodeID>=CHP_MAX)
        return NULL;

    tmp = (PARK_CHP_NODE *)ZigbeeChpAddr[NodeID].NodeAddr;
    if(tmp!=NULL)
    {
        return GetChNodeByChID(tmp->ChpTableNode.ChID);
    }

    return NULL;
}

void ZigbeeChpStatusInit(void)
{
//	struct list_head *node;
    unsigned short i;
    PARK_CHP_NODE *tmp3;

    ChpListMutexLock();
    for(i=0; i<CHP_MAX; i++)
    {
        tmp3=(PARK_CHP_NODE *)ZigbeeChpAddr[i].NodeAddr;
        if(tmp3==0)  continue;
        tmp3->UpFlag = 0xff;
    }
    ChpListMutexUnlock();
}


/*************************************************
  Function:    ����ͨ���شŽڵ�״̬���غ���.
  Description: �������Ϊ�ڵ�Ķ̵�ַ
*************************************************/
void OneChpNodeStatusUpload(unsigned int cd)
{
//	struct list_head *node;
    unsigned short i;
    PARK_CHP_NODE *tmp3;

    ChpListMutexLock();
    for(i=0; i<CHP_MAX; i++)
    {
        tmp3=(PARK_CHP_NODE *)ZigbeeChpAddr[i].NodeAddr;
        if((tmp3==0) || (tmp3->ChpTableNode.ChpID != cd))  continue;

        if((tmp3->Status&0x80)==0x80)//֮ǰΪ�����޳���Ҫ����״̬����Ϊ�������ػ��Ǹ��ϵ�ʱ�����
        {
            tmp3->Status = 0x01;//��ʼΪ�г�������������Ϊ�޳�����ڷ���һ��״̬��ʱ�����޳�״̬��
        }
        else
        {
            tmp3->Status = 0x00;//�����Ǽٵ��޳�״̬���ڵ�5�����Ժ������ʵ״̬�ϴ�
        }

        tmp3->UpFlag = 0xff;
    }
    ChpListMutexUnlock();
}

unsigned short lockNum[200]= {0},lockTotleCnt=0; //lockTotleCnt��ʾ�ж��ٸ���λ��
void ZigbeeStopStatusInit(void)
{
//	struct list_head *node;
    unsigned short i,j=0;
    PARK_STOP_NODE *tmp;

    StopListMutexLock();
    for(i=0; i<STOP_MAX; i++)
    {
        tmp=(PARK_STOP_NODE *)ZigbeeStopAddr[i].NodeAddr;
        if(tmp==0)  continue;
        tmp->UpFlag = 0xff;
//---------2018.1.26----------------
        lockNum[j++] = i;
//---------2018.1.26----------------
    }

    lockTotleCnt = j;
    printf("��Ч��λ������:%d\r\n",lockTotleCnt);
    for(i=0; i<lockTotleCnt; i++)
    {
        printf("%d ",lockNum[i]);
    }
    StopListMutexUnlock();
}

void ZigbeeGuideStatusInit(void)
{
//	struct list_head *node;
    unsigned short i;
    PARK_GUIDE_NODE *tmp1;

    GuideListMutexLock();
    for(i=0; i<GUIDE_MAX; i++)
    {
        tmp1=(PARK_GUIDE_NODE *)ZigbeeGuideAddr[i].NodeAddr;
        if(tmp1==0)  continue;
        tmp1->UpFlag = 0xff;
    }
    GuideListMutexUnlock();
}

void ZigbeeLampStatusInit(void)
{
//	struct list_head *node;
    unsigned short i;
    PARK_LAMP_NODE *tmp2;

    LampListMutexLock();
    for(i=0; i<LAMP_MAX; i++)
    {
        tmp2=(PARK_LAMP_NODE *)ZigbeeLampAddr[i].NodeAddr;
        if(tmp2==0)  continue;
        tmp2->UpFlag = 0xff;
    }
    LampListMutexUnlock();
}



//��ʼ���ڵ�״̬�����ϴ���־��ǿ���ϴ�״̬����̨
void ZigbeeStatusInit(void)
{
    ZigbeeLampStatusInit();
    ZigbeeGuideStatusInit();
    ZigbeeStopStatusInit();
//	ZigbeeChpStatusInit();
}


//�˺���������ڵ㷢�����ݣ��ڽڵ�����������洦��
void  ZigbeeSendProcess(void)
{
//	struct list_head *node;
    unsigned short i;
    PARK_STOP_NODE *tmp;
    PARK_GUIDE_NODE *tmp1;
    PARK_LAMP_NODE *tmp2;
    PARK_CHP_NODE *tmp3;
    unsigned char dat[3];

    StopListMutexLock();
    for(i=0; i<STOP_MAX; i++)
    {
        tmp=(PARK_STOP_NODE *)ZigbeeStopAddr[i].NodeAddr;
        if(tmp==0)  continue;
        if((tmp->ParkTableNode.ZdEnable&0x80)!=0)
        {
            tmp->ParkTableNode.ZdEnable=(tmp->ParkTableNode.ZdEnable&0x7f);
            tmp->KeepCnt = 0;
            tmp->Status &=0x7f;
            tmp->UpFlag = 0xff;		//�������ر�־�����ܱ�ע��
            dat[0]=tmp->ParkTableNode.ZdEnable&0x01;
            dat[1]=40;
            dat[2]=0;
            if(dat[0])
            {
                ZigbeeSend(tmp->ParkTableNode.StopID,0x0e,dat,3);
            }
            printf("0x%x��λ����״̬:%d\r\n",tmp->ParkTableNode.StopID,dat[0]);
            //StopListMutexUnlock();
            //return ;
        }
    }
    StopListMutexUnlock();

    ChpListMutexLock();
    for(i=0; i<CHP_MAX; i++)
    {
        tmp3=(PARK_CHP_NODE *)ZigbeeChpAddr[i].NodeAddr;
        if(tmp3==0)  continue;
        if((tmp3->ChpTableNode.ZdEnable&0x80)!=0)
        {
            tmp3->ChpTableNode.ZdEnable=(tmp3->ChpTableNode.ZdEnable&0x7f);
            tmp3->KeepCnt = 0;
            tmp3->Status &=0x7f;
            tmp3->UpFlag = 0xff;
            dat[0]=tmp3->ChpTableNode.ZdEnable&0x01;
            dat[1]=40;
            dat[2]=0;
            if(dat[0])
            {
                ZigbeeSend(tmp3->ChpTableNode.ChpID,0x0e,dat,3);
            }
            printf("0x%xͨ����Ԫ����״̬:%d\r\n",tmp3->ChpTableNode.ChpID,dat[0]);
            //ChpListMutexUnlock();
            //return ;
        }
    }
    ChpListMutexUnlock();

    LampListMutexLock();
    for(i=0; i<LAMP_MAX; i++)
    {
        tmp2=(PARK_LAMP_NODE *)ZigbeeLampAddr[i].NodeAddr;
        if(tmp2==0)  continue;
        if(tmp2->EmptyCnt!=tmp2->EmptyCntBak)
        {
            tmp2->EmptyCntBak = tmp2->EmptyCnt;

            if(tmp2->EmptyCnt==0)   //����λ
            {
                tmp2->Status|=0x01;
            }
            else
            {
                tmp2->Status&=0xfe;
            }
            dat[0]=tmp2->Status&0x01;
            dat[1]=0;
            dat[2]=0;

            ZigbeeSend(tmp2->LampTableNode.LampID,0x03,dat,3);
            printf("0x%xָʾ��״̬:%d,��λ��%d\r\n",tmp2->LampTableNode.LampID,dat[0],tmp2->EmptyCnt);
            //LampListMutexUnlock();
            //return ;
        }
    }
    LampListMutexUnlock();

    GuideListMutexLock();
    for(i=0; i<GUIDE_MAX; i++)
    {
        tmp1=(PARK_GUIDE_NODE *)ZigbeeGuideAddr[i].NodeAddr;
        if(tmp1==0)  continue;
        if(tmp1->EmptyCnt!=tmp1->EmptyCntBak)
        {
            tmp1->EmptyCntBak = tmp1->EmptyCnt;

            dat[0]=0;
            dat[1]=tmp1->EmptyCnt&0x00ff;
            dat[2]=tmp1->EmptyCnt>>8;

            ZigbeeSend(tmp1->GuideTableNode.GuideID,0x03,dat,3);
            printf("0x%xָʾ�ƿ�λ��:  %d\r\n",tmp1->GuideTableNode.GuideID,tmp1->EmptyCnt);
            //GuideListMutexUnlock();
            //return ;
        }
    }
    GuideListMutexUnlock();

    return ;
}

/*************************************************
  Function:    ���ƶ˷�������
  Description: ��MQTT�������洦��һֱ��ѯ����
*************************************************/
uint8_t ddxcFlag=0;
void PublishScanProcess(void)
{
//	struct list_head *node;
    PARK_STOP_NODE *tmp;
    PARK_GUIDE_NODE *tmp1;
    PARK_LAMP_NODE *tmp2;
    PARK_CHP_NODE *tmp3;
    unsigned short i=0;

    if(MQTTGetConnectStatus()==0)
        return ;

    for(i=0; i<CHP_MAX; i++)			//�������е�ͨ���شż�ⵥԪ������״̬
    {
        tmp3=(PARK_CHP_NODE *)ZigbeeChpAddr[i].NodeAddr;
        if(tmp3==0)  continue;
        if(tmp3->UpFlag)
        {
            tmp3->PubFlag =1;
            if(_MQTTPublishChpStatus(tmp3)==0)    //ͨ����ⵥԪ���ͣ�_MQTTPublishChpStatus(tmp3)==0˵�����ͳɹ�
            {
                tmp3->PubFlag =0;
                tmp3->UpFlag =0;
            }
            else
            {
                tmp3->PubFlag =0;
                return ;
            }
        }
    }
    for(i=0; i<STOP_MAX; i++)		//�������еĳ�λ�شż�ⵥԪ������״̬
    {
        tmp=(PARK_STOP_NODE *)ZigbeeStopAddr[i].NodeAddr;
        if(tmp==0)  continue;
        if(tmp->UpFlag)
        {
            tmp->PubFlag =1;
            if(_MQTTPublishCarStatus(tmp)==0)    //��λ����
            {
                tmp->UpFlag =0;
                tmp->PubFlag =0;
            }
            else
            {
                tmp->PubFlag =0;
                return ;
            }
        }
    }
    for(i=0; i<GUIDE_MAX; i++)		//�������е�ָʾ�Ƶ�Ԫ������״̬
    {
        tmp1=(PARK_GUIDE_NODE *)ZigbeeGuideAddr[i].NodeAddr;
        if(tmp1==0)  continue;
        if(tmp1->UpFlag)
        {
            tmp1->PubFlag =1;
            if(_MQTTPublishGuideStatus(tmp1)==0)    //ָʾ������
            {
                tmp1->PubFlag =0;
                tmp1->UpFlag =0;
            }
            else
            {
                tmp1->PubFlag =0;
                return ;
            }
        }
    }
    for(i=0; i<LAMP_MAX; i++)		//��������ָʾ�Ƶ�Ԫ������״̬
    {
        tmp2=(PARK_LAMP_NODE *)ZigbeeLampAddr[i].NodeAddr;
        if(tmp2==0)  continue;
        if(tmp2->UpFlag)
        {
            tmp2->PubFlag =1;
            if(_MQTTPublishLampStatus(tmp2)==0)    //ָʾ������
            {
                tmp2->PubFlag =0;
                tmp2->UpFlag =0;
            }
            else
            {
                tmp2->PubFlag =0;
                return ;
            }
        }
    }
    if(signalQuality.PublishSignalStrength_flag != 0)
    {
        uint8_t ret;
        //printf("receive mqtt SignalStrength for ���� :%d\r\n",signalQuality.mid);
        ret = _MQTTPublishSignalStrength(signalQuality.mid);

        if(ret != 0)	//�˳�ָ��ģʽ�쳣������
        {
            printf("mqtt SignalStrength pub fail!\n");
        }
        else
            sendqueueFlag = 0;
        signalQuality.PublishSignalStrength_flag = 0;
    }

    if(upgradeReack==1)  //�̼������ϵ�����
    {
        uint8_t ret=0;
        upgradeReack=0;
        ret = _MQTTPublishUpgradeStatus(NexUpgradeResume);
        if(ret!=0)
        {
            printf("�ϵ�����ʧ��\n");
            ddxcFlag++;
            if(ddxcFlag==5)  //20s*5 ����1���Ӷϵ�����ʧ�ܾ�����
            {
                Reboot();
            }
        }
        else
        {
            ddxcFlag=0;
        }
    }

    if(controlerSetTemp.controlerStatusPubFlag)	//ң��������Ӧ���ϴ�
    {
        uint8_t ret=0;
        controlerSetTemp.controlerStatusPubFlag = 0;
        ret = _MQTTPublishCtrlSetAck(controlerSetTemp);
        if(ret != 0)
        {
            printf("����Ӧ��ʧ��\r\n");
        }
    }

    if(timeLockTemp.timeSetPubFlag) //ʱ������Ӧ���ϴ�
    {
        uint8_t ret=0;
        timeLockTemp.timeSetPubFlag = 0;
        ret = _MQTTPublishLockTimesSetAck(timeLockTemp);
        if(ret != 0)
        {
            printf("����Ӧ��ʧ��\r\n");
        }
    }

    if(magneticTemp.nmagneticPubFlag) //�ش������ϴ�
    {
        uint8_t ret=0;
        magneticTemp.nmagneticPubFlag = 0;
        ret = _MQTTPublishMagneticUpload(magneticTemp);
        if(ret != 0)
        {
            printf("����Ӧ��ʧ��\r\n");
        }
    }

    if(baselineTemp.baselinePubFlag) //�شŻ��߼���ֵ�ϴ�
    {
        uint8_t ret=0;
        baselineTemp.baselinePubFlag = 0;
        ret = _MQTTPublishBaselineUpload(baselineTemp);
        if(ret != 0)
        {
            printf("����Ӧ��ʧ��\r\n");
        }
    }

    if(beepVoiceTemp.beepSetPubFlag)	//�������ü�ʱ������Ӧ���ϴ�
    {
        uint8_t ret=0;
        beepVoiceTemp.beepSetPubFlag = 0;
        ret = _MQTTPublishBeepEnableAndHlodtimeUpload(beepVoiceTemp);
        if(ret != 0)
        {
            printf("����Ӧ��ʧ��\r\n");
        }
    }

    if(faultTimeTemp.timeSetPubFlag)	//����ʱ������Ӧ��
    {
        uint8_t ret=0;
        faultTimeTemp.timeSetPubFlag= 0;
        ret = _MQTTPublishFaultTimeSetUpload(faultTimeTemp);
        if(ret != 0)
        {
            printf("����Ӧ��ʧ��\r\n");
        }
    }

    if(lockparkTimeTemp.lockingtimeSetPubFlag)	//�Զ������г�ʱ������Ӧ��
    {
        uint8_t ret=0;
        lockparkTimeTemp.lockingtimeSetPubFlag = 0;
        ret = _MQTTPublishAutomaticallyLockedUpload(lockparkTimeTemp);
        if(ret != 0)
        {
            printf("����Ӧ��ʧ��\r\n");
        }
    }

    if(lockPowerSetTemp.lockpowerSetPubFlag)		//�������������ϵ�����Ӧ��
    {
        uint8_t ret = 0;
        lockPowerSetTemp.lockpowerSetPubFlag = 0;
        ret = _MQTTPublishLockPowerOffSetUpload(lockPowerSetTemp);
        if(ret != 0)
        {
            printf("����Ӧ��ʧ��\r\n");
        }
    }

    if(ParameterResetTemp.ResetPubFlag)					//�����ָ���������Ӧ��
    {
        uint8_t ret = 0;
        ParameterResetTemp.ResetPubFlag = 0;
        ret = _MQTTPublishParameterResetUpload(ParameterResetTemp);
        if(ret != 0)
        {
            printf("����Ӧ��ʧ��\r\n");
        }
    }

}

/*************************************************
  Function: ZigBee��ѯ����
  Description: �˺������ڼ�ؽڵ��Ƿ����ߣ��ڽڵ�����������洦��
  Called By: ZigbeeNodeManageTask(void const *arg)
  Input:     none
  Output: 	 none
  Return:    none
  Others:
*************************************************/
void ZigbeeCheckProcess(void)
{
//	struct list_head *node;
    unsigned short i=0;
    PARK_STOP_NODE *tmp;    //ͣ��λ�ڵ�����ͷ
    PARK_GUIDE_NODE *tmp1;	//�������ڵ�����ͷ
    PARK_LAMP_NODE *tmp2;		//ָʾ�ƽڵ�����ͷ
    PARK_CHP_NODE *tmp3;		//ͨ�����ڵ�����ͷ
    const unsigned short keepmax=360/10;

    ChpListMutexLock();
    for(i=0; i<CHP_MAX; i++)
    {
        tmp3=(PARK_CHP_NODE *)ZigbeeChpAddr[i].NodeAddr;
        if(tmp3==0)  continue;
        if((tmp3->Status&0x80)==0x80)
        {
#ifdef mydebug
            printf("0x%x  ��Ԫ����...\r\n",tmp3->ChpTableNode.ChpID); //ͨ��
#endif
        }
        if(tmp3->KeepCnt>keepmax)
        {
            tmp3->KeepCnt=0;
            if((tmp3->Status&0x80)==0x00)   //֮ǰΪ����
                tmp3->UpFlag =0xff;
            tmp3->Status |=0x80;
            tmp3->Battery =0;
        }
        else
        {
            tmp3->KeepCnt++;
        }
    }
    ChpListMutexUnlock();


    StopListMutexLock();
    for(i=0; i<STOP_MAX; i++)
    {
        tmp=(PARK_STOP_NODE *)ZigbeeStopAddr[i].NodeAddr;
        if(tmp==0)  continue;
        if((tmp->Status&0x80)==0x80)
        {
#ifdef mydebug
            printf("0x%x��λ����... [0x%x]\r\n",tmp->ParkTableNode.StopID,tmp->Status);
#endif
        }
        if(tmp->KeepCnt>keepmax)
        {
            tmp->KeepCnt=0;
            if((tmp->Status&0x80)==0x00)   //֮ǰΪ����
                tmp->UpFlag =0xff;
            tmp->Status |=0x81;
            tmp->Battery =0;
        }
        else
        {
            tmp->KeepCnt++;
        }
    }
    StopListMutexUnlock();

    LampListMutexLock();
    for(i=0; i<LAMP_MAX; i++)
    {
        tmp2=(PARK_LAMP_NODE *)ZigbeeLampAddr[i].NodeAddr;
        if(tmp2==0)  continue;
        if((tmp2->Status&0x80)==0x80)
        {
#ifdef mydebug
            printf("0x%xָʾ������...[0x%x]\r\n",tmp2->LampTableNode.LampID,tmp2->Status);
#endif
        }
        if(tmp2->KeepCnt>keepmax)
        {
            tmp2->KeepCnt=0;
            if((tmp2->Status&0x80)==0x00)   //֮ǰΪ����
                tmp2->UpFlag =0xff;
            tmp2->Status |=0x80;
        }
        else
        {
            tmp2->KeepCnt++;
        }
    }
    LampListMutexUnlock();

    GuideListMutexLock();
    for(i=0; i<GUIDE_MAX; i++)
    {
        tmp1=(PARK_GUIDE_NODE *)ZigbeeGuideAddr[i].NodeAddr;
        if(tmp1==0)  continue;
        if((tmp1->Status&0x01)==0x01)
        {
#ifdef mydebug
            printf("0x%xָʾ������\r\n",tmp1->GuideTableNode.GuideID);
#endif
        }
        if(tmp1->KeepCnt>keepmax)    // 60s���
        {
            tmp1->KeepCnt=0;
            if((tmp1->Status&0x01)==0x00)   //֮ǰΪ����
                tmp1->UpFlag =0xff;
            tmp1->Status |= 0x01;
        }
        else
        {
            tmp1->KeepCnt++;
        }
    }
    GuideListMutexUnlock();
}

/*************************************************
  Function: �ش����ڲ�ѯ����
  Description:
*************************************************/
unsigned char MagneticInquire(unsigned short nodeNum)
{
    PARK_STOP_NODE *tmp;    //ͣ��λ�ڵ�����ͷ

    tmp=(PARK_STOP_NODE *)ZigbeeStopAddr[lockNum[nodeNum]].NodeAddr;
    if(tmp==0)
    {
        printf("û�ҵ�%d����\r\n",lockNum[nodeNum]);
        return 1;
    }
    if(tmp->LockStatus!=1)
    {
        ZigbeeSend(tmp->ParkTableNode.StopID, 0x06, 0, 3);
        printf("��ѯ%x�ĵش�����\r\n",tmp->ParkTableNode.StopID);
    }
    return 0;
}


/*************************************************
  Function: �������ж�ɨ��
  Description:
*************************************************/
void GuideAdjustScan(void)
{
//	struct list_head *guidenode;
    unsigned short i=0;
    PARK_GUIDE_NODE *tmp;

    GuideListMutexLock();
    for(i=0; i<GUIDE_MAX; i++)
    {
        tmp=(PARK_GUIDE_NODE *)ZigbeeGuideAddr[i].NodeAddr;
        if(tmp==0)  continue;
        tmp->EmptyCntBak =0xff;
    }
    GuideListMutexUnlock();
}

/*************************************************
  Function: ָʾ���ж�ɨ��
  Description:
*************************************************/
void LampAdjustScan(void)
{
//	struct list_head *lampnode;
    unsigned short i=0;
    PARK_LAMP_NODE *tmp;

    LampListMutexLock();
    for(i=0; i<LAMP_MAX; i++)
    {
        tmp=(PARK_LAMP_NODE *)ZigbeeLampAddr[i].NodeAddr;
        if(tmp==0)  continue;
        tmp->EmptyCntBak =0xff;
    }
    LampListMutexUnlock();
}

/*************************************************
  Function: ɨ��ָʾ��
  Description:
*************************************************/
void GuideScan(void)
{
    unsigned short i,j;
//	struct list_head *guidenode;
    PARK_GUIDE_NODE *tmp;
    PARK_STOP_NODE *tmp1;
    unsigned int StopID;

    GuideListMutexLock();
    for(i=0; i<GUIDE_MAX; i++)
    {
        tmp=(PARK_GUIDE_NODE *)ZigbeeGuideAddr[i].NodeAddr;
        if(tmp==0)  continue;
        tmp->EmptyCnt =0;
        for(j=0; j<tmp->GuideTableNode.StopCnt; j++)
        {
            StopID = tmp->GuideTableNode.StopTable[j];
            tmp1=(PARK_STOP_NODE *)ZigbeeStopAddr[StopID&0x00000fff].NodeAddr;
            if(tmp1!=NULL)
            {
                if((tmp1->Status&0x81)==0x00)   //ֻ�������޳�����ճ�λ
                {
                    tmp->EmptyCnt++;
                }
            }
        }
    }

    GuideListMutexUnlock();
}


/*************************************************
  Function: ɨ��ָʾ��
  Description:
*************************************************/
void LampScan(void)
{
    unsigned short i,j;
//	struct list_head *lampnode;
    PARK_LAMP_NODE *tmp;
    PARK_STOP_NODE *tmp1;
    unsigned int StopID;

    LampListMutexLock();
    for(i=0; i<LAMP_MAX; i++)
    {
        tmp=(PARK_LAMP_NODE *)ZigbeeLampAddr[i].NodeAddr;
        if(tmp==0)  continue;
        tmp->EmptyCnt =0;
        for(j=0; j<tmp->LampTableNode.StopCnt; j++)
        {
            StopID = tmp->LampTableNode.StopTable[j];
            tmp1=(PARK_STOP_NODE *)ZigbeeStopAddr[StopID&0x00000fff].NodeAddr;
            if(tmp1!=NULL)
            {
                if((tmp1->Status&0x81)==0x00)   //ֻ�������޳�����ճ�λ
                {
                    tmp->EmptyCnt++;
                }
            }
        }
    }
    LampListMutexUnlock();
}

/*************************************************
  Function:    ͨ������������ɨ��
	Description:
*************************************************/
void ChScan(PARK_CH_NODE *pCh)
{
    unsigned short i,cnt=0;
    PARK_CHP_NODE *pChpNode,*tempChpNode;

    cnt=0;
    for(i=0; i<pCh->ChTableNode.ChpCnt; i++)
    {
        pChpNode = (PARK_CHP_NODE *)ZigbeeChpAddr[pCh->ChTableNode.ChpTable[i]&0x00000fff].NodeAddr;
        if(pChpNode!=NULL)
        {
            printf("0x%x��Ԫstatus:%x\r\n",pChpNode->ChpTableNode.ChpID,pChpNode->Status);
            if((pChpNode->Status&0x81)==1)     //���߶����г� �����ߵĺ���
            {
                cnt++;
                tempChpNode = pChpNode;
            }
        }
    }
    if(cnt==0)   //û��һ���г�
    {
        if(pCh->Status==0)   //0��ı�״̬Ϊ�г���ճ�
        {
            pCh->Cnt++;
            pCh->Status=0x01;	 //1
//			printf("0x%x pch num:%d\r\n",pCh->ChTableNode.ChID,pCh->Cnt);

#if CHPFLOW
            taskENTER_CRITICAL();
#endif
//			printf("myrand=%d\n",myrand);
            if(_MQTTPublishChStatus(pCh)==0)     //�ɹ����ͣ��������ʧ���´λ��ǻ�ִ��
            {
                //printf("%dͨ�������ĳ�����Ϊ      %d\r\n",pCh->ChTableNode.ChID,pCh->Cnt);
                if(ChpZdMSG.ChpZdFlag == 1)				 //
                {
                    _MQTTPublishChpStatus(tempChpNode);
                    ChpZdMSG.ChpZdFlag = 0;
                }
            }
#if CHPFLOW
            taskEXIT_CRITICAL();
#endif
        }
    }
    else  //�г�
    {
        pCh->Status = 0;
    }
}

/*************************************************
  Function:    ͨ������������ǰ��������
  Description:
*************************************************/
void ChCntBakWriteScan(void)
{
    Ch_Data_cache();
    if(FLASH_COMPLETE==EE_WriteData(EE_KEY_CNT,(unsigned char *)ch_datacache,sizeof(ch_datacache)))
    {
        //printf("ch data save ok!\n");
    }
    else
        printf("ch data save fail!\n");
}

/*************************************************
  Function:    ���������ݻ���Ϊ���ֽ���
  Description: ���ڳ������������缰����ʱ���ݱ���
*************************************************/
void Ch_Data_cache(void)
{
    struct list_head *node;
    PARK_CH_NODE *tmp;
    unsigned char i=0,j=0;

    memset(ch_datacache,0,sizeof(ch_datacache));
    __list_for_each(node, &chhead)
    {
        tmp = list_entry(node, PARK_CH_NODE, list);
        printf("ChID:%x Cnt:%d\r\n",tmp->ChTableNode.ChID,tmp->Cnt);
        while(j<20)
        {
            if(0==(j%5))
            {
                ch_datacache[j] = tmp->ChTableNode.ChID;
                j++;
            }
            else
            {
                ch_datacache[j]=((tmp->Cnt)>>(24-((j%5)-1)*8));
                j++;
                if(0==((j+1)%5))
                {
                    ch_datacache[j]=((tmp->Cnt)>>(24-((j%5)-1)*8));
                    j++;
                    break;
                }
            }
        }
        i++;
    }
    /*
    	for(i=0;i<20;i++)
    	{
    		printf("0x%x ",ch_datacache[i]);
    		if((i+1)%5 == 0)
    		{
    			putchar('\n');
    		}
    	}
    */
}


//�ϵ��ȡͨ�����������ݱ���
void ChCntBakReadScan(void)
{
    struct list_head *node;
    PARK_CH_NODE *tmp;
    unsigned char i=0,j=0;
    unsigned char buf[20];    // ��౸�ݸ�10ͨ��������5*10
    unsigned int carCount[10]= {0}; //���ڻ��������ͨ�����������ڷ�ת
    unsigned int Chid[4]= {0};
    unsigned int count = 0;		//���ڻ��������ʱ����
    memset(buf,0,sizeof(buf));
    memset(ch_datacache,0,sizeof(ch_datacache));
    if(0==EE_ReadData(EE_KEY_CNT,(unsigned char *)buf,sizeof(buf)))
    {
        printf("ch data read ok!\n");
        memcpy(ch_datacache,buf,sizeof(buf));//�ϵ籸��
        /*
        		for(i=0;i<20;i++)
        		{
        			printf("0x%x ",ch_datacache[i]);
        			if((i+1)%5 == 0)
        			{
        				putchar('\n');
        			}
        		}
        */
    }
    else
    {
        printf("ch data read fail!\n");
    }
    ChListMutexLock();
    i=0;
    __list_for_each(node, &chhead)
    {
        tmp = list_entry(node,PARK_CH_NODE, list);
//		printf("%s [%d]",__FUNCTION__, __LINE__);
        while(j<20)
        {
            if(0==(j%5))
            {
                Chid[i] = buf[j];
                if(tmp->ChTableNode.ChID == buf[j])
                {
                    printf("nice to find match ChID:%d\r\n",tmp->ChTableNode.ChID);
                }
                j++;
            }
            else
            {
                count += (int)(buf[j]<<(24-((j%5)-1)*8));
                j++;
                if(0==((j+1)%5))
                {
                    count += (int)(buf[j]<<(24-((j%5)-1)*8));
                    j++;
                    break;
                }
            }
        }
        //tmp->Cnt=count;
        carCount[i] = count;
        count = 0;
        i++;
    }

    /*ƥ�����ǰ��ͨ��ID��ͨ������ֵ*/

    __list_for_each(node, &chhead)
    {
        tmp = list_entry(node,PARK_CH_NODE, list);
        for(i=0; i<4; i++)
        {
            if(tmp->ChTableNode.ChID == Chid[i])
            {
                tmp->Cnt=carCount[i];
//				printf("ChID:%x carCount:%d\r\n",tmp->ChTableNode.ChID, tmp->Cnt);
            }
        }
    }

    ChListMutexUnlock();
}

////////////////////////״̬LED��غ���///////////////////////
/*************************************************
  Function:    ״̬����ʾ����
  Description:
*************************************************/
void StatusLedInit(void)
{
    GpioConfig(GPIOE,GPIO_Pin_2,GPIO_Mode_Out_PP,GPIO_Speed_10MHz);		//InsideNetLed
    GpioConfig(GPIOE,GPIO_Pin_3,GPIO_Mode_Out_PP,GPIO_Speed_10MHz);		//ExterNetLed
    GpioConfig(GPIOE,GPIO_Pin_4,GPIO_Mode_Out_PP,GPIO_Speed_10MHz);   //CpuWorkSta

    /*�źŵȼ�ָʾ��io��ʼ��*/
    GpioConfig(GPIOB,GPIO_Pin_8,GPIO_Mode_Out_PP,GPIO_Speed_10MHz);		//��
    GpioConfig(GPIOB,GPIO_Pin_9,GPIO_Mode_Out_PP,GPIO_Speed_10MHz);		//��
    GpioConfig(GPIOE,GPIO_Pin_0,GPIO_Mode_Out_PP,GPIO_Speed_10MHz);   //��
}

void StatusLedOn(void)
{
    MQTTSocketLed(1);
}

void InNetLedOn(void)
{
    InNetLed(1);
}

void StatusLedFlash(void)
{
    static unsigned char status=0;

    MQTTSocketLed(status);
    status =~status;
}


void SysLedFlash(void)
{
    static unsigned char status=0;

    MQTTLed(status);
    InNetLed(InNetLED);

    status =~status;
}

void StatusLedProcess(void)
{
//	static unsigned char status=0;
    static unsigned char flag = 0, flag1 = 0;

    if(MQTTGetConnectStatus() == 0)
    {
        flag = 0;
        StatusLedFlash();
    }
    else if(flag == 0)
    {
        StatusLedOn();  //D4ָʾ����
        flag = 1;
    }

    if(InNetLED)
    {
        InNetLedOn();
    }
    else
    {
        InNetLed(flag1);
        flag1 = ~flag1;
    }
    SysLedFlash();
}

/*
	�������ܣ��ź�ǿ��״ָ̬ʾ�ƣ���4���ȼ����á��С���ޡ�
	���Σ�����Ϊ���ʵʱ��GPRS�ź�ǿ��ֵ�����ģ���52~115db
	���أ���
*/
void SignalStrengthLED(uint8_t csq_val)
{
    switch(csq_val/10)
    {
    case 5:

    case 6:
        GPIO_SetBits(GPIOB, GPIO_Pin_8 | GPIO_Pin_9);   //��
        GPIO_SetBits(GPIOE, GPIO_Pin_0);
        break;
    case 7:

    case 8:
        GPIO_ResetBits(GPIOB, GPIO_Pin_8);							//��
        GPIO_SetBits(GPIOB, GPIO_Pin_9);
        GPIO_SetBits(GPIOE, GPIO_Pin_0);
        break;

    case 9:

    case 10:
        GPIO_ResetBits(GPIOB, GPIO_Pin_8);							//��
        GPIO_ResetBits(GPIOB, GPIO_Pin_9);
        GPIO_SetBits(GPIOE, GPIO_Pin_0);
        break;
    case 11:
        GPIO_ResetBits(GPIOB, GPIO_Pin_8 | GPIO_Pin_9);	//��
        GPIO_ResetBits(GPIOE, GPIO_Pin_0);
        break;

    default :
        break;
    }
}

////////////////////////////////////////////////

/*************************************************
  Function:    ������ʼ��
  Description:
*************************************************/
void ZigbeeNodeListInit(void)
{
    //��������ͷ
    StopNodeListInit();
    GuideNodeListInit();
    LampNodeListInit();
    ChpNodeListInit();
    ChNodeListInit();

    //��ʼ�����ݿ�
    if(f_mount(0, &fs)==0)
    {
        ReadCarTable();					//��ȡ��λ���ݿ�
        ReadGuideTable();				//��ȡ���������ݿ�
        ReadLampTable();				//��ȡָʾ�����ݿ�
        ReadChpTable();					//��ȡͨ���ش����ݿ�
        ReadChTable();					//��ȡͨ�����ݱ�
        ChCntBakReadScan();   	//�ָ�ͨ������������������ϴε����ʱ�򱣴��
    }
}

/*************************************************
  Function:    ������������ʼ��
  Description:
*************************************************/
void ZigbeeNodeMutexInit(void)
{
    StopListMutexInit();
    GuideListMutexInit();
    LampListMutexInit();
    ChpListMutexInit();
    ChListMutexInit();
}

/*************************************************
  Function:    ZigBee�ڵ��������
  Description:
*************************************************/
extern unsigned char FactorySettings;
void ZigbeeNodeManageTask(void const *arg)
{
    unsigned short cnt1=0;
    unsigned short cnt2=2000;
    unsigned short cnt3=0;
//	unsigned short cnt4=0;
    static unsigned short inquireStopLockNum=0;
    unsigned short cnt5=0; //���������Բ�ѯ�ڵ�ش�����

    StatusLedInit();       //״̬LED��ʼ��
    ZigbeeNodeMutexInit(); //ZigBee�ڵ㻥������ʼ��
    ZigbeeNodeListInit();  //ZigBee�ڵ�������ʼ��

    while(1)
    {
#ifdef DOG
        DogClear();
#endif

        StatusLedProcess();
        osDelay(1000);

        if(upgradflag==1)   //������������������ڼ���ϱ�״̬
            continue;

        if(1==FactorySettings)
        {
            printf("zigbeeЭ�������ָ���������\r\n");
            FactorySettings = 0;
            sendSetZiegbee(0xfffd, 0x1a);
			
            if (NetMode == 0x02) //WAN����
            {
				TCP232ReloadFlag = 1;
				if(FLASH_COMPLETE==EE_WriteData(EE_KEY_TCP232_RELOD,&TCP232ReloadFlag,sizeof(TCP232ReloadFlag)))
				{
					printf("TCP232 factory set flag enable\n");
					Reboot();//ģ��ָ��������ú���Ҫ����һ��
				}
            }
        }

        GuideScan();    //ÿ1sͳ��һ��ָʾ����ָʾ��״̬
        LampScan();

        if(cnt1++>60)    // 1����ͬ��ZIGBEEָʾ����ָʾ��״̬
        {
            cnt1=0;
            GuideAdjustScan();
            LampAdjustScan();
        }
        if(cnt2++>1800)    // 30�����ƶ�ͬ��״̬����̨1800
        {
            cnt2=0;
            ZigbeeStatusInit();
        }
        if(cnt3++>6)      // 10 ������һ�����߼��
        {
            cnt3=0;
            ZigbeeCheckProcess();
        }
#if 0
        if(cnt4++>300)		//300 5����ͬ��һ��ͨ���شŽڵ��״̬
        {
            cnt4=0;
            ZigbeeChpStatusInit();
            ZigbeeLampStatusInit();
        }
#endif


#if 0
        if(cnt5++>8)	//8s��ѯһ���ڵ�ĵش�����  �����200���ڵ㣬��ѯһ��ش����ݴ�Լ��Ҫ30���ӣ�������û���������ݴ�ϵ���������¡�
        {
            cnt5 = 0;
            MagneticInquire(inquireStopLockNum++);
            if(inquireStopLockNum >= lockTotleCnt)
            {
                inquireStopLockNum=0;
                printf("��ͷ��ѯ\r\n");
            }
        }
#endif

        ZigbeeSendProcess();
    }
}

/*************************************************
  Function:    zigbee���մ�������
  Description: �����ڵ�������ڵ�״̬�жϺ�״̬�ϴ��ȹ���
*************************************************/
void ZigbeeRevProcessTask(void const * arg)
{
    REVPRO_MSG RevProMsg;
    unsigned int ZigbeeType,NodeID;
    PARK_STOP_NODE *pStopNode; 		//ͣ��λ�ڵ�
    PARK_LAMP_NODE *pLampNode; 		//ָʾ�ƽڵ�
    PARK_GUIDE_NODE *pGuideNode;	//ָʾ�ƽڵ�
    PARK_CHP_NODE *pChpNode;   		//ͨ�����ݽڵ�
    PARK_CH_NODE *pChNode;				//ͨ���شż��ڵ�

//	RevProCreateQueue();
    Msgsobj =  xQueueCreate(15,16);

    ZigbeeProcessStart();

#ifdef LoRa				//����֧��Lora�ڵ㹦�ܣ���������Ԥ������LoRa,ʹ��loraģ�鴮�ڹ���
    LoRaProcessStart();
#endif

    while(1)
    {
        osDelay(10);
#ifdef DOG
        DogClear();
#endif
        if(xQueueReceive(Msgsobj,&RevProMsg,0)==pdPASS)
//		if(RevProPendQueue(&RevProMsg))
        {

            printf("queueMsgCnt[%d]\r\n",queueMsgCnt--);
            if( queueMsgCnt < 15 )
            {
                sendqueueFlag = 0;		//����һ����Ϣ�Ϳ��ԷŽ��ж�һ����Ϣ
            }

            if(ZigbeeIDCheck(RevProMsg.srcID))
                continue ;

            ZigbeeType = RevProMsg.srcID&0xf0000000;
            NodeID = RevProMsg.srcID&0x00000fff;
            switch(RevProMsg.cmd)
            {
            case 0x04:
                printf("[cmd:0x%02x]  ԤԼ��λ0x%04x���س���״̬%d\r\n",RevProMsg.cmd,RevProMsg.srcID,RevProMsg.dat[0]);
                break;

            case 0x0e: //  ������������
                if(ZigbeeType==TYPE_STOP) 	//��λ�ش�����������
                {
                    StopListMutexLock();
                    pStopNode=(PARK_STOP_NODE *)ZigbeeStopAddr[NodeID].NodeAddr;
                    if(pStopNode!=NULL)
                    {
                        pStopNode->Status &=0x7f;
                        pStopNode->ParkTableNode.ZdEnable |=0x80;
                    }
                    StopListMutexUnlock();
                }
                else if(ZigbeeType==TYPE_CHP)//ͨ���ش�����������
                {
                    ChpListMutexLock();
                    pChpNode=(PARK_CHP_NODE *)ZigbeeChpAddr[NodeID].NodeAddr;
                    if(pChpNode!=NULL)
                    {
                        pChpNode->Status &=0x7f;
                        pChpNode->ChpTableNode.ZdEnable |=0x80;
                        pChNode = GetChNodeByChID(pChpNode->ChpTableNode.ChID);
                        if(pChNode!=NULL)
                        {
                            pChNode->Status =1;
                        }
                    }
                    ChpListMutexUnlock();
                }
                break;

            case 0x01:	 //�ն˷������޳�  ��̨��ѯ�󷵻ص�״̬�����ϴ�״̬
                if(ZigbeeType==TYPE_STOP)    //��λ
                {
                    StopListMutexLock();
                    pStopNode=(PARK_STOP_NODE *)ZigbeeStopAddr[NodeID].NodeAddr;
                    if(pStopNode!=NULL)
                    {
                        pStopNode->KeepCnt = 0;
                        pStopNode->Battery = (unsigned short)(RevProMsg.dat[2]<<8)+RevProMsg.dat[1];
                        if(pStopNode->PubFlag)
                        {
                            StopListMutexUnlock();
                            break;
                        }

                        pStopNode->Status = RevProMsg.dat[0]&0x01; //0x01
                        pStopNode->LockStatus = (RevProMsg.dat[0]&0x02)>>1; //0x01
                        pStopNode->UpFlag =0xff;

                        char StatusStr[2][3]= {"��","��"};
                        printf("��λ:0x%x,%s��,����:%04x  status:%x  lock:%x\r\n",RevProMsg.srcID,
                               StatusStr[RevProMsg.dat[0]&0x01],pStopNode->Battery,pStopNode->Status,pStopNode->LockStatus);

                    }
                    StopListMutexUnlock();
                }
                break;

            case 0x02:	 //�ն˷��ػ���ֵ��ֵ��ѯ����
                break;

            case 0x03:
                break;

            case 0x05:	//�ն˷������ÿ���ʱ������
                printf("��������ʱ��\r\n");
                if(ZigbeeType==TYPE_STOP)    //��λ
                {
                    timeLockTemp.timeSetPubFlag = 1;
                    timeLockTemp.lockID = RevProMsg.srcID;
                    timeLockTemp.timeN = 	RevProMsg.dat[0];
                    timeLockTemp.timeC = (unsigned short)(RevProMsg.dat[2]<<8) + RevProMsg.dat[1];
                }
                break;

            case 0x06:	//�ն˷��ص�ǰ�ų�ֵ
                break;

            case 0x07:	//��λ���ն˷����������ü�ʱ��
                if(ZigbeeType==TYPE_STOP)
                {
                    beepVoiceTemp.beepSetPubFlag = 1;
                    beepVoiceTemp.lockID = RevProMsg.srcID;
                    beepVoiceTemp.voiceEnableFlag = RevProMsg.dat[0];
                    beepVoiceTemp.holdtime = (unsigned short)(RevProMsg.dat[2]<<8) + RevProMsg.dat[1];
                }
                break;

            case 0x08:	//��λ�����ع���ʱ��Ӧ��
                if(ZigbeeType==TYPE_STOP)    //��λ
                {
                    faultTimeTemp.timeSetPubFlag = 1;
                    faultTimeTemp.lockID = RevProMsg.srcID;
                    faultTimeTemp.UpFaultTime = 	RevProMsg.dat[0];
                    faultTimeTemp.DownFaultTime = (unsigned short)(RevProMsg.dat[2]<<8) + RevProMsg.dat[1];
                }
                break;

            case 0x09:	//�ն˷����Զ��������г�ʱ����������
                if(ZigbeeType==TYPE_STOP)
                {
                    lockparkTimeTemp.lockingtimeSetPubFlag = 1;
                    lockparkTimeTemp.lockID = RevProMsg.srcID;
                    lockparkTimeTemp.loakingParkTime = (unsigned short)(RevProMsg.dat[2]<<8) + RevProMsg.dat[1];
                }
                break;

            case 0x11:	//�ն˷��ػָ�����Ĭ����������
                printf("��λ��:%x �ѻָ���������\r\n",RevProMsg.srcID);
                if(ZigbeeType==TYPE_STOP)
                {
                    ParameterResetTemp.lockID = RevProMsg.srcID;
                    ParameterResetTemp.ResetPubFlag = 1;
                }
                break;

            case 0x12:	//����ϵ缰ʱ�����÷�������
                printf("����ϵ����÷���\r\n");
                if(ZigbeeType==TYPE_STOP)
                {
                    lockPowerSetTemp.lockpowerSetPubFlag = 1;
                    lockPowerSetTemp.lockID = RevProMsg.srcID;
                    lockPowerSetTemp.enableFlag = RevProMsg.dat[0];			//����ϵ�ʹ��
                    lockPowerSetTemp.coefficient = RevProMsg.dat[1];		//�ο�ϵ����ϵ��ԽСԽ���� 1~20
                    lockPowerSetTemp.holdTime = RevProMsg.dat[2];				//����ʱ��0~20s
                }
                break;

            case 0x0f:	 //�ն�״̬����
                if(ZigbeeType==TYPE_CHP)  //ͨ����ⵥԪ(ͨ���ش�)
                {
                    ChpListMutexLock();
                    pChpNode=(PARK_CHP_NODE *)ZigbeeChpAddr[NodeID].NodeAddr;
                    if(pChpNode!=NULL)
                    {
                        pChpNode->KeepCnt = 0;
                        pChpNode->Battery = (unsigned short)(RevProMsg.dat[2]<<8)+RevProMsg.dat[1];

                        pChpNode->Status = RevProMsg.dat[0]&0x01;//����

                        if(pChpNode->PubFlag)  //ֱ��ͨ���ش�״̬������Ž⿪ͨ���ش�������Դ������
                        {
                            ChpListMutexUnlock();
                            break;
                        }
                        if((pChpNode->Status&0x80)==0x80)//֮ǰΪ���ߣ�Ҫ����״̬
                        {
                            pChpNode->Status = RevProMsg.dat[0]&0x01;
                            pChpNode->UpFlag =0xff;
                        }
//							printf("0x%x��Ԫ״̬%x\r\n",pChpNode->ChpTableNode.ChpID,pChpNode->Status);
                        pChNode = GetChNodeByChID(pChpNode->ChpTableNode.ChID);
                        if(pChNode==NULL)
                        {
                            printf("0x%x��Ԫδ��ͨ��\r\n",RevProMsg.srcID);
                            ChpListMutexUnlock();
                            break;
                        }
                        ChScan(pChNode);   //ͨ����������ͳ��ɨ��
                    }
                    else
                    {
                        printf("0x%x��Ԫδע��\r\n",RevProMsg.srcID);
                        ChpListMutexUnlock();
                        ChpAddNewInitPro(RevProMsg.srcID);
                        ChpListMutexLock();
                    }
                    ChpListMutexUnlock();
                }

                else if(ZigbeeType==TYPE_STOP)    //��λ
                {
                    StopListMutexLock();
                    pStopNode=(PARK_STOP_NODE *)ZigbeeStopAddr[NodeID].NodeAddr;
                    if(pStopNode!=NULL)
                    {
                        pStopNode->NodeVersion = RevProMsg.ver;

                        pStopNode->KeepCnt = 0;
                        pStopNode->Battery = (unsigned short)(RevProMsg.dat[2]<<8)+RevProMsg.dat[1];
                        if(pStopNode->PubFlag)
                        {
                            StopListMutexUnlock();
                            break;
                        }
                        if((pStopNode->Status&0x80)==0x80)    //֮ǰΪ���ߣ�Ҫ����״̬,���λΪ1ʱΪ����
                        {
                            pStopNode->Status = RevProMsg.dat[0]&0x01; //0x01
                            pStopNode->LockStatus = (RevProMsg.dat[0]&0x02)>>1; //0x01
                            pStopNode->UpFlag =0xff;
                        }
                        else if((pStopNode->Status&0x81)==0x01)    //֮ǰΪ�����г�
                        {
                            if((RevProMsg.dat[0]&0x01)==0x00)   		//����Ϊ�����޳�
                            {
                                pStopNode->Status = 0;
                                pStopNode->UpFlag =0xff;							//�г����޳�״̬�仯ʱ����״̬
                            }
                        }
                        else if((pStopNode->Status&0x81)==0x00)   //֮ǰΪ�����޳�
                        {
                            if((RevProMsg.dat[0]&0x01)==0x01)				//����Ϊ�����г�
                            {
                                pStopNode->Status = 0x01;
                                pStopNode->UpFlag =0xff;							//�޳����г�״̬�仯ʱ����״̬
                            }
                        }
                        if((pStopNode->LockStatus&0x81)==0x01)    //֮ǰΪ��������
                        {
                            if((RevProMsg.dat[0]&0x02)==0x00)   		//����Ϊ���߿���
                            {
                                pStopNode->LockStatus = 0;
                                pStopNode->AbnormalStatus = 0;				//����쳣��־���龰Ϊ�ֶ������ͽ���ʱ����쳣��־��
                                pStopNode->UpFlag =0xff;							//����������״̬�仯ʱ����״̬
                            }

                            if(((RevProMsg.dat[0]&0x04)==0x04) && (pStopNode->AbnormalStatus == 0))				//�ӵ����������쳣״̬�ϱ����ݱ�־
                            {
                                printf("��λ��ǿ�а�ѹ����\r\n");
                                pStopNode->AbnormalStatus = 1;
                                pStopNode->UpFlag = 0xff;
                            }

                        }
                        else if((pStopNode->LockStatus&0x81)==0x00)//֮ǰΪ���߿���
                        {
                            if((RevProMsg.dat[0]&0x02)==0x02)				//����Ϊ��������
                            {
                                pStopNode->LockStatus = 1;
                                pStopNode->AbnormalStatus = 0;				//����쳣��־���龰Ϊ�ֶ������ͽ���ʱ����쳣��־��
                                pStopNode->UpFlag =0xff;							//����������״̬�仯ʱ����״̬
                            }

                            if(((RevProMsg.dat[0]&0x04)==0x04) && (pStopNode->AbnormalStatus == 0))				//�ӵ����������쳣״̬�ϱ����ݱ�־
                            {
                                printf("��λ����������\r\n");
                                pStopNode->AbnormalStatus = 1;
                                pStopNode->UpFlag = 0xff;
                            }
                        }
                        char StatusStr[2][3]= {"��","��"};
                        printf("��λ:0x%x,%s��,����:%04x  status:%x  lock:%x abnormal:%x ver:%x\r\n",RevProMsg.srcID,
                               StatusStr[RevProMsg.dat[0]&0x01],pStopNode->Battery,pStopNode->Status,
                               pStopNode->LockStatus,pStopNode->AbnormalStatus,pStopNode->NodeVersion);

                    }
                    else
                    {
                        printf("��λ:0x%xδע��\r\n",RevProMsg.srcID);
                        StopListMutexUnlock();
                        StopAddNewInitPro(RevProMsg.srcID);
                        StopListMutexLock();
                    }
                    StopListMutexUnlock();
                }
                else if(ZigbeeType==TYPE_LAMP)    //��λ��
                {
                    LampListMutexLock();
                    pLampNode=(PARK_LAMP_NODE *)ZigbeeLampAddr[NodeID].NodeAddr;
                    if(pLampNode!=NULL)
                    {
                        pLampNode->KeepCnt = 0;
                        pLampNode->Battery = (unsigned short)(RevProMsg.dat[2]<<8)+RevProMsg.dat[1];	//��ȡָʾ��·�ɽڵ�ĵ�����Ϣ
                        if(pLampNode->PubFlag)
                        {
                            LampListMutexUnlock();
                            break;
                        }
                        if((pLampNode->Status&0x80)==0x80)    //֮ǰΪ���ߣ�Ҫ����״̬
                        {
                            pLampNode->Status &=0x7f;
                            pLampNode->UpFlag =0xff;
                        }
                        pLampNode->Status &=0x7f;
                        printf("[cmd:0x%02x]  ָʾ��0x%x����״̬%d ����:%x\r\n",RevProMsg.cmd,RevProMsg.srcID,pLampNode->Status&0x01, pLampNode->Battery);
                    }
                    else
                    {
                        printf("[cmd:0x%02x]  ָʾ��0x%xδע��\r\n",RevProMsg.cmd,RevProMsg.srcID);

                        LampListMutexUnlock();
                        LampAddNewInitPro(RevProMsg.srcID);
                        LampListMutexLock();
                    }
                    LampListMutexUnlock();
                }
                else if(ZigbeeType==TYPE_GUIDE)    //ָʾ��
                {
                    GuideListMutexLock();
                    pGuideNode=(PARK_GUIDE_NODE *)ZigbeeGuideAddr[NodeID].NodeAddr;
                    if(pGuideNode!=NULL)
                    {
                        pGuideNode->KeepCnt = 0;
                        if(pGuideNode->PubFlag)
                        {
                            GuideListMutexUnlock();
                            break;
                        }
                        if((pGuideNode->Status&0x01)==0x01)    //֮ǰΪ���ߣ�Ҫ����״̬
                        {
                            pGuideNode->Status &=0xfe;
                            pGuideNode->UpFlag =0xff;
                        }
                        pGuideNode->Status &=0xfe;
                        if(((unsigned short)(RevProMsg.dat[2]<<8)+RevProMsg.dat[1])==pGuideNode->EmptyCnt)
                        {
                            printf("[cmd:0x%02x]  ָʾ��:0x%x ���صĿ�λ��Ϊ:%d\r\n",RevProMsg.cmd,RevProMsg.srcID,pGuideNode->EmptyCnt);
                        }
                    }
                    else
                    {
                        printf("[cmd:0x%02x]  ָʾ��:0x%x δע��\r\n",RevProMsg.cmd,RevProMsg.srcID);
                        GuideListMutexUnlock();
                        IndicatorAddNewInitPro(RevProMsg.srcID);
                        GuideListMutexLock();
                    }
                    GuideListMutexUnlock();
                }
                break;

            case 0x10:	//��λ����������ң������������
                if(ZigbeeType==TYPE_STOP)    //��λ
                {
                    controlerSetTemp.controlerStatusPubFlag = 1;
                    controlerSetTemp.CtrlStatus = RevProMsg.dat[0];
                    controlerSetTemp.lockID = RevProMsg.srcID;
                }
                break;

            default:
                break;
            }
        }
        else if(errQUEUE_EMPTY == xQueueReceive(Msgsobj,&RevProMsg,0))
        {
            sendqueueFlag = 0;
            queueMsgCnt = 0;
            //printf("��Ϣ�жӿ���\r\n");
        }

    }
}

////////////////////////////////////////////////////////////////////////////////////
/*************************************************
  Function:    ��λ�����ڵ㴦��
  Description:
*************************************************/
int StopAddPro(cJSON *root)
{
    cJSON *item;
    PARK_STOP_NODE *pParkStopNode;

    taskENTER_CRITICAL();
    pParkStopNode = (PARK_STOP_NODE *)malloc(sizeof(PARK_STOP_NODE));
    if(pParkStopNode ==NULL)
    {
        printf("malloc size:%d fail!\r\n",sizeof(PARK_STOP_NODE));
        taskEXIT_CRITICAL();
        return 0xff;
    }
    memset(pParkStopNode,0,sizeof(PARK_STOP_NODE));
    taskEXIT_CRITICAL();


    item = cJSON_GetObjectItem(root,"CN");
    strcpy((char *)pParkStopNode->ParkTableNode.StopNum,item->valuestring);
    item = cJSON_GetObjectItem(root,"CD");
    sscanf(item->valuestring, "%x", &pParkStopNode->ParkTableNode.StopID);
    item = cJSON_GetObjectItem(root,"AD");
    pParkStopNode->ParkTableNode.Area=item->valuestring[0];
    item = cJSON_GetObjectItem(root,"JZ");
    pParkStopNode->ParkTableNode.ZdEnable =  (unsigned char )atoi(item->valuestring);
    if(AddStopNode(pParkStopNode))
    {
        taskENTER_CRITICAL();
        free(pParkStopNode);   //�����λ�ڵ��Ѿ����ڣ�Ӧ���ͷ��ڴ�
        taskEXIT_CRITICAL();
    }

    return 0;
}

/*************************************************
  Function:    ��λ�����ڵ��ʼ��
  Description:
*************************************************/
int StopAddNewInitPro(unsigned int StopID)
{

    PARK_STOP_NODE *pParkStopNode;

    taskENTER_CRITICAL();
    pParkStopNode = (PARK_STOP_NODE *)malloc(sizeof(PARK_STOP_NODE));
    if(pParkStopNode ==NULL)
    {
        printf("malloc size:%d fail!\r\n",sizeof(PARK_STOP_NODE));
        taskEXIT_CRITICAL();
        return 0xff;
    }
    memset(pParkStopNode,0,sizeof(PARK_STOP_NODE));
    taskEXIT_CRITICAL();


    sprintf((char *)pParkStopNode->ParkTableNode.StopNum,"%x",StopID&0x00000fff);
    pParkStopNode->ParkTableNode.StopID=StopID;
    pParkStopNode->ParkTableNode.Area='A';
    pParkStopNode->ParkTableNode.ZdEnable = 0;
    if(AddStopNode(pParkStopNode))
    {
        taskENTER_CRITICAL();
        free(pParkStopNode);   //�����λ�ڵ��Ѿ����ڣ�Ӧ���ͷ��ڴ�
        taskEXIT_CRITICAL();
    }

    return 0;
}

/*************************************************
  Function:    ����ԤԼ����
  Description: ���ڳ�λԤԼ
*************************************************/
void sendyuyue(int cd,unsigned char cmd)
{
    unsigned char dat[3];

    dat[0]=cmd&0x01;
    dat[1]=0;
    dat[2]=0;
    printf("ԤԼ stop:%d  cmd:%d\r\n",cd,cmd);
    ZigbeeSend(cd,0x04,dat,3);
}

/*************************************************
  Function:    ����ZigBeeЭ�������������������
  Description:
*************************************************/
void sendSetZiegbee(uint16_t panid, uint8_t channel)
{
    printf("panid:%x channel:0x%x\r\n",panid, channel);

    unsigned char coordinateSetSend[18];//���ڴ�������Э���������·�buf
    unsigned char *sendcrc = coordinateSetSend;
    memset(coordinateSetSend,0,sizeof(coordinateSetSend));

    coordinateSetSend[0] = 0xaa;
    coordinateSetSend[1] = 0x55;
    coordinateSetSend[2] = 0x01;

    /*cmd channel len���*/
    coordinateSetSend[11] = 0x15; //cmd	 Э���������������Э���ֶ�
    coordinateSetSend[12] = 0x03; //len
    coordinateSetSend[13] = 0x00;

    coordinateSetSend[14] = channel;     //channel
    coordinateSetSend[15] = panid;       //panid
    coordinateSetSend[16] = panid >> 8;	 //panid

    for(int i=1; i<17; i++) //����У��
    {
        *sendcrc ^= coordinateSetSend[i];
    }
    coordinateSetSend[17] = *sendcrc;
    coordinateSetSend[0] = 0xaa;

    ZigbeeSendBytes(coordinateSetSend, sizeof(coordinateSetSend));
	if(WriteZigbeeParaToFlash(channel,panid)>0)
		printf("zigbee ����MCU FLASH ʧ��\n");
}

//��ѯzigbee�ŵ���panid����
void sendInquiryZigbeeNetworkPara(void)
{
    unsigned char coordinateInquirySend[18];//���ڴ�������Э���������·�buf
    unsigned char *sendcrc = coordinateInquirySend;
    memset(coordinateInquirySend,0,sizeof(coordinateInquirySend));

    coordinateInquirySend[0] = 0xaa;
    coordinateInquirySend[1] = 0x55;
    coordinateInquirySend[2] = 0x01;

    /*cmd channel len���*/
    coordinateInquirySend[11] = 0x65; //cmd	 Э���������������Э���ֶ�


    for(int i=1; i<17; i++) //����У��
    {
        *sendcrc ^= coordinateInquirySend[i];
    }
    coordinateInquirySend[17] = *sendcrc;
    coordinateInquirySend[0] = 0xaa;

//	printf("c[0]%x c[14]%x c[15]%x c[16]%x crc=%x\r\n",coordinateSetSend[0],
//								coordinateSetSend[14],coordinateSetSend[15],
//								coordinateSetSend[16],coordinateSetSend[17]);

    ZigbeeSendBytes(coordinateInquirySend, sizeof(coordinateInquirySend));	
}

void sendSetGatewayID(unsigned int gatewayid)
{
    WriteMd(&gatewayid);
}

void sendSetNetWorkMode(unsigned char netMode)
{
    if(FLASH_COMPLETE==EE_WriteData(EE_KEY_NET_MODE,&netMode,sizeof(netMode)))
        printf("net mode ResetOK,please restart at soon!\n");
}

//��ȡ����ȫ�������������ӡ
void parameterReadAndShow(void)
{
	/*
	{
	"GWID":77, 	//����IDʮ����
	"GWST":0,	//������������״̬
	"NetMode":0,//����ģʽ 0:gprs 1:wan
	"SDU":0,	//�����������Ŀ�flash 0:��֧��sd���� 1:����A�� 2:����B��
	"SIP":"112.74.132.1",//������IP
	"SPT":1884,			 //������port
	"MQTU":"lebo",		 	 //mqtt�û�
	"MQTP":"MQTT-lebo123456",//mqtt����
	"ZBCH":0x1a,	//zigbee�ŵ�
	"ZBPD":0xfff1,	//zigbee��panID
	""
	}
	*/
	//�������涨��
//    cJSON * root =  cJSON_CreateObject();
//	uint8_t tempStr[32] = {0};
//    cJSON_AddItemToObject(root, "GWID", cJSON_CreateNumber(myID));//
//	cJSON_AddItemToObject(root, "GWST", cJSON_CreateNumber(MQTTGetConnectStatus()));//
//	cJSON_AddItemToObject(root, "NetMode", cJSON_CreateNumber(NetMode));//
//	cJSON_AddItemToObject(root, "SDU", cJSON_CreateNumber(SD_Upgrade));//
//	sprintf((char *)tempStr,"%d.%d.%d.%d",serverIp[0],serverIp[1],serverIp[2],serverIp[3]);
//	cJSON_AddItemToObject(root, "SIP", cJSON_CreateString((char *)tempStr));//
//	cJSON_AddItemToObject(root, "SPT", cJSON_CreateNumber(serverPort));//
//	cJSON_AddItemToObject(root, "MQTU", cJSON_CreateString((char *)userName));//
//	cJSON_AddItemToObject(root, "MQTP", cJSON_CreateString((char *)Passwd));//
//	cJSON_AddItemToObject(root, "ZBCH", cJSON_CreateNumber(zigbeeCh));//
//	cJSON_AddItemToObject(root, "ZBPD", cJSON_CreateNumber(zigbeePanID));//

//	printf("��Ϣ��ӡ:");
//    printf("%s\n", cJSON_Print(root));
//	cJSON_Delete(root);

	unsigned char sendBuf[192]={0};
	sprintf((char *)sendBuf,"{\"GWID\":%d,\"GWST\":%d,\"NetMode\":%d,\"SDU\":%d,\"SIP\":\"%d.%d.%d.%d\",\
	\"SPT\":%d,\"MQTU\":\"%s\",\"MQTP\":\"%s\",\"ZBCH\":%d,\"ZBPD\":%d}",
	myID,MQTTGetConnectStatus(),NetMode,SD_Upgrade,serverIp[0],serverIp[1],serverIp[2],serverIp[3],
	serverPort,(char *)userName,(char *)Passwd,zigbeeCh,zigbeePanID);
	printf("��ѯ��Ϣ:%s\n",sendBuf);
	
	sendInquiryZigbeeNetworkPara();
}

/*************************************************
  Function:    ���ն˽ڵ㷢����������
  Description: �����������ڳ�λ�شš�����ͨ���شŵ�
���еشŴ������Ľڵ�Ĵų�У����У���������ƺ�̨����
*************************************************/
void sendZhenDing(int id,unsigned int thresholdValue)
{
    unsigned char dat[3]= {0},tempVerFlag=0;
    unsigned short i;
    PARK_STOP_NODE *tmp;

    dat[0]=1;
    dat[1]=(uint8_t)thresholdValue;
    dat[2]=(uint8_t)(thresholdValue>>8);
    printf("����:%d  thresholdValue:%d\r\n",id,thresholdValue);

    StopListMutexLock();
    for(i=0; i<lockTotleCnt; i++)
    {
        tmp=(PARK_STOP_NODE *)ZigbeeStopAddr[lockNum[i]].NodeAddr;
        if(tmp==0 || (tmp->ParkTableNode.StopID != id)) continue;
        if((tmp->ParkTableNode.StopID == id) && (tmp->NodeVersion == 0))
        {
            tempVerFlag = 0;
            break;
        }
        else if((tmp->ParkTableNode.StopID == id) && (tmp->NodeVersion == 1))
        {
            tempVerFlag = 1;
            break;
        }
    }
    StopListMutexUnlock();

    if(tempVerFlag==0x00)
        ZigbeeSend(id,0x0e,dat,3);//0x0e����Ϊ��������
    else if(tempVerFlag==0x01)
        LoRaSend(id,0x0e,dat,3);//0x0e����Ϊ��������

}

/*************************************************
  Function:    ���ն˽ڵ㷢��ң����������
  Description:
*************************************************/
void sendRemoteControlerEnableSet(int id, unsigned int setVal)
{
    unsigned char dat[3]= {0},tempVerFlag=0;
    unsigned short i;
    PARK_STOP_NODE *tmp;
    dat[0] = setVal;
    dat[1] = 0;
    dat[2] = 0;
    printf("ң������:%x ֵ:%d\r\n",id,setVal);

    StopListMutexLock();
    for(i=0; i<lockTotleCnt; i++)
    {
        tmp=(PARK_STOP_NODE *)ZigbeeStopAddr[lockNum[i]].NodeAddr;
        if(tmp==0 || (tmp->ParkTableNode.StopID != id)) continue;
        if((tmp->ParkTableNode.StopID == id) && (tmp->NodeVersion == 0))
        {
            tempVerFlag = 0;
            break;
        }
        else if((tmp->ParkTableNode.StopID == id) && (tmp->NodeVersion == 1))
        {
            tempVerFlag = 1;
            break;
        }
    }
    StopListMutexUnlock();

    if(tempVerFlag==0x00)
        ZigbeeSend(id,0x10,dat,3);
    else if(tempVerFlag==0x01)
        LoRaSend(id,0x10,dat,3);
}

/*************************************************
  Function:
  Description: ��λ״̬��ѯָ��
*************************************************/
void InquireLockStatus(int id)
{
    unsigned char tempVerFlag=0;
    unsigned short i;
    PARK_STOP_NODE *tmp;

    StopListMutexLock();
    for(i=0; i<lockTotleCnt; i++)
    {
        tmp=(PARK_STOP_NODE *)ZigbeeStopAddr[lockNum[i]].NodeAddr;
        if(tmp==0 || (tmp->ParkTableNode.StopID != id)) continue;
        if((tmp->ParkTableNode.StopID == id) && (tmp->NodeVersion == 0))
        {
            tempVerFlag = 0;
            break;
        }
        else if((tmp->ParkTableNode.StopID == id) && (tmp->NodeVersion == 1))
        {
            tempVerFlag = 1;
            break;
        }
    }
    StopListMutexUnlock();

    if(tempVerFlag==0x00)
        ZigbeeSend(id,0x01,0,3);
    else if(tempVerFlag==0x01)
        LoRaSend(id,0x01,0,3);
}

/*************************************************
  Function:    ��λ����������ʱ����������
  Description:
*************************************************/
void sendLockTimeSet(int id,unsigned int thresholdValue,unsigned int thresholdValue1)
{
    unsigned char dat[3],tempVerFlag=0;
    unsigned short i;
    PARK_STOP_NODE *tmp;
    dat[0]=(uint8_t)thresholdValue;//�г����޳��Զ�����ʱ��
    dat[1]=(uint8_t)thresholdValue1;//�������޳��Զ�����ʱ��
    dat[2]=(uint8_t)(thresholdValue1>>8);
    printf("ʱ���趨:%x  thresholdValue:%d thresholdValue:%d\r\n",id,thresholdValue,thresholdValue1);

    StopListMutexLock();
    for(i=0; i<lockTotleCnt; i++)
    {
        tmp=(PARK_STOP_NODE *)ZigbeeStopAddr[lockNum[i]].NodeAddr;
        if(tmp==0 || (tmp->ParkTableNode.StopID != id)) continue;
        if((tmp->ParkTableNode.StopID == id) && (tmp->NodeVersion == 0))
        {
            tempVerFlag = 0;
            break;
        }
        else if((tmp->ParkTableNode.StopID == id) && (tmp->NodeVersion == 1))
        {
            tempVerFlag = 1;
            break;
        }
    }
    StopListMutexUnlock();

    if(tempVerFlag==0x00)
        ZigbeeSend(id,0x05,dat,3);
    else if(tempVerFlag==0x01)
        LoRaSend(id,0x05,dat,3);//0x50����Ϊ�޳�ʱ�Զ�����ʱ���趨
}

/*************************************************
  Function:    ��λ�����ͷ�����ʱ����������
  Description:
*************************************************/
void BeepSetSend(int id,unsigned char enableFlag, unsigned short holdTime)
{
    unsigned char dat[3],tempVerFlag=0;
    unsigned short i;
    PARK_STOP_NODE *tmp;
    dat[0] = enableFlag;
    dat[1] = (uint8_t)holdTime;
    dat[2] = (uint8_t)(holdTime>>8);
    printf("����������:%x  thresholdValue:%d\r\n",id,holdTime);

    StopListMutexLock();
    for(i=0; i<lockTotleCnt; i++)
    {
        tmp=(PARK_STOP_NODE *)ZigbeeStopAddr[lockNum[i]].NodeAddr;
        if(tmp==0 || (tmp->ParkTableNode.StopID != id)) continue;
        if((tmp->ParkTableNode.StopID == id) && (tmp->NodeVersion == 0))
        {
            tempVerFlag = 0;
            break;
        }
        else if((tmp->ParkTableNode.StopID == id) && (tmp->NodeVersion == 1))
        {
            tempVerFlag = 1;
            break;
        }
    }
    StopListMutexUnlock();

    if(tempVerFlag==0x00)
        ZigbeeSend(id,0x07,dat,3);
    else if(tempVerFlag==0x01)
        LoRaSend(id,0x07,dat,3);//0x07����Ϊ�������趨
}

/*************************************************
  Function:    ��λ�����͹���ʱ����������
  Description:
*************************************************/
void FaultTimeSetSend(int id,unsigned char timeUpFault, unsigned short timeDownFault)
{
    unsigned char dat[3],tempVerFlag=0;
    unsigned short i;
    PARK_STOP_NODE *tmp;

    dat[0] = timeUpFault;
    dat[1] = (uint8_t)timeDownFault;
    dat[2] = (uint8_t)(timeDownFault>>8);
    printf("����ʱ������:%x  thresholdValue:%d\r\n",id,timeDownFault);

    StopListMutexLock();
    for(i=0; i<lockTotleCnt; i++)
    {
        tmp=(PARK_STOP_NODE *)ZigbeeStopAddr[lockNum[i]].NodeAddr;
        if(tmp==0 || (tmp->ParkTableNode.StopID != id)) continue;
        if((tmp->ParkTableNode.StopID == id) && (tmp->NodeVersion == 0))
        {
            tempVerFlag = 0;
            break;
        }
        else if((tmp->ParkTableNode.StopID == id) && (tmp->NodeVersion == 1))
        {
            tempVerFlag = 1;
            break;
        }
    }
    StopListMutexUnlock();

    if(tempVerFlag==0x00)
        ZigbeeSend(id,0x08,dat,3);
    else if(tempVerFlag==0x01)
        LoRaSend(id,0x08,dat,3);//0x08����Ϊ����ʱ���趨

}

/*************************************************
  Function:    ��λ�������Զ������г�ʱ������
  Description:
*************************************************/
void LockingWithParkedTimeSetSend(int id,unsigned short setTime)
{
    unsigned char dat[3],tempVerFlag=0;
    unsigned short i;
    PARK_STOP_NODE *tmp;

    dat[0] = 0;
    dat[1] = (uint8_t)setTime;
    dat[2] = (uint8_t)(setTime>>8);
    printf("�г��Զ�����:%x  thresholdValue:%d\r\n",id,setTime);

    StopListMutexLock();
    for(i=0; i<lockTotleCnt; i++)
    {
        tmp=(PARK_STOP_NODE *)ZigbeeStopAddr[lockNum[i]].NodeAddr;
        if(tmp==0 || (tmp->ParkTableNode.StopID != id)) continue;
        if((tmp->ParkTableNode.StopID == id) && (tmp->NodeVersion == 0))
        {
            tempVerFlag = 0;
            break;
        }
        else if((tmp->ParkTableNode.StopID == id) && (tmp->NodeVersion == 1))
        {
            tempVerFlag = 1;
            break;
        }
    }
    StopListMutexUnlock();

    if(tempVerFlag==0x00)
        ZigbeeSend(id,0x09,dat,3);
    else if(tempVerFlag==0x01)
        LoRaSend(id,0x09,dat,3);//0x09����Ϊ�Զ������г�ʱ������

}

/*************************************************
  Function:    ����ϵ���������·�
 * Serializes the connect options into the buffer.
  * @param ��λ��id
  * @param ����ϵ�ʹ��
  * @param �����ж�ϵ����ԽСԽ���� ��Χ1-20
  * @param ����ʱ������Χ0-20s
  * @return serialized length, or error if 0
*************************************************/
void HinderPowerOffSetSend(unsigned int id, uint8_t enableFlag, uint8_t coefficient, uint8_t holdTime)
{
    unsigned char dat[3],tempVerFlag=0;
    unsigned short i;
    PARK_STOP_NODE *tmp;

    dat[0] = enableFlag;
    dat[1] = coefficient;
    dat[2] = holdTime;
    printf("����ϵ�����:%x  eb:%x cc:%d tm:%d \r\n",id,enableFlag,coefficient,holdTime);

    StopListMutexLock();
    for(i=0; i<lockTotleCnt; i++)
    {
        tmp=(PARK_STOP_NODE *)ZigbeeStopAddr[lockNum[i]].NodeAddr;
        if(tmp==0 || (tmp->ParkTableNode.StopID != id)) continue;
        if((tmp->ParkTableNode.StopID == id) && (tmp->NodeVersion == 0))
        {
            tempVerFlag = 0;
            break;
        }
        else if((tmp->ParkTableNode.StopID == id) && (tmp->NodeVersion == 1))
        {
            tempVerFlag = 1;
            break;
        }
    }
    StopListMutexUnlock();

    if(tempVerFlag==0x00)
        ZigbeeSend(id,0x12,dat,3);
    else if(tempVerFlag==0x01)
        LoRaSend(id,0x12,dat,3);//0x12����ϵ�ʱ������
}

/*************************************************
  Function:    ��λ������
  Description: �����ƶ˳�λ�����������
*************************************************/
int StopLockPro(cJSON *root)
{
    cJSON *item;
    PARK_STOP_NODE *tmp;
    unsigned short i;
    unsigned int cd;
    unsigned char dat[3]= {0},cmd,tempVerFlag=0;

//	item = cJSON_GetObjectItem(root,"VER");
//	sscanf(item->valuestring, "%x", &nodeVer);
    item = cJSON_GetObjectItem(root,"CD");
    sscanf(item->valuestring, "%x", &cd);
    item = cJSON_GetObjectItem(root,"CL");
    cmd =  (unsigned char )atoi(item->valuestring);

    dat[0]=cmd&0x01;
    dat[1]=0;
    dat[2]=0;

    StopListMutexLock();
    for(i=0; i<lockTotleCnt; i++)
    {
        tmp=(PARK_STOP_NODE *)ZigbeeStopAddr[lockNum[i]].NodeAddr;
        if(tmp==0 || (tmp->ParkTableNode.StopID != cd)) continue;
        if((tmp->ParkTableNode.StopID == cd) && (tmp->NodeVersion == 0))
        {
            tempVerFlag = 0;
            break;
        }
        else if((tmp->ParkTableNode.StopID == cd) && (tmp->NodeVersion == 1))
        {
            tempVerFlag = 1;
            break;
        }
    }
    StopListMutexUnlock();

    if(tempVerFlag==0x00)
        ZigbeeSend(cd,0x04,dat,3);
    else if(tempVerFlag==0x01)
        LoRaSend(cd,0x04,dat,3);

    printf("car:%d,lock status :%d\r\n",cd,dat[0]);

    _MQTTPublishCarLockStatus(cd,dat[0]);

    return 0;
}

/*************************************************
  Function:    ͣ��λ�ش����ô���
  Description:
*************************************************/
int StopSettingPro(cJSON *dat,unsigned short len)
{
    int i,size;
    cJSON *root;


    size = cJSON_GetArraySize(dat);
    if(size!=len)
    {
        printf("size:%d != len:%d\r\n",size,len);
        return 1;
    }

    for(i=0; i<size; i++)
    {
        root = cJSON_GetArrayItem(dat,i);
        if(StopAddPro(root))
        {
            printf("size:%d len:%d\r\n",size,len);
            return 1;
        }
    }

    return 0;
}

////////////////////////////////////////////////////////////////////////////////////
/*************************************************
  Function:    ָʾ�������ڵ㴦��
  Description: �Ӻ�̨�������ػ�������ڵ㲢������Ӧ
��������д��SD����
*************************************************/
int IndicatorAddPro(cJSON *root)
{
    cJSON *item,*items;
    PARK_GUIDE_NODE *pGuideNode;
//	char *out;
    unsigned short size,i;

    taskENTER_CRITICAL();
    pGuideNode = (PARK_GUIDE_NODE *)malloc(sizeof(PARK_GUIDE_NODE));
    if(pGuideNode ==NULL)
    {
        printf("malloc size:%d fail!\r\n",sizeof(PARK_GUIDE_NODE));
        taskEXIT_CRITICAL();
        return 0xff;
    }
    memset(pGuideNode,0,sizeof(PARK_GUIDE_NODE));
    taskEXIT_CRITICAL();

    item = cJSON_GetObjectItem(root,"IN");//ָʾ������
    strcpy((char *)pGuideNode->GuideTableNode.GuideNum,item->valuestring);
    item = cJSON_GetObjectItem(root,"ID");//ָʾ��ID
    sscanf(item->valuestring, "%x", &pGuideNode->GuideTableNode.GuideID);
    item = cJSON_GetObjectItem(root,"CL");//ָʾ�ĳ�λ����
    sscanf(item->valuestring, "%d", &pGuideNode->GuideTableNode.StopCnt);

    item = cJSON_GetObjectItem(root,"CD");//ָʾ�ĳ�λID����
    size = cJSON_GetArraySize(item);
    if(size!=pGuideNode->GuideTableNode.StopCnt)
    {
        return 0xff;
    }
    for(i=0; i<size; i++)
    {
        items = cJSON_GetArrayItem(item,i);
        sscanf(items->valuestring, "%x", &pGuideNode->GuideTableNode.StopTable[i]);
    }
    if(AddGuideNode(pGuideNode))
    {
        taskENTER_CRITICAL();
        free(pGuideNode);
        taskEXIT_CRITICAL();
    }

    return 0;
}

/*************************************************
  Function:    �����������ڵ��ʼ��
  Description:
*************************************************/
int IndicatorAddNewInitPro(unsigned int IndicatorID)
{

    PARK_GUIDE_NODE *pGuideNode;


    taskENTER_CRITICAL();
    pGuideNode = (PARK_GUIDE_NODE *)malloc(sizeof(PARK_GUIDE_NODE));
    if(pGuideNode ==NULL)
    {
        printf("malloc size:%d fail!\r\n",sizeof(PARK_GUIDE_NODE));
        taskEXIT_CRITICAL();
        return 0xff;
    }
    memset(pGuideNode,0,sizeof(PARK_GUIDE_NODE));
    taskEXIT_CRITICAL();

    sprintf((char *)pGuideNode->GuideTableNode.GuideNum,"%x",IndicatorID&0x00000fff);
    pGuideNode->GuideTableNode.GuideID = IndicatorID;
    pGuideNode->GuideTableNode.StopCnt = 0;
    if(AddGuideNode(pGuideNode))
    {
        taskENTER_CRITICAL();
        free(pGuideNode);
        taskEXIT_CRITICAL();
    }

    return 0;
}

/*************************************************
  Function:    ���������ô���
  Description: ������������̨��������
*************************************************/
int IndicatorSettingPro(cJSON *dat,unsigned short len)
{
    int i,size;
    cJSON *root;


    size = cJSON_GetArraySize(dat);
    if(size!=len)
    {
        printf("size:%d != len:%d\r\n",size,len);
        return 1;
    }
    for(i=0; i<size; i++)
    {
        root = cJSON_GetArrayItem(dat,i);
        if(IndicatorAddPro(root))
        {
            printf("size:%d len:%d\r\n",size,len);
            return 1;
        }
    }
    return 0;
}

/*************************************************
  Function:    ָʾ����������
  Description: ��̨�������������ڵ����������д��SD��
*************************************************/
int LampAddPro(cJSON *root)
{
    cJSON *item,*items;
    PARK_LAMP_NODE *pLampNode;

    unsigned short size,i;

    taskENTER_CRITICAL();
    pLampNode = (PARK_LAMP_NODE *)malloc(sizeof(PARK_LAMP_NODE));
    if(pLampNode ==NULL)
    {
        printf("malloc size:%d fail!\r\n",sizeof(PARK_LAMP_NODE));
        taskEXIT_CRITICAL();
        return 0xff;
    }
    memset(pLampNode,0,sizeof(PARK_LAMP_NODE));
    taskEXIT_CRITICAL();

    item = cJSON_GetObjectItem(root,"GN");//ָʾ������
    strcpy((char *)pLampNode->LampTableNode.LampNum,item->valuestring);
    item = cJSON_GetObjectItem(root,"GD");//ָʾ��ID
    sscanf(item->valuestring, "%x", &pLampNode->LampTableNode.LampID);
    item = cJSON_GetObjectItem(root,"CL");//ָʾ�ĳ�λ����
    sscanf(item->valuestring, "%d", &pLampNode->LampTableNode.StopCnt);

    item = cJSON_GetObjectItem(root,"CD");//ָʾ�ĳ�λID
    size = cJSON_GetArraySize(item);
    if(size!=pLampNode->LampTableNode.StopCnt)
        return 1;

    for(i=0; i<size; i++)
    {
        items = cJSON_GetArrayItem(item,i);
        sscanf(items->valuestring, "%x", &pLampNode->LampTableNode.StopTable[i]);
    }

    if(AddLampNode(pLampNode))
    {
        taskENTER_CRITICAL();
        free(pLampNode);
        taskEXIT_CRITICAL();
    }

    return 0;
}

/*************************************************
  Function:    ָʾ�������ڵ��ʼ������
  Description:
*************************************************/
int LampAddNewInitPro(unsigned int LampID)
{

    PARK_LAMP_NODE *pLampNode;



    taskENTER_CRITICAL();
    pLampNode = (PARK_LAMP_NODE *)malloc(sizeof(PARK_LAMP_NODE));
    if(pLampNode ==NULL)
    {
        printf("malloc size:%d fail!\r\n",sizeof(PARK_LAMP_NODE));
        taskEXIT_CRITICAL();
        return 0xff;
    }
    memset(pLampNode,0,sizeof(PARK_LAMP_NODE));
    taskEXIT_CRITICAL();

    sprintf((char *)pLampNode->LampTableNode.LampNum,"%x",LampID&0x00000fff);
    pLampNode->LampTableNode.LampID =LampID;

    if(AddLampNode(pLampNode))
    {
        taskENTER_CRITICAL();
        free(pLampNode);
        taskEXIT_CRITICAL();
    }

    return 0;
}


/*************************************************
  Function:    ͨ���شż��ڵ���������
  Description: ����ƽ̨��������ͨ���ش�ʱ�������
�����ڵ㣬�ͽ�����뵽��Ӧ�����У����ں���д��SD����
*************************************************/
int ChpAddPro(cJSON *root)
{
    cJSON *item;
    PARK_CHP_NODE *pParkChpNode;

    taskENTER_CRITICAL();
    pParkChpNode = (PARK_CHP_NODE *)malloc(sizeof(PARK_CHP_NODE));
    if(pParkChpNode ==NULL)
    {
        printf("malloc size:%d fail!\r\n",sizeof(PARK_CHP_NODE));
        taskEXIT_CRITICAL();
        return 0xff;
    }
    memset(pParkChpNode,0,sizeof(PARK_CHP_NODE));
    taskEXIT_CRITICAL();

    item = cJSON_GetObjectItem(root,"PD");//���ڵ�ID
    sscanf(item->valuestring, "%x", &pParkChpNode->ChpTableNode.ChpID);
    item = cJSON_GetObjectItem(root,"CHD");//����ͨ�����
    sscanf(item->valuestring, "%x", &pParkChpNode->ChpTableNode.ChID);
    item = cJSON_GetObjectItem(root,"JZ");//��ʾ�Ƿ�У׼
    pParkChpNode->ChpTableNode.ZdEnable =  (unsigned char )atoi(item->valuestring);

    if(AddChpNode(pParkChpNode))
    {
        taskENTER_CRITICAL();
        free(pParkChpNode);   //�����λ�ڵ��Ѿ����ڣ�Ӧ���ͷ��ڴ�
        taskEXIT_CRITICAL();
    }

    return 0;
}

/*************************************************
  Function:    ͨ���ش������ڵ���Ϣ��ʼ������
  Description:
*************************************************/
int ChpAddNewInitPro(unsigned int ChpID)
{

    PARK_CHP_NODE *pParkChpNode;

    taskENTER_CRITICAL();
    pParkChpNode = (PARK_CHP_NODE *)malloc(sizeof(PARK_CHP_NODE));
    if(pParkChpNode ==NULL)
    {
        printf("malloc size:%d fail!\r\n",sizeof(PARK_CHP_NODE));
        taskEXIT_CRITICAL();
        return 0xff;
    }
    memset(pParkChpNode,0,sizeof(PARK_CHP_NODE));
    taskEXIT_CRITICAL();

    pParkChpNode->ChpTableNode.ChID =1;
    pParkChpNode->ChpTableNode.ChpID =ChpID;
    pParkChpNode->ChpTableNode.ZdEnable =0;

    if(AddChpNode(pParkChpNode))
    {
        taskENTER_CRITICAL();
        free(pParkChpNode);   //�����λ�ڵ��Ѿ����ڣ�Ӧ���ͷ��ڴ�
        taskEXIT_CRITICAL();
    }

    return 0;
}

/*************************************************
  Function:    ͨ����������
  Description:
*************************************************/
int ChAddPro(cJSON *root)
{
    cJSON *item,*items;
    PARK_CH_NODE *pChNode;

    unsigned short size,i;

    taskENTER_CRITICAL();
    pChNode = (PARK_CH_NODE *)malloc(sizeof(PARK_CH_NODE));
    if(pChNode ==NULL)
    {
        printf("malloc size:%d fail!\r\n",sizeof(PARK_CH_NODE));
        taskEXIT_CRITICAL();
        return 0xff;
    }
    memset(pChNode,0,sizeof(PARK_CH_NODE));
    taskEXIT_CRITICAL();

    item = cJSON_GetObjectItem(root,"CHD");//ͨ�����
    sscanf(item->valuestring, "%x", &pChNode->ChTableNode.ChID);
    item = cJSON_GetObjectItem(root,"PL");//��ͨ�����ڵ������
    sscanf(item->valuestring, "%d", &pChNode->ChTableNode.ChpCnt);
    item = cJSON_GetObjectItem(root,"CHT");//ͨ������
    sscanf(item->valuestring, "%d", &pChNode->Cnt);

    item = cJSON_GetObjectItem(root,"PD");//��ͨ�����ڵ��ID
    size = cJSON_GetArraySize(item);
    if(size!=pChNode->ChTableNode.ChpCnt)
        return 1;

    for(i=0; i<size; i++)
    {
        items = cJSON_GetArrayItem(item,i);
        sscanf(items->valuestring, "%x", &pChNode->ChTableNode.ChpTable[i]);
    }

    if(AddChNode(pChNode))
    {
        taskENTER_CRITICAL();
        free(pChNode);
        taskEXIT_CRITICAL();
    }

    return 0;
}

/*************************************************
  Function:    ָʾ�����ô���
  Description:
*************************************************/
int LampSettingPro(cJSON *dat,unsigned short len)
{
    int i,size;
    cJSON *root;


    size = cJSON_GetArraySize(dat);
    if(size!=len)
    {
        printf("size:%d != len:%d\r\n",size,len);
        return 1;
    }
    for(i=0; i<size; i++)
    {
        root = cJSON_GetArrayItem(dat,i);
        if(LampAddPro(root))
        {
            printf("size:%d len:%d\r\n",size,len);
            return 1;
        }
    }
    return 0;
}

/*************************************************
  Function:    ͨ���ش����ô���
  Description:
*************************************************/
int ChpSettingPro(cJSON *dat,unsigned short len)
{
    int i,size;
    cJSON *root;


    size = cJSON_GetArraySize(dat);
    if(size!=len)
    {
        printf("size:%d != len:%d\r\n",size,len);
        return 1;
    }
    for(i=0; i<size; i++)
    {
        root = cJSON_GetArrayItem(dat,i);
        if(ChpAddPro(root))
        {
            printf("size:%d len:%d\r\n",size,len);
            return 1;
        }
    }
    return 0;
}

/*************************************************
  Function:    ͨ�����ô���
  Description:
*************************************************/
int ChSettingPro(cJSON *dat,unsigned short len)
{
    int i,size;
    cJSON *root;


    size = cJSON_GetArraySize(dat);
    if(size!=len)
    {
        printf("size:%d != len:%d\r\n",size,len);
        return 1;
    }
    for(i=0; i<size; i++)
    {
        root = cJSON_GetArrayItem(dat,i);
        if(ChAddPro(root))
        {
            printf("size:%d len:%d\r\n",size,len);
            return 1;
        }
    }
    return 0;
}



////////////////////////////////////////////////////////////////////////////////////

/*************************************************
  Function:    дͣ��λ���ݱ�
  Description:
*************************************************/
int WriteCarTable(void)
{
    FRESULT res;
    FIL file;
    unsigned int len;
    struct list_head *stopnode;
    PARK_STOP_NODE *tmp;

    res = f_unlink("CarTable.txt");    //ɾ��
    if(res!=FR_OK)
    {
        return 0xff;
    }
    res = f_open(&file,"CarTable.txt", FA_OPEN_ALWAYS|FA_WRITE|FA_READ);
    if(res!=FR_OK)
    {
        printf("��CarTable ʧ��\r\n");
        return 0xff;
    }
    StopListMutexLock();

    __list_for_each(stopnode, &stophead)
    {
        tmp = list_entry(stopnode,PARK_STOP_NODE, list);
        res = f_write(&file, &tmp->ParkTableNode,sizeof(PARK_TABLE_NODE), &len);
        printf("write stop 0x%x [%d]\r\n",tmp->ParkTableNode.StopID,res);
    }
    StopListMutexUnlock();
    f_close(&file);

    return 0;
}


/*************************************************
  Function:    ��ͣ��λ���ݱ�
  Description:
*************************************************/
int ReadCarTable(void)
{
    FRESULT res;
    FIL file;
    unsigned int len;

    PARK_STOP_NODE *tmp;

    res = f_open(&file,"CarTable.txt",FA_OPEN_ALWAYS |FA_READ);
    if(res!=FR_OK)
    {
        printf("��CarTable ʧ��[%d]\r\n",res);
        return 0xff;
    }
    res = f_lseek(&file,0);
    while(1)
    {
        taskENTER_CRITICAL();
        tmp = (PARK_STOP_NODE *)malloc(sizeof(PARK_STOP_NODE));
        if(tmp ==NULL)
        {
            printf("malloc size:%d fail!\r\n",sizeof(PARK_STOP_NODE));
            taskEXIT_CRITICAL();
            return 0xff;
        }
        res = f_read(&file, &tmp->ParkTableNode,sizeof(PARK_TABLE_NODE), &len);
        taskEXIT_CRITICAL();
        if(res || (len == 0) ||AddStopNode(tmp))
        {
            taskENTER_CRITICAL();
            free(tmp);
            taskEXIT_CRITICAL();
            break;
        }
        printf("read stop 0x%x [%d]\r\n",tmp->ParkTableNode.StopID,res);
    }

    f_close(&file);

    return 0;
}

/*************************************************
  Function:    дͨ���ش����ݱ�
  Description:
*************************************************/
int WriteChpTable(void)
{
    FRESULT res;
    FIL file;
    unsigned int len;
    struct list_head *chpnode;
    PARK_CHP_NODE *tmp;

    res = f_unlink("ChpTable.txt");    //ɾ��
    if(res!=FR_OK)
    {
        return 0xff;
    }
    res = f_open(&file,"ChpTable.txt", FA_OPEN_ALWAYS|FA_WRITE|FA_READ);
    if(res!=FR_OK)
    {
        printf("��ChpTable ʧ��\r\n");
        return 0xff;
    }
    ChpListMutexLock();
    __list_for_each(chpnode, &chphead)
    {
        tmp = list_entry(chpnode,PARK_CHP_NODE, list);
        res = f_write(&file, &tmp->ChpTableNode,sizeof(CHP_TABLE_NODE), &len);
        printf("write chp 0x%x [%d]\r\n",tmp->ChpTableNode.ChpID,res);
    }
    ChpListMutexUnlock();
    f_close(&file);

    return 0;
}


/*************************************************
  Function:    ��ͨ���ش����ݱ�
  Description:
*************************************************/
int ReadChpTable(void)
{
    FRESULT res;
    FIL file;
    unsigned int len;

    PARK_CHP_NODE *tmp;

    res = f_open(&file,"ChpTable.txt",FA_OPEN_ALWAYS |FA_READ);
    if(res!=FR_OK)
    {
        printf("��ChpTable ʧ��[%d]\r\n",res);
        return 0xff;
    }
    res = f_lseek(&file,0);
    while(1)
    {
        taskENTER_CRITICAL();
        tmp = (PARK_CHP_NODE *)malloc(sizeof(PARK_CHP_NODE));
        if(tmp ==NULL)
        {
            printf("malloc size:%d fail!\r\n",sizeof(PARK_CHP_NODE));
            taskEXIT_CRITICAL();
            return 0xff;
        }
        res = f_read(&file, &tmp->ChpTableNode,sizeof(CHP_TABLE_NODE), &len);
        taskEXIT_CRITICAL();
        if(res || (len == 0) ||AddChpNode(tmp))
        {
            taskENTER_CRITICAL();
            free(tmp);
            taskEXIT_CRITICAL();
            break;
        }
//		printf("read chp 0x%x [%d]\r\n",tmp->ChpTableNode.ChpID,res);
    }
    f_close(&file);

    return 0;
}

/*************************************************
  Function:    дͨ�����ݱ�
  Description:
*************************************************/
int WriteChTable(void)
{
    FRESULT res;
    FIL file;
    unsigned int len;
    struct list_head *chnode;
    PARK_CH_NODE *tmp;

    res = f_unlink("ChTable.txt");    //ɾ��
    if(res!=FR_OK)
    {
        return 0xff;
    }
    res = f_open(&file,"ChTable.txt", FA_OPEN_ALWAYS|FA_WRITE|FA_READ);
    if(res!=FR_OK)
    {
        printf("��ChTable ʧ��\r\n");
        return 0xff;
    }
    ChListMutexLock();
    __list_for_each(chnode, &chhead)
    {
        tmp = list_entry(chnode,PARK_CH_NODE, list);
        res = f_write(&file, &tmp->ChTableNode,sizeof(CH_TABLE_NODE), &len);
        printf("write chp 0x%x [%d]\r\n",tmp->ChTableNode.ChID,res);
    }
    ChListMutexUnlock();
    f_close(&file);

    return 0;
}


/*************************************************
  Function:    ��ͨ�����ݱ�
  Description:
*************************************************/
int ReadChTable(void)
{
    FRESULT res;
    FIL file;
    unsigned int len;

    PARK_CH_NODE *tmp;

    res = f_open(&file,"ChTable.txt",FA_OPEN_ALWAYS |FA_READ);
    if(res!=FR_OK)
    {
        printf("��ChTable ʧ��[%d]\r\n",res);
        return 0xff;
    }
    res = f_lseek(&file,0);
    while(1)
    {
        taskENTER_CRITICAL();
        tmp = (PARK_CH_NODE *)malloc(sizeof(PARK_CH_NODE));
        if(tmp ==NULL)
        {
            printf("malloc size:%d fail!\r\n",sizeof(PARK_CH_NODE));
            taskEXIT_CRITICAL();
            return 0xff;
        }
        res = f_read(&file, &tmp->ChTableNode,sizeof(CH_TABLE_NODE), &len);
        taskEXIT_CRITICAL();
        if(res || (len == 0)||AddChNode(tmp))
        {
            taskENTER_CRITICAL();
            free(tmp);
            taskEXIT_CRITICAL();
            break;
        }
        printf("read ch 0x%x [%d]\r\n",tmp->ChTableNode.ChID,res);
    }

    f_close(&file);

    return 0;
}

/*************************************************
  Function:    д���������ݱ�
  Description:
*************************************************/
int WriteGuideTable(void)
{
    FRESULT res;
    FIL file;
    unsigned int len;
    struct list_head *stopnode;
    PARK_GUIDE_NODE *tmp;

    res = f_unlink("Guide.txt");    //ɾ��
    if(res!=FR_OK)
    {
        return 0xff;
    }
    res = f_open(&file,"Guide.txt", FA_OPEN_ALWAYS|FA_WRITE|FA_READ);
    if(res!=FR_OK)
    {
        printf("��Guide ʧ��\r\n");
        return 0xff;
    }

    GuideListMutexLock();
    __list_for_each(stopnode, &guidehead)
    {
        tmp = list_entry(stopnode,PARK_GUIDE_NODE, list);
        res = f_write(&file, &tmp->GuideTableNode,sizeof(INDICATOR_TABLE_NODE), &len);
        printf("write Guide 0x%x [%d]\r\n",tmp->GuideTableNode.GuideID,res);
    }
    GuideListMutexUnlock();

    f_close(&file);

    return 0;
}

/*************************************************
  Function:    �����������ݱ�
  Description:
*************************************************/
int ReadGuideTable(void)
{
    FRESULT res;
    FIL file;
    unsigned int len;

    PARK_GUIDE_NODE *tmp;

    res = f_open(&file,"Guide.txt",FA_OPEN_ALWAYS |FA_READ |FA_WRITE);
    if(res!=FR_OK)
    {
        printf("��GuideTable ʧ��[%d]\r\n",res);
        return 0xff;
    }
    res = f_lseek(&file,0);
    while(1)
    {
        taskENTER_CRITICAL();
        tmp = (PARK_GUIDE_NODE *)malloc(sizeof(PARK_GUIDE_NODE));
        if(tmp ==NULL)
        {
            printf("malloc size:%d fail!\r\n",sizeof(PARK_GUIDE_NODE));
            taskEXIT_CRITICAL();
            return 0xff;
        }
        res = f_read(&file, &tmp->GuideTableNode,sizeof(INDICATOR_TABLE_NODE), &len);
        taskEXIT_CRITICAL();
        if(res || (len == 0) || AddGuideNode(tmp))
        {
            taskENTER_CRITICAL();
            free(tmp);
            taskEXIT_CRITICAL();
            break;
        }
        printf("read Guide 0x%x [%d]\r\n",tmp->GuideTableNode.GuideID,res);
    }

    f_close(&file);

    return 0;
}

/*************************************************
  Function:    д����ָʾ�����ݱ�
  Description:
*************************************************/
int WriteLampTable(void)
{
    FRESULT res;
    FIL file;
    unsigned int len;
    struct list_head *node;
    PARK_LAMP_NODE *tmp;

    res = f_unlink("Lamp.txt");    //ɾ��
    if(res!=FR_OK)
    {
        return 0xff;
    }
    res = f_open(&file,"Lamp.txt", FA_OPEN_ALWAYS|FA_WRITE|FA_READ);
    if(res!=FR_OK)
    {
        printf("��Lamp ʧ��\r\n");
        return 0xff;
    }
    //res = f_lseek(&file,0);

    LampListMutexLock();
    __list_for_each(node, &lamphead)
    {
        tmp = list_entry(node,PARK_LAMP_NODE, list);
        res = f_write(&file, &tmp->LampTableNode,sizeof(LAMP_TABLE_NODE), &len);
        printf("write Lamp 0x%x [%d]\r\n",tmp->LampTableNode.LampID,res);
    }
    LampListMutexUnlock();

    f_close(&file);

    return 0;
}

/*************************************************
  Function:    ������ָʾ�����ݱ�
  Description:
*************************************************/
int ReadLampTable(void)
{
    FRESULT res;
    FIL file;
    unsigned int len;
    PARK_LAMP_NODE *tmp;

    res = f_open(&file,"Lamp.txt",FA_OPEN_ALWAYS |FA_READ |FA_WRITE);
    if(res!=FR_OK)
    {
        printf("��Lamp ʧ��[%d]\r\n",res);
        return 0xff;
    }
    res = f_lseek(&file,0);
    while(1)
    {
        taskENTER_CRITICAL();
        tmp = (PARK_LAMP_NODE *)malloc(sizeof(PARK_LAMP_NODE));
        if(tmp ==NULL)
        {
            printf("malloc size:%d fail!\r\n",sizeof(PARK_LAMP_NODE));
            taskEXIT_CRITICAL();
            return 0xff;
        }
        res = f_read(&file, &tmp->LampTableNode,sizeof(LAMP_TABLE_NODE), &len);
        taskEXIT_CRITICAL();
        if(res || (len == 0) ||AddLampNode(tmp))
        {
            taskENTER_CRITICAL();
            free(tmp);
            taskEXIT_CRITICAL();
            break;
        }
        printf("read Lamp 0x%x [%d]\r\n",tmp->LampTableNode.LampID,res);
    }

    f_close(&file);

    return 0;
}

////////////�ź�����������������װ////////////

void StopListMutexInit(void)
{
    MsgsStopList = xSemaphoreCreateMutex();
    if(MsgsStopList ==NULL)
    {
        printf("[MUTEX] MsgsStopList Creat Fail!\r\n");
    }
}

int StopListMutexLock(void)
{
    return xSemaphoreTake(MsgsStopList, portMAX_DELAY);
}

int StopListMutexUnlock(void)
{
    return xSemaphoreGive(MsgsStopList);
}

void GuideListMutexInit(void)
{
    MsgsGuideList = xSemaphoreCreateMutex();
    if(MsgsGuideList ==NULL)
    {
        printf("[MUTEX] MsgsGuideList Creat Fail!\r\n");
    }
}

int GuideListMutexLock(void)
{
    return xSemaphoreTake(MsgsGuideList, portMAX_DELAY);
}

int GuideListMutexUnlock(void)
{
    return xSemaphoreGive(MsgsGuideList);
}

void LampListMutexInit(void)
{
    MsgsLampList = xSemaphoreCreateMutex();
    if(MsgsLampList ==NULL)
    {
        printf("[MUTEX] MsgsLampList Creat Fail!\r\n");
    }
}


int LampListMutexLock(void)
{
    return xSemaphoreTake(MsgsLampList, portMAX_DELAY);
}


int LampListMutexUnlock(void)
{
    return xSemaphoreGive(MsgsLampList);
}


void ChpListMutexInit(void)
{
    MsgsChpList = xSemaphoreCreateMutex();
    if(MsgsChpList ==NULL)
    {
        printf("[MUTEX] MsgsChpList Creat Fail!\r\n");
    }
}


int ChpListMutexLock(void)
{
    long ret = xSemaphoreTake(MsgsChpList, portMAX_DELAY);
//	printf("ChpListMutexLock:%d\r\n",ret);
    return ret;
}


int ChpListMutexUnlock(void)
{
    long ret = xSemaphoreGive(MsgsChpList);
//	printf("ChpUnlock:%d\r\n",ret);
    return ret;
}

void ChListMutexInit(void)
{
    MsgsChList = xSemaphoreCreateMutex();
    if(MsgsChList ==NULL)
    {
        printf("[MUTEX] MsgsChList Creat Fail!\r\n");
    }
}


int ChListMutexLock(void)
{
    long ret = xSemaphoreTake(MsgsChList, portMAX_DELAY);
//	printf("Ch Lock:%d\r\n",ret);
    return ret;
}


int ChListMutexUnlock(void)
{
    long ret = xSemaphoreGive(MsgsChList);
//	printf("Ch UnLock:%d\r\n",ret);
    return ret;
}

////////////////////////////////////////////////////////////////////////////////////

void RevProSend(REVPRO_MSG *pRevProMsg)
{
    RevProPostQueue(pRevProMsg);
}



int RevProCreateQueue(void)
{
    int ret;

    osMessageQDef(REVPRO,5,REVPRO_MSG);//10
    Msgsobj = osMessageCreate(osMessageQ(REVPRO),0);
    ret = (Msgsobj != NULL);
    if(Msgsobj==NULL)
    {
        printf("create revpro queue fail!\r\n");
    }

    return ret;
}


void RevProFlushQueue(void)
{
    xQueueReset(Msgsobj);
}


int RevProPendQueue (REVPRO_MSG *pRevProMsg)
{
    int ret = 0;

    if (xQueueReceive(Msgsobj,pRevProMsg, osWaitForever) == pdTRUE)
    {
        ret = 1;
    }

    return ret;
}


void RevProPostQueue(REVPRO_MSG *pRevProMsg)
{
    if(Msgsobj==NULL)  return ;

    if(openmachine == 1)
    {
        //int ret = osMessagePut(Msgsobj,(uint32_t)pRevProMsg,0);

        if((1 == sendqueueFlag))
            return;
        printf("queueMsgCnt[%d]\r\n",queueMsgCnt++);

        if((errQUEUE_FULL == xQueueSendFromISR( Msgsobj, pRevProMsg, 0 )) || queueMsgCnt > 30) //�����Ϣ�ж�����
        {
            sendqueueFlag = 1;		//������Ϣ�ж�
            printf("���� ZIGBEE ��Ϣ���ж�ʧ��!\r\n");
        }
    }
}

/////////////////////�������������̼���д����////////////////////////////////

/*************************************************
  Function:   �����̼��ļ�����
  Description:
*************************************************/
char BinFileName[12]= {0};
int BinFileCreate(int ver)
{
    FRESULT res;
    FIL file;

    if(ver==1)
    {
        printf("������ΪA������\r\n");
        strcpy(BinFileName,area_A);
        printf("BinFileName:%s\r\n",BinFileName);
    }
    else if(ver==2)
    {
        printf("������ΪB������\r\n");
        strcpy(BinFileName,area_B);
        printf("BinFileName:%s\r\n",BinFileName);
    }

    res = f_unlink(BinFileName);    //��ɾ��ͬ���ļ�
    if(res==FR_NO_FILE)
    {
        printf("%s�ļ�������\r\n",BinFileName);
    }
    else if(res == FR_OK)
    {
        printf("ɾ��ԭ%s�ļ��ɹ�\r\n",BinFileName);
    }

    res = f_open(&file,BinFileName,FA_OPEN_ALWAYS | FA_READ | FA_WRITE ); //�����̼��ļ�
    if(res!=FR_OK)
    {
        printf("�򿪻򴴽��̼��ļ�ʧ��[%d]\r\n",res);
        return 0xff;
    }
    else if(res==FR_OK)
    {
        printf("�����̼��ļ��ɹ�\r\n");
    }


    f_close(&file);

    return res;
}
/*************************************************
  Function:   bin�ļ����ݽ���
  Description:
*************************************************/
int FirmwareBinReceive(cJSON *dat)
{
    int i,size;
    cJSON *root;

    size = cJSON_GetArraySize(dat);
    for(i=0; i<size; i++)
    {
        root = cJSON_GetArrayItem(dat,i);
        if(FirmwareBinReceive2Array(root))
        {
            printf("size:%d\r\n",size);
            return 1;
        }
    }
    return 0;
}

int FirmwareBinReceive2Array(cJSON *root)
{
    cJSON *item,*items,*item1,*item2;

    unsigned short size,i,res=0;
    unsigned int tempCrc,crc;
    unsigned char rec_buf[256]= {0};

    memset(binstr,0,sizeof(binstr));

/////////////////������////////////////////////////////
    item = cJSON_GetObjectItem(root,"PL");//������
    item1 = cJSON_GetObjectItem(item,"data");
    size = cJSON_GetArraySize(item1);
    binPidJudge = size;
//		printf("bin data size=%d\n",size);
    for(i=0; i<size; i++)
    {
        item2 = cJSON_GetArrayItem(item1,i);
//		printf("%x ",item2->valueint);
        rec_buf[i] = (unsigned char)(item2->valueint);
    }
    memcpy(binstr,rec_buf,size);
//	for(i=0;i<size;i++)
//		printf("%x ",rec_buf[i]);

    items = cJSON_GetObjectItem(root,"CRC");//����У��λ
    sscanf(items->valuestring, "%x", &tempCrc);

    crc = xCal_crc(binstr,size);

//	printf("����У��calCrc=%d  revCrc=%d\r\n",crc,tempCrc);

    if(crc != tempCrc) //У�����
    {
        printf("����У�����\r\n");
        return 0xff;
    }
    res = FirmwareBinWrite(size);
    if(0 != res)
    {
        printf("����д��SD������\r\n");
        return 0xff;
    }
    return 0;
}


int FirmwareBinWrite(int writelen)
{
    FRESULT res;
    FIL file;
    unsigned int len;
    res = f_open(&file,BinFileName, FA_OPEN_ALWAYS|FA_WRITE|FA_READ);
    if(res!=FR_OK)
    {
        printf("��bin�ļ�ʧ��\r\n");
        return 0xff;
    }

    res = f_lseek(&file,f_size(&file));    //ָ��ƫ�Ƶ��ļ�ĩβ
    if(FR_OK != res)
    {
        printf("ƫ���ļ�ָ�����\r\n");
        return 0xff;
    }

    res = f_write(&file, binstr,writelen, &len);
    if(res != FR_OK)
    {
        printf("д���ݵ�SD��ʧ��\r\n");
        return 0xff;
    }
//	printf("дbin���ݵ�SD���ɹ�,len=%d\r\n",len);

    f_close(&file);

    return 0;
}

unsigned int xCal_crc(unsigned char *ptr,unsigned int len) //��żУ��
{
    int mytemp=0,i;
    int crc=0;
    for(i=0; i<len; i++)
    {
        mytemp = mytemp + countOne(ptr[i]);
    }
    crc = mytemp & 0xff;  //ȡ���ֽ�
    return crc;
}

//�����ÿ���ֽ��������ж��ٸ�1
unsigned int countOne(unsigned char ch)
{
    int count = 0;
    while(ch)
    {
        if(ch & 1)
            count++;
        ch = ch >> 1;
    }
    return count;
}

int getpos(void)
{
    FRESULT res;
    int ret=0;
    FIL file;
    res = f_open(&file,BinFileName, FA_OPEN_ALWAYS|FA_WRITE|FA_READ);
    if(res!=FR_OK)
    {
        printf("��bin�ļ�ʧ��\r\n");
        return 0;
    }

    ret = f_size(&file);    //ָ��ƫ�Ƶ��ļ�ĩβ
//	printf("�ļ��ֽڴ�С:%d\r\n",ret);
    return ret;
}


//�����ļ���Ŀ¼
u8 mf_scan_files(u8 * path)
{
    FRESULT res;
    char *fn;   /* This function is assuming non-Unicode cfg. */
    FILINFO fileinfo;
    DIR dir;
#if _USE_LFN
    fileinfo.lfsize = _MAX_LFN * 2 + 1;
    fileinfo.lfname = mymalloc(SRAMIN,fileinfo.lfsize);
#endif
    res = f_opendir(&dir,(const TCHAR*)path);
    if (res == FR_OK)
    {
        printf("\r\n");
        while(1)
        {
            res = f_readdir(&dir, &fileinfo);
            if (res != FR_OK || fileinfo.fname[0] == 0) break;
            if (fileinfo.fname[0] == '.') continue;
#if _USE_LFN
            fn = *fileinfo.lfname ? fileinfo.lfname : fileinfo.fname;
#else
            fn = fileinfo.fname;
#endif                                               /* It is a file. */
            printf("%s/", path);
            printf("%s\r\n", fn);
        }
    }
    return res;
}


