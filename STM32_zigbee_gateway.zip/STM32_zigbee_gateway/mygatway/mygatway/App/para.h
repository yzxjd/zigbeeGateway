#ifndef PARA_H
#define PARA_H



#define	FOLDER_LEGACY                   		"Legacy"
#define	FILE_SOUND_TAB				"Legacy/SoundTb.cfg"
#define	FILE_WORD_CARD				"Legacy/WordCrd.cfg"
#define 	FILE_WIRELESS_ID				"Legacy/WirlID.cfg"
#define	FILE_RATE_SET  					"Legacy/RatSet.cfg"
#define 	FILE_RIQISTER_TAB				"Legacy/RioiTb.cfg"
#define	FILE_PASS_RECORD 				"Legacy/PasRod.cfg"
#define	FILE_VOL_SET					"VolSet.cfg"
#define	FILE_MODEL_SET					"ModSet.cfg"
#define 	FILE_NET_CFG					"NetWork.txt"
#define 	FILE_CAN_CFG					"CanCfg"
#define	CAN_CFG						"CanAddr.txt"
#define 	FLIE_STR	"STRCFG"
#define 	FLIE_FIX	"FIXMSG"

#include "net.h"
#include "voiceApp.h"

void ParaInit(void);
void WriteNetConfig(NET_CONFIG *pNetConfig);
void WriteFixedDisplayInfo(unsigned char *FixedInfo);
unsigned short  ReadDisplayInfo(unsigned char code,unsigned char *dat);
void WriteVoiceVolInfo(VOL_CONFIG *Vol);
void ParaReset(void);




#endif
