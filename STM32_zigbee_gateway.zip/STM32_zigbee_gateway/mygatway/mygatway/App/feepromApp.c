#include "stm32f10x_lib.h"
#include "stm32f10x_api.h"
#include "usrApp.h"
#include "net.h"
#include "feeprom.h"
#include "feepromApp.h"
#include "string.h"
#include "stdlib.h"
#include "stdio.h"
#include "cmsis_os.h"
#include "updata.h"


extern unsigned int myID;
extern unsigned char serverIp[];
extern unsigned short serverPort;

void WriteMd(unsigned int *md);
void ReadMd(unsigned int *md);


long feepromFunc_store(int argc,char **argv)
{
    unsigned char ret;
    unsigned char buf[100];
    unsigned int id;

    if(!strcmp(argv[0],"write"))
    {
        ret=EE_WriteData(EE_KEY_TEST,(unsigned char *)argv[1],100);
        printf("write[%d]:%s\r\n",ret,argv[1]);
    }
    if(!strcmp(argv[0],"read"))
    {
        ret = EE_ReadData(EE_KEY_TEST,(unsigned char *)buf,100);
        printf("read[%d]:%s\r\n",ret,buf);
    }
    if(!strcmp(argv[0],"ee"))
    {
        ret = FeepromAppReset();
        printf("ee[%d]\r\n",ret);
    }
    if(!strcmp(argv[0],"myid"))
    {
        id = atoi(argv[1]);
        WriteMd(&id);

        myID = id;
        printf("set myid:%x\r\n",myID);
        Reboot();
    }
    if(!strcmp(argv[0],"port"))
    {
        id = atoi(argv[1]);
        EE_WriteData(EE_KEY_SERVER_PORT,(unsigned char *)&id,2);
        printf("set port [%d] ok\r\n",id);
    }
    return 0;
}


void FeepromAppInit(void)
{
//	HEAD Head;
//	unsigned int cnt;

    vPortEnterCritical();
    FLASH_Unlock();
    EE_Init();
    FLASH_Lock();
    vPortExitCritical();

    ReadServerIpPort((unsigned char *)serverIp,&serverPort,userName,Passwd);//��E2ROM�л�ȷ������IP�Ͷ˿ں�
    ReadMd(&myID);

#if 0
    printf("�Ҷ�����������Ϣ:\n");
    printf("id=%x port:%d\n",myID,serverPort);
    printf("ip:");

    for(cnt=0; cnt<4; cnt++)
    {
        printf("%d ",serverIp[cnt]);
    }
    printf("\n�û���:");
    for(cnt=0; cnt<strlen((char *)userName); cnt++)
    {
        printf("%c",userName[cnt]);
    }
    printf("\n����:");
    for(cnt=0; cnt<strlen((char *)Passwd); cnt++)
    {
        printf("%c",Passwd[cnt]);
    }
#endif
//	myID = GatewayID;
}


unsigned char FeepromAppReset(void)
{
    unsigned char ret;

    FeepromPendMutex();
    ret = EE_Format();
    FeepromPostMutex();

    return ret;
}

void ReadMd(unsigned int *md)
{
    unsigned int mymd = GatewayID;			//��ԭʼ������ID

    FeepromPendMutex();

    if(EE_ReadData(EE_KEY_MD,(unsigned char *)md,sizeof(unsigned int))!=0)
    {
        printf("��ȡ����IDʧ��\n");
        EE_WriteData(EE_KEY_MD,(unsigned char *)&mymd,sizeof(unsigned int));
        (*md) = mymd;
    }
//	printf("read myid :%x\r\n",*md);

    FeepromPostMutex();
}


void WriteMd(unsigned int *md)
{
    FeepromPendMutex();
    EE_WriteData(EE_KEY_MD,(unsigned char *)md,sizeof(unsigned int));
    printf("write myid :%x\r\n",*md);
    FeepromPostMutex();
}


//�쳣���ֵĵ�ַ
void HardFaultAddrWrite(unsigned int Addr)
{
    EE_WriteData(EE_KEY_FAULT_ADDR,(unsigned char *)&Addr,sizeof(unsigned int));
#ifdef PRINT
    printf("Write HardFault Addr:0x%x\r\n",Addr);
#endif
}


void HardFaultAddrRead(void)
{
    unsigned int Addr=0;

    if(EE_ReadData(EE_KEY_FAULT_ADDR,(unsigned char *)&Addr,sizeof(unsigned int))!=0)
    {
        EE_WriteData(EE_KEY_FAULT_ADDR,(unsigned char *)&Addr,sizeof(unsigned int));
    }
#ifdef PRINT
    printf("Read HardFault Addr:0x%x\r\n",Addr);
#endif
}


void ReadServerIpPort(unsigned char *ip,unsigned short *port,unsigned char *user,unsigned char *passwd)
{
//	unsigned char myip[4]={112,74,94,227};
//	unsigned short myport=8234;

#ifndef SERVER58
    unsigned char myip[4]= {112,74,132,1};  //112���Ի���
    unsigned short myport=1884;
#else
    unsigned char myip[4]= {58,20,51,165};		//58��ʽ����
    unsigned short myport=1883;
#endif

    unsigned char first_run_user[16] = FirstRunUserName;
    unsigned char first_run_pswd[16] = FirstRunPasswd;


    FeepromPendMutex();

    if(EE_ReadData(EE_KEY_SERVER_IP,(unsigned char *)ip,4)!=0)			//serverIP
    {
        EE_WriteData(EE_KEY_SERVER_IP,(unsigned char *)&myip,4);
        memcpy(ip,myip,4);
    }

    if(EE_ReadData(EE_KEY_SERVER_PORT,(unsigned char *)port,2)!=0)	//serverPort
    {
        EE_WriteData(EE_KEY_SERVER_PORT,(unsigned char *)&myport,2);
        (*port) = myport;
    }

    if(EE_ReadData(EE_KEY_MQTT_USER,(unsigned char *)user,16)!=0)	//mqtt uesr
    {
//		printf("read user none\r\n");
        EE_WriteData(EE_KEY_MQTT_USER,(unsigned char *)&first_run_user,strlen((char *)first_run_user));
        memcpy(user,first_run_user,strlen((char *)first_run_user));
    }

    if(EE_ReadData(EE_KEY_MQTT_PASSWORD,(unsigned char *)passwd,16)!=0)	//password
    {
//		printf("read pswd none\r\n");
        EE_WriteData(EE_KEY_MQTT_PASSWORD,(unsigned char *)&first_run_pswd,strlen((char *)first_run_pswd));
        memcpy(passwd,first_run_pswd,strlen((char *)first_run_pswd));
    }

    FeepromPostMutex();
}


unsigned int WriteServerIpPort(unsigned char *ip,unsigned short *port,unsigned char *user,unsigned char *passwd)
{
    int ret=0;
    FeepromPendMutex();
    if(FLASH_COMPLETE != EE_WriteData(EE_KEY_SERVER_IP,ip,4))
        ret = 1;
    if(FLASH_COMPLETE != EE_WriteData(EE_KEY_SERVER_PORT,(unsigned char *)&port,2))
        ret = 1;
    if(FLASH_COMPLETE != EE_WriteData(EE_KEY_MQTT_USER,user,16) )
    {
        printf("�û���дflashʧ��\r\n");
        ret = 1;
    }
    if(FLASH_COMPLETE != EE_WriteData(EE_KEY_MQTT_PASSWORD,passwd,16) )
    {
        printf("����дflashʧ��\r\n");
        ret = 1;
    }
    FeepromPostMutex();
    return ret;
}

unsigned int WriteZigbeeParaToFlash(unsigned char zbch,unsigned short zbpd)
{
    int ret=0;
    if(FLASH_COMPLETE != EE_WriteData(EE_KEY_ZBCH,&zbch,sizeof(zbch)))
        ret = 1;
    if(FLASH_COMPLETE != EE_WriteData(EE_KEY_ZBPD,(unsigned char *)&zbpd,sizeof(zbpd)))
        ret = 1;
    return ret;	
}

int FeepromCreateMutex(void)
{
    int ret=0;
    /*
    osMutexDef(FEEPROM_M);
    Semsobj = osMutexCreate(osMutex(FEEPROM_M));
    ret = (Semsobj != NULL);
    */
    return ret;
}


int FeepromPendMutex (void)
{
    /*
    int ret = 0;

    if(osMutexWait(Semsobj, osWaitForever) == osOK)
    {
    	ret = 1;
    }

    return ret;
    */
    vPortEnterCritical();
    return 0;
}


void FeepromPostMutex(void)
{
    /*
    if(Semsobj!=NULL)
    	osMutexRelease(Semsobj);
    */
    vPortExitCritical();
}

