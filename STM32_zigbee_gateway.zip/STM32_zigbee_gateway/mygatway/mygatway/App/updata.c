#include "updata.h"
#include "feeprom.h"
#include "stm32f10x_api.h"
#include "ff.h"
#include "stdio.h"
#include "string.h"
#include "tftp.h"
#include "net.h"
#include "des.h"
#include "crc32.h"
#include<stdlib.h>
#include "cmsis_os.h"

extern unsigned int lCrc32;
extern unsigned int total_len;
extern unsigned char upflag;

typedef  void (*pFunction)(void);
pFunction Jump_To_Application;
unsigned int JumpAddress;

__asm void __set_MSPs(uint32_t mainStackPointer)
{
    msr msp, r0
    bx lr
}

void DoAppA(void)
{
    JumpAddress = *(unsigned int*) (APPSTARTADDR_A + 4);
    Jump_To_Application = (pFunction) JumpAddress;

    NVIC_SETPRIMASK();
    __set_MSPs(APPSTARTADDR_A);
    (*Jump_To_Application)();
}


void DoAppB(void)
{
    JumpAddress = *(unsigned int*) (APPSTARTADDR_B + 4);
    Jump_To_Application = (pFunction) JumpAddress;

    NVIC_SETPRIMASK();
    __set_MSPs(APPSTARTADDR_B);
    (*Jump_To_Application)();
}


unsigned int HexToDWORD_LittleEndian(INT8U *pData,INT8U cBytes)
{
    unsigned int iReturn=0;

    if(cBytes>4)
        return 0;
    while(cBytes>0)
    {
        iReturn=(iReturn<<8)+pData[cBytes-1];
        cBytes--;
    }
    return iReturn;
}


unsigned char STM32FlashErase(unsigned int lAddr)
{
    FLASH_Status status = FLASH_COMPLETE;

    if(lAddr>0x8040000)
        return 0;

    FLASH_Unlock();
    status=FLASH_ErasePage(lAddr/PAGE_SIZE*PAGE_SIZE);
    FLASH_Lock();
    if(status!=FLASH_COMPLETE)
        return 0;
    return 1;
}



unsigned char STM32FlashWrit_Direct(unsigned int lAddr,INT8U *pData,unsigned short iLen)
{
    unsigned short iData,iCnt;
    FLASH_Status status = FLASH_COMPLETE;

    if((lAddr+iLen)>0x8040000)
        return 0;

    iCnt=0;
    FLASH_Unlock();
    while(iLen>iCnt)
    {
        iData =HexToDWORD_LittleEndian(pData,2);
        status=FLASH_ProgramHalfWord(lAddr,iData);
        if(status!=FLASH_COMPLETE)
            break;
        lAddr +=2;
        pData +=2;
        iCnt  +=2;
    }
    FLASH_Lock();

    if(status!=FLASH_COMPLETE)
        return 0;

    return 1;
}


unsigned int WriteFlashData(unsigned char *data, unsigned int data_len, unsigned short block_number)
{
    static unsigned int len,lens,lDesAddr;
    static unsigned char pBuf[PAGE_SIZE];
    static unsigned char pBufBak[PAGE_SIZE];
    static unsigned char flags;

    if(block_number==1)
    {
        if(upflag=='A')
        {
            lDesAddr = APPSTARTADDR_B;
        }
        else
        {
            lDesAddr = APPSTARTADDR_A;
        }
        len=0;
        lens=0;
    }
    if(block_number>210)  return 0;
    memcpy(pBuf+TFTP_BLK_SIZE*((block_number-1)%4),data,data_len);
    len+=data_len;
    lens+=data_len;
    if((block_number%4==0)||(data_len!=TFTP_BLK_SIZE)||(lens>=total_len))
    {
        Run1Des(DECRYPT,ECB,(const char *)pBuf,len,DES_KEY,8,(char *)pBufBak,len,NULL);
        lCrc32 =Calculate_CRC32(lCrc32,pBufBak,len);
        if(!STM32FlashErase(lDesAddr))
        {
            return 0;
        }
        if(!STM32FlashWrit_Direct(lDesAddr,pBufBak,PAGE_SIZE))
        {
            return 0;
        }
        memset(pBuf,0xff,PAGE_SIZE);
        lDesAddr +=len;
        len=0;
        if(flags==0)
        {
            flags=0xff;
            NetAddrLedSet(flags);
        }
        else if(flags==0xff)
        {
            flags=0;
            NetAddrLedSet(flags);
        }
        printf("rev len=%d  total len:%d\r\n",lens,total_len);
    }
    if(lens>=total_len)
        return 2;
    return 1;
}


void ReadHeadInfo(HEAD*pHead)
{
    if(EE_ReadData(EE_KEY_HEAD,(unsigned char *)pHead,sizeof(HEAD))!=0)
    {
        printf("û��HEAD����\r\n");
    }
    if(EE_ReadData(EE_KEY_UPDATA,(unsigned char *)&upflag,1)!=0)
    {
        upflag='A';
        printf("��ʼ��UPDATAΪ:%c��\r\n",upflag);
        EE_WriteData(EE_KEY_UPDATA,(unsigned char *)&upflag,1);
    }
    printf("��ǰ����:%c\r\n",upflag);
    printf("��ǰ�����汾:%c%c%c%c\r\n",pHead->FirmwareVer[0],pHead->FirmwareVer[1],pHead->FirmwareVer[2],pHead->FirmwareVer[3]);
    printf("��ǰӲ���汾:%c%c%c%c\r\n",pHead->HardwareVer[0],pHead->HardwareVer[1],pHead->HardwareVer[2],pHead->HardwareVer[3]);
}


void WriteHeadInfo(HEAD*pHead)
{
    if(upflag=='A')
    {
        upflag='B';
    }
    else if(upflag=='B')
    {
        upflag='A';
    }
    EE_WriteData(EE_KEY_UPDATA,(unsigned char *)&upflag,1);
    printf("����֮�������: %c\r\n",upflag);
    EE_WriteData(EE_KEY_HEAD,(unsigned char *)pHead,sizeof(HEAD));
    printf("����֮��������汾:%c%c%c%c\r\n",pHead->FirmwareVer[0],pHead->FirmwareVer[1],pHead->FirmwareVer[2],pHead->FirmwareVer[3]);
}

