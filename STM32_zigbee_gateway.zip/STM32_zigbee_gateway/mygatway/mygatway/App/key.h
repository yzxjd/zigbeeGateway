

#ifndef __KEY_H__
#define __KEY_H__

#define RESET_KEY  GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_7)//��ȡ��λ����״̬

#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_api.h"
#include "stm32f10x_exti.h"

void KEY_Init(void);
void EXTIX_Init(void);

#endif

