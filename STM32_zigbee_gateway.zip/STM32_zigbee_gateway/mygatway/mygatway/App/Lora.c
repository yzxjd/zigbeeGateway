
#include "stdint.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_usart.h"
#include "stm32f10x_nvic.h"
#include "stm32f10x_dma.h"
#include "stm32f10x_rcc.h"
#include "usrApp.h"
#include "cmsis_os.h"
#include "zigbee.h"

uint8_t UART4_Rx_buffer[512],UART4_Rx_num;

void UART4_Config(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    DMA_InitTypeDef DMA_InitStructure;	 //??DMA??????DMA_InitStructure


    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA2, ENABLE);




    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;         //IO???2?
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; //IO???
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;   //IO???????
    GPIO_Init(GPIOC, &GPIO_InitStructure);            //?????1??IO?


    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;           //IO???3?
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;//IO?????
    GPIO_Init(GPIOC, &GPIO_InitStructure);               //?????1??IO?


    USART_InitStructure.USART_BaudRate = 9600;                  //??????
    USART_InitStructure.USART_WordLength = USART_WordLength_8b; //????????
    USART_InitStructure.USART_StopBits = USART_StopBits_1;      //???????
    USART_InitStructure.USART_Parity = USART_Parity_No ;        //?????
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//??????
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;                //?????????
    USART_Init(UART4, &USART_InitStructure);      //?????4

    USART_ITConfig(UART4, USART_IT_IDLE,ENABLE);  //????4????
    USART_Cmd(UART4, ENABLE);                     //????4
    USART_ClearFlag(UART4, USART_FLAG_TC);        // ???(???)

    DMA_DeInit(DMA2_Channel3);	 //??DMA 2????
    DMA_InitStructure.DMA_PeripheralBaseAddr = 0x40004C04;	 //????
    DMA_InitStructure.DMA_MemoryBaseAddr = (u32)UART4_Rx_buffer;	 //????
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;	 //?????????
    DMA_InitStructure.DMA_BufferSize = 512;	 //DMA????:BufferSize
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;	 //??????????
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;	  	 //?????????
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte; 	//???????8?
    DMA_InitStructure.DMA_MemoryDataSize = DMA_PeripheralDataSize_Byte;	 //???????8?
    DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;	 //?????????
    DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;	 //??DMA???????
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;	 //??DMA????????????
    DMA_Init(DMA2_Channel3, &DMA_InitStructure);	 //???

    DMA_ITConfig(DMA2_Channel3, DMA_IT_TC, ENABLE);
    DMA_ITConfig(DMA2_Channel3, DMA_IT_TE, ENABLE);

    USART_DMACmd(UART4, USART_DMAReq_Rx, ENABLE);
    DMA_Cmd(DMA2_Channel3, ENABLE);
    //????4??
    NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQChannel;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    NVIC_InitStructure.NVIC_IRQChannel = DMA2_Channel3_IRQChannel;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

void UART4_IRQHandler(void)
{
    uint16_t i;
    uint16_t Data_Len;
    if(USART_GetITStatus(UART4, USART_IT_IDLE) != RESET)
    {
        DMA_Cmd(DMA2_Channel3, DISABLE);
        Data_Len=512-DMA_GetCurrDataCounter(DMA2_Channel3);
//		USART_PutStr(USART1,UART4_Rx_buffer,Data_Len);
        UART4_Rx_num=0;
        DMA_ClearFlag(DMA2_FLAG_GL3 | DMA2_FLAG_TC3 | DMA2_FLAG_TE3 | DMA2_FLAG_HT3);
        DMA2_Channel3->CNDTR = 512;
        DMA_Cmd(DMA2_Channel3, ENABLE);

        i = UART4->SR;
        i = UART4->DR;
        if(i) i=0;
        if(Data_Len)Data_Len=0;
    }
    if(USART_GetITStatus(UART4, USART_IT_PE | USART_IT_FE | USART_IT_NE) != RESET) {
        USART_ClearITPendingBit(UART4, USART_IT_PE | USART_IT_FE | USART_IT_NE);
    }
    USART_ClearITPendingBit(UART4, USART_IT_TC);
    USART_ClearITPendingBit(UART4, USART_IT_IDLE);
}

void DMA2_Channel3_IRQHandler(void)
{
//	USART_PutStr(USART1," DMA23:\r\n",9);
    DMA_ClearITPendingBit(DMA2_IT_TC3);
    DMA_ClearITPendingBit(DMA2_IT_TE3);
    DMA_Cmd(DMA2_Channel3, DISABLE);
    DMA2_Channel3->CNDTR = 512;
    DMA_Cmd(DMA2_Channel3, ENABLE);
}





