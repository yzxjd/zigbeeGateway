#include <stdio.h>
#include <string.h>
#include "TCP232.h"
#include "cyclebuffer.h"
#include "feepromApp.h"
#include "feeprom.h"
#include "fourG.h"
#include "cmsis_os.h"
#include <stdlib.h>

extern unsigned char serverIp[4];
extern unsigned short serverPort;
uint8_t TCP232ReloadFlag = 0;
/*
 ����1����   ������TCP232ģ��ͨ�ŵĴ���
*/
void Uart2Config(unsigned int eBandRate,unsigned char eDataBit,unsigned char eParity,unsigned char eStopBit)
{
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    USART_ClockInitTypeDef  USART_ClockInitStructure;
    unsigned short DataBit;
    unsigned short Parity;
    unsigned short StopBit;

    /////////////////////////////////////////////////////////////////////
    DMA_InitTypeDef   DMA_InitStructure;									//uart2��tx   DMA1_Channel7
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
    DMA_DeInit(DMA1_Channel7);
    DMA_InitStructure.DMA_PeripheralBaseAddr = (unsigned int)(&(USART2->DR));
    DMA_InitStructure.DMA_MemoryBaseAddr = (unsigned int)DmaTxBuffer;
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
    DMA_InitStructure.DMA_BufferSize = 0;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
    DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;

    DMA_Init(DMA1_Channel7, &DMA_InitStructure);
    DMA_ITConfig(DMA1_Channel7, DMA_IT_TC |DMA_IT_TE, ENABLE);
    DMA_Cmd(DMA1_Channel7, DISABLE);

    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQChannel;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    if(eDataBit==9)	 DataBit =  USART_WordLength_9b;
    else DataBit = USART_WordLength_8b;

    if(eParity=='e') Parity = USART_Parity_Even;
    else if(eParity=='o') Parity = USART_Parity_Odd;
    else Parity =  USART_Parity_No;

    if(eStopBit==2) StopBit = USART_StopBits_2;
    else StopBit =  USART_StopBits_1;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD | RCC_APB2Periph_AFIO,ENABLE);
    USART_DeInit(USART2);

    USART_ClockInitStructure.USART_Clock = USART_Clock_Disable;
    USART_ClockInitStructure.USART_CPOL = USART_CPOL_Low;
    USART_ClockInitStructure.USART_CPHA = USART_CPHA_2Edge;
    USART_ClockInitStructure.USART_LastBit = USART_LastBit_Disable;
    // Configure the USART synchronous paramters ����ͬ������
    USART_ClockInit(USART2, &USART_ClockInitStructure);

    USART_InitStructure.USART_BaudRate = eBandRate;
    USART_InitStructure.USART_WordLength = DataBit;
    USART_InitStructure.USART_StopBits = StopBit;
    USART_InitStructure.USART_Parity = Parity;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    // Configure USART basic and asynchronous paramters �����첽����
    USART_Init(USART2, &USART_InitStructure);

    USART_ITConfig(USART2,USART_IT_RXNE, ENABLE);
    USART_DMACmd(USART2,USART_DMAReq_Tx,ENABLE);

    USART_Cmd(USART2, ENABLE);
    USART_ClearFlag(USART2, USART_FLAG_TC);
}

void TCP232_init(void)
{
    GpioConfig(GPIOD,GPIO_Pin_3,GPIO_Mode_Out_PP,GPIO_Speed_10MHz); //TCP_CFG ģ���������ţ�����ʱ����
    GpioConfig(GPIOE,GPIO_Pin_1,GPIO_Mode_Out_PP,GPIO_Speed_10MHz);	//ģ���Դʹ������

    GPIO_SetBits(GPIOD, GPIO_Pin_3);
    GPIO_ResetBits(GPIOE, GPIO_Pin_1);

    GpioConfig(GPIOD,GPIO_Pin_5,GPIO_Mode_AF_PP,GPIO_Speed_50MHz);
    GpioConfig(GPIOD,GPIO_Pin_6,GPIO_Mode_IN_FLOATING,GPIO_Speed_50MHz);
    GPIO_PinRemapConfig(GPIO_Remap_USART2,ENABLE);
    Uart2Config(115200,8,0,1);
    CycleBufferInit(0);	//ѭ����������ʼ��
    ModeTCP232Reset();

//	GPIO_SetBits(GPIOB,GPIO_Pin_3); //�ر�sim800
}

void ModeTCP232Reset(void)
{
    GpioConfig(GPIOC,GPIO_Pin_5,GPIO_Mode_Out_PP,GPIO_Speed_10MHz);

    GPIO_ResetBits(GPIOC,GPIO_Pin_5);    //����ת����������λ
    delay_n100ms(3);
    GPIO_SetBits(GPIOC,GPIO_Pin_5);
    delay_n100ms(2);
}

unsigned char TCP232AppInit(void)
{
    char buf[50]={0};

    delay_n100ms(30);

    sprintf(buf,"+++");					//STM32���͡�+++����ģ���,ģ�鷵һ����a����STM32
    TCP232SendBytes((unsigned char *)buf,strlen(buf));
    FourGAtStringTimeOut((unsigned char *)"a",300);//300


    delay_n100ms(2);
    sprintf(buf,"a");
    TCP232SendBytes((unsigned char *)buf,strlen(buf));
    FourGAtStringTimeOut((unsigned char *)"ok",500);	//����װ����ģ�������ʱָ��ģʽ

	//�ж��Ƿ���Ҫ������ģ��ָ���������
	if(0==EE_ReadData(EE_KEY_TCP232_RELOD,&TCP232ReloadFlag,1))
	{
		printf("read TCP232ReloadFlag ok[%d]\n",TCP232ReloadFlag);
		if(TCP232ReloadFlag == 1)
		{
			if(TCP232_returnFactorySet()>0)
			{
				TCP232ReloadFlag = 0;
				if(FLASH_COMPLETE==EE_WriteData(EE_KEY_TCP232_RELOD,&TCP232ReloadFlag,sizeof(TCP232ReloadFlag)))
				{
					printf("TCP232 factory setted\n");
					Reboot();//ģ��ָ��������ú���Ҫ����һ��
				}
			}
			else
				printf("TCP232 factory failed\n");
		}	
	}
	else
	{
		printf("read TCP232ReloadFlag failed\n");
		TCP232ReloadFlag = 0;
		if(FLASH_COMPLETE==EE_WriteData(EE_KEY_TCP232_RELOD,&TCP232ReloadFlag,sizeof(TCP232ReloadFlag)))
		{
			printf("TCP232 first run setted\n");
		}
	}
	
	//��ģ���ʼ��Զ��IP���˿ں�
	delay_n100ms(3);
	sprintf(buf,"AT+SOCK\r");
    TCP232SendBytes((unsigned char*)buf,strlen(buf));
	sprintf(buf,"TCPC,%d.%d.%d.%d,%d",serverIp[0],serverIp[1],serverIp[2],serverIp[3],serverPort);
    if(FourGAtStringTimeOut((unsigned char*)buf,200)==0)
	{
		delay_n100ms(3);
		sprintf(buf,"AT+SOCK=TCPC,%d.%d.%d.%d,%d\r",serverIp[0],serverIp[1],serverIp[2],serverIp[3],serverPort);
		TCP232SendBytes((unsigned char*)buf,strlen(buf));
		if(FourGAtStringTimeOut((unsigned char*)"OK",200)>0)
		{
			printf("TCP232 remote para set ok\n");
			Reboot();//ģ��Զ��IP�������Ҫ����һ��
		}
	}
	
    delay_n100ms(5);
    sprintf(buf,"AT+ENTM\r");
    TCP232SendBytes((unsigned char*)buf,strlen(buf));
    FourGAtStringTimeOut((unsigned char*)"OK",200);

    return 0;
}

//AT+CLEAR
uint8_t TCP232_returnFactorySet(void)
{
    char buf[50];
//    printf("get in reload\n");
    delay_n100ms(40);
    sprintf(buf,"AT+RELD\r");					//STM32���͡�+++����ģ���,ģ�鷵һ����a����STM32
    TCP232SendBytes((unsigned char *)buf,strlen(buf));
    if(FourGAtStringTimeOut((unsigned char *)"OK",500)>0)//300
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

/*************************************************
  Function:    ��TCP232ģ�鷢���ֽڴ�����
  Description:
*************************************************/
void TCP232SendBytes(unsigned char *dat,unsigned short len)
{
    unsigned int cnt=3;

    if(len==0)   return ;
    while(DMA_GetFlagStatus(DMA1_FLAG_TC7) == RESET)
    {
        if(cnt--<=1)
        {
            if(DMA_GetFlagStatus(DMA1_FLAG_TE7) == SET)     // DMA ���ͳ���
            {
                printf("[ERROR]DMA TCP232 send error!\r\n");
                break;
            }
            else
            {
                printf("[ERROR]DMA TCP232 outtime!\r\n");
                break;
            }
        }
        osDelay(10);
    }
    DMA_Cmd(DMA1_Channel7,DISABLE);//����4�����ڻ�4Gģ��ͨ�ŵķ����ŵ�(uart4��Tx)
    DMA_ClearFlag(DMA1_FLAG_TC7);
    DMA_ClearFlag(DMA1_FLAG_TE7);
    if(len>=sizeof(DmaTxBuffer))
        return ;
    DMA1_Channel7->CNDTR = len;
    memcpy(DmaTxBuffer,dat,len);
    DMA_Cmd(DMA1_Channel7,ENABLE);
}

void TCP232SendByte(unsigned char dat)
{
    TCP232SendBytes(&dat,1);
}

void TCP232SocketSend(unsigned char *dat,unsigned short len)
{
    TCP232SendBytes(dat,len);
}

void USART2_IRQHandler(void)
{
    unsigned char cByte;

    if (USART_GetFlagStatus(USART2, USART_FLAG_ORE) != RESET)
    {
        USART_ReceiveData(USART2);
    }
    else if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)
    {
        USART_ClearFlag(USART2,USART_IT_RXNE);
        cByte=USART_ReceiveData(USART2);

        CycleBufferPush(0,cByte);
    }
}



