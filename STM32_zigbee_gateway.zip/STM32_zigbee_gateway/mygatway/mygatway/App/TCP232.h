
#ifndef __TCP232_H__
#define __TCP232_H__


#include "stm32f10x_api.h"

extern unsigned char DmaTxBuffer[1024];
extern unsigned char NetMode;
extern unsigned char TCP232Enable;
extern unsigned char SIM800Enable;

void Uart2Config(unsigned int eBandRate,unsigned char eDataBit,unsigned char eParity,unsigned char eStopBit);
void TCP232_init(void);
void TCP232SendBytes(unsigned char *dat,unsigned short len);
void TCP232SendByte(unsigned char dat);
void ModeTCP232Reset(void);
void TCP232SocketSend(unsigned char *dat,unsigned short len);
unsigned char TCP232AppInit(void);
uint8_t TCP232_returnFactorySet(void);



#endif




