#ifndef NET_H
#define NET_H


#define ADDR32PORT		GPIOB
#define ADDR16PORT		GPIOB
#define ADDR8PORT		GPIOB
#define ADDR4PORT		GPIOB
#define ADDR2PORT		GPIOD
#define ADDR1PORT		GPIOD
#define ADDR32PIN		GPIO_Pin_12
#define ADDR16PIN		GPIO_Pin_13
#define ADDR8PIN		GPIO_Pin_14
#define ADDR4PIN		GPIO_Pin_15
#define ADDR2PIN		GPIO_Pin_8
#define ADDR1PIN		GPIO_Pin_9

#ifdef HV20
#define NETLEDPORT		GPIOA
#define NETLEDPIN		GPIO_Pin_8
#else
#define NETLEDPORT		GPIOA
#define NETLEDPIN		GPIO_Pin_15
#endif



#define SOCK_TCPC1            0
#define SOCK_TFTPC            3
#define SOCK_HTTPS            4

#define NET_SEND_LED_MAX	12


typedef struct _NET_CONFIG
{
    unsigned char mac[6];					/*MAC��ַ*/
    unsigned char lip[4];					/*����IP��ַ*/
    unsigned short lport;					/*���ض˿�*/
    unsigned char sub[4];					/*��������*/
    unsigned char gw[4];					/*����*/
    unsigned char dns[4];	 				/*DNS��������ַ*/
    unsigned char rip[4];	 				/*remote IPԶ��IP��ַ*/
    unsigned char canaddr;					/*can��ַ*/
    unsigned short rport;	 				 /*�������˿ں�*/
} NET_CONFIG;



typedef void (*NetProCallBack)(unsigned char *);

void NetPostMutex(void);
int NetPendMutex (void);
int NetCreateMutex(void);

void NetCloseSocket(unsigned char socket);
void HttpCgiCallBack(unsigned char para);


void NetSetProcessCb(NetProCallBack pNetProCb);
NET_CONFIG *GetNetConfigAddr(void);
unsigned char *GetCanAddr(void);
void NetInit(void);
int TcpProcess(unsigned char s,unsigned short len);
void NetScan(void);
unsigned char NetTcpSend(unsigned char *buf,unsigned short len);
void NetSend(unsigned char *dat,unsigned char len);
void net1ProcessTask(void const * argument);
void net2ProcessTask(void const * argument);
int TcpsCallBack(unsigned char s,unsigned char *,unsigned short len);
long netFunc_Net(int argc,char **argv);

long downFunc_Net(int argc,char **argv);
int NetTftpcPro(unsigned char *remote_ip);

#endif

