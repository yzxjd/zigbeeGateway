#ifndef CONSOLE_H
#define CONSOLE_H


void ConsoleInit(void);
void ConsoleSendByte(unsigned char dat);
int ConsoleRevByte(unsigned char *pdat,unsigned short Timeout10ms);
void ConsoleSendBytes(unsigned char *dat,unsigned short len);

#endif

