#include "stm32f10x_api.h"
#include "key.h"
#include "stdio.h"

#define KEY_OPEN  PEin(12)
#define KEY_CHECK  PEin(8)
#define KEY_CLOSE  PEin(7)
#define KEY_VH20RESULT  PCin(13)


static unsigned char KeyOpenFlag=0;
static unsigned char KeyCheckFlag=0;
static unsigned char KeyCloseFlag=0;
static unsigned char KeyVH20ResultFlag=0;

void KeyInit(void)
{
	GpioConfig(GPIOE,GPIO_Pin_7,GPIO_Mode_IPU,GPIO_Speed_50MHz);
	GpioConfig(GPIOE,GPIO_Pin_8,GPIO_Mode_IPU,GPIO_Speed_50MHz);
	GpioConfig(GPIOE,GPIO_Pin_12,GPIO_Mode_IPU,GPIO_Speed_50MHz);
	#ifdef HV20
	GpioConfig(GPIOC,GPIO_Pin_13,GPIO_Mode_IPU,GPIO_Speed_50MHz);
	#endif
}

unsigned char KeyOpenStatus(void)
{
	static unsigned char bak=0xff;
	
	if(bak^KeyOpenFlag)
	{
		bak = KeyOpenFlag;
		return KeyOpenFlag;
	}
	return 0xff;
}
unsigned char KeyCheckStatus(void)
{
	static unsigned char bak=0xff;

	if(bak^KeyCheckFlag)
	{
		bak = KeyCheckFlag;
		return KeyCheckFlag;
	}
	return 0xff;
}

unsigned char KeyCloseStatus(void)
{
	static unsigned char bak=0xff;
	
	if(bak^KeyCloseFlag)
	{
		bak = KeyCloseFlag;
		return KeyCloseFlag;
	}
	return 0xff;
}

unsigned char KeyVH20ResultStatus(void)
{
	static unsigned char bak=0xff;
	
	if(bak^KeyVH20ResultFlag)
	{
		bak = KeyVH20ResultFlag;
		return KeyVH20ResultFlag;
	}
	return 0xff;
}


static void KeyOpenScan(void)
{	
	static unsigned char SenseFilterA=0,SenseFilterB=0;
	
	if(KEY_OPEN == 0)
	{
		SenseFilterA++;
		if(SenseFilterA == KEY_FILTER_VALUE)    //��������
		{	
			KeyOpenFlag =1;
		}
		else if(SenseFilterA > KEY_FILTER_VALUE)
			SenseFilterA = KEY_FILTER_VALUE;
		
		SenseFilterB = 0;
	}
	else
	{
		if(KeyOpenFlag==1)
		{
			SenseFilterB++;
			if(SenseFilterB >= KEY_FILTER_VALUE)    //����̧��
			{
				SenseFilterB = 0;
				KeyOpenFlag=0;
			}
		}
		else   
		{
			
		} 
		SenseFilterA = 0;	
	}
}


static void KeyCheckScan(void)
{	
	static unsigned int SenseFilterA=0,SenseFilterB=0;
	
	if(KEY_CHECK == 0)   
	{
		SenseFilterA++;
		if(SenseFilterA == KEY_LONG_VALUE)    //��������
		{	
			KeyCheckFlag =1;
		}
		else if(SenseFilterA > KEY_LONG_VALUE)
			SenseFilterA = KEY_LONG_VALUE;
		
		SenseFilterB = 0;
	}
	else
	{
		if(KeyCheckFlag==1)
		{
			SenseFilterB++;
			if(SenseFilterB >= KEY_FILTER_VALUE)    //����̧��
			{
				SenseFilterB = 0;
				KeyCheckFlag=0;
			}
		}
		else   
		{
			
		} 
		SenseFilterA = 0;	
	}
}

static void KeyCloseScan(void)
{	
	static unsigned char SenseFilterA=0,SenseFilterB=0;
	
	if(KEY_CLOSE == 0)   
	{
		SenseFilterA++;
		if(SenseFilterA == KEY_FILTER_VALUE)    //��������
		{	
			KeyCloseFlag =1;
		}
		else if(SenseFilterA > KEY_FILTER_VALUE)
			SenseFilterA = KEY_FILTER_VALUE;
		
		SenseFilterB = 0;
	}
	else
	{
		if(KeyCloseFlag==1)
		{
			SenseFilterB++;
			if(SenseFilterB >= KEY_FILTER_VALUE)    //����̧��
			{
				SenseFilterB = 0;
				KeyCloseFlag=0;
			}
		}
		else   
		{
			
		} 
		SenseFilterA = 0;	
	}
}

static void KeyVH20ResultScan(void)
{	
	static unsigned int SenseFilterA=0,SenseFilterB=0;
	
	if(KEY_VH20RESULT == 0)
	{
		SenseFilterA++;
		if(SenseFilterA == KEY_FILTER_VALUE)    //��������
		{	
			KeyVH20ResultFlag =1;
		}
		else if(SenseFilterA > KEY_FILTER_VALUE)
			SenseFilterA = KEY_FILTER_VALUE;
		
		SenseFilterB = 0;
	}
	else
	{
		if(KeyVH20ResultFlag==1)
		{
			SenseFilterB++;
			if(SenseFilterB >= KEY_FILTER_VALUE)    //����̧��
			{
				SenseFilterB = 0;
				KeyVH20ResultFlag=0;
			}
		}
		else
		{
			
		} 
		SenseFilterA = 0;	
	}
}



void KeyScan(void)
{
	KeyOpenScan();
	KeyCheckScan();
	KeyCloseScan();
	#ifdef HV20
	KeyVH20ResultScan();
	#endif
}


unsigned char KeyGet(void)
{
	if(KeyOpenStatus()==1)
	{
		printf("open\r\n");
		return 1;
	}
	if(KeyCheckStatus()==1)
	{
		printf("para reset\r\n");
		return 2;
	}
	if(KeyCloseStatus()==1)
	{
		printf("close\r\n");
		return 3;
	}
	#ifdef HV20
	if(KeyVH20ResultStatus()==1)
	{
		printf("VH20Result\r\n");
		return 4;
	}
	#endif
	return 0;
}




