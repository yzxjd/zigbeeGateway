#ifndef __CAN_H
#define __CAN_H


typedef void (*CanProCallBack)(unsigned char *);

void CanInit(unsigned char addr);
void CanSetProcessCb(CanProCallBack pCanProcb);

#endif

