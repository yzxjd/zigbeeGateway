#include "stm32f10x_lib.h"
#include "Wiegand.h"
#include "stdio.h"


static tWiegandConfig WiegandConfig;
static tWiegandConfig *WiegandUse; 
static unsigned long long WG_temp_buf = 0;
static unsigned char WG_cnt = 0;
static unsigned short tim_cnt=0;
static unsigned char flagok=0;
static unsigned char WG_RX_buf[4];


void WiegandDriverInit(void)
{	
	WiegandUse = WiegandInit();
	WiegandUse->Init();
	WiegandUse->ModeConfig(WG_RX_MODE);
}

unsigned char Wg26GetCard(unsigned long *lcard)
{
	unsigned long temp,temp1;
	
	if(flagok)
	{
		temp=WG_RX_buf[0];
		temp=temp<<16;
		temp1=WG_RX_buf[1];
		temp1=temp1<<8;
		
		*lcard = temp+temp1+WG_RX_buf[2];
		
		flagok=0;
		return 1;
	}
	else
	{
		return 0;
	}
}

///////////////////////////////////////////////////////////////////

static void Delay_us( unsigned char time_us )
{
  register unsigned char i;
  register unsigned char j;
  for( i=0;i<time_us;i++ )    
  {
    for( j=0;j<5;j++ )          // 25CLK
    {
      __nop();
      __nop();
      __nop();
      __nop();
      __nop();
    }      
  }                              // 25CLK*0.04us=1us
}


static void Delay_ms( unsigned short time_ms )
{
  register unsigned short i;
  for( i=0;i<time_ms;i++ )
  {
    Delay_us(250);
    Delay_us(250);
    Delay_us(250);
    Delay_us(250);
  }
}


tWiegandConfig* WiegandInit(void)
{
#if defined(USE_WIEGAND26)
	WiegandConfig.Init = WG_GPIO_Configuration ;
	WiegandConfig.ModeConfig = WG_RTX_Mode ;
	WiegandConfig.SendData = Send_Wiegand26 ;
	WiegandConfig.ReceiveData = Get_WG26_Data ;
#elif defined(USE_WIEGAND34)
	WiegandConfig.Init = WG_GPIO_Configuration ;
	WiegandConfig.ModeConfig = WG_RTX_Mode ;
	WiegandConfig.SendData = Send_Wiegand34 ;
	WiegandConfig.ReceiveData = Get_WG34_Data ;
#else
  #error "Missing define: USE_WIEGANDxx"
#endif
	return &WiegandConfig;
}



void EXTI2_IRQHandler(void)    //D0 Ϊ�͵�ƽ
{
	if(EXTI_GetITStatus(EXTI_Line2) != RESET)
	{
		if((GPIO_ReadInputDataBit(WG_GPIO,WG_DATA1_PIN) == 1))   //D0 Ϊ�͵�ƽ��ʱ��D1 �����Ǹߵ�ƽ
		{
			/*
			tim_cnt=0;
			TIM_Cmd(TIM2, ENABLE);
			while(GPIO_ReadInputDataBit(WG_GPIO,WG_DATA0_PIN) == 0)    //���ȴ��100us�ĵ͵�ƽ��ȴ�D0����
			{
				if(tim_cnt>WG_MAX_D0_TIM)   //�����ʱ��û�б���������Ϊ��Ч����
					break;
			}*/
			tim_cnt=0;
			//TIM_Cmd(TIM2, ENABLE);
			//while(GPIO_ReadInputDataBit(WG_GPIO,WG_DATA0_PIN) == 0)
			{
				
			}
			//TIM_Cmd(TIM2, DISABLE);    
			//�ٴ�ȷ��D1 �����Ǹߵ�ƽ
			if(GPIO_ReadInputDataBit(WG_GPIO,WG_DATA1_PIN) == 1)
			{
				WG_temp_buf = WG_temp_buf << 1;
				WG_temp_buf = WG_temp_buf + 0;
				WG_cnt ++;
				tim_cnt = 0;
				TIM_Cmd(TIM2, ENABLE);   //�����ʱ��ʼ��ʱ������200ms���Զ��رռ�ʱ�������
			}
			else
			{
				WG_temp_buf = 0; 
				WG_cnt = 0;
				tim_cnt = 0;
			}
			
#if defined (USE_WIEGAND26)
			if(WG_cnt > WIEGAND26)   
#elif defined (USE_WIEGAND34)
			if(WG_cnt > WIEGAND34)   
#else
    #error "Missing define: USE_WIEGANDxx"
#endif
			{
				flagok=0;
				if(!WiegandUse->ReceiveData(WG_temp_buf,WG_RX_buf))
				{
					flagok=1;
				}	
				WG_temp_buf = 0;
				WG_cnt = 0;
				tim_cnt = 0;
			}
		}
		EXTI_ClearITPendingBit(EXTI_Line2);    
	}  
}


void EXTI3_IRQHandler(void)
{
	if(EXTI_GetITStatus(EXTI_Line3) != RESET) 
	{
   		 if((GPIO_ReadInputDataBit(WG_GPIO,WG_DATA0_PIN) == 1))
		 {
		 	/*
			tim_cnt=0;
			TIM_Cmd(TIM2, ENABLE);
			while(GPIO_ReadInputDataBit(WG_GPIO,WG_DATA1_PIN) == 0)
			{
				if(tim_cnt>WG_MAX_D0_TIM) 
					break;
			}*/
			tim_cnt=0;
			//TIM_Cmd(TIM2, ENABLE);
			//while(GPIO_ReadInputDataBit(WG_GPIO,WG_DATA1_PIN) == 0)
			{
				
			}
			//TIM_Cmd(TIM2, DISABLE);
			if(GPIO_ReadInputDataBit(WG_GPIO,WG_DATA0_PIN) == 1)  
			{
				WG_temp_buf = WG_temp_buf << 1;
				WG_temp_buf = WG_temp_buf + 1;
				WG_cnt ++;
				tim_cnt = 0;
				TIM_Cmd(TIM2, ENABLE);   //�����ʱ��ʼ��ʱ������200ms���Զ��رռ�ʱ�����������
			}
			else
			{
				WG_temp_buf = 0; 
				WG_cnt = 0;
				tim_cnt = 0;
			}
			
#if defined (USE_WIEGAND26)
			if(WG_cnt > WIEGAND26)   
#elif defined (USE_WIEGAND34)
			if(WG_cnt > WIEGAND34)   
#else
    #error "Missing define: USE_WIEGANDxx"
#endif
			{
				flagok=0;
				if(!WiegandUse->ReceiveData(WG_temp_buf,WG_RX_buf))
				{
					flagok=1;
				}	
				WG_temp_buf = 0;
				WG_cnt = 0;
				tim_cnt = 0;
			}
		}
		EXTI_ClearITPendingBit(EXTI_Line3);     
	}  
}


void WG_GPIO_Configuration(void)
{
  	GPIO_InitTypeDef GPIO_InitStructure;
    	
	RCC_APB2PeriphClockCmd(RCC_WG_GPIO, ENABLE);   
	
	GPIO_InitStructure.GPIO_Pin = WG_DATA0_PIN | WG_DATA1_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 
	GPIO_Init(WG_GPIO, &GPIO_InitStructure);		 
	
	GPIO_SetBits(WG_GPIO, WG_DATA0_PIN);
	GPIO_SetBits(WG_GPIO, WG_DATA1_PIN);
}

void WG_Config_RX(void)
{
	GPIO_InitTypeDef GPIO_InitStructure; 
	EXTI_InitTypeDef EXTI_InitStructure;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	NVIC_InitTypeDef NVIC_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_WG_GPIO | RCC_APB2Periph_AFIO,ENABLE);	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2 , ENABLE); 
	
	/* EXTI line gpio config(PE2 PE3) */	
	GPIO_InitStructure.GPIO_Pin = WG_DATA0_PIN | WG_DATA1_PIN;       
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; 
	GPIO_Init(WG_GPIO, &GPIO_InitStructure);
	
	/* EXTI line(PE2) mode config */
	GPIO_EXTILineConfig(WG_PortSource, WG_DATA0_PinSource); 
	EXTI_InitStructure.EXTI_Line = EXTI_Line2;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;  
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure); 
	
	/* EXTI line(PE3) mode config */
	GPIO_EXTILineConfig(WG_PortSource, WG_DATA1_PinSource); 
	EXTI_InitStructure.EXTI_Line = EXTI_Line3;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling; 
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);

	NVIC_InitStructure.NVIC_IRQChannel = EXTI2_IRQChannel;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel = EXTI3_IRQChannel;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQChannel;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	// 10ns��ʱ
	TIM_DeInit(TIM2); //��ʼ��TIM2Ϊȱʡֵ
	TIM_TimeBaseInitStruct.TIM_Period = (10 - 1); //����ARR�Զ����ؼĴ���
	TIM_TimeBaseInitStruct.TIM_Prescaler = (72 - 1); //����PSCʱ��Ԥ��Ƶ
	TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1; //����ʱ��ָ�ֵ
	TIM_TimeBaseInitStruct.TIM_CounterMode = 0x0000; //���ü��������ϼ���
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStruct); //��ʼ��
	TIM_ClearFlag(TIM2, TIM_FLAG_Update); //�������жϱ�־
	TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE); //���ж����
	
}


void TIM2_IRQHandler(void)
{
	TIM_ClearFlag(TIM2, TIM_FLAG_Update); //�������жϱ�־
	if(tim_cnt++>2000)     //��ʱ�Զ��رռ�ʱ��
	{
		TIM_Cmd(TIM2, DISABLE);
		WG_temp_buf = 0; 
		WG_cnt = 0;
		tim_cnt = 0;
	}
}


void WG_Config_TX(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
    
	RCC_APB2PeriphClockCmd(RCC_WG_GPIO, ENABLE);   
	
	GPIO_InitStructure.GPIO_Pin = WG_DATA0_PIN | WG_DATA1_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;	 
	GPIO_Init(WG_GPIO, &GPIO_InitStructure);			 
	
	GPIO_SetBits(WG_GPIO, WG_DATA0_PIN);
	GPIO_SetBits(WG_GPIO, WG_DATA1_PIN);
}

//wg_mode : WG_RX_MODE ,WG_TX_MODE
void WG_RTX_Mode(unsigned char wg_mode)
{
	if(wg_mode == WG_RX_MODE)
	{
		WG_Config_RX();
	}
	else if(wg_mode == WG_TX_MODE)
	{
		WG_Config_TX();
	}	
}


void WG_Send_Bit_1(void)
{
	WG_DATA1_LOW;
	Delay_us(100);
	WG_DATA1_HIGH;
	Delay_ms(2);    
}

void WG_Send_Bit_0(void)
{
	WG_DATA0_LOW;
	Delay_us(100);
	WG_DATA0_HIGH;
	Delay_ms(2);   
}


void WG_Send_Byte(unsigned char WG_Byte)
{
	unsigned char i;
	for(i=0;i<8;i++)
    {
		if(WG_Byte&0x80)
			WG_Send_Bit_1();
		else
			WG_Send_Bit_0();
		WG_Byte = WG_Byte << 1;
	}
}

void Send_Wiegand26(unsigned char *str)
{
    unsigned char i;
    unsigned char check_one;  
    unsigned char even;      
    unsigned char odd;      
 
	 
	  check_one = ((str[0]&0x80)>>7)+((str[0]&0x40)>>6)+((str[0]&0x20)>>5)+((str[0]&0x10)>>4)+((str[0]&0x08)>>3)
	               +((str[0]&0x04)>>2)+((str[0]&0x02)>>1)+((str[0]&0x01))+((str[1]&0x80)>>7)+((str[1]&0x40)>>6)
								 +((str[1]&0x20)>>5)+((str[1]&0x10)>>4);
	  if((check_one&0x01)== 0)
	      even = 0;		 
	  else  
		  even = 1;	   
	  
	 
	  check_one = ((str[1]&0x08)>>3)+((str[1]&0x04)>>2)+((str[1]&0x02)>>1)+((str[1]&0x01))+((str[2]&0x80)>>7)
	              +((str[2]&0x40)>>6)+((str[2]&0x20)>>5)+((str[2]&0x10)>>4)+((str[2]&0x08)>>3)+((str[2]&0x04)>>2)
								+((str[2]&0x02)>>1)+(str[2]&0x01);
	  if((check_one&0x01)== 1) 
		  odd = 0;    
	  else  
		  odd = 1;    
	  
		WG_DATA0_HIGH;
		WG_DATA1_HIGH;

    if(even == 0)
    {
        WG_Send_Bit_0();
    }
    else
    {
        WG_Send_Bit_1();
    }
	

    for(i = 0;i<3;i++)
    {
		WG_Send_Byte(str[i]);
    }
	

    if(odd == 0)
    {
        WG_Send_Bit_0();
    }
    else
    {
        WG_Send_Bit_1();
    }
}


unsigned char Get_WG26_Data(unsigned long long src_wg26 , unsigned char *dir_ptr)
{
	unsigned char even_t,odd_t;
	unsigned char check_even , check_odd ,check_one;
//	unsigned char wg_t[3];

	src_wg26 = (uint32_t)src_wg26;
	
	even_t = (src_wg26>>25) & 0x01;
	
	odd_t  = src_wg26 & 0x01;

	check_one = ((src_wg26>>24)&1)+ ((src_wg26>>23)&1)+ ((src_wg26>>22)&1)+ ((src_wg26>>21)&1)+ ((src_wg26>>20)&1)+ ((src_wg26>>19)&1)+
		         ((src_wg26>>18)&1)+ ((src_wg26>>17)&1)+ ((src_wg26>>16)&1)+ ((src_wg26>>15)&1)+ ((src_wg26>>14)&1)+ ((src_wg26>>13)&1);
	if((check_one&0x01)== 0)
	    check_even = 0;	
	else  
		check_even = 1;	   
	
	check_one  = ((src_wg26>>12)&1)+ ((src_wg26>>11)&1)+ ((src_wg26>>10)&1)+ ((src_wg26>>9)&1)+ ((src_wg26>>8)&1)+ ((src_wg26>>7)&1)+ 
				 ((src_wg26>>6)&1)+ ((src_wg26>>5)&1)+ ((src_wg26>>4)&1)+ ((src_wg26>>3)&1)+ ((src_wg26>>2)&1)+ ((src_wg26>>1)&1);
	if((check_one&0x01)== 1)
		check_odd = 0;  
	else
		check_odd = 1;   
	
	if((even_t == check_even) && (odd_t == check_odd))
	{		
		*(dir_ptr++) = src_wg26 >>17;   //MSB
		*(dir_ptr++) = src_wg26 >>9 ;
		*(dir_ptr++) = src_wg26 >>1 ;
		
		return 0;
	}
	else
		return 1;
}



void Send_Wiegand34(unsigned char *str)
{
    unsigned char i;
    unsigned char check_one; 
    unsigned char even;      
    unsigned char odd;     
 

	  check_one = ((str[0]&0x80)>>7)+((str[0]&0x40)>>6)+((str[0]&0x20)>>5)+((str[0]&0x10)>>4)+((str[0]&0x08)>>3)+((str[0]&0x04)>>2)+((str[0]&0x02)>>1)+((str[0]&0x01))+
								((str[1]&0x80)>>7)+((str[1]&0x40)>>6)+((str[1]&0x20)>>5)+((str[1]&0x10)>>4)+((str[1]&0x08)>>3)+((str[1]&0x04)>>2)+((str[1]&0x02)>>1)+((str[1]&0x01));
	  if((check_one&0x01)== 0)
	    even = 0;			
	  else  
		  even = 1;	  

	  check_one = ((str[2]&0x80)>>7)+((str[2]&0x40)>>6)+((str[2]&0x20)>>5)+((str[2]&0x10)>>4)+((str[2]&0x08)>>3)+((str[2]&0x04)>>2)+((str[2]&0x02)>>1)+(str[2]&0x01)+
								((str[3]&0x80)>>7)+((str[3]&0x40)>>6)+((str[3]&0x20)>>5)+((str[3]&0x10)>>4)+((str[3]&0x08)>>3)+((str[3]&0x04)>>2)+((str[3]&0x02)>>1)+(str[3]&0x01);
	  if((check_one&0x01)== 1)
		  odd = 0; 
	  else
		  odd = 1;    
	  
		WG_DATA0_HIGH;
		WG_DATA1_HIGH;
	
    if(even == 0)
    {
        WG_Send_Bit_0();
    }
    else
    {
        WG_Send_Bit_1();
    }

    for(i = 0;i<4;i++)
    {
			WG_Send_Byte(str[i]);
    }

    if(odd == 0)
    {
        WG_Send_Bit_0();
    }
    else
    {
        WG_Send_Bit_1();
    }
}


unsigned char Get_WG34_Data(unsigned long long src_wg34 , unsigned char *dir_ptr)
{
	unsigned char even_t,odd_t;
	unsigned char check_even , check_odd ,check_one;

	even_t = (src_wg34>>33) & 0x01; 
	
	odd_t  = src_wg34 & 0x01;

	check_one = ((src_wg34>>32)&1)+ ((src_wg34>>31)&1)+ ((src_wg34>>30)&1)+ ((src_wg34>>29)&1)+ ((src_wg34>>28)&1)+ ((src_wg34>>27)&1)+((src_wg34>>26)&1)+ ((src_wg34>>25)&1)+
							((src_wg34>>24)&1)+ ((src_wg34>>23)&1)+ ((src_wg34>>22)&1)+ ((src_wg34>>21)&1)+((src_wg34>>20)&1)+ ((src_wg34>>19)&1)+ ((src_wg34>>18)&1)+ ((src_wg34>>17)&1);
	if((check_one&0x01)== 0)
	    check_even = 0;		
	else  
		check_even = 1;	  
	
	check_one = ((src_wg34>>16)&1)+ ((src_wg34>>15)&1)+ ((src_wg34>>14)&1)+ ((src_wg34>>13)&1)+ ((src_wg34>>12)&1)+ ((src_wg34>>11)&1)+((src_wg34>>10)&1)+ ((src_wg34>>9)&1)+
							((src_wg34>>8)&1)+ ((src_wg34>>7)&1)+ ((src_wg34>>6)&1)+ ((src_wg34>>5)&1)+((src_wg34>>4)&1)+ ((src_wg34>>3)&1)+ ((src_wg34>>2)&1)+ ((src_wg34>>1)&1);
	if((check_one&0x01)== 1)
		check_odd = 0;  
	else
		check_odd = 1;   
	
	if((even_t == check_even) && (odd_t == check_odd))
	{		
		*(dir_ptr++) = src_wg34 >>25;  //MSB
		*(dir_ptr++) = src_wg34 >>17;   
		*(dir_ptr++) = src_wg34 >>9 ;
		*(dir_ptr++) = src_wg34 >>1 ;
		
		return 0;
	}
	else
		return 1;
}



