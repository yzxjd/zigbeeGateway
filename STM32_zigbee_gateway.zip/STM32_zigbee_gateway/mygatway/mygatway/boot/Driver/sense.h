#ifndef SENSE__H
#define SENSE__H


#define	FILTER_VALUE		12


void SenseInit(void);
unsigned char SenseStatus(void);
void SenseScan(void);


#endif


