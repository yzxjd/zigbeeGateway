#include "stm32f10x_lib.h"
#include "stm32f10x_api.h"
#include <stdio.h>
#include "cmsis_os.h"
#include "shell.h"
#include "cyclebuffer.h"


void ConsoleInit(void)
{
	GpioConfig(GPIOC,GPIO_Pin_12,GPIO_Mode_AF_PP,GPIO_Speed_50MHz);
	GpioConfig(GPIOD,GPIO_Pin_2,GPIO_Mode_IN_FLOATING,GPIO_Speed_50MHz);
	Uart5Config(115200,8,0,1);
}


void ConsoleSendByte(unsigned char dat)
{
	USART_SendData(UART5,(unsigned short)dat);
	while(USART_GetFlagStatus(UART5, USART_FLAG_TXE)!=SET) ;
}



void ConsoleSendBytes(unsigned char *dat,unsigned short len)
{
	unsigned short i;
	
	for(i=0;i<len;i++)
	{
		ConsoleSendByte(dat[i]);
	}
}


void UART5_IRQHandler(void)
{	
	unsigned char cByte;
	
	if (USART_GetFlagStatus(UART5, USART_FLAG_ORE) != RESET)
	{
		USART_ReceiveData(UART5);
	}
	else if(USART_GetITStatus(UART5, USART_IT_RXNE) != RESET)  
	{
		USART_ClearFlag(UART5,USART_IT_RXNE);    
		cByte=USART_ReceiveData(UART5);
		//ConsoleSendByte(cByte);
		//FourGSendByte(cByte);
		//ShellProcess(cByte);
	}
}


/*******************************************************************/

#pragma import(__use_no_semihosting)

struct __FILE  
{  
	int handle;  
};
FILE __stdout;  

void _sys_exit(int x)  
{  
	x = x;  
}

int fputc(int ch, FILE *f)
{
	ConsoleSendByte((unsigned char)ch);
	return ch;
}



