#include "stm32f10x_api.h"
#include "sense.h"

#define SENSE  PDin(0)

static unsigned char CarFlag=0;

void SenseInit(void)
{
	GpioConfig(GPIOD,GPIO_Pin_0,GPIO_Mode_IPU,GPIO_Speed_50MHz);
}

//��ȡ�ظ���û�г�
unsigned char SenseStatus(void)
{
	return CarFlag;
}

void SenseScan(void)
{	
	static unsigned char SenseFilterA=0,SenseFilterB=0;
	
	if(SENSE == 0)   
	{
		SenseFilterA++;
		if(SenseFilterA == FILTER_VALUE)    //������ظ���
		{	
			CarFlag =1;
		}
		else if(SenseFilterA > FILTER_VALUE)
			SenseFilterA = FILTER_VALUE;
		
		SenseFilterB = 0;
	}
	else
	{
		if(CarFlag==1)
		{
			SenseFilterB++;
			if(SenseFilterB >= FILTER_VALUE)    //���뿪�ظ���
			{
				SenseFilterB = 0;
				CarFlag=0;
			}
		}
		else   //����̬��û�г�
		{
			
		} 
		SenseFilterA = 0;	
	}
}


