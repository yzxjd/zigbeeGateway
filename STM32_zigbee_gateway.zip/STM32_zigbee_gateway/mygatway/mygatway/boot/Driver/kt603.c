#include "stm32f10x_lib.h"
#include "stm32f10x_api.h"
#include <stdio.h>
#include <stdlib.h>
#include "kt603.h"
#include "voice.h"

void Kt603Process(unsigned char dat);

volatile unsigned char VoiceEndFlag;

void Kt603Init(void)
{
	GPIO_PinRemapConfig(GPIO_Remap_USART2,ENABLE);
	
	GpioConfig(GPIOD,GPIO_Pin_5,GPIO_Mode_AF_PP,GPIO_Speed_10MHz);
	GpioConfig(GPIOD,GPIO_Pin_6,GPIO_Mode_IN_FLOATING,GPIO_Speed_10MHz);
	Uart2Config(9600,8,0,1);
	USART_ClearFlag(USART2, USART_FLAG_TC);
	#ifdef HV20
	GpioConfig(GPIOA,GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2,GPIO_Mode_Out_PP,GPIO_Speed_10MHz);
	#else
	GpioConfig(GPIOC,GPIO_Pin_13,GPIO_Mode_Out_PP,GPIO_Speed_10MHz);
	#endif
	//Kt603Reset(); //оƬ��λ
	ChangeSoundVol(7);
}

void USART2_IRQHandler(void)
{	
	unsigned char cByte;
	
	if (USART_GetFlagStatus(USART2, USART_FLAG_ORE) != RESET)
	{
		USART_ReceiveData(USART2);
	}
	else if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)  
	{
		USART_ClearFlag(USART2,USART_IT_RXNE);    
		cByte=USART_ReceiveData(USART2);
		Kt603Process(cByte);
	}
}

static void Kt603SendByte(unsigned char dat)
{
	USART_SendData(USART2,(unsigned short)dat);
	while(USART_GetFlagStatus(USART2, USART_FLAG_TXE)!=SET) ;
}


/****************************************************************************/

static void Kt603Process(unsigned char dat)
{
	static char length=0;
	static char buffer[VOICE_FEED_MAX];
	
	//printf(".%02x ",dat);
	
	if(VOICE_STATUS_START==dat)
	{
		length=0;
	}
	else if(VOICE_STATUS_END==dat)
	{
		switch(buffer[3])
		{	
			case CMD_FLASH_PLAY_END:
				//printf("END\r\n");
				VoiceEndFlag = 1;
				break;
			case CMD_FLASH_ERR:
				//if(buffer[6]==3)       //����δ�������
				{
					VoiceEndFlag = 1;
				}
			//	printf("ERR:%d\r\n",buffer[6]);
				break;
			case CMD_INIT_FINISH:
			//	printf("INIT\r\n");
				break;
		}
	}
	
	buffer[length++]=dat;	
	if(length>=VOICE_FEED_MAX)
	{
		length=0;
	}
}

static void Kt603SendBytes(unsigned char *dat,unsigned short len)
{
	unsigned short i;
	
	//vPortEnterCritical();
	//printf("voice send:%d\r\n",len);
	for(i=0;i<len;i++)
	{
		Kt603SendByte(dat[i]);
		//printf(".%02x ",dat[i]);
	}
	//printf("\r\n");
	//vPortExitCritical();
}



static void SendCmdOne(unsigned char cmd,unsigned char feedback,unsigned short dat)
{
	unsigned char KT603_Buffer[15];
	
	KT603_Buffer[0] = 0x7E;
	KT603_Buffer[1] = 0xFF;
	KT603_Buffer[2] = 6;
	KT603_Buffer[3] = cmd;
	KT603_Buffer[4] = feedback;
	KT603_Buffer[5] = dat >> 8; //datah 
	KT603_Buffer[6] = dat;   //datal
	//DoSum(KT603_Buffer+1,KT603_Buffer[2]);
	KT603_Buffer[KT603_Buffer[2]+1] = 0xEF;
	Kt603SendBytes(KT603_Buffer,KT603_Buffer[2]+2);
}

static void SendCmdContinue(unsigned char cmd,unsigned char feedback,unsigned char* dat,unsigned char datlen)
{
	unsigned char KT603_Buffer[15]={0};
	

	KT603_Buffer[0] = 0x7E;
	KT603_Buffer[1] = 0xFF;
	KT603_Buffer[2] = 0x06;
	
	KT603_Buffer[3] = 0x0D;	
	KT603_Buffer[4] = 0x00;
	KT603_Buffer[5] = 0x00;	
	KT603_Buffer[6] = 0x00;
	
	KT603_Buffer[7] = 0xFE;
	KT603_Buffer[8] = 0xEE;
	
	KT603_Buffer[KT603_Buffer[2]+1] = 0xEF;

	Kt603SendBytes(KT603_Buffer,KT603_Buffer[2]+2);

}


static void SendCmdPause(unsigned char cmd,unsigned char feedback,unsigned char* dat,unsigned char datlen)
{
	unsigned char KT603_Buffer[15]={0};
	

	KT603_Buffer[0] = 0x7E;
	KT603_Buffer[1] = 0xFF;
	KT603_Buffer[2] = 0x06;
	
	KT603_Buffer[3] = 0x0E;	
	KT603_Buffer[4] = 0x00;
	KT603_Buffer[5] = 0x00;	
	KT603_Buffer[6] = 0x00;
	
	KT603_Buffer[7] = 0xFE;
	KT603_Buffer[8] = 0xED;

	KT603_Buffer[KT603_Buffer[2]+1] = 0xEF;

	Kt603SendBytes(KT603_Buffer,KT603_Buffer[2]+2);

}

static void SendCmdStop(unsigned char cmd,unsigned char feedback,unsigned char* dat,unsigned char datlen)
{
	unsigned char KT603_Buffer[15]={0};
	
	KT603_Buffer[0] = 0x7E;
	KT603_Buffer[1] = 0xFF;
	KT603_Buffer[2] = 0x06;
	
	KT603_Buffer[3] = 0x16;	
	KT603_Buffer[4] = 0x00;
	KT603_Buffer[5] = 0x00;
	KT603_Buffer[6] = 0x00;
	KT603_Buffer[7] = 0xFE;
	KT603_Buffer[8] = 0xE5;

	KT603_Buffer[KT603_Buffer[2]+1] = 0xEF;

	Kt603SendBytes(KT603_Buffer,KT603_Buffer[2]+2);

}

void Kt603Reset(void)
{
	SendCmdOne(0x0c,0,0x0);
}

void Kt603StartPlay(unsigned short id)
{
	SendCmdOne(0x0f,0,0x0100|id);
}

void Kt603ContinuePlay(void)
{
	SendCmdContinue(0x0D,0,NULL,0);
}

void Kt603PausePlay(void)
{
	SendCmdPause(0x0E,0,NULL,0);
}

void Kt603StopPlay(void)
{
	SendCmdStop(0x16,0,NULL,0);
}



//////////////////////////////////////////////////////////////////////
#ifdef HV20
#define	VOL_SET_SWITCH					PAout(0) 
#define	VOL_SET_UD	      						PAout(1)
#define 	VOL_SET_PULSE						PAout(2)	

void ChangeSoundVol(unsigned char vol)
{
	unsigned char i;
	
	if(vol < 9)
	{
		VOL_SET_SWITCH = 0;
		VOL_SET_UD = 0; 
		for(i = 0; i < 64; i++)VOL_SET_PULSE = !VOL_SET_PULSE;
		VOL_SET_UD = 1; 
		for(i = 0; i <= (vol * 8); i++)VOL_SET_PULSE = !VOL_SET_PULSE;
		VOL_SET_SWITCH = 1;
	}
	else VOL_SET_SWITCH = 1;
}
#else
#define	VOL_SET_SWITCH					PCout(13) 

void ChangeSoundVol(unsigned char vol)
{
	VOL_SET_SWITCH = 1;
}
#endif


void SetKt603Vol(unsigned short vol)
{
	SendCmdOne(0x06,0,vol);
}

