#include "stm32f10x_lib.h"
#include "stm32f10x_api.h"
#include "feeprom.h"


static void SysClockConfig(void)
{
	u16 i,j=0;
	ErrorStatus HSEStartUpStatus;
      
	// RCC system reset(for debug purpose)
	RCC_DeInit();
	
	// Enable HSE
	RCC_HSEConfig(RCC_HSE_ON);
  	
	// Wait till HSE is ready
	HSEStartUpStatus = RCC_WaitForHSEStartUp();

	while(HSEStartUpStatus != SUCCESS)
	{
		RCC_HSEConfig(RCC_HSE_ON);
		HSEStartUpStatus = RCC_WaitForHSEStartUp();
		for(i = 0; i < 500;i++);
			j++;
		if(j >= 10)
		{
			HSEStartUpStatus = SUCCESS;
			break;
		}
	}
  
	if(HSEStartUpStatus == SUCCESS)
	{
		// HCLK = SYSCLK 
		RCC_HCLKConfig(RCC_SYSCLK_Div1); 

		// PCLK2 = HCLK 
		RCC_PCLK2Config(RCC_HCLK_Div1); 

		// PCLK1 = HCLK/2 
		RCC_PCLK1Config(RCC_HCLK_Div2);

		// Flash 2 wait state 
		FLASH_SetLatency(FLASH_Latency_2);
		// Enable Prefetch Buffer 
		FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);

		// PLLCLK = 8MHz * 9 = 72 MHz 
		RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_9);

		// Enable PLL 
		RCC_PLLCmd(ENABLE);

		// Wait till PLL is ready 
		while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
		{
		}

		// Select PLL as system clock source 
		 RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);

		// Wait till PLL is used as system clock source 
		while(RCC_GetSYSCLKSource() != 0x08)
		{
		}
	}
}

static void GpioPreInit(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO|RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOC|RCC_APB2Periph_GPIOD|RCC_APB2Periph_GPIOE, ENABLE);
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);
	GPIO_DeInit(GPIOA);
	GPIO_DeInit(GPIOB);
	GPIO_DeInit(GPIOC);
	GPIO_DeInit(GPIOD);
	GPIO_DeInit(GPIOE);
}


static void NvicConfig(void)
{
	NVIC_DeInit();
	#ifdef B  //�������B��
		NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x23800); 
	#else 
		#ifdef  A   //�����������A��
		NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x8000);
		#else
		NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0000);
		#endif
	#endif
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);  //�������Ҫ��
}


void McuInit(void)
{
	SysClockConfig();
	NvicConfig();
	GpioPreInit();
}


unsigned int McuGetId(void)
{	
	unsigned int ChipUniqueID[3];
	
	ChipUniqueID[2] = *(__IO u32*)(0X1FFFF7E8);  
	ChipUniqueID[1] = *(__IO u32 *)(0X1FFFF7EC); 
	ChipUniqueID[0] = *(__IO u32 *)(0X1FFFF7F0); 
	
	return ChipUniqueID[0];
}


void Reboot(void)
{
	NVIC_SETFAULTMASK();
	NVIC_GenerateSystemReset();
}


void GpioConfig(GPIO_TypeDef* Port, INT16U Pin ,INT16U Mode,INT16U Speed)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	GPIO_InitStructure.GPIO_Pin = Pin;
	GPIO_InitStructure.GPIO_Mode =(GPIOMode_TypeDef )Mode;
	GPIO_InitStructure.GPIO_Speed =(GPIOSpeed_TypeDef )Speed;
	GPIO_Init(Port, &GPIO_InitStructure);
}


void Uart1Config(unsigned int eBandRate,unsigned char eDataBit,unsigned char eParity,unsigned char eStopBit)
{
	USART_InitTypeDef USART_InitStructure;
	USART_ClockInitTypeDef  USART_ClockInitStructure;
	unsigned short DataBit;
	unsigned short Parity;
	unsigned short StopBit;
	
	/////////////////////////////////////////////////////////////////////
	
	if(eDataBit==9)	 DataBit =  USART_WordLength_9b;
	else DataBit = USART_WordLength_8b;

	if(eParity=='e') Parity = USART_Parity_Even;
	else if(eParity=='o') Parity = USART_Parity_Odd;
	else Parity =  USART_Parity_No;

	if(eStopBit==2) StopBit = USART_StopBits_2;
	else StopBit =  USART_StopBits_1;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
	
	USART_DeInit(USART1);
	
	USART_ClockInitStructure.USART_Clock = USART_Clock_Disable;
	USART_ClockInitStructure.USART_CPOL = USART_CPOL_Low;
	USART_ClockInitStructure.USART_CPHA = USART_CPHA_2Edge;
	USART_ClockInitStructure.USART_LastBit = USART_LastBit_Disable;
	// Configure the USART synchronous paramters 
	USART_ClockInit(USART1, &USART_ClockInitStructure);
       
	USART_InitStructure.USART_BaudRate = eBandRate;
	USART_InitStructure.USART_WordLength = DataBit;
	USART_InitStructure.USART_StopBits = StopBit;
	USART_InitStructure.USART_Parity = Parity;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx |USART_Mode_Tx;
	// Configure USART basic and asynchronous paramters 
	USART_Init(USART1, &USART_InitStructure);
	
	USART_Cmd(USART1, ENABLE);
	USART_ClearFlag(USART1, USART_FLAG_TC);
}


void Uart4Config(unsigned int eBandRate,unsigned char eDataBit,unsigned char eParity,unsigned char eStopBit)
{
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	USART_ClockInitTypeDef  USART_ClockInitStructure;
	unsigned short DataBit;
	unsigned short Parity;
	unsigned short StopBit;
	
	/////////////////////////////////////////////////////////////////////
	NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQChannel;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 4;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	if(eDataBit==9)	 DataBit =  USART_WordLength_9b;
	else DataBit = USART_WordLength_8b;

	if(eParity=='e') Parity = USART_Parity_Even;
	else if(eParity=='o') Parity = USART_Parity_Odd;
	else Parity =  USART_Parity_No;

	if(eStopBit==2) StopBit = USART_StopBits_2;
	else StopBit =  USART_StopBits_1;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4,ENABLE);
	
	USART_DeInit(UART4);
	
	USART_ClockInitStructure.USART_Clock = USART_Clock_Disable;
	USART_ClockInitStructure.USART_CPOL = USART_CPOL_Low;
	USART_ClockInitStructure.USART_CPHA = USART_CPHA_2Edge;
	USART_ClockInitStructure.USART_LastBit = USART_LastBit_Disable;
	// Configure the USART synchronous paramters 
	USART_ClockInit(UART4, &USART_ClockInitStructure);
       
	USART_InitStructure.USART_BaudRate = eBandRate;
	USART_InitStructure.USART_WordLength = DataBit;
	USART_InitStructure.USART_StopBits = StopBit;
	USART_InitStructure.USART_Parity = Parity;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx |USART_Mode_Tx;
	// Configure USART basic and asynchronous paramters 
	USART_Init(UART4, &USART_InitStructure);
	
	USART_ITConfig(UART4,USART_IT_RXNE, ENABLE);	
	
	USART_Cmd(UART4, ENABLE);
	
	USART_ClearFlag(UART4, USART_FLAG_TC);
}



void Uart5Config(unsigned int eBandRate,unsigned char eDataBit,unsigned char eParity,unsigned char eStopBit)
{
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	USART_ClockInitTypeDef  USART_ClockInitStructure;
	unsigned short DataBit;
	unsigned short Parity;
	unsigned short StopBit;
	
	/////////////////////////////////////////////////////////////////////
	NVIC_InitStructure.NVIC_IRQChannel = UART5_IRQChannel;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 6;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	if(eDataBit==9)	 DataBit =  USART_WordLength_9b;
	else DataBit = USART_WordLength_8b;

	if(eParity=='e') Parity = USART_Parity_Even;
	else if(eParity=='o') Parity = USART_Parity_Odd;
	else Parity =  USART_Parity_No;

	if(eStopBit==2) StopBit = USART_StopBits_2;
	else StopBit =  USART_StopBits_1;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5,ENABLE);
	
	USART_DeInit(UART5);
	
	USART_ClockInitStructure.USART_Clock = USART_Clock_Disable;
	USART_ClockInitStructure.USART_CPOL = USART_CPOL_Low;
	USART_ClockInitStructure.USART_CPHA = USART_CPHA_2Edge;
	USART_ClockInitStructure.USART_LastBit = USART_LastBit_Disable;
	// Configure the USART synchronous paramters 
	USART_ClockInit(UART5, &USART_ClockInitStructure);
       
	USART_InitStructure.USART_BaudRate = eBandRate;
	USART_InitStructure.USART_WordLength = DataBit;
	USART_InitStructure.USART_StopBits = StopBit;
	USART_InitStructure.USART_Parity = Parity;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx |USART_Mode_Tx;
	// Configure USART basic and asynchronous paramters 
	USART_Init(UART5, &USART_InitStructure);
	
	USART_ITConfig(UART5,USART_IT_RXNE, ENABLE);	
	
	USART_Cmd(UART5, ENABLE);
	
	USART_ClearFlag(UART5, USART_FLAG_TC);
}




void Uart2Config(INT32U eBandRate,INT8U eDataBit,INT8U eParity,INT8U eStopBit)
{
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	USART_ClockInitTypeDef  USART_ClockInitStructure;
	INT16U DataBit;
	INT16U Parity;
	INT16U StopBit;
	
	NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQChannel;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 6;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	if(eDataBit==9)	 DataBit =  USART_WordLength_9b;
	else DataBit = USART_WordLength_8b;
	
	if(eParity=='e') Parity = USART_Parity_Even;
	else if(eParity=='o') Parity = USART_Parity_Odd;
	else Parity =  USART_Parity_No;
	
	if(eStopBit==2) StopBit = USART_StopBits_2;
	else StopBit =  USART_StopBits_1;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);
	
	USART_DeInit(USART2);
	USART_ClockInitStructure.USART_Clock = USART_Clock_Disable;
	USART_ClockInitStructure.USART_CPOL = USART_CPOL_Low;
	USART_ClockInitStructure.USART_CPHA = USART_CPHA_2Edge;
	USART_ClockInitStructure.USART_LastBit = USART_LastBit_Disable;
	// Configure the USART synchronous paramters 
	USART_ClockInit(USART2, &USART_ClockInitStructure);
          
	USART_InitStructure.USART_BaudRate = eBandRate;
	USART_InitStructure.USART_WordLength = DataBit;
	USART_InitStructure.USART_StopBits = StopBit;
	USART_InitStructure.USART_Parity = Parity;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx |USART_Mode_Tx;
	// Configure USART basic and asynchronous paramters 
	USART_Init(USART2, &USART_InitStructure);
	
	USART_ITConfig(USART2,USART_IT_RXNE, ENABLE);	
	
	USART_Cmd(USART2, ENABLE);
}

void Uart3Config(INT32U eBandRate,INT8U eDataBit,INT8U eParity,INT8U eStopBit)
{
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	USART_ClockInitTypeDef  USART_ClockInitStructure;
	INT16U DataBit;
	INT16U Parity;
	INT16U StopBit;
	
	NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQChannel;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 7;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;  
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	if(eDataBit==9)	 DataBit =  USART_WordLength_9b;
	else DataBit = USART_WordLength_8b;
	
	if(eParity=='e') Parity = USART_Parity_Even;
	else if(eParity=='o') Parity = USART_Parity_Odd;
	else Parity =  USART_Parity_No;
	
	if(eStopBit==2) StopBit = USART_StopBits_2;
	else StopBit =  USART_StopBits_1;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3,ENABLE);
	
	USART_DeInit(USART3);
	USART_ClockInitStructure.USART_Clock = USART_Clock_Disable;
	USART_ClockInitStructure.USART_CPOL = USART_CPOL_Low;
	USART_ClockInitStructure.USART_CPHA = USART_CPHA_2Edge;
	USART_ClockInitStructure.USART_LastBit = USART_LastBit_Disable;
	// Configure the USART synchronous paramters 
	USART_ClockInit(USART3, &USART_ClockInitStructure);
          
	USART_InitStructure.USART_BaudRate = eBandRate;
	USART_InitStructure.USART_WordLength = DataBit;
	USART_InitStructure.USART_StopBits = StopBit;
	USART_InitStructure.USART_Parity = Parity;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx |USART_Mode_Tx;
	// Configure USART basic and asynchronous paramters 
	USART_Init(USART3, &USART_InitStructure);
	
	USART_ITConfig(USART3,USART_IT_RXNE, ENABLE);	
	
	USART_Cmd(USART3, ENABLE);
}



