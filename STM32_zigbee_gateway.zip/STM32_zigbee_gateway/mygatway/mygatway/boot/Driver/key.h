#ifndef KEY__H
#define KEY__H


#define	KEY_FILTER_VALUE		100
#define	KEY_LONG_VALUE		50000


void KeyInit(void);
void KeyScan(void);
unsigned char KeyGet(void);



#endif



