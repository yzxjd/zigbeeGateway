/* Includes ------------------------------------------------------------------*/
#include "rtc.h"
#include "stm32f10x_lib.h"

/* Private define ------------------------------------------------------------*/

static unsigned int const MonthDaysAccuP[13] = {0,31,59,90,120,151,181,212,243,273,304,334,365};
static unsigned int const MonthDaysAccuR[13] = {0,31,60,91,121,152,182,213,244,274,305,335,366};
static unsigned char const LeapYearWeekTab[]={
    (3 << 5) + 31, // 1��
    (6 << 5) + 29, // 2��
    (0 << 5) + 31, // 3��
    (3 << 5) + 30, // 4��
    (5 << 5) + 31, //5��
    (1 << 5) + 30, //6��
    (3 << 5) + 31, //7��
    (6 << 5) + 31, //8��
    (1 << 5) + 30, //9��
    (4 << 5) + 31, //10��
    (0 << 5) + 30, //11��
    (2 << 5) + 31, //12��
};



void RtcInit(void)
{
	/* Enable PWR and BKP clocks */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);
	
	/* Allow access to BKP Domain */
	PWR_BackupAccessCmd(ENABLE);	 
	
	if(BKP_ReadBackupRegister(BKP_DR1) != 0x55AA)
	{
		BKP_DeInit();
		/* Enable LSE */
		RCC_LSEConfig(RCC_LSE_ON);
		/* Wait till LSE is ready */
		while (RCC_GetFlagStatus(RCC_FLAG_LSERDY) == RESET);
		
		/* Select LSE as RTC Clock Source(����ʱ��) */
		RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);
		
		/* Enable RTC Clock */
		RCC_RTCCLKCmd(ENABLE);
		
		/* Wait for RTC registers synchronization */
		RTC_WaitForSynchro();
		
		/* Wait until last write operation on RTC registers has finished */
		RTC_WaitForLastTask();
		
		/* Enable the RTC Second */
//		RTC_ITConfig(RTC_IT_SEC, ENABLE);
		
		/* Wait until last write operation on RTC registers has finished */
//		RTC_WaitForLastTask();
		
		/* Set RTC prescaler: set RTC period to 1sec */
		RTC_SetPrescaler(32767); /* RTC period = RTCCLK/RTC_PR = (32.768 KHz)/(32767+1) */
		
		/* Wait until last write operation on RTC registers has finished */
		RTC_WaitForLastTask();
		
		/* Adjust time by values entred by the user on the hyperterminal */
		//SetCurrentTime();
		
		BKP_WriteBackupRegister(BKP_DR1, 0x55AA);
		RCC_ClearFlag();
	}
	/* Wait for RTC registers synchronization */
	RTC_WaitForSynchro();
	
	/* Wait until last write operation on RTC registers has finished */
	RTC_WaitForLastTask();	
}

 

/*******************************************************************************
* Function Name  : ConversionCurrentTime
* Description    : Returns the total seconds from 2000 to current;
* Input          : None
* Output         : None
* Return         : Current time RTC counter value
*******************************************************************************/
static unsigned int	ConversionCurrentTime(TIME *Time)
{
	unsigned char	r_years,p_years,year,month,day;
	unsigned short  t_days;
	unsigned int	CurrentCountSec;	   
	
	year = ConvertFromBCD(Time->Year);
	month= ConvertFromBCD(Time->Month);
	day  = ConvertFromBCD(Time->Day);
	if(year < 100)
	{
		r_years = year / 4;	  		  //��������
		p_years = year - r_years; 	  //��ƽ����
	       t_days = 366 * r_years + 365 * p_years; 
		if(year % 4)
		{//ƽ��
			t_days += MonthDaysAccuP[month - 1] + (day - 1);
		}
		else
		{ //����
			t_days += MonthDaysAccuR[month - 1] + (day - 1);
		}
		CurrentCountSec = (unsigned int)86400 * t_days + (3600 * ConvertFromBCD(Time->Hour)) + (60 * ConvertFromBCD(Time->Minute)) + ConvertFromBCD(Time->Second);
		return(CurrentCountSec);
	}
	return 0;
}


/*******************************************************************************
* Function Name  : SetCurrentTime
* Description    : Adjusts time.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void RtcSetTime(TIME *Time)
{
  unsigned int	temp;
  /* Wait until last write operation on RTC registers has finished */
  RTC_WaitForLastTask();
  /* Change the current time */
  temp = ConversionCurrentTime(Time);
  RTC_SetCounter(temp);
  RTC_WaitForLastTask();
}

/*******************************************************************************
* Function Name  : ReadCurrentTime
* Description    : get current time
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void RtcReadTime(TIME *Time)
{
	unsigned int	CurrentCountSec;
	unsigned char	y;
	unsigned short  d;	
	/* Wait until last write operation on RTC registers has finished */
	RTC_WaitForLastTask();
	/* get the current time */	
	CurrentCountSec = RTC_GetCounter();
	Time->Second = ConvertToBCD(CurrentCountSec % 60);//��
	CurrentCountSec /= 60;
	Time->Minute = ConvertToBCD(CurrentCountSec % 60);//��
	CurrentCountSec /= 60;
	Time->Hour = ConvertToBCD(CurrentCountSec % 24);//Сʱ
  	CurrentCountSec /= 24;

  	y = (CurrentCountSec / 1461) * 4 + (CurrentCountSec % 1461) / 365; 
	Time->Year = ConvertToBCD(y);  //��
 	d = CurrentCountSec - 365 * y - CurrentCountSec / 1461;
	if(y % 4)
	{//ƽ��
		if(d < 31)      
		{
			Time->Month = 0x01; 
			if((y - 1) % 4)	Time->Day = ConvertToBCD(d + 1);
			else			Time->Day = ConvertToBCD(d);	
		}
		else if(d <  59){Time->Month = 0x02; Time->Day = ConvertToBCD(d - 30);}
		else if(d <  90){Time->Month = 0x03; Time->Day = ConvertToBCD(d - 58);}
		else if(d < 120){Time->Month = 0x04; Time->Day = ConvertToBCD(d - 89);}
		else if(d < 151){Time->Month = 0x05; Time->Day = ConvertToBCD(d - 119);}
		else if(d < 181){Time->Month = 0x06; Time->Day = ConvertToBCD(d - 150);}
		else if(d < 212){Time->Month = 0x07; Time->Day = ConvertToBCD(d - 180);}
		else if(d < 243){Time->Month = 0x08; Time->Day = ConvertToBCD(d - 211);}
		else if(d < 273){Time->Month = 0x09; Time->Day = ConvertToBCD(d - 242);}
		else if(d < 304){Time->Month = 0x10; Time->Day = ConvertToBCD(d - 272);}
		else if(d < 334){Time->Month = 0x11; Time->Day = ConvertToBCD(d - 303);}
		else 		    {Time->Month = 0x12; Time->Day = ConvertToBCD(d - 333);}
	}
	else
	{  
		if(d < 31)      {Time->Month = 0x01; Time->Day = ConvertToBCD(d + 1);}
		else if(d <  60){Time->Month = 0x02; Time->Day = ConvertToBCD(d - 30);}
		else if(d <  91){Time->Month = 0x03; Time->Day = ConvertToBCD(d - 59);}
		else if(d < 121){Time->Month = 0x04; Time->Day = ConvertToBCD(d - 90);}
		else if(d < 152){Time->Month = 0x05; Time->Day = ConvertToBCD(d - 120);}
		else if(d < 182){Time->Month = 0x06; Time->Day = ConvertToBCD(d - 151);}
		else if(d < 213){Time->Month = 0x07; Time->Day = ConvertToBCD(d - 181);}
		else if(d < 244){Time->Month = 0x08; Time->Day = ConvertToBCD(d - 212);}
		else if(d < 274){Time->Month = 0x09; Time->Day = ConvertToBCD(d - 243);}
		else if(d < 305){Time->Month = 0x10; Time->Day = ConvertToBCD(d - 273);}
		else if(d < 335){Time->Month = 0x11; Time->Day = ConvertToBCD(d - 304);}
		else 		    {Time->Month = 0x12; Time->Day = ConvertToBCD(d - 334);}
	}
	Time->Week = DayToWeek(Time->Year, Time->Month, Time->Day);
} 

/********************************************************************  
* ����: ConvertFromBCD   
* ����: BCDת������ 
* ����:  ��Ҫװ����BCD�� 
* ����ֵ: ת�����ֵ
***********************************************************************/ 
static unsigned char  ConvertFromBCD(unsigned char data)
{
	data = (data >> 4) * 10 + (data & 0xf);
	return data;
}


/********************************************************************  
* ����: ConvertToBCD   
* ����: ������תBCD 
* ����:  ��Ҫװ���Ķ������� 
* ����ֵ: ת�����BCD��
***********************************************************************/ 
static unsigned char  ConvertToBCD(unsigned char data)
{
	data = ((data / 10) << 4) + (data % 10);
	return data;
}



/********************************************************************  
i* ����: ͨ��2000�� ~ 2099�����յõ�����   
* ����:  �꣬�£��� 
* ����ֵ: ����
***********************************************************************/ 
static unsigned char DayToWeek(unsigned char year, unsigned char  month, unsigned char day)
{
	unsigned char   Week,Days;		
	year = ConvertFromBCD(year);
	month= ConvertFromBCD(month);
	day  = ConvertFromBCD(day);	
	Days  = LeapYearWeekTab[month - 1];
	Week = Days >> 5;//��������
	Days &= 0x1f;//������ 
	if((month < 3) && (year & 3))
	{//ƽ��
		if(month == 2)Days--;//ƽ��������
		Week++;
	}
	year = year + (year >> 2);
	Week = (Week + year + day + 2) % 7;	
	return Week;
}

