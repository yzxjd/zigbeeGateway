#include "stm32f10x_lib.h"
#include "stm32f10x_api.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "led.h"

//#define LED_USE_DMA 	 


#ifdef LED_USE_DMA
static unsigned char DmaTxBuffer[100];
static volatile unsigned short DmaTxCount;
#endif

void Uart1Config(unsigned int eBandRate,unsigned char eDataBit,unsigned char eParity,unsigned char eStopBit)
{
	USART_InitTypeDef USART_InitStructure;
	USART_ClockInitTypeDef  USART_ClockInitStructure;
	unsigned short DataBit;
	unsigned short Parity;
	unsigned short StopBit;
	
	#ifdef LED_USE_DMA
	NVIC_InitTypeDef NVIC_InitStructure;
	DMA_InitTypeDef   DMA_InitStructure;
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
	DMA_DeInit(DMA1_Channel4);  
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
	DMA_InitStructure.DMA_Priority = DMA_Priority_Low;
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
	DMA_InitStructure.DMA_PeripheralBaseAddr = (unsigned int)&(USART1->DR);
	DMA_InitStructure.DMA_MemoryBaseAddr = (unsigned int)DmaTxBuffer;
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
	DMA_InitStructure.DMA_BufferSize = sizeof(DmaTxBuffer);
	DMA_Init(DMA1_Channel4, &DMA_InitStructure);
	DMA_ITConfig(DMA1_Channel4, DMA_IT_TC, ENABLE);
	
	NVIC_InitStructure.NVIC_IRQChannel = DMA1_Channel4_IRQChannel;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	#endif
	/////////////////////////////////////////////////////////////////////
	
	if(eDataBit==9)	 DataBit =  USART_WordLength_9b;
	else DataBit = USART_WordLength_8b;

	if(eParity=='e') Parity = USART_Parity_Even;
	else if(eParity=='o') Parity = USART_Parity_Odd;
	else Parity =  USART_Parity_No;

	if(eStopBit==2) StopBit = USART_StopBits_2;
	else StopBit =  USART_StopBits_1;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
	
	USART_DeInit(USART1);
	
	USART_ClockInitStructure.USART_Clock = USART_Clock_Disable;
	USART_ClockInitStructure.USART_CPOL = USART_CPOL_Low;
	USART_ClockInitStructure.USART_CPHA = USART_CPHA_2Edge;
	USART_ClockInitStructure.USART_LastBit = USART_LastBit_Disable;
	// Configure the USART synchronous paramters 
	USART_ClockInit(USART1, &USART_ClockInitStructure);
       
       
	USART_InitStructure.USART_BaudRate = eBandRate;
	USART_InitStructure.USART_WordLength = DataBit;
	USART_InitStructure.USART_StopBits = StopBit;
	USART_InitStructure.USART_Parity = Parity;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Tx;
	// Configure USART basic and asynchronous paramters 
	USART_Init(USART1, &USART_InitStructure);
	
	#ifdef LED_USE_DMA
	USART_DMACmd(USART1,USART_DMAReq_Tx,ENABLE);  
	#endif
	
	USART_Cmd(USART1, ENABLE);
	USART_ClearFlag(USART1, USART_FLAG_TC);
}

#ifdef LED_USE_DMA
void DMA1_Channel4_IRQHandler(void)
{
	DMA_ClearFlag(DMA1_FLAG_TC4);  
	DMA_Cmd(DMA1_Channel4,DISABLE);
	DmaTxCount = 0;  
}
#endif

void LedInit(void)
{
	GpioConfig(GPIOA,GPIO_Pin_9,GPIO_Mode_AF_PP,GPIO_Speed_50MHz);
	GpioConfig(GPIOA,GPIO_Pin_10,GPIO_Mode_IN_FLOATING,GPIO_Speed_50MHz);
	Uart1Config(9600,8,0,1);
}


void LedSendByte(unsigned char dat)
{
	USART_SendData(USART1,(unsigned short)dat);
	while(USART_GetFlagStatus(USART1, USART_FLAG_TXE)!=SET) ;
}


#ifdef LED_USE_DMA

void LedSendBytes(unsigned char *dat,unsigned short len)
{
	int i=0;
	
	vPortEnterCritical();
	DmaTxCount = len;
	memcpy(DmaTxBuffer,dat,DmaTxCount);
	DMA_Cmd(DMA1_Channel4,DISABLE);  
	DMA1_Channel4->CNDTR = DmaTxCount;
	vPortExitCritical();
	DMA_Cmd(DMA1_Channel4,ENABLE);  
	while(DmaTxCount)  ;
	
	/*
	vPortEnterCritical();
	printf("display->%40s\r\n",&dat[2]);
	for(i=0;i<len;i++)
	{
		printf("0x%02x ",dat[i]);
	}
	printf("\r\n");
	vPortExitCritical();
	*/
}

#else
void LedSendBytes(unsigned char *dat,unsigned short len)
{
	unsigned int i;
	
	for(i=0;i<len;i++)
	{
		LedSendByte(*(dat+i));
	}
}
#endif

void LedSend(unsigned char *dat,unsigned short len,unsigned short mode)
{
	unsigned char buf[100];
	
	memset(buf,0,sizeof(buf));
	
	if(mode&DISPLAY_FIXED_FLAG)	
	{	
		buf[0]=0x1e;
		buf[1]=0x1f;	
		memcpy(buf+2,dat,len);
		if(mode&DISPLAY_TIME_FLAG)
			buf[len+2]=0x01;
		else
			buf[len+2]=0x02;
		buf[len+3]=0x1c;
		buf[len+4]=0x1d;
		LedSendBytes(buf,len+5);
	}
	else if(mode&DISPLAY_INSERT_FLAG)	
	{
		buf[0]=0x1a;
		buf[1]=0x1b;	
		memcpy(buf+2,dat,len);
		buf[len+2]=mode&0x0f;
		buf[len+3]=0x1c;
		buf[len+4]=0x1d;
		LedSendBytes(buf,len+5);
	}
	else if(mode&DISPLAY_CARNUM_FLAG)	
	{
		buf[0]=0x1a;
		buf[1]=0x55;	
		memcpy(buf+2,dat,len);
		buf[len+2]=0x1c;
		buf[len+3]=0x1d;
		LedSendBytes(buf,len+4);
	}
	else if(mode&DISPLAY_SET_TIME_FLAG)	
	{
		buf[0]=0x13;
		memcpy(buf+1,dat,7);
		LedSendBytes(buf,8);
	}
}


