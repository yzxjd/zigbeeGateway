#ifndef  GATE_APP_H
#define GATE_APP_H


#ifdef HV20
#define GATE_OPEN_PORT GPIOE
#define GATE_CLOSE_PORT GPIOE
#define GATE_OPEN_PIN GPIO_Pin_13
#define GATE_CLOSE_PIN GPIO_Pin_14
#else
#define GATE_OPEN_PORT GPIOC
#define GATE_CLOSE_PORT GPIOC
#define GATE_OPEN_PIN GPIO_Pin_1
#define GATE_CLOSE_PIN GPIO_Pin_2
#endif


void gateTask(void const * argument);
void GateInit(void);
int GateCreateSem(void);
int GatePendSem (void);
void GatePostSem(void);
void GateModeSet(unsigned char mode);
unsigned char GateModeGet(void);
void GateOpen(void);
void GateClose(void);

#endif

