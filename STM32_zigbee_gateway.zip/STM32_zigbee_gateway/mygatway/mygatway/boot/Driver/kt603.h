#ifndef VOICE_K403A_H
#define VOICE_K403A_H

#define VOICE_STATUS_START	 		0x7E 
#define VOICE_STATUS_END	 			0xEF 
#define VOICE_FEED_MAX					20
#define CMD_FLASH_PLAY_END			0x3E
#define CMD_FLASH_ERR					0x40
#define CMD_INIT_FINISH					0x3f


void Kt603Init(void);
void Kt603Reset(void);
void Kt603Process(unsigned char dat);
void Kt603StartPlay(unsigned short id);
void Kt603ContinuePlay(void);
void Kt603PausePlay(void);
void Kt603StopPlay(void);
void SetKt603Vol(unsigned short vol);




#endif
