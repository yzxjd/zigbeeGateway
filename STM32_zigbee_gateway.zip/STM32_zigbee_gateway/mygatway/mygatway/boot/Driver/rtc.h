#ifndef RTC_H
#define RTC_H

typedef struct 
{
	unsigned char  Year;  
	unsigned char  Month;
	unsigned char  Day;
	unsigned char  Hour;
	unsigned char  Minute;
	unsigned char  Second;
	unsigned char  Week;
}TIME;


unsigned char   ConvertToBCD(unsigned char data);
unsigned char   ConvertFromBCD(unsigned char data);
unsigned char   DayToWeek(unsigned char year, unsigned char  month, unsigned char day);
unsigned int	ConversionCurrentTime(TIME *CurrentTime);
void RtcSetTime(TIME *Time);
void RtcReadTime(TIME *Time);
void RtcInit(void);


#endif
