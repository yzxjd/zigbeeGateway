#ifndef LED_H
#define LED_H

#define DISPLAY_TIME_FLAG  		0x0100	
#define DISPLAY_FIXED_FLAG		0x8000
#define DISPLAY_CARNUM_FLAG	0x2000
#define DISPLAY_INSERT_FLAG	0x4000
#define DISPLAY_SET_TIME_FLAG	0x1000


void LedInit(void);
void LedSendBytes(unsigned char *dat,unsigned short len);
void LedSend(unsigned char *dat,unsigned short len,unsigned short mode);

#endif

