#include "stm32f10x_lib.h"
#include "stm32f10x_api.h"
#include "cmsis_os.h"
#include "gate.h"


static osSemaphoreId Semsobj;
static unsigned char OpenFlag=0;
static unsigned char GateMode=0;

void GateInit(void)
{
	GpioConfig(GATE_OPEN_PORT,GATE_OPEN_PIN,GPIO_Mode_Out_PP,GPIO_Speed_50MHz);
	GpioConfig(GATE_CLOSE_PORT,GATE_CLOSE_PIN,GPIO_Mode_Out_PP,GPIO_Speed_50MHz);
	GateModeSet(0);
}


void GateModeSet(unsigned char mode)
{	
	GateMode = mode;
}
unsigned char GateModeGet(void)
{	
	return GateMode;
}

void GateOpen(void)
{
	OpenFlag =1;
	GatePostSem();
}

void GateClose(void)
{
	OpenFlag =0;
	GatePostSem();
}


void gateTask(void const * argument)
{
	GateCreateSem();
	
	while(1)
	{
		GatePendSem();
		if(OpenFlag==1)
		{
			if(!GateMode)  //�Ǹ߷�ģʽ
			{	
				GPIO_SetBits(GATE_OPEN_PORT, GATE_OPEN_PIN);
				osDelay(500);
				GPIO_ResetBits(GATE_OPEN_PORT, GATE_OPEN_PIN);
			}
			else if(!GPIO_ReadOutputDataBit(GATE_OPEN_PORT,GATE_OPEN_PIN))  //�߷�ģʽ�³��ֵ͵�ƽ��˵��ǰ���й�բ��������ǰբ��״̬�ǹص�
			{	
				GPIO_SetBits(GATE_OPEN_PORT, GATE_OPEN_PIN);
				osDelay(250);
				GPIO_ResetBits(GATE_OPEN_PORT, GATE_OPEN_PIN);
				osDelay(250);
				GPIO_SetBits(GATE_OPEN_PORT, GATE_OPEN_PIN);
			}
		}
		else
		{
			GPIO_ResetBits(GATE_OPEN_PORT, GATE_OPEN_PIN);
			GPIO_SetBits(GATE_CLOSE_PORT, GATE_CLOSE_PIN);	
			osDelay(500);
			GPIO_ResetBits(GATE_CLOSE_PORT, GATE_CLOSE_PIN);
		}
	}
}



int GateCreateSem(void)
{
	int ret;

	osSemaphoreDef(GATE_E);
	Semsobj = osSemaphoreCreate(osSemaphore(GATE_E), 1);		
	ret = (Semsobj != NULL);

	return ret;
}


int GatePendSem (void)
{
	int ret = 0;

	if(osSemaphoreWait(Semsobj, osWaitForever) == osOK)
	{
		ret = 1;
	}
	
	return ret;
}


void GatePostSem(void)
{
	if(Semsobj!=NULL)
		osSemaphoreRelease(Semsobj);
}

