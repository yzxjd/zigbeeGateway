#ifndef VOICE_H
#define VOICE_H

#include "usrApp.h"

#define VOICE_BUFF_MAX   20
#define VOICE_VOL_DEFAULT  2

typedef struct _PLAY
{
	unsigned char	Code;  //���������������ļ���
	STOP_INFO  StopInfo;
}PLAY;

typedef struct _VOICE_MSG
{
	unsigned char  cmd;
	PLAY  play;
}VOICE_MSG;





void VoiceInit(void);
void VoiceVolSet(unsigned char vol);
void VoiceSend(unsigned char cmd,PLAY *pPlay);
void VoiceInsertSend(unsigned char cmd,unsigned char *codes,unsigned char len);
void VoicePlay(unsigned char cmd,PLAY *pPlay);
void VoiceSetPlayType(unsigned char Type);
void VoiceContinue(void);
void VoicePause(void);
void voiceTask(void const * argument);
int VoiceCreateQueue(void);
void VoiceFlushQueue(void);
int VoicePendQueue (VOICE_MSG *pVoiceMsg);
void VoicePostQueue(VOICE_MSG *pVoiceMsg);
int VoiceCreateSem(void);
int VoicePendSem (void);
void VoicePostSem(void);
long volFunc_Voice(int argc,char **argv);
void ChangeSoundVol(unsigned char vol);

#endif
