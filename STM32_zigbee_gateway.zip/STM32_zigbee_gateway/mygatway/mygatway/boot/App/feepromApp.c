#include "stm32f10x_lib.h"
#include "stm32f10x_api.h"
#include "usrApp.h"
#include "net.h"
#include "feeprom.h"
#include "feepromApp.h"
#include "string.h"
#include "stdlib.h"
#include "stdio.h"
#include "cmsis_os.h"
#include "updata.h"
/*********************************************************************/

//static osMutexId Semsobj;
extern unsigned short StopCarTableSize;
extern unsigned int myID;
void WriteMd(unsigned int *md);

long feepromFunc_store(int argc,char **argv)
{
	unsigned char ret;
	unsigned char buf[100];
	unsigned int id;
	
	if(!strcmp(argv[0],"write"))  
	{
		ret=EE_WriteData(EE_KEY_TEST,(unsigned char *)argv[1],100);
		printf("write[%d]:%s\r\n",ret,argv[1]);
	}
	if(!strcmp(argv[0],"read"))
	{
		ret = EE_ReadData(EE_KEY_TEST,(unsigned char *)buf,100);
		printf("read[%d]:%s\r\n",ret,buf);
	}
	if(!strcmp(argv[0],"ee"))  
	{
		ret = FeepromAppReset();
		printf("ee[%d]\r\n",ret);
	}
	if(!strcmp(argv[0],"myid"))  
	{
		id = atoi(argv[1]);
		WriteMd(&id);
		myID = id;
		printf("set myid:%x\r\n",myID);
		Reboot();
	}
	if(!strcmp(argv[0],"port"))
	{
		id = atoi(argv[1]);
		EE_WriteData(EE_KEY_SERVER_PORT,(unsigned char *)&id,2);
		printf("set port [%d] ok\r\n",id);
	}
	return 0;
}


void FeepromAppInit(void)
{	
	HEAD Head;
		
	vPortEnterCritical();
	FLASH_Unlock();
	EE_Init();
	FLASH_Lock();
	vPortExitCritical();
	
	FeepromCreateMutex();
	
	//ReadNetInfo(GetNetConfigAddr());
	//ReadHeadInfo(&Head);
}


unsigned char FeepromAppReset(void)
{
	//printf("para reset!\r\n");
	unsigned char ret;
	
	FeepromPendMutex();
	ret = EE_Format();
	FeepromPostMutex();
	
	return ret;
}



static void ReadNetInfo(NET_CONFIG *pNetConfig)
{	
	unsigned int macs;
	NET_CONFIGPARA NetConfigPara;
	
	FeepromPendMutex();
	
	macs = McuGetId();
	
	pNetConfig->mac[5]=(macs>>(8*0))&0xff;
	pNetConfig->mac[4]=(macs>>(8*1))&0xff;
	pNetConfig->mac[3]=(macs>>(8*2))&0xff;
	pNetConfig->mac[2]=(macs>>(8*3))&0xff;
	pNetConfig->mac[1]=(unsigned char)'B';
	pNetConfig->mac[0]=(unsigned char)'L';
	
	pNetConfig->lport = 5000;
	
	if(EE_ReadData(EE_KEY_NET,(unsigned char *)&NetConfigPara,sizeof(NET_CONFIGPARA))!=0)
	{
		NetConfigPara.lip[0]=192;
		NetConfigPara.lip[1]=168;
		NetConfigPara.lip[2]=1;
		NetConfigPara.lip[3]=204;
		
		NetConfigPara.sub[0]=255;
		NetConfigPara.sub[1]=255;
		NetConfigPara.sub[2]=255;
		NetConfigPara.sub[3]=0;
		
		NetConfigPara.gw[0]=192;
		NetConfigPara.gw[1]=168;
		NetConfigPara.gw[2]=1;
		NetConfigPara.gw[3]=1;
		NetConfigPara.canaddr=4;
		EE_WriteData(EE_KEY_NET,(unsigned char *)&NetConfigPara,sizeof(NET_CONFIGPARA));
		//EE_ReadData(EE_KEY_NET,(unsigned char *)&NetConfigPara,sizeof(NET_CONFIGPARA));
	}
	memcpy(pNetConfig->lip,NetConfigPara.lip,4);
	memcpy(pNetConfig->sub,NetConfigPara.sub,4);
	memcpy(pNetConfig->gw,NetConfigPara.gw,4);
	pNetConfig->canaddr = NetConfigPara.canaddr;
	FeepromPostMutex();
}


void WriteNetConfig(NET_CONFIG *pNetConfig)
{
	NET_CONFIGPARA NetConfigPara;
	
	memcpy(NetConfigPara.lip,pNetConfig->lip,4);
	memcpy(NetConfigPara.sub,pNetConfig->sub,4);
	memcpy(NetConfigPara.gw,pNetConfig->gw,4);
	NetConfigPara.canaddr=pNetConfig->canaddr;

	FeepromPendMutex();
	EE_WriteData(EE_KEY_NET,(unsigned char *)&NetConfigPara,sizeof(NET_CONFIGPARA));
	FeepromPostMutex();
}



void ReadMd(unsigned int *md)
{	
	unsigned int mymd=1;
	
	FeepromPendMutex();
	
	if(EE_ReadData(EE_KEY_MD,(unsigned char *)md,sizeof(unsigned int))!=0)
	{
		EE_WriteData(EE_KEY_MD,(unsigned char *)&mymd,sizeof(unsigned int));
		(*md) = mymd;
	}
	printf("read myid :%x\r\n",*md);
	FeepromPostMutex();
}


void WriteMd(unsigned int *md)
{
	FeepromPendMutex();
	EE_WriteData(EE_KEY_MD,(unsigned char *)md,sizeof(unsigned int));
	printf("write myid :%x\r\n",*md);
	FeepromPostMutex();
}


void ReadServerIpPort(unsigned char *ip,unsigned short *port)
{	
	unsigned char myip[4]={112,74,132,1};
	unsigned short myport=1884;
	
	FeepromPendMutex();
	
	if(EE_ReadData(EE_KEY_SERVER_IP,(unsigned char *)ip,4)!=0)
	{
		EE_WriteData(EE_KEY_SERVER_IP,(unsigned char *)&myip,4);
		memcpy(ip,myip,4);
	}
	if(EE_ReadData(EE_KEY_SERVER_PORT,(unsigned char *)port,2)!=0)
	{
		EE_WriteData(EE_KEY_SERVER_PORT,(unsigned char *)&myport,2);
		(*port) = myport;
	}
	FeepromPostMutex();
}


void WriteServerIpPort(unsigned char *ip,unsigned short *port)
{
	FeepromPendMutex();
	EE_WriteData(EE_KEY_SERVER_IP,(unsigned char *)ip,4);
	EE_WriteData(EE_KEY_SERVER_PORT,(unsigned char *)port,2);
	FeepromPostMutex();
}


int FeepromCreateMutex(void)
{
	int ret=0;
	/*
	osMutexDef(FEEPROM_M);
	Semsobj = osMutexCreate(osMutex(FEEPROM_M));		
	ret = (Semsobj != NULL);
	*/
	return ret;
}


int FeepromPendMutex (void)
{/*
	int ret = 0;
	
	if(osMutexWait(Semsobj, osWaitForever) == osOK)
	{
		ret = 1;
	}
	
	return ret;
*/
		vPortEnterCritical();
    return 0;
}


void FeepromPostMutex(void)
{
	/*
	if(Semsobj!=NULL)
		osMutexRelease(Semsobj);
*/
		vPortExitCritical();
}

