#include "usrApp.h"
#include "net.h"
#include "rtc.h"
#include "stdio.h"
#include "string.h"
#include "stm32f10x_api.h"
#include "feeprom.h"
#include "feepromApp.h"
#include "cmsis_os.h"
#include "zigbee.h"
#include "cjson.h"
#include "ff.h"
#include "MQTTFreeRTOS.h"


static osMessageQId Msgsobj,MsgsPub;
static osMessageQId MsgsStopList,MsgsGuideList,MsgsLampList;

struct list_head stophead;   //��λ����ͷ
struct list_head guidehead; 
struct list_head lamphead; 

static FATFS fs;

char serverIp[4];
int serverPort;
unsigned int myID=1;
unsigned int myIDbak=1;


void StopNodeListInit(void)
{
	StopListMutexLock(); 
	INIT_LIST_HEAD(&stophead);
	StopListMutexUnlock(); 
}


void GuideNodeListInit(void)
{
	GuideListMutexLock(); 
	INIT_LIST_HEAD(&guidehead);
	GuideListMutexUnlock(); 
}

void LampNodeListInit(void)
{
	LampListMutexLock(); 
	INIT_LIST_HEAD(&lamphead);
	LampListMutexUnlock(); 
	
}


int DelStopNode(unsigned char *pCarName)
{
	struct list_head *stopnode;
	PARK_STOP_NODE *tmp=NULL;

	StopListMutexLock();
	//����豸�Ƿ���ע��
	__list_for_each(stopnode, &stophead) 
	{
		tmp = list_entry(stopnode,PARK_STOP_NODE, list); 
		
		if(!strcmp(pCarName,tmp->ParkTableNode.StopNum))   //�����ͬ
		{
		        list_del(&tmp->list);
			 printf("ɾ%s\r\n",tmp->ParkTableNode.StopNum);
			 free(tmp);
			 StopListMutexUnlock();
			 return 0;
		}
	}
	StopListMutexUnlock();
	
	return 0xff;
}


unsigned char  FreeStopNode(void)     // �ͷ����г�λ�ڵ㣬��ʱ��Ӧ���������������ʴ�����
{
	struct list_head *stopnode;
	PARK_STOP_NODE *tmp;

	StopListMutexLock();
	__list_for_each(stopnode, &stophead)
	{
		tmp = list_entry(stopnode,PARK_STOP_NODE, list);
		list_del(&tmp->list);
		free(tmp);
	}
	StopListMutexUnlock();
	
	return 0;
}


unsigned char  FreeGuideNode(void)
{
	struct list_head *stopnode;
	PARK_GUIDE_NODE *tmp;

	GuideListMutexLock();
	__list_for_each(stopnode, &guidehead)
	{
		tmp = list_entry(stopnode,PARK_GUIDE_NODE, list); 
		list_del(&tmp->list);
		free(tmp);
	}
	GuideListMutexUnlock();
	
	return 0;
}


unsigned char  FreeLampNode(void)
{
	struct list_head *node;
	PARK_LAMP_NODE *tmp;

	 LampListMutexLock();
	__list_for_each(node, &lamphead)
	{
		tmp = list_entry(node,PARK_LAMP_NODE, list); 
		list_del(&tmp->list);
		free(tmp);
	}
	LampListMutexUnlock();

	return 0;
}

unsigned char  AddOrModifyStopNode(PARK_STOP_NODE *pStopNode)
{
	struct list_head *stopnode;
	PARK_STOP_NODE *tmp;

	StopListMutexLock();
	//����豸�Ƿ���ע��
	__list_for_each(stopnode, &stophead)
	{
		tmp = list_entry(stopnode,PARK_STOP_NODE, list); 
		if(pStopNode->ParkTableNode.StopID==tmp->ParkTableNode.StopID)   //�����ͬ,�򸲸�ԭ����
		{
			 memcpy(tmp->ParkTableNode.StopNum,pStopNode->ParkTableNode.StopNum,sizeof(pStopNode->ParkTableNode.StopNum));
			 tmp->ParkTableNode.Area = pStopNode->ParkTableNode.Area;
			 tmp->ParkTableNode.ZdEnable = pStopNode->ParkTableNode.ZdEnable;
			 printf("��%s��λID:%x\r\n",pStopNode->ParkTableNode.StopNum,pStopNode->ParkTableNode.StopID);
			 StopListMutexUnlock();
			 return 0;
		}
	}
	
	printf("��%s��λID:%x\r\n",pStopNode->ParkTableNode.StopNum,pStopNode->ParkTableNode.StopID);
	pStopNode->Status =0x81;  //Ҫ��ʼ��Ϊ�г�����ΪҪ����ͳ�ƿճ�λ���������ֵҪ��ʼ��Ϊ1
	pStopNode->StatusBak =0xff;
	list_add(&pStopNode->list,&stophead);  
	StopListMutexUnlock();
	
	return 1;
}


//��λ״̬����: ͨ����λID��,��ѯ��λ��Ӧ��Ϣ
PARK_STOP_NODE *GetStopNodeByStopID(unsigned int StopID)
{
	struct list_head *stopnode;
	PARK_STOP_NODE *tmp;
	
	__list_for_each(stopnode, &stophead) 
	{
		tmp = list_entry(stopnode,PARK_STOP_NODE, list);
		//printf("%s��λID:%x\r\n",tmp->ParkTableNode.StopNum,tmp->ParkTableNode.StopID);
		if(tmp->ParkTableNode.StopID == StopID)
		{
			 return tmp;
		}
	}
	
	return NULL;
}



PARK_GUIDE_NODE *GetGuideNodeByGuideID(unsigned int GuideID)
{
	struct list_head *guidenode;
	PARK_GUIDE_NODE *tmp;
	
	__list_for_each(guidenode, &guidehead) 
	{
		tmp = list_entry(guidenode,PARK_GUIDE_NODE, list);
		
		if(tmp->GuideTableNode.GuideID == GuideID)
		{
			  
			 return tmp;
		}
	}
	 
	return NULL;
}


PARK_LAMP_NODE *GetLampNodeByLampID(unsigned int LampID)
{
	struct list_head *node;
	PARK_LAMP_NODE *tmp;

	 
	__list_for_each(node, &lamphead) 
	{
		tmp = list_entry(node,PARK_LAMP_NODE, list);
		
		if(tmp->LampTableNode.LampID == LampID)
		{
			  
			 return tmp;
		}
	}
	 
	return NULL;
}


void KeepScanInit(void)  
{
	struct list_head *node;
	PARK_STOP_NODE *tmp;
	PARK_GUIDE_NODE *tmp1;
	PARK_LAMP_NODE *tmp2;
	
	//��λ����ɨ��
	StopListMutexLock();
	__list_for_each(node, &stophead) 
	{
		tmp = list_entry(node,PARK_STOP_NODE, list); 
		tmp->StatusBak = 0xff;
	}
	StopListMutexUnlock();
	
	//ָʾ������ɨ��
	LampListMutexLock();
	__list_for_each(node, &lamphead) 
	{
		tmp2 = list_entry(node,PARK_LAMP_NODE, list); 
		tmp2->StatusBak = 0xff;
	}
	LampListMutexUnlock();
	
	//ָʾ������ɨ��
	GuideListMutexLock();
	__list_for_each(node, &guidehead) 
	{
		tmp1 = list_entry(node,PARK_GUIDE_NODE, list); 
		tmp1->StatusBak = 0xff;
	}
	GuideListMutexUnlock();
}



void  ZigbeeSendScan(void)    // 100msһ��
{
	struct list_head *node;
	PARK_STOP_NODE *tmp;
	PARK_GUIDE_NODE *tmp1;
	PARK_LAMP_NODE *tmp2;
	unsigned char dat[3];
	
	StopListMutexLock();
	__list_for_each(node, &stophead) 
	{
		tmp = list_entry(node,PARK_STOP_NODE, list); 
		if((tmp->ParkTableNode.ZdEnable&0x80)!=0)
		{
			tmp->ParkTableNode.ZdEnable=(tmp->ParkTableNode.ZdEnable&0x7f);
			tmp->KeepCnt = 0;
			tmp->Status &=0x7f;
			tmp->StatusBak = 0xff;
			dat[0]=tmp->ParkTableNode.ZdEnable&0x01;
			dat[1]=0;
			dat[2]=0;
			ZigbeeSendToDstIDCmd(tmp->ParkTableNode.StopID,0x0e,dat,3);
			printf("%04d��λ����״̬:%d\r\n",tmp->ParkTableNode.StopID,dat[0]);
			StopListMutexUnlock();
			return ;
		}
	}
	StopListMutexUnlock();
	
	LampListMutexLock();
	__list_for_each(node, &lamphead) 
	{
		tmp2 = list_entry(node,PARK_LAMP_NODE, list); 
		if(tmp2->EmptyCnt!=tmp2->EmptyCntBak)
		{
			tmp2->EmptyCntBak = tmp2->EmptyCnt;
			
			if(tmp2->EmptyCnt==0)   //����λ
			{
				tmp2->Status|=0x01;	 
			}
			else
			{
				tmp2->Status&=0xfe;	 
			}
			dat[0]=tmp2->Status&0x01;
			dat[1]=0;
			dat[2]=0;
			
			ZigbeeSendToDstIDCmd(tmp2->LampTableNode.LampID,0x03,dat,3);
			printf("%sָʾ��,%d,��λ��%d\r\n",tmp2->LampTableNode.LampNum,dat[0],tmp2->EmptyCnt);
			LampListMutexUnlock();
			return ;    //��ʱ100ms
		}
	}
	LampListMutexUnlock();
	
	GuideListMutexLock();
	__list_for_each(node, &guidehead) 
	{
		tmp1 = list_entry(node,PARK_GUIDE_NODE, list); 
		if(tmp1->EmptyCnt!=tmp1->EmptyCntBak)
		{
			tmp1->EmptyCntBak = tmp1->EmptyCnt;
			
			dat[0]=0;
			dat[1]=tmp1->EmptyCnt&0x00ff;
			dat[2]=tmp1->EmptyCnt>>8;
			
			ZigbeeSendToDstIDCmd(tmp1->GuideTableNode.GuideID,0x03,dat,3);
			printf("%sָʾ�ƿ�λ��:  %d\r\n",tmp1->GuideTableNode.GuideNum,tmp1->EmptyCnt);
			GuideListMutexUnlock();
			return ;   //��ʱ100ms
		}
	}
	GuideListMutexUnlock();
	
	return ;
}


void KeepScan(void)   //�ն�����ɨ��,1Sһ��ˢ��
{
	struct list_head *node;
	PARK_STOP_NODE *tmp;
	PARK_GUIDE_NODE *tmp1;
	PARK_LAMP_NODE *tmp2;
	unsigned char dat[3];
	unsigned char cnt=0;
	
	StopListMutexLock();
	//��λ����ɨ��
	__list_for_each(node, &stophead) 
	{
		tmp = list_entry(node,PARK_STOP_NODE, list); 
		if(tmp->KeepCnt>120)    // 120s���
		{
			tmp->KeepCnt=0;
			if(((tmp->Status&0x80)==0)||    //�����ߵ�״̬������
				((tmp->Status&0x01)==0))      //���޳������������
			{
				if((tmp->Status&0x01)==0)  //���޳������������
				{
					StopListMutexUnlock();  //��ֹ��������
					GuideScanByStopID(tmp->ParkTableNode.StopID,0x01);   //�޳����г�
					LampScanByStopID(tmp->ParkTableNode.StopID,0x01);
					StopListMutexLock();
				}
				tmp->Status |=0x81;
				tmp->Battery =0;  // �������õ���Ϊ0
			}
			printf("%s��λ����[0x%x]\r\n",tmp->ParkTableNode.StopNum,tmp->Status);
		}
		else
		{
			tmp->KeepCnt++;
		}
		if(tmp->StatusBak  != tmp->Status)     //��ʼ̬StatusBak =0xff    Status= 0x81 
		{
			if(cnt<3)   //�ɹ�����3������Ϣһ�£�����ģ�黺��������
			{
				if(MQTTPublishCarStatus(tmp)==0)
				{
					cnt++;
				}
			}
		}
	}
	StopListMutexUnlock();
	
	//ָʾ������ɨ��
	LampListMutexLock();
	__list_for_each(node, &lamphead) 
	{
		tmp2 = list_entry(node,PARK_LAMP_NODE, list); 
		if(tmp2->KeepCnt>120)    // 120s���
		{	
			tmp2->KeepCnt=0; 
			if((tmp2->Status&0x80)==0)     //�����ߵ�״̬������
			{
				tmp2->Status |=0x80;
			}
			printf("%sָʾ������[0x%x]\r\n",tmp2->LampTableNode.LampNum,tmp2->Status);
		}
		else
		{
			tmp2->KeepCnt++;
		}
		if(tmp2->StatusBak  != tmp2->Status)
		{
			if(cnt<3)  
			{
				if(MQTTPublishLampStatus(tmp2)==0)
				{
					cnt++;
				}
			}
		}
	}
	LampListMutexUnlock();
	
	//ָʾ������ɨ��
	GuideListMutexLock();
	__list_for_each(node, &guidehead) 
	{
		tmp1 = list_entry(node,PARK_GUIDE_NODE, list); 
		if(tmp1->KeepCnt>120)    // 60s���
		{
			tmp1->KeepCnt=0; 
			if((tmp1->Status&0x01)==0)    //�������״̬������������
			{
				tmp1->Status |= 0x01;
			}
			printf("%sָʾ������\r\n",tmp1->GuideTableNode.GuideNum);
		}
		else
		{
			tmp1->KeepCnt++;
		}
		if(tmp1->StatusBak  != tmp1->Status)
		{
			if(cnt<3)  
			{
				if(MQTTPublishGuideStatus(tmp1)==0)
				{
					cnt++;
				}
			}
		}
	}
	GuideListMutexUnlock();
}



unsigned char  AddOrModifyGuideNode(PARK_GUIDE_NODE *pGuideNode)
{
	struct list_head *guidenode;
	PARK_GUIDE_NODE *tmp;
	unsigned short i;

	GuideListMutexLock();
	//����豸�Ƿ���ע��
	__list_for_each(guidenode, &guidehead)
	{
		tmp = list_entry(guidenode,PARK_GUIDE_NODE, list); 
		if(pGuideNode->GuideTableNode.GuideID==tmp->GuideTableNode.GuideID)   //�����ͬ,�򸲸�ԭ����
		{
			 memcpy(tmp->GuideTableNode.GuideNum,pGuideNode->GuideTableNode.GuideNum,sizeof(pGuideNode->GuideTableNode.GuideNum));
			 tmp->GuideTableNode.GuideID = pGuideNode->GuideTableNode.GuideID |0x40000000;
			 tmp->GuideTableNode.StopCnt = pGuideNode->GuideTableNode.StopCnt;
			 for(i=0;i<pGuideNode->GuideTableNode.StopCnt;i++)
			 {
				 tmp->GuideTableNode.StopTable[i] = pGuideNode->GuideTableNode.StopTable[i];
			 }
			 printf("����%s\r\n",pGuideNode->GuideTableNode.GuideNum);
			 GuideListMutexUnlock();  
			 return 0;
		}
	}
	
	printf("����%s\r\n",pGuideNode->GuideTableNode.GuideNum);
	pGuideNode->Status =0x01;  //Ĭ��Ϊ���� 
	pGuideNode->StatusBak =0xff;  
	pGuideNode->EmptyCnt=0;
	pGuideNode->GuideTableNode.GuideID |=0x40000000;
	list_add(&pGuideNode->list,&guidehead);  
	GuideListMutexUnlock();
	
	return 1;
}


int DelGuideNode(unsigned char *pGuideName)
{
	struct list_head *guidenode;
	PARK_GUIDE_NODE *tmp=NULL;
         
	//����豸�Ƿ���ע��
	GuideListMutexLock();
	__list_for_each(guidenode, &guidehead) 
	{
		tmp = list_entry(guidenode,PARK_GUIDE_NODE, list); 
		
		if(!strcmp(pGuideName,tmp->GuideTableNode.GuideNum))   //�����ͬ
		{
		        list_del(&tmp->list);
			 printf("ɾ��%s\r\n",tmp->GuideTableNode.GuideNum);
			 free(tmp);  
			 GuideListMutexUnlock();
			 return 0;
		}
	}
	GuideListMutexUnlock();
	return 0xff;
}


unsigned char  AddOrModifyLampNode(PARK_LAMP_NODE *pLampNode)
{
	struct list_head *lampnode;
	PARK_LAMP_NODE *tmp;
	unsigned short i;
	  
	//����豸�Ƿ���ע��
	LampListMutexLock();
	__list_for_each(lampnode, &lamphead)
	{
		tmp = list_entry(lampnode,PARK_LAMP_NODE, list); 
		if(pLampNode->LampTableNode.LampID==tmp->LampTableNode.LampID)   //�����ͬ,�򸲸�ԭ����
		{	
			 tmp->LampTableNode.LampID = pLampNode->LampTableNode.LampID |0x80000000;
			 tmp->LampTableNode.StopCnt = pLampNode->LampTableNode.StopCnt;
			 for(i=0;i<pLampNode->LampTableNode.StopCnt;i++)
			 {
				 tmp->LampTableNode.StopTable[i] = pLampNode->LampTableNode.StopTable[i];
			 }
			 printf("�ĵ�%s\r\n",pLampNode->LampTableNode.LampNum);
			 LampListMutexUnlock();
			 return 0;
		}
	}
	
	printf("����%s\r\n",pLampNode->LampTableNode.LampNum);
	pLampNode->Status =0x81;  //Ĭ��Ϊ�����г�  
	pLampNode->StatusBak =0xff;  
	pLampNode->EmptyCnt = 0;   // �ʼ��Ϊ�г�
	pLampNode->LampTableNode.LampID |=0x80000000;
	list_add(&pLampNode->list,&lamphead);
	LampListMutexUnlock(); 
	return 1;
}


int DelLampNode(unsigned char *pLampName)
{
	struct list_head *lampnode;
	PARK_LAMP_NODE *tmp=NULL;
	
        
	//����豸�Ƿ���ע��
	LampListMutexLock();
	__list_for_each(lampnode, &lamphead) 
	{
		tmp = list_entry(lampnode,PARK_LAMP_NODE, list); 
		
		if(!strcmp(pLampName,tmp->LampTableNode.LampNum))   //�����ͬ
		{
		        list_del(&tmp->list);
			 printf("ɾ��%s\r\n",tmp->LampTableNode.LampNum);
			 free(tmp);
			 LampListMutexUnlock();
			 return 0;
		}
	}
	LampListMutexUnlock(); 
	return 0xff;
}

///////////////////////////////////////////////////////////////////

void GuideScan(void)   //�����׼����ָʾ�ƵĿճ�λ����ÿ 60Sһ��
{
	unsigned short i,cnt=0;
	struct list_head *guidenode;
	PARK_GUIDE_NODE *tmp;
	PARK_STOP_NODE *pStopNode;
	unsigned char dat[3];
	
	GuideListMutexLock();
	__list_for_each(guidenode, &guidehead) 
	{
		tmp = list_entry(guidenode,PARK_GUIDE_NODE, list);
		cnt=0;
		for(i=0;i<tmp->GuideTableNode.StopCnt;i++)
		{
			pStopNode=GetStopNodeByStopID(tmp->GuideTableNode.StopTable[i]);
			//printf("Status:0x%x\r\n",pStopNode->Status);
			if(((pStopNode->Status&0x01)==0)&&((pStopNode->Status&0x80)==0))    
			{
				//printf("%s�޳�\r\n",pStopNode->ParkTableNode.StopNum);
				cnt++;
			}
		}
		tmp->EmptyCnt = cnt;
		tmp->EmptyCntBak = 0xff;   //ǿ�Ʒ���
		printf("%sָʾ�ƿ�λ����׼:  %d\r\n",tmp->GuideTableNode.GuideNum,cnt);
	}
	GuideListMutexUnlock();
}


void GuideScanByStopID(unsigned int StopID,unsigned char status)   //ɨ��ָʾ��
{
	unsigned short i,cnt=0;
	struct list_head *guidenode;
	PARK_GUIDE_NODE *tmp;
	
	GuideListMutexLock();
	__list_for_each(guidenode, &guidehead) 
	{
		tmp = list_entry(guidenode,PARK_GUIDE_NODE, list);
		for(i=0;i<tmp->GuideTableNode.StopCnt;i++)
		{
			if(tmp->GuideTableNode.StopTable[i] == StopID)
			{
				if(status==0)
				{
					if(tmp->EmptyCnt<tmp->GuideTableNode.StopCnt)
					{
						tmp->EmptyCnt++;  //�г����޳�
						printf("%d��λ[1->0]\r\n",StopID);
					}
					break;
				}
				else if(status==1)
				{
					if(tmp->EmptyCnt>0)
					{
						tmp->EmptyCnt--;    //�޳����г�
						printf("%d��λ[0->1]\r\n",StopID);
					}
					break;
				}
				
			}
		}
	}
	GuideListMutexUnlock();
}


void LampScan(void)   //�����׼����ָʾ�ƵĿճ�λ����ÿ 60Sһ��
{
	unsigned short i,cnt=0;
	struct list_head *lampnode;
	PARK_LAMP_NODE *tmp;
	PARK_STOP_NODE *pStopNode;
	unsigned char dat[3];

	LampListMutexLock();
	__list_for_each(lampnode, &lamphead) 
	{
		tmp = list_entry(lampnode,PARK_LAMP_NODE, list);
		cnt=0;
		for(i=0;i<tmp->LampTableNode.StopCnt;i++)
		{
			pStopNode=GetStopNodeByStopID(tmp->LampTableNode.StopTable[i]);
			//printf("Status:0x%x\r\n",pStopNode->Status);
			if(((pStopNode->Status&0x01)==0)&&((pStopNode->Status&0x80)==0))     //���߶����޳� ����ճ�λ��
			{
				//printf("%s�޳�\r\n",pStopNode->ParkTableNode.StopNum);
				cnt++;
			}
		}
		tmp->EmptyCnt = cnt;
		if(tmp->EmptyCnt==0)   //����λ
		{
			tmp->Status|=0x01;  //�����
		}
		else
		{
			tmp->Status&=0xfe;     //���̵�
		}
		tmp->EmptyCntBak = 0xff;   //ǿ�Ʒ���
		printf("%sָʾ�Ʊ�׼:  0x%x,��λ��%d\r\n",tmp->LampTableNode.LampNum,dat[0],tmp->EmptyCnt);
	}
	LampListMutexUnlock();
}

void LampScanByStopID(unsigned int StopID,unsigned char status)   //ɨ��ָʾ��
{
	unsigned short i;
	struct list_head *lampnode;
	PARK_LAMP_NODE *tmp;
	unsigned char dat[3];
	
	LampListMutexLock(); 
	__list_for_each(lampnode, &lamphead)
	{
		tmp = list_entry(lampnode,PARK_LAMP_NODE, list);
		for(i=0;i<tmp->LampTableNode.StopCnt;i++)
		{
			if(tmp->LampTableNode.StopTable[i] == StopID)
			{
				if(status==0)   // �г����޳�
				{
					if(tmp->EmptyCnt<tmp->LampTableNode.StopCnt)
						tmp->EmptyCnt++;  
					break;
				}
				else if(status==1)      //�޳����г�
				{
					if(tmp->EmptyCnt>0)
						tmp->EmptyCnt--;
					break;
				}
			}
		}
	}
	LampListMutexUnlock(); 
}


void NetConnectLedInit(void)
{
	GpioConfig(GPIOD,GPIO_Pin_10,GPIO_Mode_Out_PP,GPIO_Speed_10MHz);
	GpioConfig(GPIOD,GPIO_Pin_9,GPIO_Mode_Out_PP,GPIO_Speed_10MHz);
}


void NetConnectLedPro(Timer *timer)
{
	static unsigned char status=0;
	static unsigned char flag=0;
	
	if(MQTTGetStatus()==0)
	{	
		flag =0;
		if(TimerIsExpired(timer)) 
		{
			TimerCountdownMS(timer, 500);
			MQTTSocketLed(status);
			MQTTLed(status);
			status =~status;
		}
	}
	else if(flag==0)  
	{
		MQTTSocketLed(1);
		MQTTLed(1);
		flag =1;
	}
}



void usrTask(void const * argument)      // ����ZIGBEE���գ�����
{
	Timer timer,timer1;
	REVPRO_MSG RevProMsg;
	unsigned short cnt1=0;
	unsigned short cnt2=0;
	unsigned short cnt3=0;
	
	RevProCreateQueue();
	
	StopNodeListInit();
 	GuideNodeListInit();
	LampNodeListInit();
	
	if(f_mount(0, &fs)==0)
	{
		ReadCarTable();
		ReadGuideTable();
		ReadLampTable();
	}
	
	TimerInit(&timer);
  	TimerCountdownMS(&timer, 100);
	TimerInit(&timer1);
  	TimerCountdownMS(&timer1, 500);
	NetConnectLedInit();
	while(1)     // MQTT�����ӹ�����Ӧ��Ӱ�����ZIGBEE�Ľ���������
	{	
		#ifdef DOG
		DogClear();
		#endif
		
		NetConnectLedPro(&timer1);
		if(TimerIsExpired(&timer))    //ÿ��100Sɨ��һ��
		{
			if(cnt1++>600)    // 60�����ڸ��º�̨
			{
				cnt1=0;
				GuideScan();  
				LampScan();
			}
			if(cnt2++>10)   // 1�����ڼ��������ˢ��״̬���º�̨
			{
				cnt2=0;
				KeepScan();
			}
			ZigbeeSendScan(); 
			TimerCountdownMS(&timer, 100);   
		}
		if(RevProPendQueue(&RevProMsg))  
		{	
			if(RevProMsg.type==0)
			{
				switch(RevProMsg.cmd)
				{
					case 0x0e:    //�ն� ������ѯ�������ն��Ƿ���������
						if((RevProMsg.srcID&0xc0000000)==0)   //��λ
						{
							PARK_STOP_NODE *pStopNode;
							StopListMutexLock();    
							pStopNode = GetStopNodeByStopID(RevProMsg.srcID);
							if(pStopNode!=NULL)
							{
								pStopNode->ParkTableNode.ZdEnable |=0x80;   //���λ��1��ʾҪ����
							}
							StopListMutexUnlock(); 
						}
						break;
					case 0x04:
						printf("[cmd:0x%02x]  ԤԼ��λ0x%04x���س���״̬%d\r\n",RevProMsg.cmd,RevProMsg.srcID,RevProMsg.dat[0]);
						break;	
					case 0x01:	 //�ն˷���������������
					case 0x02:	 //�ն˷���������ѯ����
					case 0x03:	
					case 0x0f:	 //�ն�״̬����	
						if((RevProMsg.srcID&0xc0000000)==0)   //��λ
						{
							PARK_STOP_NODE *pStopNode;
							StopListMutexLock(); 
							pStopNode = GetStopNodeByStopID(RevProMsg.srcID);
							if(pStopNode!=NULL)
							{
								pStopNode->KeepCnt = 0;
								pStopNode->Battery = (unsigned short)(RevProMsg.dat[2]<<8)+RevProMsg.dat[1];
								if(((pStopNode->Status&0x80)==0x80)||     //���߱�����
									((pStopNode->Status&0x01)!=RevProMsg.dat[0]))    //״̬�б仯
								{
									if((pStopNode->Status&0x01)!=RevProMsg.dat[0])  //�г����޳����޳����г�������(�г�)���޳�
									{
										StopListMutexUnlock();   //��ֹ����
										GuideScanByStopID(pStopNode->ParkTableNode.StopID,RevProMsg.dat[0]);
										LampScanByStopID(pStopNode->ParkTableNode.StopID,RevProMsg.dat[0]);
										StopListMutexUnlock(); 
									}
									pStopNode->Status = RevProMsg.dat[0]|(pStopNode->Status&0x7e); 
								}
								//char StatusStr[2][3]={"��","��"};
								//printf("[cmd:0x%02x]  ��λ:%04d,%s%s��,����:%04x  status:%x\r\n",RevProMsg.cmd,RevProMsg.srcID,pStopNode->ParkTableNode.StopNum,StatusStr[RevProMsg.dat[0]],pStopNode->Battery,pStopNode->Status);
							}
							else
								printf("[cmd:0x%02x]  ��λ:%04dδע��\r\n",RevProMsg.cmd,RevProMsg.srcID);
							StopListMutexUnlock(); 
						}
						else if((RevProMsg.srcID&0xc0000000)==0x80000000)    //��λ��
						{
							PARK_LAMP_NODE *pLampNode;
							LampListMutexLock(); 
							pLampNode = GetLampNodeByLampID(RevProMsg.srcID);
							if(pLampNode!=NULL)
							{
								pLampNode->KeepCnt = 0;
								if((pLampNode->Status&0x80) ==0x80)   //���֮ǰ������
								{
									pLampNode->Status &=0x7f;
								}
								printf("[cmd:0x%02x]  ָʾ��0x%04x����״̬%d\r\n",RevProMsg.cmd,RevProMsg.srcID,pLampNode->Status&0x01);
							}
							else
								printf("[cmd:0x%02x]  ָʾ��0x%04xδע��\r\n",RevProMsg.cmd,RevProMsg.srcID);
							LampListMutexUnlock(); 
						}
						else if((RevProMsg.srcID&0xc0000000)==0x40000000)    //ָʾ��
						{
							PARK_GUIDE_NODE *pGuideNode;
							GuideListMutexLock(); 
							pGuideNode = GetGuideNodeByGuideID(RevProMsg.srcID);
							if(pGuideNode!=NULL)
							{
								pGuideNode->KeepCnt = 0; 
								if((pGuideNode->Status&0x01)==0x01)    //��������߱������
								{
									pGuideNode->Status &=0xfe;
								}
								if(((unsigned short)(RevProMsg.dat[2]<<8)+RevProMsg.dat[1])==pGuideNode->EmptyCnt)
								{
									printf("[cmd:0x%02x]  ָʾ��:0x%04x ���صĿ�λ��Ϊ:%d\r\n",RevProMsg.cmd,RevProMsg.srcID,pGuideNode->EmptyCnt);
								}
							}
							else
							{
								printf("[cmd:0x%02x]  ָʾ��:0x%04x δע��\r\n",RevProMsg.cmd,RevProMsg.srcID);
							}
							GuideListMutexUnlock(); 
						}
						break;
						
					default:
						break;
				}
			}
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////

int StopAddPro(cJSON *root)
{
	cJSON *item;
	PARK_STOP_NODE *pParkStopNode;

	taskENTER_CRITICAL();
	pParkStopNode = (PARK_STOP_NODE *)malloc(sizeof(PARK_STOP_NODE));
	if(pParkStopNode ==NULL)  
	{
		printf("malloc size:%d fail!\r\n",sizeof(PARK_STOP_NODE));
		taskEXIT_CRITICAL();
		return 0xff;
	}
	taskEXIT_CRITICAL();
	
	memset(pParkStopNode,0,sizeof(pParkStopNode));
	item = cJSON_GetObjectItem(root,"CN");
	strcpy(pParkStopNode->ParkTableNode.StopNum,item->valuestring);
	item = cJSON_GetObjectItem(root,"CD");
	sscanf(item->valuestring, "%d", &pParkStopNode->ParkTableNode.StopID);
	item = cJSON_GetObjectItem(root,"AD");
	pParkStopNode->ParkTableNode.Area=item->valuestring[0];
	item = cJSON_GetObjectItem(root,"JZ");
	pParkStopNode->ParkTableNode.ZdEnable =  (unsigned char )atoi(item->valuestring);
	if(!AddOrModifyStopNode(pParkStopNode))
	{
		taskENTER_CRITICAL();
		free(pParkStopNode);   //�����λ�ڵ��Ѿ����ڣ�Ӧ���ͷ��ڴ�
		taskEXIT_CRITICAL();
	}
	
	return 0;
}


int StopDelPro(cJSON *root)
{
	cJSON *item;

	item = cJSON_GetObjectItem(root,"CN");
	
	return DelStopNode(item->valuestring);
}

void sendyuyue(int cd,unsigned char cmd)
{
	unsigned char dat[3];
		
	dat[0]=cmd&0x01;
	dat[1]=0;
	dat[2]=0;
	printf("yuyue stop:%d  cmd:%d\r\n",cd,cmd);
	ZigbeeSendToDstIDCmd(cd,0x04,dat,3);
}

int StopLockPro(cJSON *root)
{
	cJSON *item;
	int cd;
	unsigned char dat[3],cmd;
	
	item = cJSON_GetObjectItem(root,"CD");
	sscanf(item->valuestring, "%d", &cd);
	item = cJSON_GetObjectItem(root,"CL");
	cmd =  (unsigned char )atoi(item->valuestring);
	
	dat[0]=cmd&0x01;
	dat[1]=0;
	dat[2]=0;
	ZigbeeSendToDstIDCmd(cd,0x04,dat,3);
	
	printf("car:%d,lock status :%d\r\n",cd,dat[0]);
	
	_MQTTPublishCarLockStatus(cd,dat[0]);
	
	return 0;
}


int StopSettingPro(cJSON *dat,unsigned short len)
{
	int i,size;
	cJSON *root,*item;
	char *out;
	
	size = cJSON_GetArraySize(dat);
	if(size!=len)
	{
		printf("size:%d != len:%d\r\n",size,len);
		return 1;
	}
	
	for(i=0;i<size;i++)
	{	
		root = cJSON_GetArrayItem(dat,i);
		if(StopAddPro(root))
		{
			printf("size:%d len:%d\r\n",size,len);
			return 1;
		}
	}
	
	return 0;
}

int StopSettingDelPro(cJSON *dat,unsigned short len)
{
	int i,size;
	cJSON *root,*item;
	char *out;
	
	size = cJSON_GetArraySize(dat);
	if(size!=len)
	{
		printf("size:%d != len:%d\r\n",size,len);
		return 1;
	}
	
	for(i=0;i<size;i++)
	{	
		root = cJSON_GetArrayItem(dat,i);
		if(StopDelPro(root))
		{
			printf("size:%d len:%d\r\n",size,len);
			return 1;
		}
	}
	
	return 0;
}

////////////////////////////////////////////////////////////////////////////////////


int IndicatorAddPro(cJSON *root)
{
	cJSON *item,*items;
	PARK_GUIDE_NODE *pGuideNode;
	char *out;
	unsigned short size,i;
	
	/*
	out = cJSON_Print(root);
	printf("%s\r\n",out);
	free(out);
	*/
	taskENTER_CRITICAL();
	pGuideNode = (PARK_GUIDE_NODE *)malloc(sizeof(PARK_GUIDE_NODE));
	if(pGuideNode ==NULL)  
	{
		printf("malloc size:%d fail!\r\n",sizeof(PARK_GUIDE_NODE));
		taskEXIT_CRITICAL();
		return 0xff;
	}
	memset(pGuideNode,0,sizeof(pGuideNode));
	taskEXIT_CRITICAL();
	
	item = cJSON_GetObjectItem(root,"IN");
	strcpy(pGuideNode->GuideTableNode.GuideNum,item->valuestring);
	item = cJSON_GetObjectItem(root,"ID");
	sscanf(item->valuestring, "%d", &pGuideNode->GuideTableNode.GuideID);
	item = cJSON_GetObjectItem(root,"CL");
	sscanf(item->valuestring, "%d", &pGuideNode->GuideTableNode.StopCnt);
	
	item = cJSON_GetObjectItem(root,"CD");
	size = cJSON_GetArraySize(item);
	if(size!=pGuideNode->GuideTableNode.StopCnt)
	{
		return 0xff;
	}
	for(i=0;i<size;i++)
	{	
		items = cJSON_GetArrayItem(item,i);
		sscanf(items->valuestring, "%d", &pGuideNode->GuideTableNode.StopTable[i]);
	}
	if(!AddOrModifyGuideNode(pGuideNode))
	{
		taskENTER_CRITICAL();
		free(pGuideNode);
		taskEXIT_CRITICAL();
	}
	
	return 0;
}


int IndicatorDelPro(cJSON *root)
{
	cJSON *item;
	char *out=NULL;
	
	item = cJSON_GetObjectItem(root,"IN");
	
	return DelGuideNode(item->valuestring);
}


int IndicatorSettingPro(cJSON *dat,unsigned short len)
{
	int i,size;
	cJSON *root,*item;
	char *out;
	
	size = cJSON_GetArraySize(dat);
	if(size!=len)
	{
		printf("size:%d != len:%d\r\n",size,len);
		return 1;
	}
	for(i=0;i<size;i++)
	{	
		root = cJSON_GetArrayItem(dat,i);
		if(IndicatorAddPro(root))
		{
			printf("size:%d len:%d\r\n",size,len);
			return 1;
		}
	}
	return 0;
}

int IndicatorSettingDelPro(cJSON *dat,unsigned short len)
{
	int i,size;
	cJSON *root,*item;
	char *out;
	
	size = cJSON_GetArraySize(dat);
	if(size!=len)
		return 1;
	for(i=0;i<size;i++)
	{	
		root = cJSON_GetArrayItem(dat,i);
		if(IndicatorDelPro(root))
			break;
	}
	return 0;
}

////////////////////////////////////////////////////////////////////////////////////


int LampAddPro(cJSON *root)
{
	cJSON *item,*items;
	PARK_LAMP_NODE *pLampNode;
	char *out;
	unsigned short size,i;
	
	/*
	out = cJSON_Print(root);
	printf("%s\r\n",out);
	free(out);
	*/
	taskENTER_CRITICAL();
	pLampNode = (PARK_LAMP_NODE *)malloc(sizeof(PARK_LAMP_NODE));
	if(pLampNode ==NULL)  
	{
		printf("malloc size:%d fail!\r\n",sizeof(PARK_LAMP_NODE));
		taskEXIT_CRITICAL();
		return 0xff;
	}
	memset(pLampNode,0,sizeof(pLampNode));
	taskEXIT_CRITICAL();
	
	item = cJSON_GetObjectItem(root,"GN");
	strcpy(pLampNode->LampTableNode.LampNum,item->valuestring);
	item = cJSON_GetObjectItem(root,"GD");
	sscanf(item->valuestring, "%d", &pLampNode->LampTableNode.LampID);
	item = cJSON_GetObjectItem(root,"CL");
	sscanf(item->valuestring, "%d", &pLampNode->LampTableNode.StopCnt);
	
	item = cJSON_GetObjectItem(root,"CD");
	size = cJSON_GetArraySize(item);
	if(size!=pLampNode->LampTableNode.StopCnt)
		return 1;
	
	for(i=0;i<size;i++)
	{	
		items = cJSON_GetArrayItem(item,i);
		sscanf(items->valuestring, "%d", &pLampNode->LampTableNode.StopTable[i]);
	}
	
	if(!AddOrModifyLampNode(pLampNode))
	{
		taskENTER_CRITICAL();
		free(pLampNode);
		taskEXIT_CRITICAL();
	}
	
	return 0;
}


int LampDelPro(cJSON *root)
{
	cJSON *item;
	char *out=NULL;
	
	item = cJSON_GetObjectItem(root,"GN");
	return DelLampNode(item->valuestring);
}


int LampSettingPro(cJSON *dat,unsigned short len)
{
	int i,size;
	cJSON *root,*item;
	char *out;
	
	size = cJSON_GetArraySize(dat);
	if(size!=len)
	{
		printf("size:%d != len:%d\r\n",size,len);
		return 1;
	}
	for(i=0;i<size;i++)
	{	
		root = cJSON_GetArrayItem(dat,i);
		if(LampAddPro(root))
		{
			printf("size:%d len:%d\r\n",size,len);
			return 1;
		}
	}
	return 0;
}

int LampSettingDelPro(cJSON *dat,unsigned short len)
{
	int i,size;
	cJSON *root,*item;
	char *out;
	
	size = cJSON_GetArraySize(dat);
	if(size!=len)
		return 1;
	for(i=0;i<size;i++)
	{	
		root = cJSON_GetArrayItem(dat,i);
		if(LampDelPro(root))
			break;
	}
	return 0;
}


////////////////////////////////////////////////////////////////////////////////////
int DeleteCarTable(void)
{
	FRESULT res; 
	
	res = f_unlink("CarTable.txt");    //ɾ��
	if(res!=FR_OK)
	{
		return 0xff;
	}

	return 0;
}

int WriteCarTable(void)
{
	FRESULT res; 
	FIL file; 
	int len;
	struct list_head *stopnode;
	PARK_STOP_NODE *tmp;

	res = f_unlink("CarTable.txt");    //ɾ��
	if(res!=FR_OK)
	{
		return 0xff;
	}
	res = f_open(&file,"CarTable.txt", FA_OPEN_ALWAYS|FA_WRITE|FA_READ);
	if(res!=FR_OK)
	{
		printf("��CarTable ʧ��\r\n");
		return 0xff;
	}
	StopListMutexLock();
	__list_for_each(stopnode, &stophead)
	{
		tmp = list_entry(stopnode,PARK_STOP_NODE, list);
		res = f_write(&file, &tmp->ParkTableNode,sizeof(PARK_TABLE_NODE), &len);
		printf("write stop %s [%d]\r\n",tmp->ParkTableNode.StopNum,res);
	}
	StopListMutexUnlock(); 
	f_close(&file);
	
	return 0;
}



int ReadCarTable(void)
{
	FRESULT res; 
	FIL file; 
	int len;
	struct list_head *stopnode;
	PARK_STOP_NODE *tmp;
	
	res = f_open(&file,"CarTable.txt",FA_OPEN_ALWAYS |FA_READ);
	if(res!=FR_OK)
	{
		printf("��CarTable ʧ��[%d]\r\n",res);
		return 0xff;
	}
	res = f_lseek(&file,0);
	while(1)
	{
		taskENTER_CRITICAL();
		tmp = (PARK_STOP_NODE *)malloc(sizeof(PARK_STOP_NODE));
		if(tmp ==NULL)  
		{
			printf("malloc size:%d fail!\r\n",sizeof(PARK_STOP_NODE));
			taskEXIT_CRITICAL();
			return 0xff;
		}
		res = f_read(&file, &tmp->ParkTableNode,sizeof(PARK_TABLE_NODE), &len);
		taskEXIT_CRITICAL();
		if((res || (len == 0))||(AddOrModifyStopNode(tmp)==0))
		{
			taskENTER_CRITICAL();
			free(tmp);
			taskEXIT_CRITICAL();
			break;
		}
		printf("read stop %s [%d]\r\n",tmp->ParkTableNode.StopNum,res);
	}
	
	f_close(&file);
	
	return 0;
}


int WriteGuideTable(void)
{
	FRESULT res; 
	FIL file; 
	int len;
	struct list_head *stopnode;
	PARK_GUIDE_NODE *tmp;

	res = f_unlink("Guide.txt");    //ɾ��
	if(res!=FR_OK)
	{
		return 0xff;
	}
	res = f_open(&file,"Guide.txt", FA_OPEN_ALWAYS|FA_WRITE|FA_READ);
	if(res!=FR_OK)
	{
		printf("��Guide ʧ��\r\n");
		return 0xff;
	}
	//res = f_lseek(&file,0);
	GuideListMutexLock();
	__list_for_each(stopnode, &guidehead)
	{
		tmp = list_entry(stopnode,PARK_GUIDE_NODE, list);
		res = f_write(&file, &tmp->GuideTableNode,sizeof(INDICATOR_TABLE_NODE), &len);
		printf("write Guide %s [%d]\r\n",tmp->GuideTableNode.GuideNum,res);
	}
	GuideListMutexUnlock(); 
	
	f_close(&file);
	
	return 0;
}


int ReadGuideTable(void)
{
	FRESULT res; 
	FIL file; 
	int len;
	struct list_head *stopnode;
	PARK_GUIDE_NODE *tmp;
	
	res = f_open(&file,"Guide.txt",FA_OPEN_ALWAYS |FA_READ |FA_WRITE);
	if(res!=FR_OK)
	{
		printf("��GuideTable ʧ��[%d]\r\n",res);
		return 0xff;
	}
	res = f_lseek(&file,0);
	while(1)
	{
		taskENTER_CRITICAL();
		tmp = (PARK_GUIDE_NODE *)malloc(sizeof(PARK_GUIDE_NODE));
		if(tmp ==NULL)  
		{
			printf("malloc size:%d fail!\r\n",sizeof(PARK_GUIDE_NODE));
			taskEXIT_CRITICAL();
			return 0xff;
		}
		res = f_read(&file, &tmp->GuideTableNode,sizeof(INDICATOR_TABLE_NODE), &len);
		taskEXIT_CRITICAL();
		if((res || (len == 0))||(AddOrModifyGuideNode(tmp)==0))
		{
			taskENTER_CRITICAL();
			free(tmp);
			taskEXIT_CRITICAL();
			break;
		}
		printf("read Guide %s [%d]\r\n",tmp->GuideTableNode.GuideNum,res);
	}
	
	f_close(&file);
	
	return 0;
}


int WriteLampTable(void)
{
	FRESULT res; 
	FIL file; 
	int len;
	struct list_head *node;
	PARK_LAMP_NODE *tmp;

	res = f_unlink("Lamp.txt");    //ɾ��
	if(res!=FR_OK)
	{
		return 0xff;
	}
	res = f_open(&file,"Lamp.txt", FA_OPEN_ALWAYS|FA_WRITE|FA_READ);
	if(res!=FR_OK)
	{
		printf("��Lamp ʧ��\r\n");
		return 0xff;
	}
	//res = f_lseek(&file,0);

	LampListMutexLock();
	__list_for_each(node, &lamphead)
	{
		tmp = list_entry(node,PARK_LAMP_NODE, list);
		res = f_write(&file, &tmp->LampTableNode,sizeof(LAMP_TABLE_NODE), &len);
		printf("write Lamp %s [%d]\r\n",tmp->LampTableNode.LampNum,res);
	}
	LampListMutexUnlock();
	
	f_close(&file);
	
	return 0;
}


int ReadLampTable(void)
{
	FRESULT res; 
	FIL file; 
	int len;
	struct list_head *stopnode;
	PARK_LAMP_NODE *tmp;
	
	res = f_open(&file,"Lamp.txt",FA_OPEN_ALWAYS |FA_READ |FA_WRITE);
	if(res!=FR_OK)
	{
		printf("��Lamp ʧ��[%d]\r\n",res);
		return 0xff;
	}
	res = f_lseek(&file,0);
	while(1)
	{
		taskENTER_CRITICAL();
		tmp = (PARK_LAMP_NODE *)malloc(sizeof(PARK_LAMP_NODE));
		if(tmp ==NULL)  
		{
			printf("malloc size:%d fail!\r\n",sizeof(PARK_LAMP_NODE));
			taskEXIT_CRITICAL();
			return 0xff;
		}
		res = f_read(&file, &tmp->LampTableNode,sizeof(LAMP_TABLE_NODE), &len);
		taskEXIT_CRITICAL();
		if((res || (len == 0))||(AddOrModifyLampNode(tmp)==0))
		{
			taskENTER_CRITICAL();
			free(tmp);
			taskEXIT_CRITICAL();
			break;
		}
		printf("read Lamp %s [%d]\r\n",tmp->LampTableNode.LampNum,res);
	}
	
	f_close(&file);
	
	return 0;
}



////////////////////////////////////////////////////////////////////////////////////
void PubMutexInit(void)
{
	MsgsPub = xSemaphoreCreateMutex();
}

int PubMutexLock(void)
{
	return xSemaphoreTake(MsgsPub, portMAX_DELAY);
}

int PubMutexUnlock(void)
{
	return xSemaphoreGive(MsgsPub);
}

void StopListMutexInit(void)
{
	MsgsStopList = xSemaphoreCreateMutex();
}

int StopListMutexLock(void)
{
	return xSemaphoreTake(MsgsStopList, portMAX_DELAY);
}

int StopListMutexUnlock(void)
{
	return xSemaphoreGive(MsgsStopList);
}

void GuideListMutexInit(void)
{
	MsgsGuideList = xSemaphoreCreateMutex();
}

int GuideListMutexLock(void)
{
	return xSemaphoreTake(MsgsGuideList, portMAX_DELAY);
}

int GuideListMutexUnlock(void)
{
	return xSemaphoreGive(MsgsGuideList);
}

void LampListMutexInit(void)
{
	MsgsLampList = xSemaphoreCreateMutex();
}


int LampListMutexLock(void)
{
	return xSemaphoreTake(MsgsLampList, portMAX_DELAY);
}


int LampListMutexUnlock(void)
{
	return xSemaphoreGive(MsgsLampList);
}

////////////////////////////////////////////////////////////////////////////////////

void RevProSend(REVPRO_MSG *pRevProMsg)
{
	RevProPostQueue(pRevProMsg);
}


int RevProCreateQueue(void)
{
	int ret;
	
	osMessageQDef(REVPRO,10,REVPRO_MSG);
	Msgsobj = osMessageCreate(osMessageQ(REVPRO),0);		
	ret = (Msgsobj != NULL);
	if(Msgsobj==NULL)
	{
		printf("create revpro queue fail!\r\n");
	}
	return ret;
}


void RevProFlushQueue(void)
{
	xQueueReset(Msgsobj);
}


int RevProPendQueue (REVPRO_MSG *pRevProMsg)
{
	int ret = 0;
	
	if (xQueueReceive(Msgsobj,pRevProMsg, 1) == pdTRUE)    // 1s
	{
		ret = 1;
	}
	
	return ret;
}



void RevProPostQueue(REVPRO_MSG *pRevProMsg)
{	
	if(Msgsobj==NULL)  return ;
	
	if(osMessagePut (Msgsobj,(uint32_t)pRevProMsg,0))
	{
		printf("����ZIGBEE��Ϣʧ��!\r\n");
	}
}

