#include "stdio.h"
#include "string.h"
#include "stm32f10x_api.h"
#include "feeprom.h"
#include "feepromApp.h"
#include "fourG.h"
#include "cmsis_os.h"
#include "usrApp.h"

extern unsigned char serverIp[];
extern unsigned short serverPort;
extern unsigned int myID;

void FourGSendBytes(unsigned char *dat,unsigned short len);
void FourGSendByte(unsigned char dat);

long ATFunc_Net(int argc,char **argv)
{	
	char buf[50];
	
	if(!strcmp(argv[0],"AT"))
	{
		sprintf(buf,"123456#AT+%s\r\n",argv[1]);
		FourGSendBytes(buf,strlen(buf));
	}
	else if(!strcmp(argv[0],"OPEN"))
	{
		FourGSocketOpen();
	}
	else if(!strcmp(argv[0],"CLOSE"))
	{
		FourGSocketClose();
	}
	else if(!strcmp(argv[0],"STATUS"))
	{
		sprintf(buf,"123456#AT+SOCKALK\r\n");
		FourGSendBytes(buf,strlen(buf));
	}
	else if(!strcmp(argv[0],"CONNECT"))
	{
		FourGSocketConnect("123",3,20);
	}
	else if(!strcmp(argv[0],"CONNET"))
	{
		mqttconnect();
	}
	else if(!strcmp(argv[0],"DISCONNET"))
	{
		mqttdisconnect();
	}
	else if(!strcmp(argv[0],"SUB"))
	{
		mqttsub();
	}
	else if(!strcmp(argv[0],"PUB"))
	{
		//MQTTPublishCarStatus(1,"0005",0x01,0);	
		MQTTPublishGuideStatus("2",atoi(argv[1]));	
	}
	else
	{
		FourGSendBytes(argv[0],strlen(argv[0]));
	}
	
	return 0;
}

void FourGReset(void)
{
	GpioConfig(GPIOC,GPIO_Pin_3,GPIO_Mode_Out_PP,GPIO_Speed_10MHz);
	
	GPIO_ResetBits(GPIOC,GPIO_Pin_3);    //ǿ�Ƹ�λ
	osDelay(200);
	GPIO_SetBits(GPIOC,GPIO_Pin_3); 
	osDelay(200);
}

void MQTTLed(unsigned char status)
{
	if(!status)
	{
		GPIO_ResetBits(GPIOD,GPIO_Pin_9);  //lianjie 
	}  
	else
	{
		GPIO_SetBits(GPIOD,GPIO_Pin_9);    //duankai
	}
}


void MQTTSocketLed(unsigned char status)
{
	if(!status)
	{
		GPIO_ResetBits(GPIOD,GPIO_Pin_10);  //lianjie 
	}  
	else
	{
		GPIO_SetBits(GPIOD,GPIO_Pin_10);    //duankai
	}
}


void FourGInit(void)
{
	GpioConfig(GPIOC,GPIO_Pin_10,GPIO_Mode_AF_PP,GPIO_Speed_50MHz);
	GpioConfig(GPIOC,GPIO_Pin_11,GPIO_Mode_IN_FLOATING,GPIO_Speed_50MHz);
	Uart4Config(115200,8,0,1);
	CycleBufferInit(0);
}



unsigned short FourGAtStringTimeOut(unsigned char *str,unsigned short TimeOut)
{
	unsigned short cnt=0;
	unsigned char flag=0,temp,strbuf[100],strbufss[50];
	char *ptr=NULL;
	
	memset(strbuf,0,sizeof(strbuf));
	
	while((TimeOut!=0))
	{	
		while(CycleBufferPop(0,&temp)==0)
		{
			TimeOut = 10;
			strbuf[cnt++]=temp;
			//sprintf(strbufss,"%x ",temp);
			//printf(strbufss);
			ptr=strstr(strbuf,str);
			if(ptr)
			{
				flag = 1;
				continue ;
			}
		}
		TimeOut--;
		osDelay(10);
	}
	
	if(flag)
	{
		printf("�ҵ���%s\r\n",str);
		return cnt;
	}
	printf("û�ҵ�%s\r\n",str);
	return 0;
	
}


unsigned short FourGAtStringTimeOuts(unsigned char *str,unsigned short offset,unsigned short TimeOut)
{
	unsigned short cnt=0;
	unsigned char flag=0,temp,strbuf[100],strbufss[50];
	char *ptr=NULL;
	
	memset(strbuf,0,sizeof(strbuf));
	
	while((TimeOut!=0))
	{	
		while(CycleBufferPop(0,&temp)==0)
		{
			strbuf[cnt++]=temp;
			//sprintf(strbufss,"%x ",temp);
			//printf(strbufss);
			ptr=strstr(strbuf+offset,str);
			if(ptr)
			{
				TimeOut = 5;
				flag = 1;
				continue ;
			}
		}
		TimeOut--;
		osDelay(10);
	}
	
	if(flag)
	{
		printf("�ҵ���%s\r\n",str);
		return cnt;
	}
	printf("û�ҵ�%s\r\n",str);
	return 0;
}



void FourGAppInit(void)
{
	char buf[50];
	
	FourGReset();
	
	if(FourGAtStringTimeOuts("GM3",1,1000))
	{
		osDelay(50);
		//printf("\r\nGM3 OK\r\n");
	}
	else
	{
		Reboot();
	}
	
	sprintf(buf,"+++");
	FourGSendBytes(buf,strlen(buf));
	FourGAtStringTimeOut("a",200);
	
	sprintf(buf,"a");
	FourGSendBytes(buf,strlen(buf));
	FourGAtStringTimeOut("ok",200);
	
	sprintf(buf,"AT+CMDPW=\"123456\"\r");
	FourGSendBytes(buf,strlen(buf));
	FourGAtStringTimeOut("OK",200);
	
	sprintf(buf,"AT+RSTIM=0\r");
	FourGSendBytes(buf,strlen(buf));
	FourGAtStringTimeOut("OK",200);
	
	sprintf(buf,"AT+SLEEP=\"off\"\r");
	FourGSendBytes(buf,strlen(buf));
	FourGAtStringTimeOut("OK",200);
	
	sprintf(buf,"AT+CACHEN=\"on\"\r");
	FourGSendBytes(buf,strlen(buf));
	FourGAtStringTimeOut("OK",200);
	
	sprintf(buf,"AT+UATEN=\"on\"\r");
	FourGSendBytes(buf,strlen(buf));
	FourGAtStringTimeOut("OK",200);
	
	sprintf(buf,"AT+WKMOD=\"NET\"\r");
	FourGSendBytes(buf,strlen(buf));
	FourGAtStringTimeOut("OK",200);
	
	sprintf(buf,"AT+HEARTEN=\"off\"\r");
	FourGSendBytes(buf,strlen(buf));
	FourGAtStringTimeOut("OK",200);
	
	sprintf(buf,"AT+SOCKAEN=\"on\"\r");
	FourGSendBytes(buf,strlen(buf));
	FourGAtStringTimeOut("OK",200);
	
	sprintf(buf,"AT+SOCKASL=\"long\"\r");
	FourGSendBytes(buf,strlen(buf));
	FourGAtStringTimeOut("OK",200);
	
	sprintf(buf,"AT+SOCKA=\"TCP\",\"%d.%d.%d.%d\",%d\r",serverIp[0],serverIp[1],serverIp[2],serverIp[3],serverPort);
	FourGSendBytes(buf,strlen(buf));
	FourGAtStringTimeOut("OK",200);
	
	sprintf(buf,"AT+S\r");
	FourGSendBytes(buf,strlen(buf));
	FourGAtStringTimeOuts("OK",0,1000);
	
	//sprintf(buf,"AT+ENTM\r");
	//FourGSendBytes(buf,strlen(buf));
	//FourGAtString("OK");
	
	FourGAtStringTimeOuts("GM3",1,1000);
	
	osDelay(100);
}



void FourGSocketOpen(void)
{
	char buf[50];
	
	sprintf(buf,"123456#AT+SOCKAEN=\"on\"\r");
	FourGSendBytes(buf,strlen(buf));
	FourGAtStringTimeOut("OK",200);
}


void FourGSocketClose(void)
{
	char buf[50];
	
	sprintf(buf,"123456#AT+SOCKAEN=\"off\"\r");
	FourGSendBytes(buf,strlen(buf));
	FourGAtStringTimeOut("OK",200);
}

void FourGSocketReset(void)
{
	char buf[50];
	
	sprintf(buf,"AT+Z\r");
	FourGSendBytes(buf,strlen(buf));
	FourGAtStringTimeOuts("OK",0,1000);
}

unsigned char FourGSocketConnect(unsigned char *ip,unsigned short port,unsigned char cnt)
{
	unsigned char strbuf[100];
	
	printf("4G SocketA connect...\r\n");

	FourGSocketOpen();
	
	while(1)
	{	
		sprintf(strbuf,"123456#AT+SOCKALK\r\n");
		FourGSocketSend(strbuf,strlen(strbuf));
		if(FourGAtStringTimeOut("SOCKALK:connected",100))      //�ҵ��˶Ͽ���
		{
			printf("4G SocketA Connect OK\r\n");
			break;
		}
		else if(cnt--==0)
		{
			return 0xff;
		}
		else
			osDelay(1000);
	}
	return 0;
}


void FourGSocketSend(unsigned char *dat,unsigned short len)
{
	FourGSendBytes(dat,len);
}


unsigned short FourGSocketRev(unsigned char *dat,unsigned short TimeOut)
{
	unsigned short cnt=0;
	unsigned char temp;
	
	while((TimeOut!=0))
	{	
		while(CycleBufferPop(0,&temp)==0) 
		{
			TimeOut = 5;
			dat[cnt++]=temp;
		}
		TimeOut--;
		osDelay(10);
	}
	
	return cnt;
	
}
	
unsigned short FourGSocketRevCnt(unsigned char *dat,unsigned short len,unsigned short TimeOut)
{
	unsigned short cnt=0;
	unsigned char temp;
	unsigned char buf[10];
	
	while((TimeOut!=0))
	{	
		while(CycleBufferPop(0,&temp)==0) 
		{
			TimeOut = 5;
			dat[cnt++]=temp;
			//sprintf(buf,"%x[%c] ",temp,temp);
			//printf(buf);
			if(cnt>=len)
			{
				return len;
			}
		}
		TimeOut--;
		osDelay(10);
	}
	
	return cnt;
}


void FourGSendByte(unsigned char dat)
{    
	
	USART_SendData(UART4,(unsigned short)dat);
	while(USART_GetFlagStatus(UART4, USART_FLAG_TXE)!=SET) ;
	//ConsoleSendByte(dat);
}


void FourGSendBytes(unsigned char *dat,unsigned short len)
{
	unsigned short i;
	
	taskENTER_CRITICAL();
	for(i=0;i<len;i++)
	{
		FourGSendByte(dat[i]);
		//ConsoleSendByte(dat[i]);
	}
	taskEXIT_CRITICAL();
}


void UART4_IRQHandler(void)
{	
	unsigned char cByte;
	
	if (USART_GetFlagStatus(UART4, USART_FLAG_ORE) != RESET)
	{
		USART_ReceiveData(UART4);
	}
	else if(USART_GetITStatus(UART4, USART_IT_RXNE) != RESET)  
	{
		USART_ClearFlag(UART4,USART_IT_RXNE);
		cByte=USART_ReceiveData(UART4);
		   
		CycleBufferPush(0,cByte);
	}
}


