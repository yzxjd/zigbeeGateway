#include <stdio.h>
#include "stm32f10x_api.h"
#include "spi_msd_driver.h"
#include "console.h"
#include "rtc.h"
#include "usrApp.h"
#include "feeprom.h"
#include "fourG.h"
#include "des.h"
#include "crc32.h"
#include "ff.h"


static char FunctionFlag='A';
static unsigned char hv[]="10"; 


////////////////////////////////////////////////////////////

#define DES_KEY		"HnLbKjSj"

#define APPSTARTADDR_A		0x08008000		//AӦ�ó���ʼ��ַ  Ӧ��ռ110K  ��������ռ32K  ����ռ4K
#define APPSTARTADDR_B		0x08023800		//BӦ�ó���ʼ��ַ  Ӧ��ռ110K  
#define EE_KEY_UPDATA		0xfe	 			//App���������־
#define EE_KEY_HEAD			0xfd  			//������BIN�ļ�ͷ�ļ�48���ֽ�



#pragma pack(push)//�������״̬ 
#pragma pack(1)  //����Ϊ1�ֽڶ���
typedef struct _HEAD
{	
	unsigned char CompanyName[2];  //��˾��: �̶� "LB"	2�ֽ�
	unsigned char ProductType[10];	//��Ʒ����: 		10�ֽ�
	unsigned char HardwareVer[10];	//��ӦӲ���汾��:	10�ֽ�
	unsigned char FunctionFlag; 	//��Ʒ���ܱ�ʾ: 	1�ֽ�
	unsigned char FirmwareVer[4];	//�����汾��:		4�ֽ�
	unsigned char ProductionDate[8]; //��������:		 8�ֽ�
	unsigned char ReserveInfo[13];	//Ԥ���ֽ�: 		13�ֽ�
}HEAD;
#pragma pack(pop)//�ָ�����״̬ 

void HEAD_init(HEAD head);

static unsigned char buf[PAGE_SIZE];
static unsigned char bufbak[PAGE_SIZE];
static unsigned char bufbaks[PAGE_SIZE];
static FATFS Fs;

typedef  void (*pFunction)(void);
pFunction Jump_To_Application;
unsigned int JumpAddress;

__asm void __set_MSP(uint32_t mainStackPointer)
{
  msr msp, r0
  bx lr
}


void NvicConfig(uint32_t offset)
{
	NVIC_DeInit();
	NVIC_SetVectorTable(NVIC_VectTab_FLASH, offset);
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
}


void NetLedInit(void)
{	
	GpioConfig(GPIOE,GPIO_Pin_4,GPIO_Mode_Out_PP,GPIO_Speed_10MHz);
}


void NetAddrLedSet(unsigned char IpEnd)
{
	if(!IpEnd)
	{
		GPIO_ResetBits(GPIOE,GPIO_Pin_4);  //lianjie 
	}  
	else
	{
		GPIO_SetBits(GPIOE,GPIO_Pin_4);    //duankai
	}
}

void DoAppA(void)
{
	JumpAddress = *(unsigned int*) (APPSTARTADDR_A + 4);
	Jump_To_Application = (pFunction) JumpAddress;
	
	NVIC_SETPRIMASK();
//	NVIC_SetVectorTable(0x8000000,0x8000);
	__set_MSP(APPSTARTADDR_A);
	(*Jump_To_Application)();
}


void DoAppB(void)
{

	JumpAddress = *(unsigned int*) (APPSTARTADDR_B + 4);
	Jump_To_Application = (pFunction) JumpAddress;

	NVIC_SETPRIMASK();

	__set_MSP(APPSTARTADDR_B);
	(*Jump_To_Application)();

}

unsigned int HexToDWORD_LittleEndian(INT8U *pData,INT8U cBytes)
{
	unsigned int iReturn=0;
	
	if(cBytes>4)
		return 0;
	while(cBytes>0)
	{
		iReturn=(iReturn<<8)+pData[cBytes-1];
		cBytes--;
	}
	return iReturn;
}


unsigned char STM32FlashErase(unsigned int lAddr)
{
	FLASH_Status status = FLASH_COMPLETE;

	if(lAddr>0x8040000)
		return 0;
	
	FLASH_Unlock();
	status=FLASH_ErasePage(lAddr/PAGE_SIZE*PAGE_SIZE);
	FLASH_Lock();
	if(status!=FLASH_COMPLETE)
		return 0;
	return 1;
}

unsigned char STM32FlashWrit_Direct(unsigned int lAddr,INT8U *pData,unsigned short iLen)
{
	unsigned short iData,iCnt;
	FLASH_Status status = FLASH_COMPLETE;
	
	if((lAddr+iLen)>0x8040000)
		return 0;
		
	iCnt=0;
	FLASH_Unlock();
	while(iLen>iCnt)
	{
		iData =HexToDWORD_LittleEndian(pData,2); 
		status=FLASH_ProgramHalfWord(lAddr,iData);
		if(status!=FLASH_COMPLETE)
			break;
		lAddr +=2;
		pData +=2;
		iCnt  +=2;
	}
	FLASH_Lock();
	
	if(status!=FLASH_COMPLETE)
		return 0;
	
	return 1;
}


void ReadHeadInfo(HEAD*pHead)
{
	unsigned char upflag=0;
	
	if(EE_ReadData(EE_KEY_HEAD,(unsigned char *)pHead,sizeof(HEAD))!=0)
	{
		printf("û��HEAD����\r\n");
	}
	if(EE_ReadData(EE_KEY_UPDATA,(unsigned char *)&upflag,1)!=0)
	{
		upflag='A';
		printf("��ʼ��UPDATAΪ:%c��\r\n",upflag);
		EE_WriteData(EE_KEY_UPDATA,(unsigned char *)&upflag,1);
	}
	printf("��ǰ����:%c\r\n",upflag);
	printf("��ǰ�����汾:%c%c%c%c\r\n",pHead->FirmwareVer[0],pHead->FirmwareVer[1],pHead->FirmwareVer[2],pHead->FirmwareVer[3]);
	printf("��ǰӲ���汾:%c%c%c%c\r\n",pHead->HardwareVer[0],pHead->HardwareVer[1],pHead->HardwareVer[2],pHead->HardwareVer[3]);
}

unsigned char AppCopyToCpu(unsigned char flag,unsigned char *phead)
{	
	static unsigned char flags;
	unsigned char name[30];
	unsigned char name1[30];
	unsigned short iReadCnt,iCnt,iOffset;
	unsigned int lCrc32=0,Crc32,lCrc32Temp,lLenBak,lLen,lSrcAddr,lDesAddr;
	FIL fp;

	if(flag=='A')   //���������A����������B���ĳ���
	{
		sprintf(name,"BYD%cH%s.BIN",FunctionFlag,hv);
	}
	else if(flag=='B')   //���������B����������A���ĳ���
	{
		sprintf(name,"AYD%cH%s.BIN",FunctionFlag,hv);
	}
	
	if(f_open(&fp, name, FA_OPEN_ALWAYS |FA_READ) != FR_OK)
	{	
		printf("û���ҵ�%s\r\n",name);
		return 0;
	}
	else
	{	
		lLenBak=get_filesize("/",name);
//		lLenBak = fp.fsize;
		printf("bin_file:%s lLenBak:%d\r\n",name,lLenBak);
		if(lLenBak>=(110*1024))    
		{
			printf("�̼����ȴ���\r\n");
			return 0;
		}
	}
	if(f_read(&fp, (unsigned char *)&lLen, 4, (void *)&iCnt) != FR_OK)
		return 0;
//	lLenBak = ((lLen/8)*8+56);
	if(lLenBak!=((lLen/8)*8+56))
	{
		printf("���ȴ���\r\n");
		printf("lLenBak: %d lLen: %d\r\n",lLenBak,lLen);
		return 0;
	}
	if(f_read(&fp, (unsigned char *)&Crc32, 4, (void *)&iCnt) != FR_OK)
		return 0;
	

#if 1	
	if(f_read(&fp,bufbak, sizeof(HEAD), (void *)&iCnt) != FR_OK)
		return 0;
	Run1Des(DECRYPT,ECB,bufbak,sizeof(HEAD),DES_KEY,8,phead,sizeof(HEAD),NULL);
	lCrc32 =Calculate_CRC32(0,phead,sizeof(HEAD));
#else	
	if(f_read(&fp,phead, sizeof(HEAD), (void *)&iCnt) != FR_OK)
		return 0;
	lCrc32 =Calculate_CRC32(0,phead,sizeof(HEAD));
#endif
	if(flag=='A')
		lDesAddr=APPSTARTADDR_B;
	else
		lDesAddr=APPSTARTADDR_A;

	iOffset=lDesAddr%PAGE_SIZE;
	while(lLen>0x00)
	{	
		iReadCnt=PAGE_SIZE;
		if(iReadCnt>lLen)
			iReadCnt=lLen;
		if(iReadCnt!=PAGE_SIZE)
			memcpy(bufbaks,(unsigned char*)lDesAddr,PAGE_SIZE);  //���һҳ
		if(f_read(&fp, bufbak, iReadCnt, (void *)&iCnt) != FR_OK)
			return 0;
		else if(iReadCnt!=iCnt)
			return 0;
		NVIC_SETPRIMASK();
		Run1Des(DECRYPT,ECB,bufbak,iCnt,DES_KEY,8,buf,iCnt,NULL);
		lCrc32 =Calculate_CRC32(lCrc32,buf,iCnt);
		NVIC_RESETPRIMASK();
		if(!STM32FlashErase(lDesAddr))
		{
			printf("оƬ��ʽ������\r\n");
			return 0;
		}
		memcpy(bufbaks,buf,iCnt);
		if(!STM32FlashWrit_Direct(lDesAddr,bufbaks,PAGE_SIZE))
		{
			printf("оƬ��д����\r\n");
			return 0;
		}
		lDesAddr +=iReadCnt;
		lLen	 -=iReadCnt;
		
		if(flags==0)
		{
			flags=0xff;
			NetAddrLedSet(flags);
		}
		else if(flags==0xff)
		{
			flags=0;
			NetAddrLedSet(flags);
		}
	}
	NetAddrLedSet(0);
	
	if(lCrc32!=Crc32)   
	{
		printf("CRCУ�����\r\n");
		return 0;
	}
		
	return 1;
}


void FsInit(void)
{	
	if(disk_initialize(0))
	{
		return ;
	}
	else if (f_mount(0,&Fs) != FR_OK)
	{	
		return ;
	}
}


int main(void)
{
	unsigned char flag=0;
	HEAD head;
	unsigned int ver,dev;
	
	McuInit();
	
//	DoAppB();
	RtcInit();
	ConsoleInit();
	NetLedInit();
	FLASH_Unlock();
	EE_Init();
	FLASH_Lock();
	MSD_SPI_Configuration();
	FsInit();
	ReadHeadInfo(&head);
	
	ver=DBGMCU_GetREVID();
	dev=DBGMCU_GetDEVID();
	printf("ver:0x%x  dev:0x%x\r\n",ver,dev);
				
	if(EE_ReadData(EE_KEY_UPDATA,(unsigned char *)&flag,1)!=0)
	{
		flag = 'A';    //Ĭ��A�� 
		EE_WriteData(EE_KEY_UPDATA,(unsigned char *)&flag,1);
	}
	if(AppCopyToCpu(flag,(unsigned char *)&head))  //�����ǰ��A����������B������������A��
	{
		if(flag=='A')
			flag = 'B';
		else
			flag = 'A';
		EE_WriteData(EE_KEY_UPDATA,(unsigned char *)&flag,1);
		EE_WriteData(EE_KEY_HEAD,(unsigned char *)&head,sizeof(head));
		printf("�����ɹ�\r\n");
	}
	if(flag=='A')
	{
		printf("��ת��A��\r\n");
		DoAppA();
		
	}
	else if(flag=='B')
	{
		printf("��ת��B��\r\n");
		DoAppB();
		NVIC_SetVectorTable(0x8000000,0x23800);
	}
	else   //�������������ת��A��
	{
		flag = 'A';   
		EE_WriteData(EE_KEY_UPDATA,(unsigned char *)&flag,1);
		DoAppA();
	}
}




