#include "wiegand.h"
#include "wgApp.h"
#include "stm32f10x_api.h"


void WgInit(void)
{
	WiegandDriverInit();
	WgStatusLedInit();
}

void WgStatusLedInit(void)
{
	GpioConfig(WGLEDPORT,WGLEDPIN,GPIO_Mode_Out_PP,GPIO_Speed_50MHz);
	WgStatusLedSet(0);
}

void WgStatusLedSet(unsigned char status)
{
	if(status)
	{
		GPIO_ResetBits(WGLEDPORT,WGLEDPIN);
	}
	else
		GPIO_SetBits(WGLEDPORT,WGLEDPIN);
}

unsigned char WgCardScan(unsigned long *lcard)
{
	unsigned char status;
	static unsigned int cnt;
	static unsigned char flag=0;
	
	status = Wg26GetCard(lcard);
	if(status)
	{
		flag=1;    //Ӧ����һ��led��˸
		WgStatusLedSet(flag);
	}
	if(flag&&(cnt++>3000))//������һ��ʱ��
	{
		cnt=0;
		flag=0;
		WgStatusLedSet(flag);
	}

	return status;
}

