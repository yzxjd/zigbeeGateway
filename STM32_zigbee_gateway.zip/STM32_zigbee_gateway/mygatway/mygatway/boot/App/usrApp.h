#ifndef USRAPP_H
#define USRAPP_H

#include "lists.h"
#include "cjson.h"


typedef struct _PARK_TABLE_NODE
{  
	unsigned char  StopNum[8];   //��λ���
	char Area;     //���������
	char Area2;     //����
	unsigned char ZdEnable;   //������־
	unsigned int StopID;   //��λID
}PARK_TABLE_NODE;


typedef struct _INDICATOR_TABLE_NODE
{  
	unsigned char  GuideNum[8];   //���
	unsigned int GuideID;   
	unsigned short StopCnt;  
	unsigned int StopTable[100];  
}INDICATOR_TABLE_NODE;

typedef struct _LAMP_TABLE_NODE
{  
	unsigned char  LampNum[8];   //���
	unsigned int LampID;   
	unsigned short StopCnt;  
	unsigned int StopTable[5];  
}LAMP_TABLE_NODE;


typedef struct _PARK_STOP_NODE  
{  
	PARK_TABLE_NODE ParkTableNode;    //��λ��һ��
	unsigned short KeepCnt;  //������������
	unsigned char Status;    //ͣ��״̬,���λ��ʾ��û������
	unsigned char StatusBak;    //״̬����
	unsigned short Battery;	  //����
	struct list_head list;
}PARK_STOP_NODE;

typedef struct _PARK_GUIDE_NODE  
{
	INDICATOR_TABLE_NODE GuideTableNode; 
	unsigned short EmptyCnt;   //�ճ�λ��
	unsigned short EmptyCntBak; 
	unsigned short KeepCnt;  //������������
	unsigned char Status;  //��ʾ��û������
	unsigned char StatusBak;
	struct list_head list;
}PARK_GUIDE_NODE;


typedef struct _PARK_LAMP_NODE  
{
	LAMP_TABLE_NODE LampTableNode; 
	unsigned short KeepCnt;  //������������
	unsigned char Status;  //��ʾ��û������,���/�̵�
	unsigned char StatusBak;
	unsigned char EmptyCnt;   //�ճ������� 
	unsigned char EmptyCntBak; 
	struct list_head list;
}PARK_LAMP_NODE;


typedef struct _REVPRO_MSG
{
	unsigned char  type;
	unsigned char  cmd;
	unsigned char  dat[9];
	unsigned int srcID;
}REVPRO_MSG;


void UsrAppInit(void);
void usrTask(void const * argument);
void UsrProcessCallBack(unsigned char *dat);
void UsrNetSend(unsigned char cmd,unsigned char *data,unsigned short len);
PARK_STOP_NODE *GetStopNodeByStopID(unsigned int StopID);
PARK_GUIDE_NODE *GetGuideNodeByGuideID(unsigned int GuideID);
PARK_STOP_NODE *GetStopNodeByLightID(unsigned int LightID);

void GuideScanByStopID(unsigned int StopID,unsigned char status) ;
void LampScanByStopID(unsigned int StopID,unsigned char status)   ;

void usrTask(void const * argument);
int RevProCreateQueue(void);
void RevProFlushQueue(void);
int RevProPendQueue (REVPRO_MSG *pMsg);
void RevProPostQueue(REVPRO_MSG *pMsg);
void RevProSend(REVPRO_MSG *pRevProMsg);
/////////////////////////////////////////////////
int StopSettingPro(cJSON *dat,unsigned short len);

int DelStopNode(unsigned char *pCarName);

int WriteCarTable(void);
int ReadCarTable(void);

void StopListMutexInit(void);

int StopListMutexLock(void);

int StopListMutexUnlock(void);

void GuideListMutexInit(void);

int GuideListMutexLock(void);

int GuideListMutexUnlock(void);

void LampListMutexInit(void);

int LampListMutexLock(void);

int LampListMutexUnlock(void);

#endif
