#include "display.h"
#include "displayApp.h"
#include "math.h"
#include "string.h"
#include "stdio.h"
#include "stdlib.h"
#include "para.h"
#include "cmsis_os.h"

static DISPLAY Display;

long ledFunc_Display(int argc,char **argv)
{	
	unsigned short cmd;
	
	cmd = atoi(argv[0]);
	
	if(cmd==0)
		DisplaySend((unsigned char *)argv[1],strlen(argv[1]),DISPLAY_FIXED_FLAG);
	else if(cmd==1)
		DisplaySend((unsigned char *)argv[1],strlen(argv[1]),DISPLAY_INSERT_FLAG |3);
	else if(cmd==2)
	{
		Display.pParkInfo->RemanStop =100;
		DisplaySends(CMD_DIS_REMAINPARK);
	}
	else if(cmd==3)
	{	
		Display.Code =atoi(argv[1]);
		DisplaySends(CMD_DIS_SINGLE);
	}
	else if(cmd==4)
	{	
		Display.pStopInfo->CarNumber[0] = 119;
		strcpy((char *)&Display.pStopInfo->CarNumber[1],"AF3W9");
		Display.pStopInfo->CarNumber[6] = 142;
		Display.pStopInfo->RemanDays =atoi(argv[1]);
		DisplaySends(CMD_DIS_CARNUMBER);
	}
	else if(cmd==5)
	{
		Display.pStopInfo->Balance = atoi(argv[1]);
		DisplaySends(CMD_DIS_BALANCE);
	}
	else if(cmd==6)    
	{	
		Display.pStopInfo->CarNumber[0] = 119;
		strcpy((char *)&Display.pStopInfo->CarNumber[1],"AF3W93");
		Display.pStopInfo->StopTime.Hour = 20;
		Display.pStopInfo->StopTime.Min = 30;
		Display.pStopInfo->Fee = 50;
		DisplaySends(CMD_DIS_TIME_FEE);
	}
	return 0;
}


static unsigned char DisplayFloatConv(unsigned int IntNum,unsigned char PointPos,unsigned char *codes)
{	
	unsigned char count=0,len=0;
	char buf[20];
	unsigned char *ptr=codes;
	unsigned int value,temp;
	
	temp = IntNum;
	sprintf(buf,"%d",temp);	
	len = strlen(buf);
	
	if(len<=PointPos) 	//���С����λ�ó����˱����ĳ����򰴱���������Ϊ��ȷλ��
	{
		*codes++ ='0';
		PointPos=len;
	}
	for(count=len;count>0;count--)
	{
		temp=temp%(int)pow(10,count);
		value= temp/(int)pow(10,count-1);
		if(count==PointPos) *codes++ ='.';
		*codes++ = value+'0';
	}
	return codes-ptr;
}



static void DisplayCarNumber(unsigned char *dat)
{
	unsigned char i=0,conut,codes[12],buf[100];
	
	ReadDisplayInfo(85,buf);
	memset(codes,0,sizeof(codes));
	
	for(conut = 0;conut < 8; conut++)
	{	
		if(dat[conut] == ' ') break;
		if((conut == 7) && (dat[ 0 ] >= 110 && dat[ 0 ] <= 147))  break;
		else if((dat[conut] >= 110) && (dat[conut] <= 147))    
		{
			codes[i++] = *(buf + ((dat[conut] - 110) * 2));
			codes[i++] = *(buf + ((dat[conut] - 110) * 2 + 1));
		}
		else if((dat[conut] >= 'A' )&& (dat[conut] <= 'Z'))
		{
			codes[i++]=dat[conut];
		}
		else if((dat[conut] >= '0') && (dat[conut] <= '9'))
		{
			codes[i++]=dat[conut];
		}
	}
	DisplaySend(codes,i,DISPLAY_INSERT_FLAG |3);
}


void DisplayAppInit(DISPLAY **ppUsrDisplay)
{
	*ppUsrDisplay = (DISPLAY *)&Display;
}

unsigned char *DisplayGetFixedInfoAddr(void)
{
	return Display.FixedInfo;
}

void DisplaySetTime(unsigned char *para)
{
	DisplaySend((unsigned char *)para,7,DISPLAY_SET_TIME_FLAG);
}


void DisplayVoiceSends(VOICE_MSG *pVoiceMsg)
{	
	unsigned char dat[100];
	unsigned char i=0;
	
	memset(dat,0,sizeof(dat));
	
	switch(pVoiceMsg->cmd)
	{	
		case CMD_DIS_SINGLE:
			i+=ReadDisplayInfo(pVoiceMsg->play.Code,dat);
			DisplaySend(dat,i,DISPLAY_INSERT_FLAG|3);
			break;	
		case CMD_DIS_CARNUMBER:
			DisplayCarNumber(pVoiceMsg->play.StopInfo.CarNumber);
			break;
		case CMD_DIS_REMAINDAY:
			i+=ReadDisplayInfo(14,dat);
			i+=DisplayFloatConv(pVoiceMsg->play.StopInfo.RemanDays,0,&dat[i]);
			dat[i++] 	= 0xCC;  //�� 
			dat[i++]  = 0xEC;
			DisplaySend(dat,i,DISPLAY_INSERT_FLAG|3);
			break;
		case CMD_DIS_BALANCE: 
			i+=ReadDisplayInfo(15,dat);
			i+=DisplayFloatConv(pVoiceMsg->play.StopInfo.Balance,1,&dat[i]);
			dat[i++] 	= 0xD4;  //Ԫ
			dat[i++]  = 0xAA;
			DisplaySend(dat,i,DISPLAY_INSERT_FLAG);
			break;
		case CMD_DIS_TIME_FEE:
			i+=ReadDisplayInfo(6,dat);
			i+=DisplayFloatConv(pVoiceMsg->play.StopInfo.StopTime.Hour,0,&dat[i]);
			dat[i++] 	= 0xD0;  //Сʱ
			dat[i++]  = 0xA1;
			dat[i++] 	= 0xCA;  
			dat[i++]  = 0xB1;
			i+=DisplayFloatConv(pVoiceMsg->play.StopInfo.StopTime.Min,0,&dat[i]);
			dat[i++] 	= 0xB7;  //����
			dat[i++]  = 0xD6;
			dat[i++] 	= 0xD6;
			dat[i++]  = 0xD3;
			i+=ReadDisplayInfo(7,&dat[i]);
			i+=DisplayFloatConv(pVoiceMsg->play.StopInfo.Fee,1,&dat[i]);
			dat[i++] 	= 0xD4;  //Ԫ
			dat[i++]  = 0xAA;
			DisplaySend(dat,i,DISPLAY_INSERT_FLAG |3);
			break;	
		
		default:
			break;
	}
}




void DisplaySends(unsigned char cmd)
{	
	unsigned char dat[100];
	unsigned char i=0;
	
	memset(dat,0,sizeof(dat));
	
	switch(cmd)
	{	
		case CMD_DIS_FIXED:
			DisplaySend(Display.FixedInfo,strlen((char *)Display.FixedInfo),DISPLAY_FIXED_FLAG);
			break;	
		case CMD_DIS_REMAINPARK:
			i+=ReadDisplayInfo(34,dat);
			i+=DisplayFloatConv(Display.pParkInfo->RemanStop,0,&dat[i]);
			DisplaySend(dat,i,DISPLAY_INSERT_FLAG|3);
			break;
		case CMD_DIS_SET_TIME:
			
			break;
		default:
			break;
	}
}



