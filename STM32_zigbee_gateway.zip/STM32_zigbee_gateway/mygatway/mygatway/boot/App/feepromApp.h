#ifndef EEPROMAPP__H
#define EEPROMAPP__H

#include "net.h"
#include "usrApp.h"

#define EE_KEY_NET 	3
#define EE_KEY_MD 	4   //����ID
#define EE_KEY_SERVER_IP 	5    //������IP
#define EE_KEY_SERVER_PORT 	6    //�������˿ں�

#define EE_KEY_TEST 	0x0f

typedef struct _NET_CONFIGPARA
{
	unsigned char lip[4];					
	unsigned char sub[4];					
	unsigned char gw[4];				
	unsigned char canaddr;				
}NET_CONFIGPARA;


void WriteNetConfig(NET_CONFIG *pNetConfig);
void ReadNetInfo(NET_CONFIG *pNetConfig);
unsigned char FeepromAppReset(void);
void FeepromAppInit(void);

void FeepromPostMutex(void);
int FeepromPendMutex (void);
int FeepromCreateMutex(void);
long feepromFunc_store(int argc,char **argv);

#endif

