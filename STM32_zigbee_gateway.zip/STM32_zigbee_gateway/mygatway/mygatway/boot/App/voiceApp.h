#ifndef VOICE_APP_H
#define VOICE_APP_H

#include "usrApp.h"
#include "voice.h"

#define	VOICE_DAY		(unsigned char)(51)
#define	VOICE_HOUR	(unsigned char)(52)
#define	VOICE_MINUTE	(unsigned char)(53)

#define 	VOICE_WAN		(unsigned char)(48)
#define 	VOICE_QIAN		(unsigned char)(47)
#define	VOICE_SHI		(unsigned char)(45)
#define 	VOICE_BAI		(unsigned char)(46)
#define	VOICE_YUAN		(unsigned char)(54)
#define	VOICE_JIAO		(unsigned char)(55)
#define	VOICE_A		(unsigned char)(56)
#define	VOICE_0		(unsigned char)(35)


#define CMD_VOICE_SINGLE			0x0E 	//���Ź̶�����
#define CMD_VOICE_TIME_FEE			0x0F 	//ͣ��ʱ��,����
#define CMD_VOICE_REMAINDAY	  	0x60	//ʣ������
#define CMD_VOICE_BALANCE	  		0x61	//���
#define CMD_VOICE_CARNUMBER	  	0x62	//����


typedef struct	
{
	unsigned char	Hour;				 
	unsigned char	Minute;
	unsigned char Value;			
}VolType;

typedef struct	
{
	VolType 			CurrentDayVol;
	VolType 			CurrentNightVol;
	unsigned char   	CurrentModex;	
}VOL_CONFIG;


typedef struct _VOICE
{
	unsigned char	Code;  //���������������ļ���
	VOL_CONFIG VolConfig;
	STOP_INFO  *pStopInfo;
	PARK_INFO  *pParkInfo;
}VOICE;


unsigned char VoiceMsgConvertPlays(VOICE_MSG *pVoiceMsg,unsigned char *dat);
long playFunc_Voice(int argc,char **argv);
void VoiceAppInit(VOICE **ppUsrVoice);
VOL_CONFIG *VoiceGetVolConfigAddr(void);


#endif
