#include "display.h"
#include "cmsis_os.h"
#include "stdlib.h"
#include "stdio.h"
#include "string.h"
#include "ff.h"


static osSemaphoreId Semsobj;


void DisplayInit(void)
{
	LedInit();
	DisplayCreateMutex();
}


void DisplaySend(unsigned char *dat,unsigned short len,unsigned short mode)
{
	DisplayPendMutex();
	LedSend(dat,len,mode);
	DisplayPostMutex();
}


int DisplayCreateMutex(void)
{
	int ret;
	
	osMutexDef(DIS_M);
	Semsobj = osMutexCreate(osMutex(DIS_M));		
	ret = (Semsobj != NULL);
	
	return ret;
}


int DisplayPendMutex (void)
{
	int ret = 0;
	
	if(osMutexWait(Semsobj, osWaitForever) == osOK)
	{
		ret = 1;
	}
	
	return ret;
}


void DisplayPostMutex(void)
{
	if(Semsobj!=NULL)
		osMutexRelease(Semsobj);
}


