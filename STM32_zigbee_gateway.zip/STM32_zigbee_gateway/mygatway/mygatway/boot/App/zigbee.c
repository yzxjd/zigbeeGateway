#include "stdio.h"
#include "string.h"
#include "stm32f10x_api.h"
#include "feeprom.h"
#include "feepromApp.h"
#include "zigbee.h"
#include "cmsis_os.h"
#include "usrApp.h"

extern void ConsoleSendByte(unsigned char dat);
extern unsigned int myID;
extern unsigned int myIDbak;

long zigbeeFunc_Net(int argc,char **argv)
{	
	if(!strcmp(argv[0],"lamp"))
	{
		LampScan();
	}
	else if(!strcmp(argv[0],"guide"))
	{
		GuideScan();
	}
	else if(!strcmp(argv[0],"yuyue"))    //zigbee yuyue 1 1
	{
		sendyuyue(atoi(argv[1]),atoi(argv[2]));
	}
	
	return 0;
}

void ZigbeeInit(void)
{
	GpioConfig(GPIOD,GPIO_Pin_5,GPIO_Mode_AF_PP,GPIO_Speed_50MHz);
	GpioConfig(GPIOD,GPIO_Pin_6,GPIO_Mode_IN_FLOATING,GPIO_Speed_50MHz);
	GPIO_PinRemapConfig(GPIO_Remap_USART2,ENABLE);
	Uart2Config(115200,8,0,1);
}



void ZigbeeSendByte(unsigned char dat)
{
	unsigned char buf[20];
	
	USART_SendData(USART2,(unsigned short)dat);
	while(USART_GetFlagStatus(USART2, USART_FLAG_TXE)!=SET) ;
	sprintf(buf,"%02x",dat);
	printf("%s ",buf);
}


void ZigbeeSendBytes(unsigned char *dat,unsigned short len)
{
	unsigned short i;
	
	for(i=0;i<len;i++)
	{
		ZigbeeSendByte(dat[i]);
	}
}


unsigned char ZigbeeDataCheck(unsigned char *buf)
{
	unsigned short i;
	unsigned char xxor=0;
	ZIGBEE_HEAD *pZigbeeHead;
	
	pZigbeeHead = (ZIGBEE_HEAD *)buf;
	
	//if(pZigbeeHead->ver==0x01)
	{
		xxor ^= 0x55;
		xxor ^= 0xaa;
		for(i=0;i<sizeof(ZIGBEE_HEAD)+pZigbeeHead->len;i++)
		{
			xxor ^= buf[i];
		}	
		if(xxor==buf[i])
		{
			return 1;
		}
		else
		{
			printf("xxor error %x != %x\r\n",xxor,buf[i]);
		}
	}
	return 0;
}


unsigned int ZigbeeProcess(unsigned char *buf)
{
	ZIGBEE_HEAD *pZigbeeHead=(ZIGBEE_HEAD *)buf;
	REVPRO_MSG RevProMsg;
	unsigned char i ;
	
	/*
	printf("srcID:0x%x dstID:0x%x cmd:0x%x [DATA]",pZigbeeHead->srcID,pZigbeeHead->dstID,pZigbeeHead->cmd);
	for(i=0;i<pZigbeeHead->len;i++)
	{
		printf(" 0x%02x",*(buf+sizeof(ZIGBEE_HEAD)+i));
	}
	printf("\r\n");
	*/
	//if((pZigbeeHead->dstID&0x7fffffff)!=myID)
	//{
	//
	//	myIDbak = pZigbeeHead->dstID&0x7fffffff;
	//}
	RevProMsg.type = 0; 
	RevProMsg.cmd = pZigbeeHead->cmd;
	RevProMsg.srcID = pZigbeeHead->srcID;
	memcpy(RevProMsg.dat,buf+sizeof(ZIGBEE_HEAD),pZigbeeHead->len);
	
	RevProSend(&RevProMsg);
	
	return 0;
}


void ZigbeeSendToDstIDCmd(unsigned int dstID,unsigned char cmd,unsigned char *dat,unsigned short len)
{
	unsigned char buf[50],xxor=0;
	unsigned short i;
	ZIGBEE_HEAD ZigbeeHead;
	
	ZigbeeHead.cmd = cmd;
	ZigbeeHead.ver =0x01;
	ZigbeeHead.srcID = (0x80000000|myID);
	ZigbeeHead.dstID = dstID;
	ZigbeeHead.len = len;
	
	buf[0]=0xaa;
	buf[1]=0x55;
	memcpy(&buf[2],&ZigbeeHead,sizeof(ZIGBEE_HEAD));

	if(dat==NULL)
	{
		for(i=0;i<len;i++)
		{
			buf[2+sizeof(ZIGBEE_HEAD)+i] =0;
		}
	}
	else
	{
		for(i=0;i<len;i++)
		{
			buf[2+sizeof(ZIGBEE_HEAD)+i] = dat[i];
		}
	}
	for(i=0;i<2+sizeof(ZIGBEE_HEAD)+len;i++)
	{
		xxor ^=buf[i];
	}
	taskENTER_CRITICAL();
	ZigbeeSendBytes(buf,2+sizeof(ZIGBEE_HEAD)+len);
	ZigbeeSendByte(xxor);
	taskEXIT_CRITICAL();
}


void ZigbeeRev(unsigned char dat)
{
	char i=0;
	static char flag=0;
	static char length=0;
	static char buffer[150];
	static ZIGBEE_HEAD *pZigbeeHead;
	
	//ConsoleSendByte(dat);
	
	buffer[length++]=dat;	
	if(length>=sizeof(buffer))
	{
		length=0;
	}
	if((length>=2)&&(buffer[length-2]==0x55)&&(buffer[length-1]==0xaa))   
	{
		length=0;
		pZigbeeHead  = (ZIGBEE_HEAD *)(buffer+length);
		pZigbeeHead->len =3;
		flag=1;
	}
	else if((flag==1)&&(length>=(sizeof(ZIGBEE_HEAD)+pZigbeeHead->len+1)))    //��Ч����
	{
		//if(ZigbeeDataCheck(buffer))
		{
			ZigbeeProcess(buffer);
		}
		flag=0;
		length=0;
		pZigbeeHead->len =0;
	}
}

void USART2_IRQHandler(void)
{	
	unsigned char cByte;
	
	if (USART_GetFlagStatus(USART2, USART_FLAG_ORE) != RESET)
	{
		USART_ReceiveData(USART2);
	}
	else if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)  
	{
		USART_ClearFlag(USART2,USART_IT_RXNE);    
		cByte=USART_ReceiveData(USART2);
		ZigbeeRev(cByte);
	}
}



