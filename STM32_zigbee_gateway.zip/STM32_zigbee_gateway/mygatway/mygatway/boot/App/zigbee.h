#ifndef ZIGBEE_H
#define ZIGBEE_H


#pragma pack(push)//�������״̬ 
#pragma pack(1)  //����Ϊ1�ֽڶ���
typedef struct _ZIGBEE_HEAD
{
	unsigned char ver;
	unsigned int srcID;
	unsigned int dstID;
	unsigned char cmd;
	unsigned short len;
}ZIGBEE_HEAD;
#pragma pack(pop)

void ZigbeeInit(void);
void ZigbeeProcessTask(void const * argument);
long zigbeeFunc_Net(int argc,char **argv);

void ZigbeeSendToDstIDCmd(unsigned int dstID,unsigned char cmd,unsigned char *dat,unsigned short len);

#endif
