#include "Fourg.h"
#include "mqttApp.h"
#include "MQTTPacket.h"
#include "stdio.h"
#include "cmsis_os.h"
#include <string.h>

void mqtt_subscribe(void);
void mqtt_connect(void);


static unsigned short len = 0;	
static uint8_t buf[2048];
static MQTTString topicString = MQTTString_initializer;

int transport_open(void)
{
	FourGSocketOpen();
	
	return 0;
}

int transport_close(void)
{
	FourGSocketClose();
	
	return 0;
}

int transport_status(void)
{	
	unsigned char strbuf[100];
	
	sprintf(strbuf,"123456#AT+SOCKALK\r\n");
	FourGSocketSend(strbuf,strlen(strbuf));
	if(at_return_string("connected"))
	{
		return 1;
	}
	return 0;
}

unsigned char transport_connect(unsigned char *ip,unsigned short port,unsigned char cnt)
{
	unsigned char strbuf[100];

	printf("4G SocketA Open...\r\n");
	
	sprintf(strbuf,"123456#AT+SOCKAEN=\"on\"\r");
	FourGSocketSend(strbuf,strlen(strbuf));
	if(!at_return_string("OK"))
		return 0;
	
	printf("4G SocketA Connect...\r\n");
	sprintf(strbuf,"123456#AT+SOCKA=\"TCP\",\"%d.%d.%d.%d\",%d\r",ip[0],ip[1],ip[2],ip[3],port);
	FourGSocketSend(strbuf,strlen(strbuf));
	if(!at_return_string("OK"))
		return 0;
	
	while(1)
	{
		sprintf(strbuf,"123456#AT+SOCKALK\r\n");
		FourGSocketSend(strbuf,strlen(strbuf));
		if(at_return_string("SOCKALK:connected"))
		{
			printf("4G SocketA Connect OK\r\n");
			break;
		}
		else if(cnt--==0)
		{
			return 0;
		}
		osDelay(500);
	}
	return 0xff;
}


void transport_sendPacketBuffer(uint8_t* buf, int32_t buflen)
{
	//printf("[DAT]:\r\n");
	FourGSocketSend(buf,buflen);
	//ConsoleSendBytes(buf,buflen);
	//printf("[END]:\r\n");
}


void mqtt_init(void)
{
	unsigned char ip[4]={112,74,132,1};
	unsigned short port=1884;
	
	if(!transport_connect(ip,port,50))
	{
		printf("4G SocketA Connect Fail\r\n");
		return ;
	}
	//mqtt_connect();
}


void mqtt_connect(void)
{
	MQTTPacket_connectData data = MQTTPacket_connectData_initializer;
	
	printf("MQTT Connect...\r\n");
	
	data.clientID.cstring = "gateway test";
	data.keepAliveInterval = 0;
	data.cleansession = 1;
	
	//data.username.cstring = "admin";
	//data.password.cstring = "password";
	
	len = MQTTSerialize_connect(buf, sizeof(buf), &data);
	CycleBufferInit(0);
	transport_sendPacketBuffer(buf, len);      //�������ݰ�	
	mqtt_ack_process(1000);
}



void mqtt_subscribe(void)
{
	unsigned short msgid = 1;
	int req_qos = 0;
	
	topicString.cstring = "test";
	len = MQTTSerialize_subscribe(buf, sizeof(buf), 0, msgid, 1, &topicString, &req_qos);
	CycleBufferInit(0);
	transport_sendPacketBuffer(buf, len);	//�������ݰ�	
	mqtt_ack_process(1000);
}



void mqtt_publish(unsigned char *payload,unsigned short payloadlen)
{
	unsigned char buf[100];
	unsigned short len;
	
	topicString.cstring = "1";       //ֱ�ӷ��͵�����
	
	memset(buf,0,sizeof(buf));
	len = MQTTSerialize_publish(buf, sizeof(buf), 0, 1, 0, 1, topicString, (unsigned char*)payload, payloadlen);
	CycleBufferInit(0);
	transport_sendPacketBuffer(buf, len);	//�������ݰ�
	mqtt_ack_process(1000);
}



void testmqtt_publish(void)
{
	unsigned char str[]="hello zd";
	
	mqtt_publish(str,strlen(str));
}


void mqtt_heartbeat(void)
{
	len = MQTTSerialize_pingreq(buf,sizeof(buf));
	transport_sendPacketBuffer(buf,len);
}


unsigned short mqtt_rev(unsigned char *dat,unsigned short timeout)
{
	unsigned char temp;
	unsigned short cnt=0;
	
	while(1)
	{
		if(CycleBufferPop(0,&temp)==0)
		{	
			dat[cnt++]=temp;
			break;
		}
		else
		{
			if(timeout--==0)
			{
				return 0;
			}
			osDelay(10);
		}
	}
	timeout = 5;
	while(1)
	{
		if(CycleBufferPop(0,&temp)==0)
		{	
			dat[cnt++]=temp;
		}
		else
		{
			if(timeout--==0)
			{
				return cnt;
			}
			osDelay(10);
		}
	}
	return 0;
}



unsigned short mqtt_ack_process(unsigned short timeout)
{
	unsigned short size,ret=0;
	unsigned char strtobuf[100];
	
	memset(strtobuf,0,sizeof(strtobuf));
	memset(buf,0,sizeof(buf));
	
	size=mqtt_rev(buf,timeout);
	if(size> 0) 
	{
		//printf("[FROM]%s\r\n",buf);
		MQTTFormat_toClientString(strtobuf,sizeof(strtobuf),buf,size);
		//printf("[TO]%s\r\n",strtobuf);
	}
	else
	{
		printf("process fail\r\n");
	}
	
	return ret;
}

unsigned short at_return_string(unsigned char *str)
{
	unsigned short size;
	
	memset(buf,0,sizeof(buf));
	size=mqtt_rev(buf,500);
	if(size> 0)
	{
		//printf("[AT]%s\r\n",buf);
		if(strstr(buf,str)!=NULL);
		{
			return size;
		}
	}
	
	return 0;
}



/*
uint32_t do_mqtt_client(uint8_t sn,uint8_t* destip, uint16_t destport)
{
	uint32_t ret; 
	uint16_t any_port = 50000;
	unsigned char ir;
	uint32_t size; 
	unsigned char strbuf[100];
	
	switch(getSn_SR(sn))
	{
	  	case SOCK_ESTABLISHED :
			ir =getSn_IR(sn);
			if(ir & Sn_IR_CON)
			{
				setSn_IR(sn,Sn_IR_CON);
				mqtt_connect();    //����MQTT������
				mqtt_subscribe(); //��������
			}
			if(ir & Sn_IR_TIMEOUT)
			{
				close(sn);
				setSn_IR(sn,Sn_IR_TIMEOUT);
			}
			if((size = getSn_RX_RSR(sn)) > 0)  
			{
				if(size > 2048) size = 2048;
				ret = recv(sn, buf, size);
				
				if(ret <= 0) return ret;
				MQTTFormat_toClientString(strbuf,sizeof(strbuf),buf,size);
				printf("%s\r\n",strbuf);
				break;
			}
		  break;
		  
		  case SOCK_CLOSE_WAIT :
		     if((ret=disconnect(sn)) != SOCK_OK) return ret;
		     printf("%d:Socket Closed\r\n", sn);
		     break;

		  case SOCK_INIT :
			 //printf("%d:Try to connect to the %d.%d.%d.%d : %d\r\n", sn, destip[0], destip[1], destip[2], destip[3], destport);
			 if( (ret = connect(sn, destip, destport)) != SOCK_OK) return ret;	//	Try to TCP connect to the TCP server (destination)
		     break;
		  
		  case SOCK_CLOSED:
			  close(sn);
			  //if((ret=socket(sn, Sn_MR_TCP, any_port++, 0x00)) != sn) return ret; // TCP socket open with 'any_port' port number
			  if((ret=socket(sn, Sn_MR_TCP, any_port++, 0x00)) != Sn_MR_ND) return ret;
		     break;
		  default:
		     break;
	}
	return 1;
}
*/

