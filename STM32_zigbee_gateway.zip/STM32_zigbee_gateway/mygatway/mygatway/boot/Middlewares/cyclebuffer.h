#ifndef CYCLEBUFFER_H
#define CYCLEBUFFER_H

void CycleBufferInit(unsigned char Id);
int CycleBufferPush(unsigned char Id ,unsigned char Data);
int CycleBufferPop(unsigned char Id,unsigned char *pData);


#endif
