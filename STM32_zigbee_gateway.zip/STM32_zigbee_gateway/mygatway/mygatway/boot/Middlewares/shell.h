#ifndef SHELL_H
#define SHELL_H

void ShellPutChar(char data);
void ShellPutChars(char *data,unsigned short len);
void ShellProcess(char ch);

  //===========================================================
#define ShellOutTXT    	printf
#define ShellOutChar   	ShellPutChar
#define NextLine()	    	do {ShellOutChar('\r');ShellOutChar('\n');}while(0)
#define Prompt()   	    	ShellPutChars("\\>",strlen("\\>"))

#define MAX_CMD_LEN	64
#define MAX_ARGS		MAX_CMD_LEN/4

#define ENTER_KEY		0x0d
#define BACK_KEY		0x08
#define ESC_KEY			0x1b

int ShellCreateSem(void);
int ShellPendSem (void);
void ShellPostSem(void);
void shellTask(void const * argument);

#endif
