#ifndef CRC32_H
#define CRC32_H

unsigned long Calculate_CRC32(unsigned long CRC32,unsigned char *buff,unsigned long Len);

#endif
