#include "shell.h"
#include "console.h"
#include <stdio.h>
#include <string.h>
#include "feepromApp.h"
#include "cmsis_os.h"
//#include "net.h"
#include "zigbee.h"
#include "fourG.h"

static osSemaphoreId Semsobj;
static int CntGlobal;
static char KeyGlobal;
static char CmdGlobal[MAX_CMD_LEN];

void ShellPutChar(char data)
{
	ConsoleSendByte(data);
}


void ShellPutChars(char *data,unsigned short len)
{
	ConsoleSendBytes((unsigned char*)data,len);
}

long Help(int argc, char *argv[]);

typedef long(*CMD_PROC_CB)(int argc, char *argv[]);

typedef struct
{
  char *cmd;
  char *hlp;
  CMD_PROC_CB proc;
} CMD_STRUC;


static const CMD_STRUC CMD_INNER[] =
{
  {
    "help", "show help", Help
  }
  ,
  {
    "?", "= help", Help
  }
  ,
  {
    "------", "------", NULL
  } /*
  ,
  {
    "net", "config    -������Ϣ��ʾ", netFunc_Net
  }
  
  ,
  {
    "down", "down    -���� ����", downFunc_Net
  }*/
   ,
  {
    "AT", "AT    -AT����", ATFunc_Net
  }  
    ,
  {
    "zigbee", "zigbee    -zigbee����", zigbeeFunc_Net
  }  ,
  {
    "eeprom", "eeprom    -feeprom ����", feepromFunc_store
  }   
    ,
  {
    NULL, NULL, NULL
  }
};




long Help(int argc, char *argv[])
{
  int i;

  for (i = 0; CMD_INNER[i].cmd != NULL; i++)
  {
    if (CMD_INNER[i].hlp != NULL)
    {
      printf("%s	------	%s\r\n", CMD_INNER[i].cmd, CMD_INNER[i].hlp);
    }
  }

  return 0;
}

/*********************************************************/
void ParseArgs(char *cmdline, int *argc, char **argv)
{
  #define STATE_WHITESPACE	0
  #define STATE_WORD			1

  char *c;
  int i;
  int state = STATE_WHITESPACE;

  *argc = 0;

  if (strlen(cmdline) == 0)
    return ;

  /* convert all tabs into single spaces */
  c = cmdline;
  while (*c != '\0')
  {
    if (*c == '\t')
      *c = ' ';
    c++;
  }

  c = cmdline;
  i = 0;

  /* now find all words on the command line */
  while (*c != '\0')
  {
    if (state == STATE_WHITESPACE)
    {
      if (*c != ' ')
      {
        argv[i] = c; //��argv[i]ָ��c
        i++;
        state = STATE_WORD;
      }
    }
    else
    {
       /* state == STATE_WORD */
      if (*c == ' ')
      {
        *c = '\0';
        state = STATE_WHITESPACE;
      }
    }
    c++;
  }

  *argc = i;
  #undef STATE_WHITESPACE
  #undef STATE_WORD
}

int GetCmdMatche(char *cmdline)
{
  int i;

  for (i = 0; CMD_INNER[i].cmd != NULL; i++)
  {
    if (strncmp(CMD_INNER[i].cmd, cmdline, strlen(CMD_INNER[i].cmd)) == 0)
      return i;
  }

  return  - 1;
}

int ParseCmd(char *cmdline, int cmd_len)
{
  int argc;
  int num_commands;
  char *argv[MAX_ARGS];

  ParseArgs(cmdline, &argc, argv);

  /* only whitespace */
  if (argc == 0)
    return 0;

  num_commands = GetCmdMatche(argv[0]);
  if (num_commands < 0)
    return  - 1;

  argc--;

  if (CMD_INNER[num_commands].proc != NULL)
    CMD_INNER[num_commands].proc(argc, &argv[1]);

  return 0;
}


void ShellProcess(char ch)
{

  KeyGlobal = ch;
  if (KeyGlobal == BACK_KEY)
  {
    if (CntGlobal)
    {
      ShellOutChar(KeyGlobal);
      ShellOutChar(' ');
      ShellOutChar(KeyGlobal);
    }
    CntGlobal -= CntGlobal ? 1 : 0;
  }
  else if (KeyGlobal == ENTER_KEY)
  {
    CmdGlobal[CntGlobal] = 0;
    NextLine();
    ShellPostSem();
  }
  else
  {
    if (CntGlobal < MAX_CMD_LEN - 1)
    {
      CmdGlobal[CntGlobal++] = KeyGlobal;
      ShellOutChar(KeyGlobal);
    }
  }
}


/*******************************************************/

void shellTask(void const * argument)
{  
	ShellCreateSem();
	
	while(1)
	{
		if(ShellPendSem())
		{
			if (ParseCmd(CmdGlobal, CntGlobal) < 0)
			printf("Bad command\r\n");
			Prompt();
			CntGlobal = 0;
		}
	}
}



int ShellCreateSem(void)
{
	int ret;

	osSemaphoreDef(SH);
	Semsobj = osSemaphoreCreate(osSemaphore(SH), 1);		
	ret = (Semsobj != NULL);
	
	return ret;
}



int ShellPendSem (void)
{
	int ret = 0;

	if(osSemaphoreWait(Semsobj, osWaitForever) == osOK)
	{
		ret = 1;
	}

	return ret;
}



void ShellPostSem(void)
{
	if(Semsobj!=NULL)
		osSemaphoreRelease(Semsobj);
}



