#include "cyclebuffer.h"

typedef struct
{
	unsigned char	bRxStopFlag;		//ֹͣ���ձ��
	unsigned short	iRxInPtr;			//��ջָ��
	unsigned short	iRxOutPtr;			//��ջָ��
	unsigned char (*RecvCtrPro)(unsigned char,unsigned char );    //���ջ�����������ʱ��ֹ�ж�
}CycleBufferTag;

#define ENABLE_USART_NUM	2

#define REVEICEBUFF1_SIZE	4096			
#define REVEICEBUFF2_SIZE	1024

static CycleBufferTag CycleBuffer[ENABLE_USART_NUM];	

static unsigned char CycleBuffer1[REVEICEBUFF1_SIZE];	   
static unsigned char CycleBuffer2[REVEICEBUFF2_SIZE];	 

static unsigned short cycleSizeTable[ENABLE_USART_NUM]={REVEICEBUFF1_SIZE,REVEICEBUFF2_SIZE};
static unsigned char *cycleAddrTable[ENABLE_USART_NUM]={CycleBuffer1,CycleBuffer2};


void CycleBufferInit(unsigned char Id)
{
	if(CycleBuffer[Id].bRxStopFlag!=0)
	{
		//if(CycleBuffer[Id].RecvCtrPro!=NULL)
		//	(*CycleBuffer[Id].RecvCtrPro)(Id,1);
		
		CycleBuffer[Id].bRxStopFlag=0;
	}
	
	CycleBuffer[Id].iRxInPtr=0;
	CycleBuffer[Id].iRxOutPtr=0;
}


int CycleBufferPush(unsigned char Id ,unsigned char Data)
{
	unsigned short iNextInPtr;
	
	iNextInPtr=(CycleBuffer[Id].iRxInPtr+1)%cycleSizeTable[Id];
	if(iNextInPtr!=CycleBuffer[Id].iRxOutPtr)
	{
		*(cycleAddrTable[Id]+CycleBuffer[Id].iRxInPtr)=Data;
		CycleBuffer[Id].iRxInPtr=iNextInPtr;
		//ConsoleSendByte(Data);  
		iNextInPtr=(CycleBuffer[Id].iRxInPtr+1)%cycleSizeTable[Id];
		if(iNextInPtr==CycleBuffer[Id].iRxOutPtr)
		{	
			//if(CycleBuffer[Id].RecvCtrPro!=NULL)
			//	(*CycleBuffer[Id].RecvCtrPro)(Id,0);
			CycleBuffer[Id].bRxStopFlag=1;
			return -1;
		}
	}   

	return 0;
}                    


int CycleBufferPop(unsigned char Id,unsigned char *pData)
{
	unsigned short iRxInPtr;

	//taskENABLE_INTERRUPTS();
	iRxInPtr=CycleBuffer[Id].iRxInPtr;
	if(iRxInPtr!=CycleBuffer[Id].iRxOutPtr)
	{
		*pData=*(cycleAddrTable[Id]+CycleBuffer[Id].iRxOutPtr++);
		if(CycleBuffer[Id].iRxOutPtr==cycleSizeTable[Id])
			CycleBuffer[Id].iRxOutPtr=0;
		ConsoleSendByte(*pData);      //�յ���ģ�����Ϣ����ӡ����
		return 0; 
	}
	else     //buffer empty
	{
		if(CycleBuffer[Id].bRxStopFlag!=0)
		{
			//if(CycleBuffer[Id].RecvCtrPro!=NULL)
			//	(*CycleBuffer[Id].RecvCtrPro)(Id,1);
			CycleBuffer[Id].bRxStopFlag=0;
		}
	}
	
	return -1;
}




