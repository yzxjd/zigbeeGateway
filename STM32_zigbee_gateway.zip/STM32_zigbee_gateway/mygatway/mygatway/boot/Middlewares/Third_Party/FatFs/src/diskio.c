/*-----------------------------------------------------------------------*/
/* Low level disk I/O module skeleton for FatFs     (C)ChaN, 2007        */
/*-----------------------------------------------------------------------*/
/* This is a stub disk I/O module that acts as front end of the existing */
/* disk I/O modules and attach it to FatFs module with common interface. */
/*-----------------------------------------------------------------------*/

#include "diskio.h"
#include "SPI_MSD_Driver.h"
/*-----------------------------------------------------------------------*/
/* Correspondence between physical drive number and physical drive.      */
extern MSD_CARDINFO CardInfo;

/*-----------------------------------------------------------------------*/
/* Inidialize a Drive                                                    */

DSTATUS disk_initialize (
	BYTE drv				/* Physical drive nmuber (0..) */
)
{
	int Status;
	switch ( drv )	
	{
		case 0 :
			Status=MSD_Init();     /* SD_USER_Init() ����������û���д */
			if ( Status == 0 )	 /* SD ����ʼ���ɹ�,��һ���ǳ���Ҫ */
				return 0;
			else
			return STA_NOINIT;

		case 1 :
			return STA_NOINIT;

		case 2 :
			return STA_NOINIT;
	}
	return STA_NOINIT;
}



/*-----------------------------------------------------------------------*/
/* Return Disk Status                                                    */

DSTATUS disk_status (
	BYTE drv		/* Physical drive nmuber (0..) */
)
{
	switch (drv) /* �û��Լ�����Ӧ�ô��� */
	{
	  case 0 :
		
	  /* translate the reslut code here	*/

	    return 0;

	  case 1 :
	
	  /* translate the reslut code here	*/

	    return 0;

	  case 2 :
	
	  /* translate the reslut code here	*/

	    return 0;

	  default:

        break;
	}
	return STA_NOINIT;
	
}



/*-----------------------------------------------------------------------*/
/* Read Sector(s)                                                        */

DRESULT disk_read (
	BYTE drv,		/* Physical drive nmuber (0..) */
	BYTE *buff,		/* Data buffer to store read data */
	DWORD sector,	/* Sector address (LBA) */
	BYTE count		/* Number of sectors to read (1..255) */
)
{	
  int Status;
  if( !count )
  {    
    return RES_PARERR;  /* count���ܵ���0�����򷵻ز������� */
  }

  switch (drv)
  {
    case 0:
    if(count==1)            /* 1��sector�Ķ����� */      
    {       
	  Status =  MSD_ReadSingleBlock( sector ,buff );
    }                                                
    else                    /* ���sector�Ķ����� */     
    {   
      Status = MSD_ReadMultiBlock( sector , buff ,count);
    }                                                
    if(Status == 0)
    {
      return RES_OK;
    }
    else
    {
      return RES_ERROR;
    }
    default:break;   
  }  
  return RES_ERROR;	 	
}



/*-----------------------------------------------------------------------*/
/* Write Sector(s)                                                       */

#if _READONLY == 0
DRESULT disk_write (
	BYTE drv,			/* Physical drive nmuber (0..) */
	const BYTE *buff,	/* Data to be written */
	DWORD sector,		/* Sector address (LBA) */
	BYTE count			/* Number of sectors to write (1..255) */
)
{	
  int Status;
  if( !count )
  {    
    return RES_PARERR;  /* count���ܵ���0�����򷵻ز������� */
  }

  switch (drv)
  {
    case 0:
    if(count==1)            /* 1��sector��д���� */      
    {   
       Status = MSD_WriteSingleBlock( sector , (uint8_t *)(&buff[0]) ); 
    }                                                
    else                    /* ���sector��д���� */    
    {   
       Status = MSD_WriteMultiBlock( sector , (uint8_t *)(&buff[0]) , count );	  
    }                                                
    if(Status == 0)
    {
       return RES_OK;
    }
    else
    {
       return RES_ERROR;
    }
    case 2:
	   break;
    default :
       break;
  }
 return RES_ERROR;
}
#endif /* _READONLY */



/*-----------------------------------------------------------------------*/
/* Miscellaneous Functions                                               */

DRESULT disk_ioctl (
	BYTE drv,		/* Physical drive nmuber (0..) */
	BYTE ctrl,		/* Control code */
	void *buff		/* Buffer to send/receive control data */
)
{
	return RES_OK;		
}
							

/* ����������û����壬��Ϊff.c�е�����������������ļ�ϵͳ��û�ж���
 * �����û���������������ԭ�͡�         
 * 31-25: Year(0-127 org.1980), 24-21: Month(1-12), 20-16: Day(1-31)                                                                                                                                                                                                                                        
 * 15-11: Hour(0-23), 10-5: Minute(0-59), 4-0: Second(0-29 *2) 
 */                                                                                                                                                                                                                                                
DWORD get_fattime (void)
{   
	return 0;
}
