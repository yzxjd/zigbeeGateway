#ifndef FF_CMDS_H
#define FF_CMDS_H

#define _error_Fat		printf
#define _log_Fat			printf


void CreateTargetValBuf(const char *arg);

long lsFunc_Fat(int argc, char **argv);
long rmFunc_Fat(int argc, char **argv);
long catFunc_Fat(int argc, char **argv);

long writeFunc_Fat(int argc, char **argv);
long mkdirFunc_Fat(int argc, char **argv);
long freeFunc_Fat(int argc, char **argv);

long cdFunc_Fat(int argc, char **argv);
long pwdFunc_Fat(int argc, char **argv);
long ShowFunc_Fat(int argc, char **argv);
long RegisterFunc_Fat(int argc, char **argv);
void _show_directory_Fat(const char *path);
void _write_file_Fat(const char *name, const char *txt);
void _dump_file_Fat(const char *name);
void _show_free_Fat(void);


#endif

