#include "circleBuffer.h"
#include "cmsis_os.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define  EnterCriticalSection  taskENTER_CRITICAL
#define  LeaveCriticalSection  taskEXIT_CRITICAL
#define  CP_ASSERT(expr) ((expr) ? (int)0 : printf("[!error]Wrong parameters value: file %s on line %d\r\n", __FILE__, __LINE__))
#define  CP_CHECKOBJECT(expr) ((expr) ? (int)0 : printf("[!error]Wrong parameters addr: file %s on line %d\r\n", __FILE__, __LINE__))

#define CIC_WAITTIMEOUT  100
static void *CreateEvent(void);
static void CloseHandle(void *sobj);
static void SetEvent(void *sobj);
static int WaitForSingleObject (void *sobj,unsigned int delay);

////////////////////////////////////////////////////////////////////////////////


//
//
//
CircleBuffer* CircleBufferCreate(const unsigned int iBufferSize)
{
	CircleBuffer* pNewBuffer = (CircleBuffer*)malloc(sizeof(CircleBuffer));
	CP_CHECKOBJECT(pNewBuffer);
	
	pNewBuffer->Uninitialise = CircleBufferUninitialise;
	pNewBuffer->Write = CircleBufferWrite;
	pNewBuffer->Read = CircleBufferRead;
	pNewBuffer->Flush = CircleFlush;
	pNewBuffer->GetUsedSize = CircleGetUsedSpace;
	pNewBuffer->GetFreeSize = CircleGetFreeSpace;
	pNewBuffer->SetComplete = CircleSetComplete;
	pNewBuffer->IsComplete = CircleIsComplete;
	
	pNewBuffer->m_iBufferSize = iBufferSize;
	pNewBuffer->m_pBuffer = (unsigned char*)malloc(iBufferSize);
	pNewBuffer->m_iReadCursor = 0;
	pNewBuffer->m_iWriteCursor = 0;
	pNewBuffer->m_bComplete = 0;
	pNewBuffer->m_evtDataAvailable = CreateEvent();
	
	return pNewBuffer;
}

//
//
//
void CircleBufferUninitialise(CircleBuffer* pCBuffer)
{
	CP_CHECKOBJECT(pCBuffer);
	CloseHandle(pCBuffer->m_evtDataAvailable);
	free(pCBuffer->m_pBuffer);
	free(pCBuffer);
}

//
//
//
void CircleBufferWrite(CircleBuffer* pCBuffer, const void* _pSourceBuffer, const unsigned int _iNumBytes)
{
	unsigned int iBytesToWrite = _iNumBytes;
	unsigned char* pReadCursor = (unsigned char*)_pSourceBuffer;
	
	CP_ASSERT(iBytesToWrite <= pCBuffer->GetFreeSize(pCBuffer));
	CP_ASSERT(pCBuffer->m_bComplete == 0);
	
	EnterCriticalSection();
	
	// We *know* there is enough space in the buffer for this
	// entire stream - write all the data until the end of the block
	
	if (pCBuffer->m_iWriteCursor >= pCBuffer->m_iReadCursor)
	{
		// Determine how much data we can fit into the end part of the CBuffer
		unsigned int iChunkSize = pCBuffer->m_iBufferSize - pCBuffer->m_iWriteCursor;
		
		if (iChunkSize > iBytesToWrite)
			iChunkSize = iBytesToWrite;
			
		// Copy the data
		memcpy(pCBuffer->m_pBuffer + pCBuffer->m_iWriteCursor,
			   pReadCursor, iChunkSize);
		       
		pReadCursor += iChunkSize;
		
		iBytesToWrite -= iChunkSize;
		
		// Update write cursor (wrapping if needed)
		pCBuffer->m_iWriteCursor += iChunkSize;
		
		if (pCBuffer->m_iWriteCursor >= pCBuffer->m_iBufferSize)
			pCBuffer->m_iWriteCursor -= pCBuffer->m_iBufferSize;
	}
	
	// Fill the start part of the CBuffer with any data that may be left
	
	if (iBytesToWrite)
	{
		memcpy(pCBuffer->m_pBuffer + pCBuffer->m_iWriteCursor,
			   pReadCursor, iBytesToWrite);
		pCBuffer->m_iWriteCursor += iBytesToWrite;
		CP_ASSERT(pCBuffer->m_iWriteCursor < pCBuffer->m_iBufferSize);
	}
	
	SetEvent(pCBuffer->m_evtDataAvailable);
	
	LeaveCriticalSection();
}

//
//
//
unsigned int CircleBufferRead(CircleBuffer* pCBuffer, void* pDestBuffer, const unsigned int _iBytesToRead, unsigned int* pbBytesRead)
{
	unsigned int iBytesToRead = _iBytesToRead;
	unsigned int iBytesRead = 0;
	int dwWaitResult;
	unsigned int bComplete = 0;
	
	CP_CHECKOBJECT(pCBuffer);
	
	while (iBytesToRead > 0 && bComplete == 0)
	{
		dwWaitResult = WaitForSingleObject(pCBuffer->m_evtDataAvailable, CIC_WAITTIMEOUT);
		
		if (dwWaitResult ==0)
		{
			//printf("Circle buffer - did not fill in time!");
			*pbBytesRead = iBytesRead;
			return 0;
		}
		
		EnterCriticalSection();
		
		// Take what we can from the CBuffer
		
		if (pCBuffer->m_iReadCursor > pCBuffer->m_iWriteCursor)
		{
			unsigned int iChunkSize = pCBuffer->m_iBufferSize - pCBuffer->m_iReadCursor;
			
			if (iChunkSize > iBytesToRead)
				iChunkSize = iBytesToRead;
				
			// Perform the read
			memcpy((unsigned char*)pDestBuffer + iBytesRead,
				   pCBuffer->m_pBuffer + pCBuffer->m_iReadCursor,
				   iChunkSize);
			       
			iBytesRead += iChunkSize;
			iBytesToRead -= iChunkSize;
			
			pCBuffer->m_iReadCursor += iChunkSize;
			
			if (pCBuffer->m_iReadCursor >= pCBuffer->m_iBufferSize)
				pCBuffer->m_iReadCursor -= pCBuffer->m_iBufferSize;
		}
		
		if (iBytesToRead && pCBuffer->m_iReadCursor < pCBuffer->m_iWriteCursor)
		{
			unsigned int iChunkSize = pCBuffer->m_iWriteCursor - pCBuffer->m_iReadCursor;
			
			if (iChunkSize > iBytesToRead)
				iChunkSize = iBytesToRead;
				
			// Perform the read
			memcpy((unsigned char*)pDestBuffer + iBytesRead,
				   pCBuffer->m_pBuffer + pCBuffer->m_iReadCursor,
				   iChunkSize);
			       
			iBytesRead += iChunkSize;
			iBytesToRead -= iChunkSize;
			pCBuffer->m_iReadCursor += iChunkSize;
		}
		
		// Is there any more data to read
		
		if (pCBuffer->m_iReadCursor == pCBuffer->m_iWriteCursor)
		{
			if (pCBuffer->m_bComplete)
				bComplete = 1;
		}
		
		else
			SetEvent(pCBuffer->m_evtDataAvailable);
			
		LeaveCriticalSection();
	}
	
	*pbBytesRead = iBytesRead;
	
	return bComplete ? 0 : 1;
}

//
//
//
void CircleFlush(CircleBuffer* pCBuffer)
{
	CP_CHECKOBJECT(pCBuffer);
	
	EnterCriticalSection();
	pCBuffer->m_iReadCursor = 0;
	pCBuffer->m_iWriteCursor = 0;
	LeaveCriticalSection();
}

//
//
//
unsigned int CircleGetFreeSpace(CircleBuffer* pCBuffer)
{
	unsigned int iNumBytesFree;
	
	CP_CHECKOBJECT(pCBuffer);
	EnterCriticalSection();
	
	if (pCBuffer->m_iWriteCursor < pCBuffer->m_iReadCursor)
		iNumBytesFree = (pCBuffer->m_iReadCursor - 1) - pCBuffer->m_iWriteCursor;
	else if (pCBuffer->m_iWriteCursor == pCBuffer->m_iReadCursor)
		iNumBytesFree = pCBuffer->m_iBufferSize;
	else
		iNumBytesFree = (pCBuffer->m_iReadCursor - 1) + (pCBuffer->m_iBufferSize - pCBuffer->m_iWriteCursor);
		
	LeaveCriticalSection();
	
	return iNumBytesFree;
}

//
//
//
unsigned int CircleGetUsedSpace(CircleBuffer* pCBuffer)
{
	return pCBuffer->m_iBufferSize - CircleGetFreeSpace(pCBuffer);
}

//
//
//
void CircleSetComplete(CircleBuffer* pCBuffer)
{
	CP_CHECKOBJECT(pCBuffer);
	
	EnterCriticalSection();
	pCBuffer->m_bComplete = 1;
	SetEvent(pCBuffer->m_evtDataAvailable);
	LeaveCriticalSection();
}

//
//
//
unsigned int CircleIsComplete(CircleBuffer* pCBuffer)
{
	return pCBuffer->m_bComplete;
}

//
//
//
/**************************************************************/
static void *CreateEvent(void)
{
	  osSemaphoreDef(CB);
	  return osSemaphoreCreate(osSemaphore(CB), 1);
}

static void CloseHandle(void *sobj)
{
	 osSemaphoreDelete(sobj);
}


static int WaitForSingleObject (void *sobj,unsigned int delay)
{
	int ret = 0;
  	
	if(osSemaphoreWait(sobj, delay) == osOK)
	{
		ret = 1;
	}
	
	return ret;
}

static void SetEvent(void *sobj)
{
	osSemaphoreRelease(sobj);
}

