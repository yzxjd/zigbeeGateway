#ifndef CIRCLEBUFFER__H
#define CIRCLEBUFFER__H

////////////////////////////////////////////////////////////////////////////////

// Forward reference
struct _CircleBuffer;

////////////////////////////////////////////////////////////////////////////////
// Stream functions

typedef struct _CircleBuffer* CP_HCIRCLEBUFFER;
typedef void (*pfn_CircleBufferUninitialise)(CP_HCIRCLEBUFFER bBuffer);
//
typedef void (*pfn_CircleBufferWrite)(CP_HCIRCLEBUFFER bBuffer, const void* pSourceBuffer, const unsigned int iNumBytes);
typedef unsigned int (*pfn_CircleBufferRead)(CP_HCIRCLEBUFFER bBuffer, void* pDestBuffer, const unsigned int iBytesToRead, unsigned int* pbBytesRead);
typedef unsigned int (*pfn_CircleGetUsedSpace)(CP_HCIRCLEBUFFER bBuffer);
typedef unsigned int (*pfn_CircleGetFreeSpace)(CP_HCIRCLEBUFFER bBuffer);
typedef void (*pfn_CircleFlush)(CP_HCIRCLEBUFFER bBuffer);
typedef void (*pfn_CircleSetComplete)(CP_HCIRCLEBUFFER bBuffer);
typedef unsigned int (*pfn_CircleIsComplete)(CP_HCIRCLEBUFFER bBuffer);
//
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// Circle Buffer
typedef struct _CircleBuffer
{
	// Public functions
	pfn_CircleBufferUninitialise Uninitialise;
	pfn_CircleBufferWrite Write;
	pfn_CircleBufferRead Read;
	pfn_CircleFlush Flush;
	pfn_CircleGetUsedSpace GetUsedSize;
	pfn_CircleGetFreeSpace GetFreeSize;
	pfn_CircleSetComplete SetComplete;
	pfn_CircleIsComplete IsComplete;
	
	// Private variables
	unsigned char* m_pBuffer;
	unsigned int m_iBufferSize;
	unsigned int m_iReadCursor;
	unsigned int m_iWriteCursor;
	void *m_evtDataAvailable;
	unsigned int m_bComplete;
} CircleBuffer;

//
////////////////////////////////////////////////////////////////////////////////
CircleBuffer* CircleBufferCreate(const unsigned int iBufferSize);
void CircleBufferUninitialise(CircleBuffer* pCBuffer);
void CircleBufferWrite(CircleBuffer* pCBuffer, const void* pSourceBuffer, const unsigned int iNumBytes);
unsigned int CircleBufferRead(CircleBuffer* pCBuffer, void* pDestBuffer, const unsigned int iBytesToRead, unsigned int* pbBytesRead);
void CircleFlush(CircleBuffer* pCBuffer);
unsigned int CircleGetFreeSpace(CircleBuffer* pCBuffer);
unsigned int CircleGetUsedSpace(CircleBuffer* pCBuffer);
void CircleSetComplete(CircleBuffer* pCBuffer);
unsigned int CircleIsComplete(CircleBuffer* pCBuffer);

#endif
