/* Standard includes. */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* FreeRTOS+TCP includes. */
//#include "FreeRTOS_IP.h"
//#include "FreeRTOS_Sockets.h"


#include "MQTTFreeRTOS.h"
#include "MQTTClient.h"
#include "cjson.h"
#include "usrApp.h"
#include "cmsis_os.h"
#include "fourG.h"

typedef struct _MQTTMSG
{
	unsigned char cmd;
	int *p;
}MQTTMSG;



int MQTTProPostQueue(MQTTMSG *pMsg);
int MQTTProPendQueue (MQTTMSG *pMsg);
int MQTTProCreateQueue(void);


MQTTClient client;
Network network;
unsigned char sendbuf[256], readbuf[4096];
static MQTTPacket_connectData connectData = MQTTPacket_connectData_initializer;
extern unsigned char serverIp[];
extern unsigned short serverPort;
extern int myID;
static osMessageQId Msgsobj;

char TopicTable[10][30];
MQTTString TopicTableString[10];
int RequestedQoSs[10];
char TopicCnts =0;



void mqttconnect(void)
{
	int rc = 0;
	
	if ((rc = MQTTConnect(&client, &connectData)) != 0)
	{
		printf("Return code from MQTT connect is %d\n", rc);
		return ;
	}
	else
		printf("MQTT Connected\n");
}


void mqttdisconnect(void)
{
	MQTTDisconnect(&client);
}


void mqttsub(void)
{
	int rc = 0;
	
	if ((rc = SubTopicInit(myID,&client)) != 0)
	{
		printf("Return code from MQTT SubTopic is %d\n", rc);
		return ;
	}
	else
		printf("MQTT SubTopic OK\n");

}

int MQTTGetStatus(void)
{
	int ret;
	
	taskENTER_CRITICAL();
	ret = client.issubed;
	taskEXIT_CRITICAL();

	return ret;
}

int MQTTGetConnectStatus(void)
{
	int ret;
	
	ret = client.isconnected;

	return ret;
}


int MQTTPublishOnline(void)
{
	MQTTMessage message;
	unsigned char buf[50];
	int rc = 0;

	message.qos = 2;
	message.retained = 0;
	
	snprintf(buf,sizeof(buf),"{\"MD\":\"%d\",\"MS\":\"%d\"}",myID,0);
	
	message.payload = buf;
	message.payloadlen = strlen(buf);
	if ((rc = MQTTPublish(&client, "lebo/parklot/mstatus", &message)) != 0)
		printf("Return code from MQTT publish is %d\n", rc);
	
	return rc;
}

int MQTTPublishLampStatus(PARK_LAMP_NODE *pLampNode)
{
	MQTTMSG msg;
	int rc = 0;
	
	if(MQTTGetConnectStatus()==0)
		return 1;
	
	memset(&msg,0,sizeof(msg));
	
	msg.cmd = 3;
	msg.p=(int*)pLampNode;
	if(MQTTProPostQueue(&msg))
		return 1;
	
	return rc;
}

int _MQTTPublishLampStatus(PARK_LAMP_NODE *pLampNode)
{
	MQTTMessage message;
	unsigned char buf[100];
	int rc = 0;

	if(MQTTGetConnectStatus()==0)
		return 1;
	
	message.qos = 0;
	message.retained = 0;
	
	snprintf(buf,sizeof(buf),"{\"VER\":\"0\",\"CMD\":\"32\",\"MD\":\"%d\",\"GN\":\"%s\",\"GS\":\"%x\"}",myID,pLampNode->LampTableNode.LampNum,pLampNode->Status);
	
	message.payload = buf;
	message.payloadlen = strlen(buf);
	if ((rc = MQTTPublish(&client, "lebo/g/getstatus", &message)) != 0)
		printf("Return code from MQTT publish is %d\n", rc);
	else
	{
		taskENTER_CRITICAL();
		printf("pub lamp:%s [%x->%x]\r\n",pLampNode->LampTableNode.LampNum,pLampNode->StatusBak,pLampNode->Status);
		pLampNode->StatusBak = pLampNode->Status;
		taskEXIT_CRITICAL();
	}
	
	return rc;
}


int MQTTPublishCarStatus(PARK_STOP_NODE *pStopNode)
{
	MQTTMSG msg;
	int rc = 0;

	if(MQTTGetConnectStatus()==0)
		return 1;
	
	memset(&msg,0,sizeof(msg));
	
	msg.cmd = 1;
	msg.p=(int*)pStopNode;
	if(MQTTProPostQueue(&msg))
		return 1;
	
	return rc;
}


int _MQTTPublishCarStatus(PARK_STOP_NODE *pStopNode)
{
	MQTTMessage message;
	unsigned char buf[100];
	int rc = 0;
	
	if(MQTTGetConnectStatus()==0)
		return 1;
	
	message.qos = 0;
	message.retained = 0;
	
	snprintf(buf,sizeof(buf),"{\"VER\":\"0\",\"CMD\":\"12\",\"MD\":\"%d\",\"CN\":\"%s\",\"CS\":\"%x\",\"BS\":\"%x\"}",myID,pStopNode->ParkTableNode.StopNum,pStopNode->Status,pStopNode->Battery);
	
	message.payload = buf;
	message.payloadlen = strlen(buf);
	
	if ((rc = MQTTPublish(&client, "lebo/parklot/getstatus", &message)) != 0)
	{
		printf("Return code from MQTT publish is %d\n", rc);
	}
	else
	{
		taskENTER_CRITICAL();
		//printf("pub stop:%s [%x->%x]\r\n",pStopNode->ParkTableNode.StopNum,pStopNode->StatusBak,pStopNode->Status);
		pStopNode->StatusBak = pStopNode->Status;
		taskEXIT_CRITICAL();
	}

	return rc;
}


int _MQTTPublishGuideStatus(PARK_GUIDE_NODE *pGuideNode)
{
	MQTTMessage message;
	unsigned char buf[100];
	int rc = 0;
	
	if(MQTTGetConnectStatus()==0)
		return 1;
	
	message.qos = 0;
	message.retained = 0;
	
	snprintf(buf,sizeof(buf),"{\"VER\":\"0\",\"CMD\":\"22\",\"MD\":\"%d\",\"IN\":\"%s\",\"IS\":\"%x\"}",myID,pGuideNode->GuideTableNode.GuideNum,pGuideNode->Status);
	
	message.payload = buf;
	message.payloadlen = strlen(buf);
	if ((rc = MQTTPublish(&client, "lebo/indicator/getstatus", &message)) != 0)
		printf("Return code from MQTT publish is %d\n", rc);
	else
	{
		taskENTER_CRITICAL();
		printf("pub guide:%s [%x->%x]\r\n",pGuideNode->GuideTableNode.GuideNum,pGuideNode->StatusBak,pGuideNode->Status);
		pGuideNode->StatusBak = pGuideNode->Status;
		taskEXIT_CRITICAL();
	}
	
	return rc;
}


int MQTTPublishGuideStatus(PARK_GUIDE_NODE *pGuideNode)
{
	MQTTMSG msg;
	int rc = 0;
	
	if(MQTTGetConnectStatus()==0)
		return 1;
	
	memset(&msg,0,sizeof(msg));
	
	msg.cmd = 2;
	msg.p=(int*)pGuideNode;

	if(MQTTProPostQueue(&msg))
		return 1;
	
	return rc;
}



int _MQTTPublishCarSetAck(unsigned char cmd,unsigned short pid)
{
	MQTTMessage message;
	unsigned char buf[100];
	int rc = 0;
	
	if(MQTTGetConnectStatus()==0)
		return 1;
	
	memset(&message,0,sizeof(message));
	
	message.qos = 0;
	message.retained = 0;
	
	snprintf(buf,sizeof(buf),"{\"VER\":\"0\",\"CMD\":\"%d\",\"MD\":\"%d\",\"PID\":\"%d\"}",cmd,myID,pid);
	
	message.payload = buf;
	message.payloadlen = strlen(buf);
	if ((rc = MQTTPublish(&client, "lebo/parklot/setack", &message)) != 0)
		printf("Return code from MQTT publish is %d\n", rc);
	
	return rc;
}



int _MQTTPublishIndicatorSetAck(unsigned char cmd,unsigned short pid)
{
	MQTTMessage message;
	unsigned char buf[50];
	int rc = 0;

	if(MQTTGetConnectStatus()==0)
		return 1;
	
	message.qos = 0;
	message.retained = 0;
	
	snprintf(buf,sizeof(buf),"{\"VER\":\"0\",\"CMD\":\"%d\",\"MD\":\"%d\",\"PID\":\"%d\"}",cmd,myID,pid);
	
	message.payload = buf;
	message.payloadlen = strlen(buf);
	if ((rc = MQTTPublish(&client, "lebo/indicator/setack", &message)) != 0)
		printf("Return code from MQTT publish is %d\n", rc);

	return rc;
}


int _MQTTPublishLampSetAck(unsigned char cmd ,unsigned short pid)
{
	MQTTMessage message;
	unsigned char buf[50];
	int rc = 0;

	if(MQTTGetConnectStatus()==0)
		return 1;
	
	message.qos = 0;
	message.retained = 0;
	
	snprintf(buf,sizeof(buf),"{\"VER\":\"0\",\"CMD\":\"%d\",\"MD\":\"%d\",\"PID\":\"%d\"}",cmd,myID,pid);
	
	message.payload = buf;
	message.payloadlen = strlen(buf);
	if ((rc = MQTTPublish(&client, "lebo/g/setack", &message)) != 0)
		printf("Return code from MQTT publish is %d\n", rc);

	return rc;
}


int _MQTTPublishCarLockStatus(int cd,unsigned char status)
{
	MQTTMessage message;
	unsigned char buf[100];
	int rc = 0;
	
	if(MQTTGetConnectStatus()==0)
		return 1;
	
	memset(&message,0,sizeof(message));
	
	message.qos = 0;
	message.retained = 0;
	
	snprintf(buf,sizeof(buf),"{\"VER\":\"0\",\"CMD\":\"18\",\"CD\":\"%d\",\"CL\":\"%d\"}",cd,status);
	
	message.payload = buf;
	message.payloadlen = strlen(buf);
	if ((rc = MQTTPublish(&client, "lebo/parklot/lockstatus", &message)) != 0)
		printf("Return code from MQTT publish is %d\n", rc);

	return rc;
}



void MQTTAppInit(void)
{
	taskENTER_CRITICAL();
	NetworkInit(&network);
	MQTTClientInit(&client, &network, 30000, sendbuf, sizeof(sendbuf), readbuf, sizeof(readbuf));
	taskEXIT_CRITICAL();
}



//�˺�����MQTT�����������У���MQTT���������͵���Ϣ���մ���
void messageArrived(MessageData* data)     
{	
	cJSON *root,*item;
	unsigned int cmd=0;
	unsigned int pid,len;
	static unsigned int aid=0,aid1=0,aid2=0;
	
	root = cJSON_Parse((const char *)data->message->payload); 
	if(root==NULL) return ;
	
	item = cJSON_GetObjectItem(root,"VER");
	item = cJSON_GetObjectItem(root,"CMD");
	sscanf(item->valuestring, "%d", &cmd);
	
	switch(cmd)
	{
		case 99:    //��̨��ѯ����״̬Ӧ��
			printf("Online Status\r\n");
			MQTTPublishOnline();   
			break;
		case 17:   //�ƶ˻�ȡ����״̬
			StopLockPro(root);
			break;
			
		case 11:    //�������س�λ
		case 16:
		case 14:   	
			item = cJSON_GetObjectItem(root,"LEN");
			sscanf(item->valuestring, "%d", &len);
			item = cJSON_GetObjectItem(root,"PID");
			sscanf(item->valuestring, "%d", &pid);
			printf("pro pid:%d \r\n",pid);
			if(pid==1)
			{
				item = cJSON_GetObjectItem(root,"AID");     //�ܰ���
				sscanf(item->valuestring, "%d", &aid);
			}
			item = cJSON_GetObjectItem(root,"DATA");
			if((cmd==11)&&(pid==1))   //����ǵ�һ����ɾ�������ļ����������
			{	
				FreeStopNode();    //�ͷ����г�λ�ڵ�
				StopNodeListInit(); //���³�ʼ������
			}
			if(cmd==14)   //ɾ��
			{
				if(StopSettingDelPro(item,len)==0)   
				{
					_MQTTPublishCarSetAck(cmd,pid);    //Ӧ��ְ�
					printf("del ack\r\n");
				}
				else
					break;
			}
			else     // �������޸�
			{
				if(StopSettingPro(item,len)==0)  
				{
					_MQTTPublishCarSetAck(cmd,pid);    //Ӧ��ְ�
					printf("set ack pid:%d \r\n",pid);
				}
				else if(cmd==11)  //����ʧ�ܣ��ָ�����
				{
					ReadCarTable();
					break;
				}
			}
			if(aid==pid)    //���±��ļ�
			{
				WriteCarTable();  
			}
			break;
				
		case 21:   //��������ָʾ��
		case 26:
		case 24:
			item = cJSON_GetObjectItem(root,"LEN");
			sscanf(item->valuestring, "%d", &len);
			item = cJSON_GetObjectItem(root,"PID");
			sscanf(item->valuestring, "%d", &pid);
			printf("pro pid:%d \r\n",pid);
			if(pid==1)
			{
				item = cJSON_GetObjectItem(root,"AID");     //�ܰ���
				sscanf(item->valuestring, "%d", &aid1);
			}
			item = cJSON_GetObjectItem(root,"DATA");
			if((cmd==21)&&(pid==1))  
			{
				FreeGuideNode();
				GuideNodeListInit();
			}
			if(cmd==24)
			{
				if(IndicatorSettingDelPro(item,len)==0)
				{
					_MQTTPublishIndicatorSetAck(cmd,pid);    //Ӧ��ְ�
				}
				else
					break;
			}
			else     // �������޸�
			{
				if(IndicatorSettingPro(item,len)==0)  
				{
					_MQTTPublishIndicatorSetAck(cmd,pid);    //Ӧ��ְ�
					printf("set ack pid:%d \r\n",pid);
				}
				else if(cmd==21)  //����ʧ�ܣ��ָ�����
				{
					ReadGuideTable();
					break;
				}
			}
			if(aid1==pid)    //���±��ļ�
			{
				WriteGuideTable();  
			}
			break;

		case 31:  //��������ָʾ��
		case 36:
		case 34:   
			item = cJSON_GetObjectItem(root,"LEN");
			sscanf(item->valuestring, "%d", &len);
			item = cJSON_GetObjectItem(root,"PID");
			sscanf(item->valuestring, "%d", &pid);
			printf("pro pid:%d \r\n",pid);
			if(pid==1)
			{
				item = cJSON_GetObjectItem(root,"AID");     //�ܰ���
				sscanf(item->valuestring, "%d", &aid2);
			}
			item = cJSON_GetObjectItem(root,"DATA");
			if((cmd==31)&&(pid==1))  
			{
				FreeLampNode();
				LampNodeListInit();
			}
			if(cmd==34)
			{
				if(LampSettingDelPro(item,len)==0)
				{
					_MQTTPublishLampSetAck(cmd,pid);    //Ӧ��ְ�
					printf("del ack lamp\r\n",pid);
				}
				else
					break;
			}
			else     // �������޸�
			{
				if(LampSettingPro(item,len)==0)  
				{
					_MQTTPublishLampSetAck(cmd,pid);    //Ӧ��ְ�
					printf("set ack pid:%d \r\n",pid);
				}
				else if(cmd==31)  //����ʧ�ܣ��ָ�����
				{
					ReadLampTable();
					break;
				}
			}
			if(aid2==pid)    //���±��ļ�
			{
				WriteLampTable();  
			}
			break;
			
		default:
			break;
			
	}
	cJSON_Delete(root); 
	
	printf("\r\nMessage OK![%d]\r\n",data->message->payloadlen);
	
	//printf("Message arrived on topic %.*s: %.*s\r\n", data->topicName->lenstring.len, data->topicName->lenstring.data,data->message->payloadlen, data->message->payload);
}


int  SubTopicInit(int MyID,MQTTClient *pClient)
{
	int i,rc=0;
		
	TopicCnts=0;
	
	sprintf(TopicTable[TopicCnts++],"lebo/parklot/set/%d",MyID);
	sprintf(TopicTable[TopicCnts++],"lebo/parklot/add/%d",MyID);
	sprintf(TopicTable[TopicCnts++],"lebo/parklot/del/%d",MyID);
	sprintf(TopicTable[TopicCnts++],"lebo/parklot/lock/%d",MyID);
	sprintf(TopicTable[TopicCnts++],"lebo/parklot/getmstatus/%d",MyID);   //��̨��ѯ����״̬
	
	for(i=0;i<TopicCnts;i++)
	{
		TopicTableString[i].cstring = TopicTable[i];
		TopicTableString[i].lenstring.data = TopicTable[i];
		TopicTableString[i].lenstring.len = strlen(TopicTable[i]);
		RequestedQoSs[i]=1;
	}
	if(MQTTSubscribes(pClient)!=0)
	{
		return 1;
	}
	
	printf("MyID:%x\r\n",MyID);
	
	return rc;
}


void MQTTConnectServer(void)
{
	int rc = 0,len;
	static unsigned char WillMsg[30];
	static unsigned char ClientID[20];
	
	while(1)
	{
		connectData.MQTTVersion = 3;
		sprintf(ClientID,"parklot/%d",myID);
		connectData.clientID.cstring = ClientID;
		connectData.willFlag =1;
		connectData.cleansession=1;
		connectData.will.qos =1;
		connectData.will.retained =0;
		connectData.will.topicName.lenstring.data = "lebo/parklot/mstatus";
		connectData.will.topicName.lenstring.len = strlen(connectData.will.topicName.lenstring.data);
		len =sprintf(WillMsg,"{\"MD\":\"%d\",\"MS\":\"%d\"}",myID,1);
		connectData.will.message.lenstring.data =WillMsg;
		connectData.will.message.lenstring.len = strlen(connectData.will.message.lenstring.data);
		
		client.isconnected = 0;
		client.issubed = 0;
		client.ping_outstanding =0;
		
		CycleBufferInit(0);
		FourGAppInit();
		
		rc = MQTTConnect(&client, &connectData);
		if ((rc!=0)&&(rc!=0xff))      //����MQTT������
		{
			printf("Return code from MQTT connect is %d\n", rc);
			FourGSocketClose();
			continue ;
		}
		else    //���ӳɹ�
		{
			printf("MQTT Connected\n");
			MQTTPublishOnline();   //���ߺ�̨����
			if ((rc = SubTopicInit(myID,&client)) != 0)
			{
				printf("Return code from MQTT SubTopic is %d\n", rc);
				FourGSocketClose();
				continue ;
			}
			else
			{
				printf("MQTT SubTopic OK\n");
				KeepScanInit();      //�������ߺ��ƶ��Ǳ߻���������Ϊ���ߣ������������ӵ�ʱ��Ҫ���еĶ������·���һ��״̬
				break;
			}
		}
	}
}



void MQTTTask(void const * argument)    // MQTT ���ӹ�������:���ӣ����ͣ�����
{
	Timer timer;
	MQTTMSG mqttmsg;
	
	MQTTProCreateQueue();
	PubMutexInit();
	StopListMutexInit();
	GuideListMutexInit();
 	LampListMutexInit();
	
	ReadServerIpPort(serverIp,&serverPort);    //��ȡ������IP��PORT
	ReadMd(&myID);   //��ȡ����ZIGBEE ����ID
	
	MQTTAppInit();	 // MQTT ��ʼ��һ���ͻ���
	usrTaskInit();
	TimerInit(&timer);
	while(1)
	{
		#ifdef DOG
		DogClear();
		#endif
		if(MQTTGetConnectStatus()==0)    //����
		{
			MQTTConnectServer();
			client.ping_outstanding=0;
			TimerCountdownMS(&client.ping_timer,10);    //Ҫ��֤����֮����һ��keep
		}
		if(MQTTProPendQueue(&mqttmsg))      //������������ָʾ�ķ���ָ��
		{
			switch(mqttmsg.cmd)
			{
				case 0x01:
					_MQTTPublishCarStatus((PARK_STOP_NODE *)(mqttmsg.p));
					break;
				case 0x02:
					_MQTTPublishGuideStatus((PARK_GUIDE_NODE *)(mqttmsg.p));
					break;
				case 0x03:
					_MQTTPublishLampStatus((PARK_LAMP_NODE *)(mqttmsg.p));
					break;
				default:
					break;
			}
		}
		cycle(&client, &timer);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////

int MQTTProCreateQueue(void)
{
	int ret;
	
	osMessageQDef(MQTTPRO,20,MQTTMSG);
	Msgsobj = osMessageCreate(osMessageQ(MQTTPRO),0);		
	ret = (Msgsobj != NULL);
	if(Msgsobj==NULL)
	{
		printf("create MQTTPro queue fail!\r\n");
	}
	return ret;
}


void MQTTProFlushQueue(void)
{
	xQueueReset(Msgsobj);
}


int MQTTProPendQueue (MQTTMSG *pMsg)
{
	int ret = 0;
	
	if (xQueueReceive(Msgsobj,pMsg, 10) == pdTRUE)    // 1s
	{
		ret = 1;
	}
	
	return ret;
}



int MQTTProPostQueue(MQTTMSG *pMsg)
{	
	if(Msgsobj==NULL)  return 1;
	
	if(osMessagePut (Msgsobj,(uint32_t)pMsg,0))
	{
		//printf("����MQTT��Ϣʧ��!\r\n");
		return 1;
	}
	return 0;
}

/*-----------------------------------------------------------*/


