/**
 * @file	httpUtil.c
 * @brief	HTTP Server Utilities	
 * @version 1.0
 * @date	2014/07/15
 * @par Revision
 *			2014/07/15 - 1.0 Release
 * @author	
 * \n\n @par Copyright (C) 1998 - 2014 WIZnet. All rights reserved.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "httpUtil.h"
#include "net.h"


static cgi_callback HttpPro;

void HttpSetCallBack(cgi_callback HttpProcess)
{
	HttpPro = HttpProcess;
}


uint8_t predefined_get_cgi_processor(uint8_t * uri_name, uint8_t * buf, uint16_t * len)
{
	NET_CONFIG *pNetConfig = GetNetConfigAddr();
	
	if(strcmp((const char *)uri_name,"w5500.js")==0)
	{
		sprintf((char *)buf,"settingsCallback({\"ver\":\"%d\",\
						\"mac\":\"%02X:%02X:%02X:%02X:%02X:%02X\",\
						\"ip\":\"%d.%d.%d.%d\",\
						\"gw\":\"%d.%d.%d.%d\",\
						\"sub\":\"%d.%d.%d.%d\",\
						});",pNetConfig->canaddr,
						pNetConfig->mac[0],pNetConfig->mac[1],pNetConfig->mac[2],pNetConfig->mac[3],pNetConfig->mac[4],pNetConfig->mac[5],
						pNetConfig->lip[0],pNetConfig->lip[1],pNetConfig->lip[2],pNetConfig->lip[3],
						pNetConfig->gw[0],pNetConfig->gw[1],pNetConfig->gw[2],pNetConfig->gw[3],
						pNetConfig->sub[0],pNetConfig->sub[1],pNetConfig->sub[2],pNetConfig->sub[3]
						);
		*len=strlen((char *)buf);
		
		return 1;
	}
	return 0;
}


uint8_t http_get_cgi_handler(uint8_t * uri_name, uint8_t * buf, uint32_t * file_len)
{
	uint8_t ret = HTTP_OK;
	uint16_t len = 0;
	
	if(predefined_get_cgi_processor(uri_name, buf, &len))
	{
		;
	}
	else if(strcmp((const char *)uri_name, "example.cgi") == 0)
	{
		// To do
		;
	}
	else
	{
		// CGI file not found
		ret = HTTP_FAILED;
	}

	if(ret)	*file_len = len;
	return ret;
}

static unsigned char  ConvertToBCD(unsigned char data)
{
	data = ((data / 10) << 4) + (data % 10);
	return data;
}

uint8_t predefined_set_cgi_processor(uint8_t * uri_name, uint8_t * uri, uint8_t * buf, uint16_t * len)
{
	unsigned char *param;
	NET_CONFIG *pNetConfig = GetNetConfigAddr();
	unsigned char para=1;
	
	if(strcmp((const char *)uri_name,"config.cgi")==0)							  	
	{
		//printf("uri:\r\n%s\r\n",uri);
		
		param = get_http_param_value((char *)uri,"ip");		/*��ȡ�޸ĺ��IP��ַ*/
		if(param)
		{
			inet_addr_((unsigned char*)param, pNetConfig->lip);	
		}
		param = get_http_param_value((char *)uri,"gw");		/*��ȡ�޸ĺ������*/
		if(param)
		{
			inet_addr_((unsigned char*)param, pNetConfig->gw);	
		}
		param = get_http_param_value((char *)uri,"sub");	/*��ȡ�޸ĺ����������*/
		if(param)
		{
			inet_addr_((unsigned char*)param, pNetConfig->sub);		
		}
		param = get_http_param_value((char *)uri,"ver");		/*��ȡ�޸ĺ������*/
		if(param)
		{
			inet_addr_((unsigned char*)param, &pNetConfig->canaddr);	
		}
		param = get_http_param_value((char *)uri,"save");
		if(param)
		{
			para =1;
		}
		param = get_http_param_value((char *)uri,"reset");
		if(param)
		{
			pNetConfig->lip[0]=192;
			pNetConfig->lip[1]=168;
			pNetConfig->lip[2]=1;
			pNetConfig->lip[3]=204;
			para =2;
		}
		if(HttpPro!=NULL)
			 (*HttpPro)(para);
		
		sprintf((char *)buf,"<html><head><title>iWeb - Configuration</title><script language=javascript>j=%d;function func(){document.getElementById('delay').innerText=' '+j + ' ';j--;setTimeout('func()',1000);if(j==0)location.href='http://%d.%d.%d.%d/';}</script></head><body onload='func()'>please wait for a while, the module will boot in<span style='color:red;' id='delay'></span> seconds.</body></html>",5,pNetConfig->lip[0],pNetConfig->lip[1],pNetConfig->lip[2],pNetConfig->lip[3]);
		
		*len=strlen((char *)buf);
		
		return 1;
	}
	return 0;
}


uint8_t http_post_cgi_handler(uint8_t * uri_name, st_http_request * p_http_request, uint8_t * buf, uint32_t * file_len)
{
	uint8_t ret = HTTP_OK;
	uint16_t len = 0;
	uint8_t val = 0;
	
	if(predefined_set_cgi_processor(uri_name, p_http_request->URI, buf, &len))
	{
		ret=HTTP_RESET;
	}
	else if(strcmp((const char *)uri_name, "example.cgi") == 0)
	{
		// To do
		val = 1;
		len = sprintf((char *)buf, "%d", val);
	}
	else
	{
		// CGI file not found
		ret = HTTP_FAILED;
	}

	if(ret)	*file_len = len;
	return ret;
}
