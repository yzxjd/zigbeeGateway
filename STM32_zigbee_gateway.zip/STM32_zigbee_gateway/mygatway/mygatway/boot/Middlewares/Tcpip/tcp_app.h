#ifndef __TCP_APP_H
#define __TCP_APP_H

typedef int (*NET_PRO_CB)(unsigned char ,unsigned char*,unsigned short);

unsigned int do_mqtt_client(unsigned char sn,unsigned char* destip, unsigned short destport);
void mqtt_publish(unsigned char *payload,unsigned short payloadlen);
unsigned int mqtt_ack_process(unsigned char sn,unsigned short timeout);




#endif 

