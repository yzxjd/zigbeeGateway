#include "webpge.h"
#include "http_server.h"
#include "net.h"
#include "http_app.h"
#include "utility.h"

extern void Reboot(void);

static char tx_buf[2048];
static char rx_buf[2048];

static SOCKET ch;	
static HTTP_TRANS HttpTrans;

/**
*@brief		��ʼ��http
*@param		��
*@return	��
*/
void https_init(SOCKET Socket,HTTP_TRANS *pHttpTrans)
{
	ch = Socket;
	memcpy((void *)&HttpTrans,pHttpTrans,sizeof(HTTP_TRANS));
}


/**
*@brief		���http��Ӧ
*@param		��
*@return	��
*/
void do_https(void)
{											
	unsigned short len;
	st_http_request *http_request;			
	
	switch(getSn_SR(ch))																		/*��ȡsocket״̬*/
	{
		case SOCK_INIT:																				/*socket���ڳ�ʼ��״̬*/
			listen(ch);
			break;
		
		case SOCK_LISTEN:																			/*socket���ڼ���״̬*/
			break;
		
		case SOCK_ESTABLISHED:				 /*socket��������״̬*/	
			if(getSn_IR(ch) & Sn_IR_CON)
			{
				setSn_IR(ch, Sn_IR_CON);													/*����жϱ�־λ*/
			}
			if ((len = getSn_RX_RSR(ch)) > 0)		
			{
				memset(rx_buf,0x00,MAX_URI_SIZE);
				http_request = (st_http_request*)rx_buf;		
				len = recv(ch, (unsigned char*)http_request, len); 				/*����http����*/
				*(((unsigned char*)http_request)+len) = 0;
				proc_http(ch, (unsigned char*)http_request);							/*����http���󲢷���http��Ӧ*/
				disconnect(ch);
			}
			break;
			
		case SOCK_CLOSE_WAIT:   															/*socket���ڵȴ��ر�״̬*/
			if ((len = getSn_RX_RSR(ch)) > 0)
			{
				len = recv(ch, (unsigned char*)http_request, len);				/*����http����*/      
				*(((unsigned char*)http_request)+len) = 0;
				proc_http(ch, (unsigned char*)http_request);							/*����http���󲢷���http��Ӧ*/
			}
			disconnect(ch);
			break;
			
		case SOCK_CLOSED:                   									/*socket���ڹر�״̬*/
			socket(ch, Sn_MR_TCP, 80, 0x00);   									/*��socket*/
			break;
		
		default:
			break;
	}
}

/**
*@brief		����http�����Ĳ�����http��Ӧ
*@param		s: http������socket
*@param		buf��������������
*@return	��
*/
void proc_http(SOCKET s, unsigned char * buf)
{
	char* name; 											
	char req_name[32]={0x00,};															/*����һ��http��Ӧ���ĵ�ָ��*/
	unsigned int file_len=0;																/*����http������ͷ�Ľṹ��ָ��*/
	unsigned short send_len=0;
	unsigned char* http_response;
	st_http_request *http_request;
	
	memset(tx_buf,0x00,MAX_URI_SIZE);
	http_response = (unsigned char*)rx_buf;
	http_request = (st_http_request*)tx_buf;
	parse_http_request(http_request, buf);    							/*����http������ͷ*/

	switch (http_request->METHOD)		
  	{
		case METHOD_ERR :																			/*������ͷ����*/
			memcpy(http_response, ERROR_REQUEST_PAGE, sizeof(ERROR_REQUEST_PAGE));
			send(s, (unsigned char *)http_response, strlen((char const*)http_response));
			break;
		
		case METHOD_HEAD:																			/*HEAD����ʽ*/
			
		case METHOD_GET:																			/*GET����ʽ*/
			name = http_request->URI;
			if(strcmp(name,"/index.htm")==0 || strcmp(name,"/")==0 || (strcmp(name,"/index.html")==0))
			{
				file_len = strlen(INDEX_HTML);
				make_http_response_head((unsigned char*)http_response, PTYPE_HTML,file_len);
				send(s,http_response,strlen((char const*)http_response));
				send_len=0;
				while(file_len)
				{
					if(file_len>1024)
					{
						if(getSn_SR(s)!=SOCK_ESTABLISHED)
						{
							return;
						}
						send(s, (unsigned char *)INDEX_HTML+send_len, 1024);
						send_len+=1024;
						file_len-=1024;
					}
					else
					{
						send(s, (unsigned char *)INDEX_HTML+send_len, file_len);
						send_len+=file_len;
						file_len-=file_len;
					} 
				}
			}
			else if(strcmp(name,"/w5500.js")==0)
			{
				memset(tx_buf,0,MAX_URI_SIZE);
				make_basic_config_setting_callback(tx_buf);
				sprintf((char *)http_response,"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length:%d\r\n\r\n%s",strlen(tx_buf),tx_buf);
				send(s, (unsigned char *)http_response, strlen((char const*)http_response));
			}
			break;
			
		case METHOD_POST:																			/*POST����*/
			mid(http_request->URI, "/", " ", req_name);					/*��ȡ��������ļ���*/
			if(strcmp(req_name,"config.cgi")==0)							  	
			{
				cgi_ipconfig(http_request);									/*��������Ϣд����Ƭ��eeprom*/
				make_cgi_response(5,(char*)HttpTrans.pNetConfig->lip,tx_buf);	/*������Ӧ���ı�����*/        
				sprintf((char *)http_response,"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length:%d\r\n\r\n%s",strlen(tx_buf),tx_buf);
																													/*����http��Ӧ*/
				send(s, (unsigned char *)http_response, strlen((char *)http_response));		
				disconnect(s);																		/*�Ͽ�socket����*/				
				Reboot();																/*������־λ��1*/
				return;
			}
			break;
			
		default :
			break;
	}
}

/**
*@brief		��������������Ϣ���õ�json_callback
*@param		��
*@return	��
*/
static void make_basic_config_setting_callback(char* buf)
{	
	sprintf(buf,"settingsCallback({\"ver\":\"%d\",\
                \"mac\":\"%02X:%02X:%02X:%02X:%02X:%02X\",\
                \"ip\":\"%d.%d.%d.%d\",\
                \"gw\":\"%d.%d.%d.%d\",\
                \"sub\":\"%d.%d.%d.%d\",\
				\"dis\":\"%s\",\
                });",HttpTrans.pNetConfig->canaddr,
                HttpTrans.pNetConfig->mac[0],HttpTrans.pNetConfig->mac[1],HttpTrans.pNetConfig->mac[2],HttpTrans.pNetConfig->mac[3],HttpTrans.pNetConfig->mac[4],HttpTrans.pNetConfig->mac[5],
                HttpTrans.pNetConfig->lip[0],HttpTrans.pNetConfig->lip[1],HttpTrans.pNetConfig->lip[2],HttpTrans.pNetConfig->lip[3],
                HttpTrans.pNetConfig->gw[0],HttpTrans.pNetConfig->gw[1],HttpTrans.pNetConfig->gw[2],HttpTrans.pNetConfig->gw[3],
                HttpTrans.pNetConfig->sub[0],HttpTrans.pNetConfig->sub[1],HttpTrans.pNetConfig->sub[2],HttpTrans.pNetConfig->sub[3],HttpTrans.pFixedInfoBuf
                );
}

/**
*@brief		��������Ϣд����Ƭ��
*@param		http_request������һ��http����Ľṹ��ָ��
*@return	��
*/
static void cgi_ipconfig(st_http_request *http_request)
{ 
	unsigned char * param;
	param = get_http_param_value(http_request->URI,"ip");		/*��ȡ�޸ĺ��IP��ַ*/
	if(param)
	{
		inet_addr_((unsigned char*)param, HttpTrans.pNetConfig->lip);	
	}
	param = get_http_param_value(http_request->URI,"gw");		/*��ȡ�޸ĺ������*/
	if(param)
	{
		inet_addr_((unsigned char*)param, HttpTrans.pNetConfig->gw);	
	}
	param = get_http_param_value(http_request->URI,"sub");	/*��ȡ�޸ĺ����������*/
	if(param)
	{
		inet_addr_((unsigned char*)param, HttpTrans.pNetConfig->sub);		
	}
	param = get_http_param_value(http_request->URI,"ver");		/*��ȡ�޸ĺ������*/
	if(param)
	{
		inet_addr_((unsigned char*)param, &HttpTrans.pNetConfig->canaddr);	
	}
	param = get_http_param_value(http_request->URI,"dis");
	if(param)
	{
		strcpy((char *)HttpTrans.pFixedInfoBuf,(const char *)param);
	}
	if(HttpTrans.pCgiCallBack!=NULL)
		 (*HttpTrans.pCgiCallBack)(&HttpTrans);
}

/**
*@brief		ִ��http��Ӧ
*@param		��  
*@return	��
*/
static void make_cgi_response(unsigned short delay, char* url,char* cgi_response_buf)
{
	sprintf(cgi_response_buf,"<html><head><title>iWeb - Configuration</title><script language=javascript>j=%d;function func(){document.getElementById('delay').innerText=' '+j + ' ';j--;setTimeout('func()',1000);if(j==0)location.href='http://%d.%d.%d.%d/';}</script></head><body onload='func()'>please wait for a while, the module will boot in<span style='color:red;' id='delay'></span> seconds.</body></html>",delay,url[0],url[1],url[2],url[3]);
}


