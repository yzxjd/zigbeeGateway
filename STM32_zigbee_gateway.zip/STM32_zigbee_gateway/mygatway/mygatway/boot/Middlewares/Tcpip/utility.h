#ifndef _UTILITY_H
#define _UTILITY_H

unsigned short atoi16(char* str,unsigned short base); 			/* Convert a string to integer number */
unsigned int atoi32(char* str,unsigned short base); 			/* Convert a string to integer number */
void itoa(unsigned short n,unsigned char* str, unsigned char len);
int validatoi(char* str, int base, int* ret); 		/* Verify character string and Convert it to (hexa-)decimal. */
char c2d(unsigned char c); 					/* Convert a character to HEX */

unsigned short swaps(unsigned short i);
unsigned int swapl(unsigned int l);

void replacetochar(char * str, char oldchar, char newchar);

void mid(char* src, char* s1, char* s2, char* sub);
void inet_addr_(unsigned char* addr,unsigned char *ip);


char* inet_ntoa(unsigned int addr);			/* Convert 32bit Address into Dotted Decimal Format */
char* inet_ntoa_pad(unsigned int addr);

unsigned int inet_addr(unsigned char* addr);		/* Converts a string containing an (Ipv4) Internet Protocol decimal dotted address into a 32bit address */

char verify_ip_address(char* src, unsigned char * ip);/* Verify dotted notation IP address string */

unsigned short htons( unsigned short hostshort);	/* htons function converts a unsigned short from host to TCP/IP network byte order (which is big-endian).*/

unsigned int htonl(unsigned int hostlong);		/* htonl function converts a unsigned int from host to TCP/IP network byte order (which is big-endian). */

unsigned int ntohs(unsigned short netshort);		/* ntohs function converts a unsigned short from TCP/IP network byte order to host byte order (which is little-endian on Intel processors). */

unsigned int ntohl(unsigned int netlong);		/* ntohl function converts a unsigned int from TCP/IP network order to host byte order (which is little-endian on Intel processors). */

unsigned short checksum(unsigned char * src, unsigned int len);		/* Calculate checksum of a stream */

unsigned char check_dest_in_local(unsigned int destip);			/* Check Destination in local or remote */


#endif
