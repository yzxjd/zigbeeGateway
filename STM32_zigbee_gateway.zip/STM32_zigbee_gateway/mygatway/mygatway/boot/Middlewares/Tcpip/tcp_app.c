#include "net.h"
#include "tcp_app.h"
#include "socket.h"
#include "stdio.h"
#include "w5500.h"
#include "cmsis_os.h"
#include <string.h>
#include "MQTTPacket.h"

void mqtt_subscribe(void);

static unsigned short len = 0;	
static uint8_t buf[2048];
static MQTTString topicString = MQTTString_initializer;
static NET_PRO_CB pTcpProCb;
unsigned int packid=1;


void TcpsSetCallBack(NET_PRO_CB pTcpProCbs)
{
	pTcpProCb = pTcpProCbs;
}

int transport_open(void)
{
	return 0;
}

int transport_close()
{
	return 0;
}

void transport_sendPacketBuffer(uint8_t* buf, int32_t buflen)
{
	send(SOCK_TCPC1,buf,buflen);	
}


void mqtt_connect(void)
{
	MQTTPacket_connectData data = MQTTPacket_connectData_initializer;
	
	printf("MQTT Connect...\r\n");
	transport_open();	
	
	data.clientID.cstring = "gateway test";
	data.keepAliveInterval = 20;
	data.cleansession = 1;
	data.username.cstring = "admin";
	data.password.cstring = "password";    
	
	len = MQTTSerialize_connect(buf, sizeof(buf), &data);	
	transport_sendPacketBuffer(buf, len); //�������ݰ�	
	mqtt_ack_process(SOCK_TCPC1,50);
}


void mqtt_subscribe(void)
{
	unsigned short msgid = 1;
	int req_qos = 0;
	
	topicString.cstring = "status";
	len = MQTTSerialize_subscribe(buf, sizeof(buf), 0, msgid, 1, &topicString, &req_qos);
	transport_sendPacketBuffer(buf, len);	//�������ݰ�	
	mqtt_ack_process(SOCK_TCPC1,50);
}


void mqtt_publish(unsigned char *payload,unsigned short payloadlen)
{
	topicString.cstring = "1";       //ֱ�ӷ��͵�����
	len = MQTTSerialize_publish(buf, sizeof(buf), 0, 1, 0, packid, topicString, (unsigned char*)payload, payloadlen);
	transport_sendPacketBuffer(buf, len);	//�������ݰ�
	mqtt_ack_process(SOCK_TCPC1,50);
}


void mqtt_heartbeat(void)
{
	len = MQTTSerialize_pingreq(buf,sizeof(buf));
	transport_sendPacketBuffer(buf,len);
	//mqtt_ack_process(SOCK_TCPC1,50);
}


uint32_t mqtt_ack_process(unsigned char sn,unsigned short timeout)
{
	uint32_t size,cnt=0,ret=0; 
	unsigned char strbuf[100];
	unsigned char buf[100];
	unsigned char dat;

	memset(buf,0,sizeof(buf));
	memset(strbuf,0,sizeof(strbuf));
	while(1)
	{
		osDelay(10);
		if(CycleBufferPop(0,&dat)==0)
		{
			buf[cnt++]=dat;
			MQTTFormat_toClientString(strbuf,sizeof(strbuf),buf,cnt);
			printf("%s\r\n",strbuf);
			break;
		}
		else if(cnt++>timeout)
		{
			 break;
		}
	}
	return ret;
}


uint32_t do_mqtt_client(uint8_t sn,uint8_t* destip, uint16_t destport)
{
	uint32_t ret; 
	uint16_t any_port = 50000;
	unsigned char ir;
	uint32_t size; 
	unsigned char strbuf[100];
	
	switch(getSn_SR(sn))
	{
	  	case SOCK_ESTABLISHED :
			ir =getSn_IR(sn);
			if(ir & Sn_IR_CON)
			{
				setSn_IR(sn,Sn_IR_CON);
				mqtt_connect();    //����MQTT������
				mqtt_subscribe(); //��������
			}
			if(ir & Sn_IR_TIMEOUT)
			{
				close(sn);
				setSn_IR(sn,Sn_IR_TIMEOUT);
			}
			if((size = getSn_RX_RSR(sn)) > 0)  
			{
				if(size > 2048) size = 2048;
				ret = recv(sn, buf, size);
				
				if(ret <= 0) return ret;
				MQTTFormat_toClientString(strbuf,sizeof(strbuf),buf,size);
				printf("%s\r\n",strbuf);
				break;
			}
		  break;
		  
		  case SOCK_CLOSE_WAIT :
		     if((ret=disconnect(sn)) != SOCK_OK) return ret;
		     printf("%d:Socket Closed\r\n", sn);
		     break;

		  case SOCK_INIT :
			 //printf("%d:Try to connect to the %d.%d.%d.%d : %d\r\n", sn, destip[0], destip[1], destip[2], destip[3], destport);
			 if( (ret = connect(sn, destip, destport)) != SOCK_OK) return ret;	//	Try to TCP connect to the TCP server (destination)
		     break;
		  
		  case SOCK_CLOSED:
			  close(sn);
			  //if((ret=socket(sn, Sn_MR_TCP, any_port++, 0x00)) != sn) return ret; // TCP socket open with 'any_port' port number
			  if((ret=socket(sn, Sn_MR_TCP, any_port++, 0x00)) != Sn_MR_ND) return ret;
		     break;
		  default:
		     break;
	}
	return 1;
}




