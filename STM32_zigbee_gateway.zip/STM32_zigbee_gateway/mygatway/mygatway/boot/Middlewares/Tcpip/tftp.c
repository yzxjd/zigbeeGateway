#include <string.h>
#include "feeprom.h"
#include "tftp.h"
#include "w5500.h"
#include "socket.h"
#include "stdio.h"
#include "stdint.h"
#include "updata.h"
#include "des.h"
#include "crc32.h"
/* Global Variable ----------------------------------------------*/
static int		g_tftp_socket = -1;

static uint8_t g_filename[FILE_NAME_SIZE+1];

static uint32_t g_server_ip = 0;
static uint16_t g_server_port = 0;
static uint16_t g_local_port = 0;

static uint32_t g_tftp_state = STATE_NONE;
static uint16_t g_block_num = 0;

static uint32_t g_timeout = 0xffff;
static uint32_t g_resend_flag = 0;
static uint32_t tftp_time_cnt = 0;


static uint8_t *g_tftp_rcv_buf = NULL;

unsigned int total_len;
unsigned int crc32;
unsigned int lCrc32=0;
char upflag='A';
static HEAD newhead;
extern void Reboot(void);

static TFTP_OPTION default_tftp_opt;//=
//{
//	.code = (uint8_t *)"blksize",
//	.value = (uint8_t *)"2048",
//};

uint8_t g_progress_state = TFTP_PROGRESS;

/**
*@brief	 	16λ�ַ���8λ��8λת��
*@param		i:Ҫת��������
*@return	ת���������
*/
unsigned short swaps(unsigned short i)
{
  unsigned short ret=0;
  ret = (i & 0xFF) << 8;
  ret |= ((i >> 8)& 0xFF);
  return ret;	
}
/**
*@brief	 	32λ�ַ��ߵ�λ�任
*@param		i:Ҫת��������
*@return	ת���������
*/
unsigned int swapl(unsigned int l)
{
  unsigned int ret=0;
  ret = (l & 0xFF) << 24;
  ret |= ((l >> 8) & 0xFF) << 16;
  ret |= ((l >> 16) & 0xFF) << 8;
  ret |= ((l >> 24) & 0xFF);
  return ret;
}

/**
@brief	htons function converts a unsigned short from host to TCP/IP network byte order (which is big-endian).
@return 	the value in TCP/IP network byte order
*/ 
unsigned short htons( 
	unsigned short hostshort	/**< A 16-bit number in host byte order.  */
	)
{
#if ( SYSTEM_ENDIAN == _ENDIAN_LITTLE_ )
	return swaps(hostshort);
#else
	return hostshort;
#endif		
}


/**
@brief	htonl function converts a unsigned long from host to TCP/IP network byte order (which is big-endian).
@return 	the value in TCP/IP network byte order
*/ 
unsigned long htonl(
	unsigned long hostlong		/**< hostshort  - A 32-bit number in host byte order.  */
	)
{
#if ( SYSTEM_ENDIAN == _ENDIAN_LITTLE_ )
	return swapl(hostlong);
#else
	return hostlong;
#endif	
}


/**
@brief	ntohs function converts a unsigned short from TCP/IP network byte order to host byte order (which is little-endian on Intel processors).
@return 	a 16-bit number in host byte order
*/ 
unsigned long ntohs
	(
	unsigned short netshort	/**< netshort - network odering 16bit value */
	)
{
#if ( SYSTEM_ENDIAN == _ENDIAN_LITTLE_ )	
	return htons(netshort);
#else
	return netshort;
#endif		
}


/**
@brief	converts a unsigned long from TCP/IP network byte order to host byte order (which is little-endian on Intel processors).
@return 	a 16-bit number in host byte order
*/ 
unsigned long ntohl(unsigned long netlong)
{
#if ( SYSTEM_ENDIAN == _ENDIAN_LITTLE_ )
	return htonl(netlong);
#else
	return netlong;
#endif		
}

/* static function define ---------------------------------------*/
static void set_filename(uint8_t *file, uint32_t file_size)
{
	memcpy(g_filename, file, file_size);
}

void set_server_ip(uint32_t ipaddr)
{
	g_server_ip = ipaddr;
}

uint32_t get_server_ip()
{
	return g_server_ip;
}

void set_server_port(uint16_t port)
{
	g_server_port = port;
}

uint16_t get_server_port()
{
	return g_server_port;
}

void set_local_port(uint16_t port)
{
	g_local_port = port;
}

uint16_t get_local_port()
{
	return g_local_port;
}

uint16_t genernate_port()
{
	/* TODO */
	return 0;
}

void set_tftp_state(uint32_t state)
{
	g_tftp_state = state;
}

uint32_t get_tftp_state()
{
	return g_tftp_state;
}

void set_tftp_timeout(uint32_t timeout)
{
	g_timeout = timeout;
}

uint32_t get_tftp_timeout()
{
	return g_timeout;
}

void set_block_number(uint16_t block_number)
{
	g_block_num = block_number;
}

uint16_t get_block_number()
{
	return g_block_num;
}

int open_tftp_socket(uint8_t sock)								// ��һ·Socket����TFTPͨ��
{
	uint8_t sd, sck_state;
	sd = socket(sock, Sn_MR_UDP, TFTP_TEMP_PORT,0);
	if(sd != sock) 
	{
		printf("[%s] socket error\r\n", __func__);
		return -1;
	}
	do
	{
		sck_state=getSn_SR(sd);
	} 	
	while(sck_state != SOCK_UDP);
	return sd;
}

int send_udp_packet(int socket, uint8_t *packet, uint32_t len, uint32_t ip, uint16_t port)
{
	int snd_len;
	ip = htonl(ip);
	snd_len = sendto(socket, packet, len, (uint8_t *)&ip, port);
	if(snd_len != len) 
	{
		//DBG_PRINT(ERROR_DBG, "[%s] sendto error\r\n", __func__);
		return -1;
	}
	return snd_len;
}

uint16_t recv_udp_packet(int socket, uint8_t *packet, uint32_t len, uint32_t *ip, uint16_t *port)
{
//	int ret;
	uint8_t sck_state;
	uint16_t recv_len;
	/* Receive Packet Process */
	sck_state=getSn_SR(socket);
//	printf(" %2x\r\n",sck_state);
	if(sck_state == SOCK_UDP) 
	{
		recv_len=getSn_RX_RSR(socket);
		if(recv_len) 
		{
			recv_len = recvfrom(socket, packet, len, (uint8_t *)ip, port);
			if((int32_t)recv_len < 0) 
			{
				printf("[%s] recvfrom error\r\n", __func__);
				return 0;
			}
			*ip = ntohl(*ip);
			return recv_len;
		}
	}
	return 0;
}

void close_tftp_socket(int socket)
{
	close(socket);
}


void init_tftp(void)
{
	g_filename[0] = 0;
	set_server_ip(0);
	set_server_port(0);
	set_local_port(0);
	set_tftp_state(STATE_NONE);
	set_block_number(0);

	/* timeout flag */
	g_resend_flag = 0;
	//tftp_retry_cnt = tftp_time_cnt = 0;

	g_progress_state = TFTP_PROGRESS;
}

void tftp_cancel_timeout(void)
{
	if(g_resend_flag) 
{
		g_resend_flag = 0;
		//tftp_retry_cnt = tftp_time_cnt = 0;
	}
}

void tftp_reg_timeout()
{
	if(g_resend_flag == 0) 
	{
		g_resend_flag = 1;
		//tftp_retry_cnt = tftp_time_cnt = 0;
	}
}

uint8_t process_tftp_option(uint8_t *msg, uint32_t msg_len)
{
	TFTP_HEAD_T *data = (TFTP_HEAD_T *)msg;

	data->opcode = ntohs(data->opcode);
	total_len = data->filelen;
	crc32 = data->crc32;
	
	if((total_len>105*1024)||(total_len==0))    //����105K������
	{
		return 0;
	}
	Run1Des(DECRYPT,ECB,(const char *)data->buf,48,DES_KEY,8,(char *)&newhead,48,NULL);
	lCrc32=0;
	lCrc32 =Calculate_CRC32(lCrc32,(unsigned char *)&newhead,48);
	printf("head lCrc32=%x  HardwareVer:%s,FirmwareVer:%s\r\n",lCrc32,newhead.HardwareVer,newhead.FirmwareVer);
	
	return 1;
}

void send_tftp_rrq(uint8_t *filename, uint8_t *mode, TFTP_OPTION *opt, uint8_t opt_len)
{
	uint8_t snd_buf[128];
	uint8_t *pkt = snd_buf;
	uint32_t i, len;
	
	memset(snd_buf,0,sizeof(snd_buf));

	*((uint16_t *)pkt) = htons(TFTP_RRQ);
	pkt += 2;
	strcpy((char *)pkt, (const char *)filename);
	pkt += strlen((char *)filename) + 1;
	strcpy((char *)pkt, (const char *)mode);
	pkt += strlen((char *)mode) + 1;

	for(i = 0 ; i < opt_len ; i++) {
		strcpy((char *)pkt, (const char *)opt[i].code);
		pkt += strlen((char *)opt[i].code) + 1;
		strcpy((char *)pkt, (const char *)opt[i].value);
		pkt += strlen((char *)opt[i].value) + 1;
	}

	len = pkt - snd_buf;

	send_udp_packet(g_tftp_socket,  snd_buf, len, get_server_ip(), TFTP_SERVER_PORT);
	set_tftp_state(STATE_RRQ);
	set_filename(filename, strlen((char *)filename) + 1);
	tftp_reg_timeout();
#ifdef __TFTP_DEBUG__
	printf(">> TFTP RRQ : FileName(%s), Mode(%s)\r\n", filename, mode);
#endif
}

#if 0	// 2014.07.01 sskim
void send_tftp_wrq(uint8_t *filename, uint8_t *mode, TFTP_OPTION *opt, uint8_t opt_len)
{
	uint8_t snd_buf[MAX_MTU_SIZE];
	uint8_t *pkt = snd_buf;
	uint32_t i, len;

	*((uint16_t *)pkt) = htons((uint16_t)TFTP_WRQ);
	pkt += 2;
	strcpy((char *)pkt, (const char *)filename);
	pkt += strlen((char *)filename) + 1;
	strcpy((char *)pkt, (const char *)mode);
	pkt += strlen((char *)mode) + 1;

	for(i = 0 ; i < opt_len ; i++) {
		strcpy((char *)pkt, (const char *)opt[i].code);
		pkt += strlen((char *)opt[i].code) + 1;
		strcpy((char *)pkt, (const char *)opt[i].value);
		pkt += strlen((char *)opt[i].value) + 1;
	}

	len = pkt - snd_buf;

	send_udp_packet(g_tftp_socket , snd_buf, len, get_server_ip(), TFTP_SERVER_PORT);
	set_tftp_state(STATE_WRQ);
	set_filename(filename, strlen((char *)filename) + 1);
	tftp_reg_timeout();
#ifdef __TFTP_DEBUG__
	DBG_PRINT(IPC_DBG, ">> TFTP WRQ : FileName(%s), Mode(%s)\r\n", filename, mode);
#endif
}
#endif

#if 0	// 2014.07.01 sskim
void send_tftp_data(uint16_t block_number, uint8_t *data, uint16_t data_len)
{
	uint8_t snd_buf[MAX_MTU_SIZE];
	uint8_t *pkt = snd_buf;
	uint32_t len;

	*((uint16_t *)pkt) = htons((uint16_t)TFTP_DATA);
	pkt += 2;
	*((uint16_t *)pkt) = htons(block_number);
	pkt += 2;
	memcpy(pkt, data, data_len);
	pkt += data_len;

	len = pkt - snd_buf;

	send_udp_packet(g_tftp_socket , snd_buf, len, get_server_ip(), get_server_port());
	tftp_reg_timeout();
#ifdef __TFTP_DEBUG__
	DBG_PRINT(IPC_DBG, ">> TFTP DATA : Block Number(%d), Data Length(%d)\r\n", block_number, data_len);
#endif
}
#endif

void send_tftp_ack(uint16_t block_number)
{
	uint8_t snd_buf[4];
	uint8_t *pkt = snd_buf;

	*((uint16_t *)pkt) = htons((uint16_t)TFTP_ACK);
	pkt += 2;
	*((uint16_t *)pkt) = htons(block_number);
	pkt += 2;

	send_udp_packet(g_tftp_socket , snd_buf, 4, get_server_ip(), get_server_port());
	tftp_reg_timeout();
#ifdef __TFTP_DEBUG__
//	printf(">> TFTP ACK : Block Number(%d)\r\n", block_number);
#endif
}

void send_tftp_version(unsigned char *buf,unsigned short len)
{
	uint8_t snd_buf[100];
	uint8_t *pkt = snd_buf;
	
	memset(snd_buf,0,sizeof(snd_buf));
	
	if(len>(sizeof(snd_buf)-2))
		return ;
	*((uint16_t *)pkt) = htons((uint16_t)TFTP_VERSION);
	pkt += 2;
	memcpy(pkt,buf,len);
	pkt += len;
	
	send_udp_packet(g_tftp_socket , snd_buf, 2+len, get_server_ip(), get_server_port());
	tftp_reg_timeout();
#ifdef __TFTP_DEBUG__
	printf(">> TFTP VERSION \r\n");
#endif
}

void recv_tftp_rrq(uint8_t *msg, uint32_t msg_len)
{
	/* When TFTP Server Mode */
}

void recv_tftp_wrq(uint8_t *msg, uint32_t msg_len)
{
	/* When TFTP Server Mode */
}

void recv_tftp_data(uint8_t *msg, uint32_t msg_len)
{
	TFTP_DATA_T *data = (TFTP_DATA_T *)msg;

	data->opcode = ntohs(data->opcode);
	data->block_num = ntohs(data->block_num);
	#ifdef __TFTP_DEBUG__
	printf("<< TFTP_DATA : opcode(%d), block_num(%d)\r\n", data->opcode, data->block_num);
	#endif
	
	switch(get_tftp_state())
	{
		case STATE_RRQ :
		case STATE_OACK :
			if(data->block_num == 1) 
			{
				set_tftp_state(STATE_DATA);
				set_block_number(data->block_num);					
				save_data(data->data, msg_len - 4, data->block_num);
				tftp_cancel_timeout();
			}
			send_tftp_ack(data->block_num);
			
			if((msg_len - 4) < TFTP_BLK_SIZE)     //�ļ���СС��512
			{
				init_tftp();				
				g_progress_state = TFTP_SUCCESS;
			}
			break;
			
		case STATE_DATA :
			if(data->block_num == (get_block_number() + 1)) 
			{
				set_block_number(data->block_num);
				if(save_data(data->data, msg_len - 4, data->block_num)==2)
				{
					tftp_cancel_timeout();
					send_tftp_ack(data->block_num);
					init_tftp();
					g_progress_state = TFTP_SUCCESS;
					break;
				}
				tftp_cancel_timeout();
			}
			send_tftp_ack(data->block_num);
			
			if((msg_len - 4) < TFTP_BLK_SIZE) 
			{
				init_tftp();
				g_progress_state = TFTP_SUCCESS;
			}
			break;
		default :
			/* invalid message */
			break;
	}
}

void recv_tftp_ack(uint8_t *msg, uint32_t msg_len)
{
#ifdef __TFTP_DEBUG__
	printf("<< TFTP_ACK : \r\n");
#endif

	switch(get_tftp_state())
	{
		case STATE_WRQ :
			break;
		case STATE_ACK :
			break;
		default :
			/* invalid message */
			break;
	}
}

void recv_tftp_oack(uint8_t *msg, uint32_t msg_len)
{
#ifdef __TFTP_DEBUG__
	printf("<< TFTP_OACK : \r\n");
#endif

	switch(get_tftp_state())
	{
		case STATE_RRQ :
			if(!process_tftp_option(msg, msg_len))	//���Ȳ�����,��Ӧ�������
			{
				break;
			}
			set_tftp_state(STATE_OACK);
			tftp_cancel_timeout();
			send_tftp_ack(0);
			break;

		case STATE_WRQ :
			process_tftp_option(msg, msg_len);	
			set_tftp_state(STATE_ACK);
			tftp_cancel_timeout();

			/* TODO DATA Transfer */
			//send_tftp_data(...);
			break;

		default :
			/* invalid message */
			break;
	}
}

void recv_tftp_error(uint8_t *msg, uint32_t msg_len)
{
	TFTP_ERROR_T *data= (TFTP_ERROR_T *)msg;

	data->opcode = ntohs(data->opcode);
	data->error_code = ntohs(data->error_code);

#ifdef __TFTP_DEBUG__
	printf("<< TFTP_ERROR : %d (%s)\r\n", data->error_code, data->error_msg);
	printf("[%s] Error Code : %d (%s)\r\n", __func__, data->error_code, data->error_msg);
#endif
	init_tftp();
	g_progress_state = TFTP_FAIL;
}

void recv_tftp_version(uint8_t *msg, uint32_t msg_len)
{
	char buf[49];
	HEAD curhead;
	
	#ifdef __TFTP_DEBUG__
		printf("<< TFTP_VERSION\r\n");
	#endif
	memset(&curhead,0,sizeof(curhead));
	ReadHeadInfo((HEAD*)&curhead);
	memcpy(buf,&curhead,48);
	buf[48]=upflag; 
	send_tftp_version((unsigned char*)buf,49);
}


void recv_tftp_updata(uint8_t *msg, uint32_t msg_len)
{
	TFTP_UPDATA_T *data = (TFTP_UPDATA_T *)msg;
	unsigned char filename[FILE_NAME_SIZE+1];
	
	data->opcode = ntohs(data->opcode);

	memset(filename,0,sizeof(filename));
	memcpy(filename,data->filename,FILE_NAME_SIZE);
	TFTP_read_request(get_server_ip(),filename);	// TFTP������	

#ifdef __TFTP_DEBUG__
	printf("<< TFTP_UPDATA[file name:%s]\r\n",filename);
#endif
}



void recv_tftp_packet(uint8_t *packet, uint32_t packet_len, uint32_t from_ip, uint16_t from_port)
{
	uint16_t opcode;
	
	opcode = ntohs(*((uint16_t *)packet));
	/* Set Server Port */
	if((get_tftp_state() == STATE_WRQ) || (get_tftp_state() == STATE_RRQ)) 
	{
		set_server_port(from_port);
		#ifdef __TFTP_DEBUG__
		printf("[%s] Set Server Port : %d\r\n", __func__, from_port);
		#endif
	}
	switch(opcode)
	{
		case TFTP_RRQ :						/* When Server */
			recv_tftp_rrq(packet, packet_len);
			break;
		case TFTP_WRQ :						/* When Server */
			recv_tftp_wrq(packet, packet_len);
			break;
		case TFTP_DATA :
			recv_tftp_data(packet, packet_len);
			break;
		case TFTP_ACK :
			recv_tftp_ack(packet, packet_len);
			break;
		case TFTP_OACK :
			recv_tftp_oack(packet, packet_len);
			break;
		case TFTP_ERROR :
			recv_tftp_error(packet, packet_len);
			break;
		case TFTP_VERSION:
			set_server_ip(from_ip);
			set_server_port(from_port);
			recv_tftp_version(packet, packet_len);
			break;
		case TFTP_UPDATA:
			recv_tftp_updata(packet, packet_len);
			break;

		default :
			// Unknown Mesage
			break;
	}
}

/* Functions ----------------------------------------------------*/
void TFTP_init(uint8_t socket, uint8_t *buf)
{
	init_tftp();																						// TFTP��ʼ��

	g_tftp_socket = open_tftp_socket(socket);								// ��һ·Socket����TFTPͨ��
	g_tftp_rcv_buf = buf;																		
}

void TFTP_exit(void)
{
	init_tftp();

	close_tftp_socket(g_tftp_socket);
	g_tftp_socket = -1;

	g_tftp_rcv_buf = NULL;
}

void TFTP_run(void)																// TFTP����
{
	uint16_t len, from_port;
	uint32_t from_ip;
	
	/* ��ʱ����
	if(g_resend_flag)
	{
		if(tftp_time_cnt++ >= g_timeout) 
		{
			switch(get_tftp_state()) 
			{
			case STATE_WRQ:				
				break;
			case STATE_RRQ:
				send_tftp_rrq(g_filename, (uint8_t *)TRANS_BINARY, &default_tftp_opt, 1);
				break;
			case STATE_OACK:
			case STATE_DATA:
				send_tftp_ack(get_block_number());
				break;
			case STATE_ACK:				
				break;
			default:
				break;
			}
			tftp_time_cnt = 0;
			tftp_retry_cnt++;
			if(tftp_retry_cnt >= 5) 
			{
				init_tftp();
				g_progress_state = TFTP_FAIL;
			}
		}
	}*/
	// �������ݰ�����
	len = recv_udp_packet(g_tftp_socket, g_tftp_rcv_buf, MAX_MTU_SIZE, &from_ip, &from_port);
	if(len>0)
	{
		recv_tftp_packet(g_tftp_rcv_buf, len, from_ip, from_port);
	}
	if(g_progress_state == TFTP_SUCCESS)
	{
		g_progress_state = TFTP_PROGRESS;
		if(crc32 != lCrc32)
		{
			printf("crc error! lCrc32=%x crc32:%x\r\n",lCrc32,crc32);
			printf("����ʧ��!��������...\r\n");
			Reboot();
		}
		WriteHeadInfo(&newhead);
		printf("���سɹ�!��������...\r\n");
		Reboot();
	}
	else if(g_progress_state == TFTP_FAIL)
	{
		printf("����ʧ��!��������...\r\n");
		Reboot();
	}
}


void TFTP_read_request(uint32_t server_ip, uint8_t *filename)
{
	set_server_ip(server_ip);
	#ifdef __TFTP_DEBUG__
	printf("[%s] Set Tftp Server : %x\r\n", __func__, server_ip);
	#endif
	g_progress_state = TFTP_PROGRESS;
	send_tftp_rrq(filename, (uint8_t *)TRANS_BINARY, &default_tftp_opt, 1);
}

void tftp_timeout_handler(void)
{
	if(g_resend_flag) 
		tftp_time_cnt++;
}

unsigned int save_data(uint8_t *data, uint32_t data_len, uint16_t block_number)
{
	return  WriteFlashData(data,data_len,block_number);
}

