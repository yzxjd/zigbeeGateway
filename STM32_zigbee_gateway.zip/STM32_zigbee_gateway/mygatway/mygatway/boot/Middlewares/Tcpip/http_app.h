#ifndef	__HTTPAPP_H__
#define	__HTTPAPP_H__

#include <stdio.h>
#include <string.h>
#include "w5500.h"
#include "socket.h"
#include "http_server.h"

struct _HTTP_TRANS;

typedef void (*cgi_callback)(struct _HTTP_TRANS *);

typedef struct _HTTP_TRANS
{
	NET_CONFIG 	*pNetConfig;				
	unsigned char *pFixedInfoBuf;
	cgi_callback pCgiCallBack;
}HTTP_TRANS;




void https_init(SOCKET Socket,HTTP_TRANS *pHttpTrans);
void proc_http(SOCKET s, unsigned char * buf);
void do_https(void);
void cgi_ipconfig(st_http_request *http_request);
void make_basic_config_setting_callback(char*);
void make_cgi_response(unsigned short ,char* ,char* );

#endif


