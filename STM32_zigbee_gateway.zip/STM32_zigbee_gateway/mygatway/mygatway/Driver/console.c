#include "stm32f10x_lib.h"
#include "stm32f10x_api.h"
#include <stdio.h>
#include "cmsis_os.h"
#include "shell.h"
#include "cyclebuffer.h"

/*************************************************
  Function:    ����5����
  Description: 
*************************************************/
void Uart5Config(unsigned int eBandRate,unsigned char eDataBit,unsigned char eParity,unsigned char eStopBit)
{
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	USART_ClockInitTypeDef  USART_ClockInitStructure;
	unsigned short DataBit;
	unsigned short Parity;
	unsigned short StopBit;
	
	/////////////////////////////////////////////////////////////////////
	NVIC_InitStructure.NVIC_IRQChannel = UART5_IRQChannel;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 8;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	if(eDataBit==9)	 DataBit =  USART_WordLength_9b;
	else DataBit = USART_WordLength_8b;

	if(eParity=='e') Parity = USART_Parity_Even;
	else if(eParity=='o') Parity = USART_Parity_Odd;
	else Parity =  USART_Parity_No;

	if(eStopBit==2) StopBit = USART_StopBits_2;
	else StopBit =  USART_StopBits_1;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5,ENABLE);
	
	USART_DeInit(UART5);
	
	USART_ClockInitStructure.USART_Clock = USART_Clock_Disable;
	USART_ClockInitStructure.USART_CPOL = USART_CPOL_Low;
	USART_ClockInitStructure.USART_CPHA = USART_CPHA_2Edge;
	USART_ClockInitStructure.USART_LastBit = USART_LastBit_Disable;
	// Configure the USART synchronous paramters 
	USART_ClockInit(UART5, &USART_ClockInitStructure);
       
	USART_InitStructure.USART_BaudRate = eBandRate;
	USART_InitStructure.USART_WordLength = DataBit;
	USART_InitStructure.USART_StopBits = StopBit;
	USART_InitStructure.USART_Parity = Parity;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	// Configure USART basic and asynchronous paramters 
	USART_Init(UART5, &USART_InitStructure);
	
	USART_ITConfig(UART5,USART_IT_RXNE, ENABLE);	
	
	USART_Cmd(UART5, ENABLE);
	
	USART_ClearFlag(UART5, USART_FLAG_TC);
}

/*************************************************
  Function:    ����̨���ڳ�ʼ��
  Description: 
*************************************************/
void ConsoleInit(void)
{
	GpioConfig(GPIOC,GPIO_Pin_12,GPIO_Mode_AF_PP,GPIO_Speed_50MHz);
	GpioConfig(GPIOD,GPIO_Pin_2,GPIO_Mode_IN_FLOATING,GPIO_Speed_50MHz);
	Uart5Config(115200,8,0,1);
}

/*************************************************
  Function:    ����̨�����ֽ�
  Description: 
*************************************************/
void ConsoleSendByte(unsigned char dat)
{
	USART_SendData(UART5,(unsigned short)dat);
	while(USART_GetFlagStatus(UART5, USART_FLAG_TXE)!=SET) ;
}

/*************************************************
  Function:    ����̨�����ַ���
  Description: 
*************************************************/
void ConsoleSendBytes(unsigned char *dat,unsigned short len)
{
	unsigned short i;
	
	for(i=0;i<len;i++)
	{
		ConsoleSendByte(dat[i]);
	}
}

/*************************************************
  Function:    ����5�жδ�������
  Description: 
*************************************************/
void UART5_IRQHandler(void)
{	
	unsigned char cByte;
	
	if (USART_GetFlagStatus(UART5, USART_FLAG_ORE) != RESET)
	{
		USART_ReceiveData(UART5);
	}
	else if(USART_GetITStatus(UART5, USART_IT_RXNE) != RESET)  
	{
		USART_ClearFlag(UART5,USART_IT_RXNE);    
		cByte=USART_ReceiveData(UART5);
//		ConsoleSendByte(cByte);
		//FourGSendByte(cByte);
		ShellProcess(cByte);
	}
}


/*******************************************************************/

#pragma import(__use_no_semihosting)

struct __FILE  
{  
	int handle;  
};
FILE __stdout;  

void _sys_exit(int x)  
{  
	x = x;  
}

int fputc(int ch, FILE *f)
{
	ConsoleSendByte((unsigned char)ch);
	return ch;
}



