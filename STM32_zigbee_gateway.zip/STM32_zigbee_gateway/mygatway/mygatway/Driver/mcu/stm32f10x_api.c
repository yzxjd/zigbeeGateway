#include "stm32f10x_lib.h"
#include "stm32f10x_api.h"
#include "feeprom.h"
#include "feepromApp.h"
#include "usrApp.h"
#include "stm32f10x_pwr.h"
#include "stm32f10x_wwdg.h"
#include <stdio.h>

static void SysClockConfig(void)
{
	u16 i,j=0;
	ErrorStatus HSEStartUpStatus;
      
	// RCC system reset(for debug purpose)
	RCC_DeInit();
	
	// Enable HSE
	RCC_HSEConfig(RCC_HSE_ON);
  	
	// Wait till HSE is ready
	HSEStartUpStatus = RCC_WaitForHSEStartUp();

	while(HSEStartUpStatus != SUCCESS)
	{
		RCC_HSEConfig(RCC_HSE_ON);
		HSEStartUpStatus = RCC_WaitForHSEStartUp();
		for(i = 0; i < 500;i++);
			j++;
		if(j >= 10)
		{
			HSEStartUpStatus = SUCCESS;
			break;
		}
	}
  
	if(HSEStartUpStatus == SUCCESS)
	{
		// HCLK = SYSCLK 
		RCC_HCLKConfig(RCC_SYSCLK_Div1); 

		// PCLK2 = HCLK 
		RCC_PCLK2Config(RCC_HCLK_Div1); 

		// PCLK1 = HCLK/2 
		RCC_PCLK1Config(RCC_HCLK_Div2);

		// Flash 2 wait state 
		FLASH_SetLatency(FLASH_Latency_2);
		// Enable Prefetch Buffer 
		FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);

		// PLLCLK = 8MHz * 9 = 72 MHz 
		RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_9);

		// Enable PLL 
		RCC_PLLCmd(ENABLE);

		// Wait till PLL is ready 
		while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
		{
		}

		// Select PLL as system clock source 
		 RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);

		// Wait till PLL is used as system clock source 
		while(RCC_GetSYSCLKSource() != 0x08)
		{
		}
	}
}

static void GpioPreInit(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO|RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOC|RCC_APB2Periph_GPIOD|RCC_APB2Periph_GPIOE, ENABLE);
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);
	GPIO_DeInit(GPIOA);
	GPIO_DeInit(GPIOB);
	GPIO_DeInit(GPIOC);
	GPIO_DeInit(GPIOD);
	GPIO_DeInit(GPIOE);
}


static void NvicConfig(void)
{
	NVIC_DeInit();
	#ifdef B  //�������B��
		NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x23800); 
	#else 
		#ifdef  A   //�����������A��
		NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x8000);
		#else
		NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0000);
		#endif
	#endif
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);  //�������Ҫ��
}


void SysTickConfig(void)
{
	RCC_ClocksTypeDef  rcc_clocks;
	u32  cnt;
	
	NVIC_SystemHandlerPriorityConfig(SystemHandler_SysTick,15,0);
	
	RCC_GetClocksFreq(&rcc_clocks);
	
	cnt = (u32)rcc_clocks.HCLK_Frequency/100;

	SysTick_SetReload(cnt);
	SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK);
	SysTick_CounterCmd(SysTick_Counter_Enable);
	SysTick_ITConfig(ENABLE);
}

/*
	�������Ź���ʼ��
*/
void DogInit(void)
{
	RCC_LSICmd(ENABLE);		//��LSI
	while(RCC_GetFlagStatus(RCC_FLAG_LSIRDY)==RESET)	;// �ȴ�ֱ��LSI�ȶ�
	//ʹ�ܼĴ���д	
	FLASH_UserOptionByteConfig(OB_IWDG_HW,OB_STOP_RST,OB_STDBY_RST);
	//�����������Ź���ʹ�ܶԼĴ���Iд����
	IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
	//�趨ι��ʱ��
	IWDG_SetPrescaler(IWDG_Prescaler_64);		//64��Ƶ һ������1.6ms  ����IWDGԤ��Ƶֵ
	IWDG_SetReload(800);						//�12λ [0,4096] 800*1.6=1.28S   ����IWDG��װ��ֵ
	// Reload IWDG counter
	IWDG_ReloadCounter();			//��װ��IWDG������
	DBGMCU_Config(DBGMCU_IWDG_STOP,ENABLE);
	// Enable IWDG (the LSI oscillator will be enabled by hardware)
	IWDG_Enable();
}


void DogClear(void)
{
	IWDG_ReloadCounter();
}

void PowerConfig(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;
	EXTI_InitTypeDef EXTI_InitStructure;
 
	RCC_APB1PeriphClockCmd( RCC_APB1Periph_PWR, ENABLE);
	
	/* Configure EXTI Line16(PVD Output) to generate an interrupt on rising and
	 falling edges */
	
	EXTI_ClearITPendingBit(EXTI_Line16); 
	EXTI_InitStructure.EXTI_Line = EXTI_Line16;// PVD���ӵ��ж���16�� 
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;//ʹ���ж�ģʽ 
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;//��ѹ�������½�Խ���趨��ֵʱ�������жϡ�
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;// ʹ���ж���
	EXTI_Init(&EXTI_InitStructure);// ��ʼ
	
	NVIC_ClearIRQChannelPendingBit(PVD_IRQChannel);
	NVIC_InitStructure.NVIC_IRQChannel = PVD_IRQChannel;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	PWR_PVDLevelConfig(PWR_PVDLevel_2V9);
	PWR_PVDCmd(ENABLE);
}


void McuInit(void)
{
	unsigned int cnt=0xfffff;
	
	SysClockConfig();  //ϵͳʱ������
	NvicConfig();			 //�жϿ���������
	while(cnt--);      
	PowerConfig();     //��Դ����
	#ifdef DOG
	DogInit();         //���Ź���ʼ��
	#endif
	GpioPreInit();		 //GPIOԤ��ʼ��
	SysTickConfig();	 //ϵͳ�δ�ʱ������
}

/*************************************************
  Function:    �ⲿ�����ж�
  Description: �жϴ�����Ὣ����ǰ�����ݱ��浽E2ROM��
*************************************************/
extern struct list_head chhead;
void PVD_IRQHandler(void) 
{ 
	EXTI_ClearITPendingBit(EXTI_Line16); 
	
	if (PWR_GetFlagStatus(PWR_FLAG_PVDO)== SET) 
	{ 
//		printf("�������ֵ�����~_~......\r\n");	
//		ChCntBakWriteScan();
//		myChCntBakWriteScan();
//		printf("data save ok\r\n");
	}
}


void HardFault_Handler(void)
{
	while(1) ;
}


unsigned int McuGetId(void)
{	
	unsigned int ChipUniqueID[3];
	
	ChipUniqueID[2] = *(__IO u32*)(0X1FFFF7E8);  
	ChipUniqueID[1] = *(__IO u32 *)(0X1FFFF7EC); 
	ChipUniqueID[0] = *(__IO u32 *)(0X1FFFF7F0); 
	
	return ChipUniqueID[0];
}


void Reboot(void)
{
	NVIC_SETFAULTMASK();
	NVIC_GenerateSystemReset();
}


void GpioConfig(GPIO_TypeDef* Port, INT16U Pin ,INT16U Mode,INT16U Speed)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	GPIO_InitStructure.GPIO_Pin = Pin;
	GPIO_InitStructure.GPIO_Mode =(GPIOMode_TypeDef )Mode;
	GPIO_InitStructure.GPIO_Speed =(GPIOSpeed_TypeDef )Speed;
	GPIO_Init(Port, &GPIO_InitStructure);
}


