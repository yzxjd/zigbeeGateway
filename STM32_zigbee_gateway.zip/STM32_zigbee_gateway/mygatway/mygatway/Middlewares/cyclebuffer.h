#ifndef CYCLEBUFFER_H
#define CYCLEBUFFER_H

extern unsigned char closedCnt;

void CycleBufferInit(unsigned char Id);
int CycleBufferPush(unsigned char Id ,unsigned char Data);
int CycleBufferPop(unsigned char Id,unsigned char *pData);


#endif
