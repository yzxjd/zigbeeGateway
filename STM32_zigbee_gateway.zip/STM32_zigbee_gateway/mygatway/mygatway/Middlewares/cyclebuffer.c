#include "cyclebuffer.h"
#include "console.h"
#include "stm32f10x_api.h"
#include <string.h>
#include <stdio.h>

typedef struct
{
	unsigned char	bRxStopFlag;		//ֹͣ���ձ��
	unsigned short	iRxInPtr;			//��ջָ��
	unsigned short	iRxOutPtr;			//��ջָ��
	unsigned char (*RecvCtrPro)(unsigned char,unsigned char );    //���ջ�����������ʱ��ֹ�ж�
}CycleBufferTag;

#define ENABLE_USART_NUM	2

#define REVEICEBUFF1_SIZE	4096			
#define REVEICEBUFF2_SIZE	1024

static CycleBufferTag CycleBuffer[ENABLE_USART_NUM];	

static unsigned char CycleBuffer1[REVEICEBUFF1_SIZE];	   
static unsigned char CycleBuffer2[REVEICEBUFF2_SIZE];	 

static unsigned short cycleSizeTable[ENABLE_USART_NUM]={REVEICEBUFF1_SIZE,REVEICEBUFF2_SIZE};
static unsigned char *cycleAddrTable[ENABLE_USART_NUM]={CycleBuffer1,CycleBuffer2};


void CycleBufferInit(unsigned char Id)
{
	if(CycleBuffer[Id].bRxStopFlag!=0)
	{
		//if(CycleBuffer[Id].RecvCtrPro!=NULL)
		//	(*CycleBuffer[Id].RecvCtrPro)(Id,1);
		
		CycleBuffer[Id].bRxStopFlag=0;
	}
	
	CycleBuffer[Id].iRxInPtr=0;
	CycleBuffer[Id].iRxOutPtr=0;
}


int CycleBufferPush(unsigned char Id ,unsigned char Data)
{
	unsigned short iNextInPtr;
//	unsigned char buf[10];
	
	iNextInPtr=(CycleBuffer[Id].iRxInPtr+1)%cycleSizeTable[Id];
	if(iNextInPtr!=CycleBuffer[Id].iRxOutPtr)
	{
		*(cycleAddrTable[Id]+CycleBuffer[Id].iRxInPtr)=Data;
		CycleBuffer[Id].iRxInPtr=iNextInPtr;
//		sprintf(buf,"%x ",Data);
//		ConsoleSendBytes(buf,strlen(buf));      //�յ���ģ�����Ϣ����ӡ����
		//ConsoleSendByte(Data);  
		iNextInPtr=(CycleBuffer[Id].iRxInPtr+1)%cycleSizeTable[Id];
		if(iNextInPtr==CycleBuffer[Id].iRxOutPtr)
		{	
			//if(CycleBuffer[Id].RecvCtrPro!=NULL)
			//	(*CycleBuffer[Id].RecvCtrPro)(Id,0);
			CycleBuffer[Id].bRxStopFlag=1;
			return -1;
		}
	}   

	return 0;
}                    

extern int toConnectTCP_IP(void);
extern void shutGSM(void);
extern unsigned char NetMode;
unsigned char closedCnt=0;
int CycleBufferPop(unsigned char Id,unsigned char *pData)
{
	unsigned short iRxInPtr;
	unsigned char buf[10];
	static unsigned char NetCloseFlag = 0,GsmShutFlag = 0;
	//taskENABLE_INTERRUPTS();
	iRxInPtr=CycleBuffer[Id].iRxInPtr;
	if(iRxInPtr!=CycleBuffer[Id].iRxOutPtr)
	{
		*pData=*(cycleAddrTable[Id]+CycleBuffer[Id].iRxOutPtr++);
		if(CycleBuffer[Id].iRxOutPtr==cycleSizeTable[Id])
			CycleBuffer[Id].iRxOutPtr=0;
		
		sprintf((char *)buf,"%c",*pData);
		if(NetMode == 0x01)	//ֻ��SIM�������������ж�
		{
			if(*pData == 'C')
			{
				NetCloseFlag = 1;
			}
			else if(NetCloseFlag == 1 && *pData == 'L')
			{
					NetCloseFlag = 2;

			}
			else if(NetCloseFlag == 2 && *pData == 'O') //CLOSE
			{
					if(closedCnt++ > 10)
					{
							Reboot();
					}
					printf("�����쳣����������TCP\n");
					toConnectTCP_IP();
					NetCloseFlag = 0;
			}
			else 
			{
				NetCloseFlag = 0;
			}
			
			if(*pData == '+')
			{
				GsmShutFlag = 1;
			}
			else if(GsmShutFlag == 1 && *pData == 'P')
			{
					printf("ģ��\n");
					Reboot();
					GsmShutFlag = 0;
			}
			else 
			{
				GsmShutFlag = 0;
			}
		}
//		ConsoleSendBytes(buf,strlen((char *)buf));      //�յ���ģ�����Ϣ����ӡ����
		
		return 0; 
	}
	else     //buffer empty
	{
		if(CycleBuffer[Id].bRxStopFlag!=0)
		{
			//if(CycleBuffer[Id].RecvCtrPro!=NULL)
			//	(*CycleBuffer[Id].RecvCtrPro)(Id,1);
			CycleBuffer[Id].bRxStopFlag=0;
		}
	}
	
	return -1;
}




