#ifndef MQTTECHO_H
#define	MQTTECHO_H

#include "MQTTFreeRTOS.h"
#include "MQTTClient.h"

/* Standard includes. */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"


#include "cjson.h"
#include "usrApp.h"
#include "cmsis_os.h"
#include "fourG.h"
#include "cyclebuffer.h"
#include "ff.h"
#include "feeprom.h"
#include <string.h>

//#define MyDebug

//#ifdef MyDebug 
//#define DEBUG_PRINT printf
//#else
//#define DEBUG_PRINT (void)
//#endif

extern unsigned char upgradflag;

typedef struct _Signal_Quality
{
	unsigned char PublishSignalStrength_flag;	
	unsigned int mid;
}SIGNAL_QUALITY;

typedef struct _ChpZhengdingMsg
{
	unsigned char ChpZdFlag;	
	unsigned int pid;
}ChpZdMsg;

typedef struct _UpgradeStatus
{
	unsigned char ver;			//���������еĹ̼�����汾
	unsigned char status;		//��ǰ������״̬ 0������֡������� 1������֡���ճ���
	unsigned char err;
	unsigned int pid;				//��ǰ��ID
	unsigned int position;	//�ļ�λ��
}UPGRADE_STATUS;


void messageArrived(MessageData* data);
void MQTTConnectManage(void);
int MQTTGetConnectStatus(void);
int _MQTTPublishChpStatus(PARK_CHP_NODE *pChpNode);
int _MQTTPublishLampStatus(PARK_LAMP_NODE *pLampNode);
int _MQTTPublishCarStatus(PARK_STOP_NODE *pStopNode);
int _MQTTPublishChStatus(PARK_CH_NODE *pChNode);
int _MQTTPublishGuideStatus(PARK_GUIDE_NODE *pGuideNode);
int _MQTTPublishCarLockStatus(unsigned int cd,unsigned char status);
int _MQTTPublishZhengDingStatus(unsigned int cd,unsigned char status);
int _MQTTPublishChpZhengDingStatus(unsigned int cd,unsigned char status);
int _MQTTPublishSignalStrength(int mid);
int _MQTTPublishUpgradeStatus(UPGRADE_STATUS sta); //��������״̬���غ���

extern void ZigbeeRevProcessTask(void const * arg);
extern void ZigbeeNodeManageTask(void const *arg);
extern void ZigbeeSend(unsigned int dstID,unsigned char cmd,unsigned char *dat,unsigned short len);
extern void ZigbeeDleInit(void); 

void MQTTRunTask(void* parm);

UPGRADE_STATUS upgradeStaAssignment(unsigned char ver,unsigned char sta,unsigned int pid, unsigned int pos);
unsigned char oldBinDelete(void);

int _MQTTPublishCtrlSetAck(CTRL_SET sta);	//ң��������ʹ��Ӧ��2017.11.27
int _MQTTPublishLockTimesSetAck(LOCKTIME_SET locktimeSet);
int _MQTTPublishBaselineUpload(BASELINE_VAL baselinVal);
int _MQTTPublishMagneticUpload(MAGNETIC_VAL magnetVal);

//2017.12.11 ����Э��Ӧ����
int _MQTTPublishBeepEnableAndHlodtimeUpload(BEEP_SET beepset);
int _MQTTPublishFaultTimeSetUpload(FAULT_TIME_SET faultTimetmp);
int _MQTTPublishAutomaticallyLockedUpload(LOCKING_TIME_SET autolockTime);
int _MQTTPublishLockPowerOffSetUpload(LOCK_POWER_DOWN lockPowerOffset);
int _MQTTPublishParameterResetUpload(PARAMETER_RESET temp);

//2018.2.2
unsigned int SaveMqttParameters(unsigned char *sIP,unsigned int sPort,unsigned char *user,unsigned char *passwd);




#endif
