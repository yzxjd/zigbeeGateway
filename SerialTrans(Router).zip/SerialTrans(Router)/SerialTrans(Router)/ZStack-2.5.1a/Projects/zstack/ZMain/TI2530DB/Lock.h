#ifndef __LOCK__H
#define __LOCK__H

void LockInit(void);
void LockOpen(void);
void LockClose(void) ;
void LockStop(unsigned char flag);
void LockCheckPoll(void);
void StatusKeepPollProcess(void);   // ���״̬ά��

#endif