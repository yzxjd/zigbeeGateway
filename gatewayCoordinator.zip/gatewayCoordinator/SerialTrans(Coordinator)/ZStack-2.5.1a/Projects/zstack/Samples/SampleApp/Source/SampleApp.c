/**************************************************************************************************
Filename:       SampleApp.c
Revised:        $Date: 2009-03-18 15:56:27 -0700 (Wed, 18 Mar 2009) $
Revision:       $Revision: 19453 $

Description:    Sample Application (no Profile).


Copyright 2007 Texas Instruments Incorporated. All rights reserved.

IMPORTANT: Your use of this Software is limited to those specific rights
granted under the terms of a software license agreement between the user
who downloaded the software, his/her employer (which must be your employer)
and Texas Instruments Incorporated (the "License").  You may not use this
Software unless you agree to abide by the terms of the License. The License
limits your use, and you acknowledge, that the Software may not be modified,
copied or distributed unless embedded on a Texas Instruments microcontroller
or used solely and exclusively in conjunction with a Texas Instruments radio
frequency transceiver, which is integrated into your product.  Other than for
the foregoing purpose, you may not use, reproduce, copy, prepare derivative
works of, modify, distribute, perform, display or sell this Software and/or
its documentation for any purpose.

YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE
PROVIDED �AS IS?WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE,
NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL
TEXAS INSTRUMENTS OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT,
NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER
LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE
OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT
OF SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

Should you have any questions regarding your right to use this Software,
contact Texas Instruments Incorporated at www.TI.com.
**************************************************************************************************/

/*********************************************************************
This application isn't intended to do anything useful, it is
intended to be a simple example of an application's structure.

This application sends it's messages either as broadcast or
broadcast filtered group messages.  The other (more normal)
message addressing is unicast.  Most of the other sample
applications are written to support the unicast message model.

Key control:
SW1:  Sends a flash command to all devices in Group 1.
SW2:  Adds/Removes (toggles) this device in and out
of Group 1.  This will enable and disable the
reception of the flash command.
*********************************************************************/

/*********************************************************************
* INCLUDES
*/
#include "OSAL.h"
#include "ZGlobals.h"
#include "AF.h"
#include "aps_groups.h"
#include "ZDApp.h"

#include "SampleApp.h"
#include "SampleAppHw.h"

#include "OnBoard.h"

/* HAL */
#include "hal_lcd.h" 
#include "hal_led.h"
#include "hal_key.h"
#include "hal_defs.h"
#include "MT_UART.h"
#include "MT_APP.h"
#include "MT.h"
#include "hal_uart.h"
#include "user_uarst.h"

#include "string.h"
#include "stdlib.h"
#include "stdio.h"
#include "ZDNwkConfig.h"
#include "sapi.h"

/*********************************************************************
* MACROS
*/

/*********************************************************************
* CONSTANTS
*/
#define MAX_MODULE_ADDR_NUM 130  //����ܴ�ŵ�ģ���ַ
#define DEBUG_PRINT_EN 0 //�������ʹ�� 

#define MAST_TO_DEV_FRAME_SOP1 0xaa //�������͸��ն�����֡��ʼ��־
#define MAST_TO_DEV_FRAME_SOP2 0x55

#define DEV_TO_MAST_FRAME_SOP1 0x55 //�ն˷��͸���������֡��ʼ��־
#define DEV_TO_MAST_FRAME_SOP2 0xaa

#define PRINT_UART_PORT 0



/*********************************************************************
* TYPEDEFS
*/

/*********************************************************************
* GLOBAL VARIABLES
*/
uint8 AppTitle[] = "mast"; //Ӧ�ó�������

// This list should be filled with Application specific Cluster IDs.
const cId_t SampleApp_ClusterList[SAMPLEAPP_MAX_CLUSTERS] =
{
  SAMPLEAPP_DEV_TO_MAST_CLUSTERID_DATA,
  SAMPLEAPP_MAST_TO_DEV_CLUSTERID_DATA
};

const SimpleDescriptionFormat_t SampleApp_SimpleDesc =
{
  SAMPLEAPP_ENDPOINT,              //  int Endpoint;
  SAMPLEAPP_PROFID,                //  uint16 AppProfId[2];
  SAMPLEAPP_DEVICEID,              //  uint16 AppDeviceId[2];
  SAMPLEAPP_DEVICE_VERSION,        //  int   AppDevVer:4;
  SAMPLEAPP_FLAGS,                 //  int   AppFlags:4;
  SAMPLEAPP_MAX_CLUSTERS,          //  uint8  AppNumInClusters;
  (cId_t *)SampleApp_ClusterList,  //  uint8 *pAppInClusterList;
  SAMPLEAPP_MAX_CLUSTERS,          //  uint8  AppNumInClusters;
  (cId_t *)SampleApp_ClusterList   //  uint8 *pAppInClusterList;
};

// This is the Endpoint/Interface description.  It is defined here, but
// filled-in in SampleApp_Init().  Another way to go would be to fill
// in the structure here and make it a "const" (in code space).  The
// way it's defined in this sample app it is define in RAM.
endPointDesc_t SampleApp_epDesc;

/*********************************************************************
* EXTERNAL VARIABLES
*/

/*********************************************************************
* EXTERNAL FUNCTIONS
*/

/*********************************************************************
* LOCAL VARIABLES
*/
uint8 SampleApp_TaskID;   // Task ID for internal task/event processing
// This variable will be received when
// SampleApp_Init() is called.
devStates_t SampleApp_NwkState;

uint8 SampleApp_TransID;  // This is the unique message ID (counter)

afAddrType_t SampleApp_Dev_To_Mast_DstAddr; // �ն�(·�������ն��豸)������(Э����)���õ�Ե�
afAddrType_t SampleApp_Mast_To_Dev_DstAddr; //����(Э����)���ն�(·�������ն��豸)���ù㲥��ʽ
afAddrType_t SampleApp_Mast_To_Dev_Broadcast_DstAddr; //�������ն�Ⱥ��

aps_Group_t SampleApp_Group;

uint8 SampleAppPeriodicCounter = 0;
uint8 SampleAppFlashCounter = 0;
int8 myRssi[2]={0};

//uint16 gModuleToNetAddr[MAX_MODULE_ADDR_NUM]; //�±����ģ���ַ�����ݴ��������ַ
uint8 gDevModuleAddr = 0; //�ն�ģ���ַ,������IEEE�������ַ
/*********************************************************************
* LOCAL FUNCTIONS
*/
void SampleApp_MessageMSGCB( afIncomingMSGPacket_t *pckt );
void SampleApp_SendSerailDataToOTA(UART_Rec_t *pkt);
void SampleApp_DevSendModuleAddrToMast(uint8 moduleAddr);
void SampleApp_MastReqDevModuleAddr(void);
void SampleApp_MastUpdateModuleAddr(uint16 *moduleToNetAddr, uint8 moduleAddr, uint16 shortAddr);
void show_RSSI(afIncomingMSGPacket_t *pkt);   //�����źŵ��ź�ǿ��ָ��
uint8 XorParity(uint8 *p,uint16 len);
/*********************************************************************
* NETWORK LAYER CALLBACKS
*/

/*********************************************************************
* PUBLIC FUNCTIONS
*/

/*********************************************************************
* @fn      SampleApp_Init
*
* @brief   Initialization function for the Generic App Task.
*          This is called during initialization and should contain
*          any application specific initialization (ie. hardware
*          initialization/setup, table initialization, power up
*          notificaiton ... ).
*
* @param   task_id - the ID assigned by OSAL.  This ID should be
*                    used to send messages and set timers.
*
* @return  none
*/
void SampleApp_Init( uint8 task_id )
{ 
  SampleApp_TaskID = task_id;
  SampleApp_NwkState = DEV_INIT;
  SampleApp_TransID = 0;
#if 1
  userUartConfig(); //���ô���
  HalUARTOpen(MY_DEFINE_UART_PORT , &uartConfig); //�򿪴���
#endif 
  HalUARTWrite(0,"UartInit OK\n", sizeof("UartInit OK\n"));//��ʾ��Ϣ
  // Device hardware initialization can be added here or in main() (Zmain.c).
  // If the hardware is application specific - add it here.
  // If the hardware is other parts of the device add it in main().
  
#if defined ( BUILD_ALL_DEVICES )
  // The "Demo" target is setup to have BUILD_ALL_DEVICES and HOLD_AUTO_START
  // We are looking at a jumper (defined in SampleAppHw.c) to be jumpered
  // together - if they are - we will start up a coordinator. Otherwise,
  // the device will start as a router.
  if ( readCoordinatorJumper() )
    zgDeviceLogicalType = ZG_DEVICETYPE_COORDINATOR;
  else
    zgDeviceLogicalType = ZG_DEVICETYPE_ROUTER;
#endif // BUILD_ALL_DEVICES
  
#if defined ( HOLD_AUTO_START )
  // HOLD_AUTO_START is a compile option that will surpress ZDApp
  //  from starting the device and wait for the application to
  //  start the device.
  ZDOInitDevice(0);
#endif
#if 1
  SampleApp_Dev_To_Mast_DstAddr.addrMode = (afAddrMode_t)Addr16Bit;
  SampleApp_Dev_To_Mast_DstAddr.endPoint = SAMPLEAPP_ENDPOINT;
  SampleApp_Dev_To_Mast_DstAddr.addr.shortAddr = 0x0000;
#else 
  SampleApp_Dev_To_Mast_DstAddr.addrMode = (afAddrMode_t)AddrBroadcast;
  SampleApp_Dev_To_Mast_DstAddr.endPoint = SAMPLEAPP_ENDPOINT;
  SampleApp_Dev_To_Mast_DstAddr.addr.shortAddr = 0xFFFC;
#endif
#if 0
  SampleApp_Mast_To_Dev_DstAddr.addrMode = (afAddrMode_t)AddrBroadcast;
  SampleApp_Mast_To_Dev_DstAddr.endPoint = SAMPLEAPP_ENDPOINT;
  SampleApp_Mast_To_Dev_DstAddr.addr.shortAddr = 0xFFFF;
#else
  SampleApp_Mast_To_Dev_DstAddr.addrMode = (afAddrMode_t)Addr16Bit;
  SampleApp_Mast_To_Dev_DstAddr.endPoint = SAMPLEAPP_ENDPOINT;
  SampleApp_Mast_To_Dev_DstAddr.addr.shortAddr = 0;
#endif
  
  SampleApp_Mast_To_Dev_Broadcast_DstAddr.addrMode = (afAddrMode_t)AddrBroadcast;
  SampleApp_Mast_To_Dev_Broadcast_DstAddr.endPoint = SAMPLEAPP_ENDPOINT;
  SampleApp_Mast_To_Dev_Broadcast_DstAddr.addr.shortAddr = 0xFFFF;
  
  
  // Fill out the endpoint description.
  SampleApp_epDesc.endPoint = SAMPLEAPP_ENDPOINT;
  SampleApp_epDesc.task_id = &SampleApp_TaskID;
  SampleApp_epDesc.simpleDesc
    = (SimpleDescriptionFormat_t *)&SampleApp_SimpleDesc;
  SampleApp_epDesc.latencyReq = noLatencyReqs;
  
  // Register the endpoint description with the AF
  afRegister( &SampleApp_epDesc );
  
  // Register for all key events - This app will handle all key events
  RegisterForKeys( SampleApp_TaskID );
  
  // By default, all devices start out in Group 1
  SampleApp_Group.ID = 0x0001;
  osal_memcpy( SampleApp_Group.name, "Group 1", 7 );
  aps_AddGroup( SAMPLEAPP_ENDPOINT, &SampleApp_Group );
  
  //����ڴ��е�����,��������Ҫ���д��룬�ն˺�·������Ҫ���д���
  zgWriteStartupOptions(ZG_STARTUP_SET, ZCD_STARTOPT_DEFAULT_NETWORK_STATE);//�����ŵ�ʱ����ʹ�ã����ϵ����Σ�Ȼ����ע�͵���
#if defined ( LCD_SUPPORTED )
  //HalLcdWriteString( "SampleApp", HAL_LCD_LINE_1 );
#endif
}

/*********************************************************************
* @fn      SampleApp_ProcessEvent
*
* @brief   Generic Application Task event processor.  This function
*          is called to process all events for the task.  Events
*          include timers, messages and any other user defined events.
*
* @param   task_id  - The OSAL assigned task ID.
* @param   events - events to process.  This is a bit map and can
*                   contain more than one event.
*
* @return  none
*/
uint16 SampleApp_ProcessEvent( uint8 task_id, uint16 events )
{
  static uint8 i=50;
  if(!(i--))
  {
    i=50;
    
#if MyDebug    
    char str[50]={0};
    //    HalFlashRead(NetWorkInitAdrr / (HAL_FLASH_PAGE_SIZE ), NetWorkInitAdrr % HAL_FLASH_PAGE_SIZE,  (uint8*)&mynwkConfig, sizeof(mynwkConfig));
    sprintf(str,"PanId:%x %x Channel:%x %x %d\r\n",mynwkConfig.XpanID,_NIB.nwkPanId, mynwkConfig.Xchannel,_NIB.nwkLogicalChannel,mynwkConfig.setFlag);
    HalUARTWrite(0,(uint8 *)str,strlen(str)); 
#endif
    
    if(mynwkConfig.Xchannel == 0xff)
    {
      mynwkConfig.Xchannel = _NIB.nwkLogicalChannel; 
      mynwkConfig.XchannelList = _NIB.channelList;  
      HalFlashErase(NetWorkInitAdrr / (HAL_FLASH_PAGE_SIZE ));
      HalFlashWrite(NetWorkInitAdrr/HAL_FLASH_WORD_SIZE, (uint8*)&mynwkConfig, sizeof(mynwkConfig));       
    }
    
    if( mynwkConfig.setFlag )
    {
      if( mynwkConfig.XpanID != _NIB.nwkPanId || mynwkConfig.Xchannel != _NIB.nwkLogicalChannel )
      {  
        zgWriteStartupOptions(ZG_STARTUP_SET, ZCD_STARTOPT_DEFAULT_NETWORK_STATE);//�����ŵ�ʱ����ʹ�ã����ϵ����Σ�Ȼ����ע�͵���
        setNwkParameter(mynwkConfig.XpanID,mynwkConfig.Xchannel,mynwkConfig.XchannelList); 
      }
      else
      {       
        mynwkConfig.setFlag = 0;
        HalFlashErase(NetWorkInitAdrr / (HAL_FLASH_PAGE_SIZE ));
        HalFlashWrite(NetWorkInitAdrr/HAL_FLASH_WORD_SIZE, (uint8*)&mynwkConfig, sizeof(mynwkConfig)); 
        //        osal_start_timerEx( SampleApp_TaskID, SAMPLEAPP_SYS_RESET_SOFT, 500);//����һ������5S������
      }
    }    
  }
  
  
  afIncomingMSGPacket_t *MSGpkt;
  uint8 keyValue = 1;
  (void)task_id;  // Intentionally unreferenced parameter
  if ( events & SYS_EVENT_MSG )
  {
    MSGpkt = (afIncomingMSGPacket_t *)osal_msg_receive( SampleApp_TaskID );
    while ( MSGpkt )
    {
      switch ( MSGpkt->hdr.event )
      {       		
        // Received when a messages is received (OTA) for this endpoint
      case AF_INCOMING_MSG_CMD:
        SampleApp_MessageMSGCB( MSGpkt );
        break;
        // Received whenever the device changes state in the network
      case ZDO_STATE_CHANGE:
        SampleApp_NwkState = (devStates_t)(MSGpkt->hdr.status);
        if ( (SampleApp_NwkState == DEV_ZB_COORD) ||
            (SampleApp_NwkState == DEV_ROUTER)
              || (SampleApp_NwkState == DEV_END_DEVICE) )
        {
          // Start sending the periodic message in a regular interval.
          if (SampleApp_NwkState == DEV_ZB_COORD)
          {
            SampleApp_MastReqDevModuleAddr();
            osal_start_timerEx( SampleApp_TaskID, KEY_TIEM_MSG_EVT,
                               (KEY_TIEM_MSG_TIMEOUT + (osal_rand() & 0x0f)) );
#if DEBUG_PRINT_EN == 1
            HalUARTWrite(PRINT_UART_PORT,"mast start up\n", sizeof("mast start up\n"));
#endif
          }else
          {
            if (gDevModuleAddr != 0)
            {
              SampleApp_DevSendModuleAddrToMast(gDevModuleAddr);
#if DEBUG_PRINT_EN == 1
              HalUARTWrite(PRINT_UART_PORT,"dev join in addr\n", sizeof("dev join in addr\n"));
#endif
            }else
            {
#if DEBUG_PRINT_EN == 1
              HalUARTWrite(PRINT_UART_PORT,"dev join in no addr\n", sizeof("dev join in no addr\n"));
#endif
            }
          }
        }
        else
        {
          // Device is no longer in the network
        }
        break;
      case SPI_INCOMING_ZAPP_DATA: //���Դ��ڵ�����
        SampleApp_SendSerailDataToOTA(((UART_Rec_t *)MSGpkt));
        //          char str[50]={0};
        //          HalFlashRead(NetWorkInitAdrr / (HAL_FLASH_PAGE_SIZE ), NetWorkInitAdrr % HAL_FLASH_PAGE_SIZE,  (uint8*)&mynwkConfig, sizeof(mynwkConfig));
        //          sprintf(str,"PanId:%x %x Channel:%x %x %d\r\n",mynwkConfig.XpanID,_NIB.nwkPanId, mynwkConfig.Xchannel,_NIB.nwkLogicalChannel,mynwkConfig.setFlag);
        //          HalUARTWrite(0,str,strlen(str)); 
        //          if(mynwkConfig.setFlag)
        //          {          
        //            if( mynwkConfig.XpanID != _NIB.nwkPanId || mynwkConfig.Xchannel != _NIB.nwkLogicalChannel)
        //            {
        //             
        //                (mynwkConfig.setFlag)--;
        //                HalFlashErase(NetWorkInitAdrr / (HAL_FLASH_PAGE_SIZE ));
        //                HalFlashWrite(NetWorkInitAdrr/HAL_FLASH_WORD_SIZE, (uint8*)&mynwkConfig, sizeof(mynwkConfig));  
        //                setNwkParameter(mynwkConfig.XpanID,mynwkConfig.Xchannel,mynwkConfig.XchannelList); 
        //                osal_start_timerEx( SampleApp_TaskID,SAMPLEAPP_RESET_EVT,SAMPLEAPP_RESET_TIMEOUT );
        //            }
        //          }
        
        break;
      default:
        break;
      }
      // Release the memory
      osal_msg_deallocate( (uint8 *)MSGpkt );
      
      // Next - if one is available
      MSGpkt = (afIncomingMSGPacket_t *)osal_msg_receive( SampleApp_TaskID );
    }
    // return unprocessed events
    return (events ^ SYS_EVENT_MSG);
  }
  else if(events & KEY_TIEM_MSG_EVT)
  {
    // SampleApp_SendPeriodicMessage();  
    //    KEY_FLASH_CLR(keyValue);
#if 1
    
    //�����尴��
    /*  P0SEL &= ~0x1; 
    P0DIR &= ~0x01;  
    keyValue = P0_1;*/
    
    //�װ尴��
    /*   P1SEL &= ~0x2; 
    P1DIR &= ~0x02;  
    keyValue = P1_1;*/
    
    //��������P2_2DC
    P2SEL &= ~0x4; 
    P2DIR &= ~0x04;  
    keyValue = P2_2;  
    if(keyValue==0x00)//�����������
    {
      //        zgWriteStartupOptions(ZG_STARTUP_SET, ZCD_STARTOPT_DEFAULT_NETWORK_STATE);//�����ŵ�ʱ����ʹ�ã����ϵ����Σ�Ȼ����ע�͵���
      //        SystemReset();
    }
#endif
    osal_start_timerEx( SampleApp_TaskID, KEY_TIEM_MSG_EVT,
                       (KEY_TIEM_MSG_TIMEOUT + (osal_rand() & 0x0f)) );
    // return unprocessed events
    return (events ^ KEY_TIEM_MSG_EVT);
  }
  else if(events & SAMPLEAPP_SYS_RESET_SOFT)
  {
    if(mynwkConfig.setFlag !=0 )
    {
      mynwkConfig.setFlag--;
    }
    
    HalFlashErase(NetWorkInitAdrr / (HAL_FLASH_PAGE_SIZE ));
    HalFlashWrite(NetWorkInitAdrr/HAL_FLASH_WORD_SIZE, (uint8*)&mynwkConfig, sizeof(mynwkConfig)); 
    
    HAL_SYSTEM_RESET();     //����ϵͳ
    //    return (events ^ SAMPLEAPP_SYS_RESET_SOFT);
  }
  
  
  // Discard unknown events
  return 0;
}

/********************************************
//�ѴӴ��ڽ��յ�������ͨ�����߷�ʽ���ͳ�ȥ
*********************************************/
void SampleApp_SendSerailDataToOTA(UART_Rec_t *pkt)
{
  char tmpstr[50]={0};
  char res[18]={0};
#if DEBUG_PRINT_EN
  sprintf(tmpstr,"receive data from uart\n");     
  HalUARTWrite(0,(uint8*)tmpstr,strlen(tmpstr));
#endif
  
  uint16 modulesAddr; // range:0-254,255������ �̵�ַ
  // static char rec;
  // uint16 i;
  //==================Э��������======================
  if (zgDeviceLogicalType == ZG_DEVICETYPE_COORDINATOR)  // ���ݷ��͵�Э�������ڣ�Э�������߷����ն�
  {
    if (pkt->hdr.status>=14) //
    {
      // modulesAddr = pkt->data[7]; // �ն�ID��8λ
      modulesAddr= ((uint16)pkt->data[8])<<8;
      modulesAddr += ((uint16)pkt->data[7]);          
      if (pkt->data[0] == MAST_TO_DEV_FRAME_SOP1 && pkt->data[1] == MAST_TO_DEV_FRAME_SOP2)//֡��ʼsop1,sop2 ���յ�������AA55
      {
#if MyDebug
        sprintf(tmpstr,"SEND MODE\n");   
        HalUARTWrite(0,(uint8*)tmpstr,strlen(tmpstr));
#endif
        
        switch(pkt->data[11]) 
        {
        case 0x25:
          //-----------------�㲥����------------------------------------
          if (modulesAddr == 0xFFFF) //�㲥
          {                 
            if ( AF_DataRequest( &SampleApp_Mast_To_Dev_Broadcast_DstAddr, &SampleApp_epDesc,
                                SAMPLEAPP_MAST_TO_DEV_CLUSTERID_DATA,
                                pkt->hdr.status,
                                (uint8*)&pkt->data,
                                &SampleApp_TransID,
                                AF_DISCV_ROUTE,
                                AF_DEFAULT_RADIUS ) == afStatus_SUCCESS )
            {
            }
            else
            {
              // Error occurred in request to send.
#if DEBUG_PRINT_EN ==0
              HalUARTWrite(PRINT_UART_PORT,"mast to dev error\n", sizeof("mast to dev error\n"));//��ʾ��Ϣ
#endif
            }
          }
          break;
        case 0x35://�������ýڵ������������
          //-----------------�ǹ㲥����----------------------------------
          {
#if MyDebug
            sprintf(tmpstr,"get single node set\n");   
            HalUARTWrite(0,(uint8*)tmpstr,strlen(tmpstr));
#endif          
            SampleApp_Mast_To_Dev_DstAddr.addr.shortAddr = ((uint16)pkt->data[8])<<8;
            SampleApp_Mast_To_Dev_DstAddr.addr.shortAddr += ((uint16)pkt->data[7]);
            
            if (SampleApp_Mast_To_Dev_DstAddr.addr.shortAddr!=0) //�Ѿ�����ӳ��ͷ��ͣ�û��ӳ�䲻����
            {           
              if ( AF_DataRequest( &SampleApp_Mast_To_Dev_DstAddr, &SampleApp_epDesc,
                                  SAMPLEAPP_MAST_TO_DEV_CLUSTERID_DATA,
                                  pkt->hdr.status, 
                                  (uint8*)&pkt->data,
                                  &SampleApp_TransID,
                                  AF_DISCV_ROUTE,
                                  AF_DEFAULT_RADIUS ) == afStatus_SUCCESS )
              {
#if  0
                HalUARTWrite(PRINT_UART_PORT,"mast to dev ok\n", sizeof("mast to dev ok\n"));//��ʾ��Ϣ
#endif
                
              }
              else
              {
                // Error occurred in request to send.
#if DEBUG_PRINT_EN == 0
                HalUARTWrite(PRINT_UART_PORT,"mast to dev error\n", sizeof("mast to dev error\n"));//��ʾ��Ϣ
#endif
              }
            }        
          }
          break;
          
        case 0x15: //�յ���������Э���������������
          {
#if MyDebug
            sprintf(tmpstr,"got coordinator set\r\n");   
            HalUARTWrite(0,(uint8*)tmpstr,strlen(tmpstr));
#endif          
            res[0]=0x55;
            res[1]=0xaa;
            res[2]=0x01;
            res[11]=0x45;
            res[12]=0x02;//len��������������֡
            res[17]=XorParity((uint8*)res,sizeof(res)-1);
            HalUARTWrite(0,(uint8*)res,sizeof(res));
            //          char str[64]={0};
            //���������ŵ�
            mynwkConfig.Xchannel = (uint8)pkt->data[14];
            
            //��������PAN ID
            mynwkConfig.XpanID = BUILD_UINT16(pkt->data[15], pkt->data[16]);   
            
            mynwkConfig.XchannelList = BUILD_UINT32(mychannel[pkt->data[14]-11][0], 
                                                    mychannel[pkt->data[14]-11][1], 
                                                    mychannel[pkt->data[14]-11][2], 
                                                    mychannel[pkt->data[14]-11][3]);
            
            //          sprintf(str,"Cha:%x panid:%x over\r\n",mynwkConfig.Xchannel, mynwkConfig.XpanID);     
            //          HalUARTWrite(0,(uint8*)str,32);
            
            mynwkConfig.setFlag=2;
            HalFlashErase(NetWorkInitAdrr / (HAL_FLASH_PAGE_SIZE ));
            HalFlashWrite(NetWorkInitAdrr/HAL_FLASH_WORD_SIZE, (uint8*)&mynwkConfig, sizeof(mynwkConfig));           
            
          }
          break;
        case 0x65:
          //���ز�ѯЭ����zigbeeƵ�μ�panid��Ϣ
          res[0]=0x55;
          res[1]=0xaa;
          res[2]=0x01;
          res[11]=0x66;
          res[12]=0x02;//len��������������֡
          res[14]=mynwkConfig.Xchannel;
          res[15]=mynwkConfig.XpanID;
          res[16]=mynwkConfig.XpanID >> 8;
          res[17]=XorParity((uint8*)res,sizeof(res)-1);
          HalUARTWrite(0,(uint8*)res,sizeof(res));
          break;
        default: //��ͨ������������������
          {
#if MyDebug
            sprintf(tmpstr,"NORMAL SEND\n");   
            HalUARTWrite(0,(uint8*)tmpstr,strlen(tmpstr));
#endif
            //��ȡ�̵�ַ
            //          SampleApp_Mast_To_Dev_DstAddr.addr.shortAddr = gModuleToNetAddr[modulesAddr];
            SampleApp_Mast_To_Dev_DstAddr.addr.shortAddr = ((uint16)pkt->data[8])<<8;
            SampleApp_Mast_To_Dev_DstAddr.addr.shortAddr += ((uint16)pkt->data[7]);
            
            if (SampleApp_Mast_To_Dev_DstAddr.addr.shortAddr!=0) //�Ѿ�����ӳ��ͷ��ͣ�û��ӳ�䲻����
            {           
              if ( AF_DataRequest( &SampleApp_Mast_To_Dev_DstAddr, &SampleApp_epDesc,
                                  SAMPLEAPP_MAST_TO_DEV_CLUSTERID_DATA,
                                  pkt->hdr.status, 
                                  (uint8*)&pkt->data,
                                  &SampleApp_TransID,
                                  AF_DISCV_ROUTE,
                                  AF_DEFAULT_RADIUS ) == afStatus_SUCCESS )
              {
#if  0
                HalUARTWrite(PRINT_UART_PORT,"mast to dev ok\n", sizeof("mast to dev ok\n"));//��ʾ��Ϣ
#endif
                
              }
              else
              {
                // Error occurred in request to send.
#if DEBUG_PRINT_EN == 0
                HalUARTWrite(PRINT_UART_PORT,"mast to dev error\n", sizeof("mast to dev error\n"));//��ʾ��Ϣ
#endif
              }
            }
          }
          break;
        }
          
        }
      }
    }
    //==================·��������======================
    else
    {
      //-----------------����ģ��ID-------------------------
      if (pkt->hdr.status == 3) //����Ϊ3�ֽ�
      {
        if (pkt->data[0] == 0xA5 && pkt->data[2] == 0x5A && pkt->data[1] < 0xFF)
        {
          if (gDevModuleAddr != pkt->data[1])//��ַ��ԭ�ȱ����ַ��һ��
          {
            gDevModuleAddr = pkt->data[1];
            SampleApp_DevSendModuleAddrToMast(gDevModuleAddr);
          }
        }
      }
      //--------------------�û�����----------------------
      else
      {
        if (pkt->hdr.status >= 14 && pkt->data[0] == DEV_TO_MAST_FRAME_SOP1 && pkt->data[1] == DEV_TO_MAST_FRAME_SOP2)
        {
          gDevModuleAddr = pkt->data[3];// �ն�ID��8λ
        }
        if ( AF_DataRequest( &SampleApp_Dev_To_Mast_DstAddr, &SampleApp_epDesc,
                            SAMPLEAPP_DEV_TO_MAST_CLUSTERID_DATA,
                            pkt->hdr.status,
                            (uint8*)&pkt->data,
                            &SampleApp_TransID,
                            AF_DISCV_ROUTE,
                            AF_DEFAULT_RADIUS ) == afStatus_SUCCESS )
        {
        }
        else
        {
          // Error occurred in request to send.
#if DEBUG_PRINT_EN == 1
          HalUARTWrite(PRINT_UART_PORT,"dev to mast error\n", sizeof("dev to mast error\n"));//��ʾ��Ϣ
#endif
        }
      }
    }
  } 
  //�ڵ㷢���Լ���ģ���ַ������(Э����)
  void SampleApp_DevSendModuleAddrToMast(uint8 moduleAddr)
  {
    if ( AF_DataRequest( &SampleApp_Dev_To_Mast_DstAddr, &SampleApp_epDesc,
                        SAMPLEAPP_DEV_TO_MAST_CLUSTERID_ADDR,
                        1,
                        &moduleAddr,
                        &SampleApp_TransID,
                        AF_DISCV_ROUTE,
                        AF_DEFAULT_RADIUS ) == afStatus_SUCCESS )
    {
    }
    else
    {
      // Error occurred in request to send.
#if DEBUG_PRINT_EN == 1
      HalUARTWrite(PRINT_UART_PORT,"dev to mast error\n", sizeof("dev to mast error\n"));//��ʾ��Ϣ
#endif
    }
  }
  
  //�������ù㲥��ʽѯ�����нڵ��ģ���ַ
  void SampleApp_MastReqDevModuleAddr(void)
  {  
    if ( AF_DataRequest( &SampleApp_Mast_To_Dev_Broadcast_DstAddr, &SampleApp_epDesc,
                        SAMPLEAPP_MAST_TO_DEV_CLUSTERID_ADDR_REQ,
                        0,
                        NULL,
                        &SampleApp_TransID,
                        AF_DISCV_ROUTE,
                        AF_DEFAULT_RADIUS ) == afStatus_SUCCESS )
    {
    }
    else
    {
      // Error occurred in request to send.
#if DEBUG_PRINT_EN == 1
      HalUARTWrite(PRINT_UART_PORT,"mast to dev error\n", sizeof("mast to dev error\n"));//��ʾ��Ϣ
#endif
    }
  }
  /*********************************************************************
  * LOCAL FUNCTIONS
  */
  
  /*********************************************************************
  * @fn      SampleApp_MessageMSGCB
  *
  * @brief   Data message processor callback.  This function processes
  *          any incoming data - probably from other devices.  So, based
  *          on cluster ID, perform the intended action.
  *
  * @param   none
  *
  * @return  none
  */
  void SampleApp_MessageMSGCB( afIncomingMSGPacket_t *pkt ) //���߽�������
  { 
    // char str[20];
    //  uint32 i=0;
    uint8 keyValue;
    uint8 moduleAddr;
    uint8 CRC;
    switch ( pkt->clusterId)
    {
    case SAMPLEAPP_MAST_TO_DEV_CLUSTERID_DATA:  //�������ߵĶ�Ҫת��������
      HalUARTWrite(MY_DEFINE_UART_PORT, pkt->cmd.Data, pkt->cmd.DataLength);
      break;
    case SAMPLEAPP_DEV_TO_MAST_CLUSTERID_DATA:
      if ((pkt->cmd.DataLength >= 14)  &&  (pkt->cmd.Data[0] == DEV_TO_MAST_FRAME_SOP1 && pkt->cmd.Data[1] == DEV_TO_MAST_FRAME_SOP2)) //�ж�֡����ĳ��ֵ
      {
        CRC = XorParity(&pkt->cmd.Data[0],pkt->cmd.DataLength-1);
        if (pkt->cmd.Data[pkt->cmd.DataLength-1] == CRC )//֡��ʼsop1,sop2
        {
          //ÿ�ζ������ն˵�ģ���ַ
          //moduleAddr = pkt->cmd.Data[3]; // �ն�ID��8λ
          //SampleApp_MastUpdateModuleAddr(gModuleToNetAddr, moduleAddr, pkt->srcAddr.addr.shortAddr);
          pkt->cmd.Data[7]  = (uint8)(pkt->srcAddr.addr.shortAddr);
          pkt->cmd.Data[8]  = (uint8)(pkt->srcAddr.addr.shortAddr>>8);
          pkt->cmd.Data[9] = 0;
          pkt->cmd.Data[10] = 0;          
          pkt->cmd.Data[pkt->cmd.DataLength-1] = XorParity(&pkt->cmd.Data[0],pkt->cmd.DataLength-1);
          
#if Signal_Strength
          show_RSSI(pkt);
#else  
#endif          
          //-----------8.22�����������÷�����Ϣ----------------
          if(pkt->cmd.Data[11]==0x85)//�ڵ�����������Ϣ�·����سɹ�
          {
            HalUARTWrite(MY_DEFINE_UART_PORT,"nwkSet send arrived\n",strlen("nwkSet send arrived\n"));
          }
          
          //-----------8.22�����������÷�����Ϣ----------------          
          HalUARTWrite(MY_DEFINE_UART_PORT, pkt->cmd.Data, pkt->cmd.DataLength);//���͸�����        
          
          /*         if( (pkt->cmd.Data[3]==0x30)  && (pkt->cmd.Data[4]==0x00))
          {
          HalUARTWrite(MY_DEFINE_UART_PORT, pkt->cmd.Data, pkt->cmd.DataLength);
        }
          if( (pkt->cmd.Data[3]==0x23)  && (pkt->cmd.Data[4]==0x00))
          {
          HalUARTWrite(MY_DEFINE_UART_PORT, pkt->cmd.Data, pkt->cmd.DataLength);
        }*/
#if 1
          ////////////
          //��������P2_2DC
          P2SEL &= ~0x4; 
          P2DIR &= ~0x04;  
          keyValue = P2_2;  
          if(keyValue==0x00)//�����������
          {
            /////////////
            if(pkt->cmd.Data[11]==0x0e)//
            {
              pkt->cmd.Data[0]=0xaa;
              pkt->cmd.Data[1]=0x55;            
              pkt->cmd.Data[14]=0x01;
              pkt->cmd.Data[15]=60;//�ж����޳��ķ�ֵ
              pkt->cmd.Data[pkt->cmd.DataLength-1] = XorParity( &pkt->cmd.Data[0],pkt->cmd.DataLength-1);
              SampleApp_Mast_To_Dev_DstAddr.addr.shortAddr =  pkt->srcAddr.addr.shortAddr;//gModuleToNetAddr[ pkt->cmd.Data[7]];
              if (SampleApp_Mast_To_Dev_DstAddr.addr.shortAddr!=0) //�Ѿ�����ӳ��ͷ��ͣ�û��ӳ�䲻����
              {
                if ( AF_DataRequest( &SampleApp_Mast_To_Dev_DstAddr, &SampleApp_epDesc,
                                    SAMPLEAPP_MAST_TO_DEV_CLUSTERID_DATA,
                                    pkt->cmd.DataLength, 
                                    (uint8*)  pkt->cmd.Data,
                                    &SampleApp_TransID,
                                    AF_DISCV_ROUTE,
                                    AF_DEFAULT_RADIUS ) == afStatus_SUCCESS )
                {
                  //              HalUARTWrite(PRINT_UART_PORT,"mast to dev ok\n", sizeof("mast to dev ok\n"));//��ʾ��Ϣ
                }
                else
                {
                  // Error occurred in request to send.
#if DEBUG_PRINT_EN == 1
                  HalUARTWrite(PRINT_UART_PORT,"mast to dev error\n", sizeof("mast to dev error\n"));//��ʾ��Ϣ
#endif
                }
              }
            } 
          }
#endif            
        }
      }         
      break;
    case SAMPLEAPP_DEV_TO_MAST_CLUSTERID_ADDR: //�������յ��ն˷������ĵ�ַ
      moduleAddr = pkt->cmd.Data[0];
      //     SampleApp_MastUpdateModuleAddr(gModuleToNetAddr, moduleAddr, pkt->srcAddr.addr.shortAddr);
#if DEBUG_PRINT_EN == 1
      sprintf(str,"M:%d,N:%d\n",moduleAddr,gModuleToNetAddr[moduleAddr]);
      HalUARTWrite(PRINT_UART_PORT,str, strlen(str));
#endif
      break;
    case SAMPLEAPP_MAST_TO_DEV_CLUSTERID_ADDR_REQ: //�ն˽��յ�����Ⱥ����ѯ�豸��ַ������
      if (gDevModuleAddr != 0)
      {
        //        SampleApp_DevSendModuleAddrToMast(gDevModuleAddr);
      }
      break;
    default:
      break;
    }
  }
  
  void SampleApp_MastUpdateModuleAddr(uint16 *moduleToNetAddr, uint8 moduleAddr, uint16 shortAddr)
  {
    uint16 i;
    if (moduleAddr < 0xFF && moduleAddr < MAX_MODULE_ADDR_NUM) //0xFFΪ�㲥��ַ������Ϊģ���ַ,����������ַӳ��
    {
      if (moduleToNetAddr[moduleAddr] != shortAddr) //��ַ��Ҫ���
      {
        for (i = 0; i<MAX_MODULE_ADDR_NUM; i++) //��ԭ���ĵ�ַ����
        {
          if (moduleToNetAddr[i] == shortAddr)
          {
            moduleToNetAddr[i] = 0;
          }
        }
        moduleToNetAddr[moduleAddr] = shortAddr;
      }
    }
  }
  /*********************************************************************
  *********************************************************************/
  uint8 XorParity(uint8 *p,uint16 len)
  {
    uint8 parity;
    uint8 i;
    parity = p[0];
    for(i=1;i<len;i++)
    {
      parity ^=p[i];   
    }
    return(parity);
  }
  
  /************���ڴ�ӡ�ź�ǿ��***************/
  void show_RSSI(afIncomingMSGPacket_t *pkt)
  {
    float lqi=0.0;
    char rssi_buf[24]={0};
    
    sprintf(rssi_buf,"RSSI:%ddbm ",pkt->rssi);     //��������ʱ��RSSI�ź�ǿ��
    HalUARTWrite(MY_DEFINE_UART_PORT,(uint8 *)rssi_buf,strlen(rssi_buf));
    
    lqi = -(81-((int)(pkt->LinkQuality)*91/255));   //ͨ����·����ź�ǿ��
    sprintf(rssi_buf,"LQI:%.0fdbm ",lqi);
    HalUARTWrite(MY_DEFINE_UART_PORT,(uint8 *)rssi_buf,strlen(rssi_buf)); 
    
    sprintf(rssi_buf,"ID:0x%x%x%x%x\n",pkt->cmd.Data[6],pkt->cmd.Data[5],pkt->cmd.Data[4],pkt->cmd.Data[3]);
    HalUARTWrite(MY_DEFINE_UART_PORT,(uint8 *)rssi_buf,strlen(rssi_buf)); 
  }
  
  
  
  
  
  
  