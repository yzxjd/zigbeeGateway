/**************************************************************************************************
  Filename:       SampleApp.h
  Revised:        $Date: 2007-10-27 17:22:23 -0700 (Sat, 27 Oct 2007) $
  Revision:       $Revision: 15795 $

  Description:    This file contains the Sample Application definitions.


  Copyright 2007 Texas Instruments Incorporated. All rights reserved.

  IMPORTANT: Your use of this Software is limited to those specific rights
  granted under the terms of a software license agreement between the user
  who downloaded the software, his/her employer (which must be your employer)
  and Texas Instruments Incorporated (the "License").  You may not use this
  Software unless you agree to abide by the terms of the License. The License
  limits your use, and you acknowledge, that the Software may not be modified,
  copied or distributed unless embedded on a Texas Instruments microcontroller
  or used solely and exclusively in conjunction with a Texas Instruments radio
  frequency transceiver, which is integrated into your product.  Other than for
  the foregoing purpose, you may not use, reproduce, copy, prepare derivative
  works of, modify, distribute, perform, display or sell this Software and/or
  its documentation for any purpose.

  YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE
  PROVIDED �AS IS?WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, 
  INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE, 
  NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL
  TEXAS INSTRUMENTS OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT,
  NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER
  LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
  INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE
  OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT
  OF SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
  (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

  Should you have any questions regarding your right to use this Software,
  contact Texas Instruments Incorporated at www.TI.com. 
**************************************************************************************************/

#ifndef SAMPLEAPP_H
#define SAMPLEAPP_H

#ifdef __cplusplus
extern "C"
{
#endif

/*********************************************************************
 * INCLUDES
 */
#include "ZComDef.h"
#include "osal.h"
/*********************************************************************
 * CONSTANTS
 */

#define ZIGBEE_MODEL_TYP  1   //0;Ϊ�����⹺ģ�飬1Ϊ��ɳ�⹺ģ�� 2�����ڻ���΢ģ��(ֻ��һ����Ʒ) 
#define MyDebug           0   //0���ر��ŵ����ô�ӡ��Ϣ�� 1�������ŵ����ô�ӡ��Ϣ
#define Signal_Strength   0   //1���Դ��ڴ�ӡ�ڵ㷢�����ݺ���ź�ǿ�ȣ�0���θù���  
#define Security_Enable   0   //�豸�Ƿ���ܣ�1������  0���ر�  �������������豸����Э�������뿪������

   
#define NetWorkInitAdrr   0x3b800//     ���ڴ洢�������ò�������ͨ��Ƶ���ŵ���PANID   
// These constants are only for example and should be changed to the
// device's needs
#define SAMPLEAPP_ENDPOINT           20
#define SAMPLEAPP_PROFID             0x0F08
#define SAMPLEAPP_DEVICEID           0x0001
#define SAMPLEAPP_DEVICE_VERSION     0
#define SAMPLEAPP_FLAGS              0

#define SAMPLEAPP_MAX_CLUSTERS       2
#define SAMPLEAPP_COM_CLUSTERID      1
#define SAMPLEAPP_DEV_TO_MAST_CLUSTERID_DATA 2  //�ն˷��͸������û�����
#define SAMPLEAPP_MAST_TO_DEV_CLUSTERID_DATA 3 //�������͸��ն��û�����
#define SAMPLEAPP_DEV_TO_MAST_CLUSTERID_ADDR 4  //�ն˷��͸�������ַ����
#define SAMPLEAPP_MAST_TO_DEV_CLUSTERID_ADDR_REQ 5

#define KEY_TIEM_MSG_TIMEOUT       100    //100MS��ʱ


#define SAMPLEAPP_GROUP_ADDR 1

// Send Message Timeout
#define SAMPLEAPP_SEND_PERIODIC_MSG_TIMEOUT   500     // Every 1 ms
    
// Application Events (OSAL) - These are bit weighted definitions.
#define SAMPLEAPP_SEND_PERIODIC_MSG_EVT       0x0001

  
#define KEY_FLASH_CLR(val)   {P2SEL &= ~0x1; P2DIR = ~0x01;  val = P2_0;}//P2_0��ΪFLASH����������
  

/*********************************************************************
 * TYPEDEFS
 */
 /*
typedef struct
{
  uint16 moduleAddr; 
}SAMPLEAPP_ModuleAddr_t;
*/
typedef struct
{
  osal_event_hdr_t hdr;
  uint16 moduleAddr;
}SAMPLEAPP_ModuleAddr_t;

/*********************************************************************
 * MACROS
 */

/*********************************************************************
 * FUNCTIONS
 */

/*
 * Task Initialization for the Generic Application
 */
extern void SampleApp_Init( uint8 task_id );

/*
 * Task Event Processor for the Generic Application
 */
extern UINT16 SampleApp_ProcessEvent( uint8 task_id, uint16 events );

/*********************************************************************
*********************************************************************/


extern uint8 SampleApp_TaskID;   // Task ID for internal task/event processing
                          // This variable will be received when
                          // SampleApp_Init() is called.
					
#ifdef __cplusplus
}
#endif

#endif /* SAMPLEAPP_H */
