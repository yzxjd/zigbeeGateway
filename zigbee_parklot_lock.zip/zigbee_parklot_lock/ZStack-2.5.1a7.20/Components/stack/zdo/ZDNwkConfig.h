#ifndef __ZDNwkConfig_H__
#define __ZDNwkConfig_H__

#include "hal_types.h"
#include "hal_mcu.h"
#include "hal_adc.h"
#include "hal_flash.h"
#include "hal_types.h"
#include "OSAL_Nv.h"
#include "ZComDef.h"
#include "hal_uart.h"
#include "NLMEDE.h"
#include "hal_defs.h"
#include "ZDApp.h"
#include "ZComDef.h"
#include "nwk.h"
#include "comdef.h"
#include <stdio.h>
#include <string.h>


typedef struct myNetConfigure
{
  uint8 setFlag;    //0,1,2
  uint8 Xchannel;
  uint16 XpanID;
  uint32 XchannelList;
  uint32 setSlaveID;
}MY_NETWORKCONFIGURE;

extern char mychannel[16][4];
//extern MY_NETWORKCONFIGURE mynwkConfig;
extern void setNwkParameter(uint16 pan_id, uint8 channel ,uint32 chanlist);
extern void changeNwkFunction(uint16 pan_id, uint8 channel);


#endif


