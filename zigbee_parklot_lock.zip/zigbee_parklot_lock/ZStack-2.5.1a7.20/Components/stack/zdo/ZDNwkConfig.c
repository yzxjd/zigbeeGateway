#include "ZDNwkConfig.h"
#include "SampleApp.h"
#include "OSAL_Timers.h"
#include "hal_sleep.h"
#include "comdef.h"
//MY_NETWORKCONFIGURE mynwkConfig;
extern uint8 SampleApp_TaskID;
char mychannel[16][4]=
{ 
//  0x01,0x00,0x00,0x00,//         0      : 868 MHz     0x00000001                0
//  0xfe,0x07,0x00,0x00,//         1 - 10 : 915 MHz     0x000007FE                1
  0x00,0x08,0x00,0x00,//-DDEFAULT_CHANLIST=0x00000800  // 11 - 0x0B //(1-13)    2
  0x00,0x10,0x00,0x00,//-DDEFAULT_CHANLIST=0x00001000    // 12 - 0x0C           3
  0x00,0x20,0x00,0x00,//-DDEFAULT_CHANLIST=0x00002000  // 13 - 0x0D //(14-62)   4
  0x00,0x40,0x00,0x00,//-DDEFAULT_CHANLIST=0x00004000  // 14 - 0x0E             5
  0x00,0x80,0x00,0x00,//-DDEFAULT_CHANLIST=0x00008000  // 15 - 0x0F //(63-111)  6
  0x00,0x00,0x01,0x00,//-DDEFAULT_CHANLIST=0x00010000  // 16 - 0x10             7
  0x00,0x00,0x02,0x00,//-DDEFAULT_CHANLIST=0x00020000  // 17 - 0x11 //(112-151) 8
  0x00,0x00,0x04,0x00,//-DDEFAULT_CHANLIST=0x00040000  // 18 - 0x12             9
  0x00,0x00,0x08,0x00,//-DDEFAULT_CHANLIST=0x00080000  // 19 - 0x13 //(152-172) 10
  0x00,0x00,0x10,0x00,//-DDEFAULT_CHANLIST=0x00100000  // 20 - 0x14             11
  0x00,0x00,0x20,0x00,//-DDEFAULT_CHANLIST=0x00200000  // 21 - 0x15//(173-180)  12
  0x00,0x00,0x40,0x00,//-DDEFAULT_CHANLIST=0x00400000  // 22 - 0x16             13
  0x00,0x00,0x80,0x00,//-DDEFAULT_CHANLIST=0x00800000  // 23 - 0x17//(180-199)  14
  0x00,0x00,0x00,0x01,//-DDEFAULT_CHANLIST=0x01000000  // 24 - 0x18             15
  0x00,0x00,0x00,0x02,//-DDEFAULT_CHANLIST=0x02000000  // 25 - 0x19             16
  0x00,0x00,0x00,0x04,//-DDEFAULT_CHANLIST=0x04000000    // 26 - 0x1A           17
//  0x00,0xf8,0xff,0x07,//-DMAX_CHANNELS_24GHZ      0x07FFF800                    18
};//00 & 80<<8 & 00<<16 & 00<<24==0x00008000 

//void setNwkParameter(uint16 pan_id, uint8 *channel)
//{ 
//  uint8 set_panid,set_channel;
//  uint32 tmp32 = BUILD_UINT32(channel[0], channel[1], channel[2], channel[3]);
//  _NIB.nwkLogicalChannel = tmp32;
//  _NIB.nwkPanId = pan_id;//����Ҫ��ID
//
//  osal_nv_item_init(ZCD_NV_PANID , sizeof(uint16) , NULL); 
//  set_panid = osal_nv_write( ZCD_NV_PANID , 0 , sizeof(uint16) , &_NIB.nwkPanId);   //дFlash�к�PANID�洢�йصĲ���
//  set_channel= osal_nv_write(ZCD_NV_CHANLIST, 0, osal_nv_item_len( ZCD_NV_CHANLIST ), &tmp32);
//               
//  NLME_RestoreFromNV();//������Ż������µ�PAN_ID����Ȼֻ���޸���NV��������ݡ�
//  if((set_panid == ZSUCCESS) && (set_channel == ZSUCCESS) )
//  {
//    NLME_UpdateNV(0x01);    //ָʾ������������Ϣд��Flash��
//    HAL_SYSTEM_RESET();     //����ϵͳ
//  }
//}
//
//
//
//void changeNwkFunction(uint16 pan_id, uint8 channel)
//{
//  char str[50]={0};
//  sprintf(str,"nwkPanId:%x nwkLogicalChannel:%x\r\n",_NIB.nwkPanId, _NIB.nwkLogicalChannel);
//  HalUARTWrite(0,str,strlen(str));
//  if(_NIB.nwkPanId!=pan_id)
//  {
//    setNwkParameter(pan_id,(uint8 *)mychannel[channel]);
//  }
//  sprintf(str,"nwkPanId:%x nwkLogicalChannel:%x\r\n",_NIB.nwkPanId, _NIB.nwkLogicalChannel);
//  HalUARTWrite(0,str,strlen(str));
//}

void setNwkParameter(uint16 pan_id, uint8 channel ,uint32 chanlist)
{ 
  uint8 set_panid,set_channel;
  
  _NIB.channelList = chanlist;      //����ɨ����ŵ�
  _NIB.nwkLogicalChannel = channel; //����ʹ�õ��߼��ŵ� 
  _NIB.nwkPanId = pan_id;           //����Ҫ��PANID
   
  osal_nv_item_init(ZCD_NV_PANID , osal_nv_item_len(ZCD_NV_PANID) , NULL); 
  set_panid = osal_nv_write( ZCD_NV_PANID , 0 , osal_nv_item_len(ZCD_NV_PANID) , &_NIB.nwkPanId);   //дFlash�к�PANID�洢�йصĲ���
  
  osal_nv_item_init(ZCD_NV_CHANLIST , osal_nv_item_len(ZCD_NV_CHANLIST) , NULL); 
  set_channel= osal_nv_write(ZCD_NV_CHANLIST, 0, osal_nv_item_len( ZCD_NV_CHANLIST ), &chanlist);
  NLME_RestoreFromNV();//������Ż������µ�PAN_ID����Ȼֻ���޸���NV��������ݡ�             
  
  if((set_panid == ZSUCCESS) && (set_channel == ZSUCCESS) )
  {
    NLME_UpdateNV(0x01);    //ָʾ������������Ϣд��Flash��
 //   halSleep(3000);
    osal_start_timerEx( SampleApp_TaskID, SAMPLEAPP_SYS_RESET_SOFT, 3000);//����һ������5S������
 //   HAL_SYSTEM_RESET();     //����ϵͳ
  }
}


