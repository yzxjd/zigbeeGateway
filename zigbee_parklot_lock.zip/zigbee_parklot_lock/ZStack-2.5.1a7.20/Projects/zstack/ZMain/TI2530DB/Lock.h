#ifndef __LOCK__H
#define __LOCK__H

void LockInit(void);
//void LockOpen(void);
//void LockClose(void) ;
void LockStop(unsigned char flag);
char  LockCheckPoll(void);
char StatusKeepPollProcess(void);   // ���״̬ά��
//////////

void my_printf(uint8 *p);

void ParkingReservationMainLoop(void);//��������  
void feelDog(void);
uint16 ReadVolDataC( void );
void InitKey(void);
unsigned char KeyScan(void);
void ledEnableCheck(void);

#endif