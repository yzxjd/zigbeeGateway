#include "spi.h"
#include "hal_uart.h"
#include "SampleApp.h"

void SpiInit(void)//��ʼ��
{
#if 0
  P2SEL &= ~BV(1);//CS  P21
  P2SEL &= ~BV(0);//FCS  P20
  P1SEL &= ~BV(4);//SCL P14 
  P1SEL &= ~BV(5);//SDA P15
 
  //  P1DIR |= BV(4);//���,���IO��Ҫ��
  SDA_OUT();//SDA���
  

  P1DIR |= BV(4);//SCL���
  P2DIR |= BV(1);//CS���
  P2DIR |= BV(0); //FCS��� 
  
  RFM_SDA = 1;
  RFM_CS = 1;
  RFM_FCS = 1;//
  RFM_SCL = 0; 
#endif

#if 1
  P2SEL &= ~BV(0);//CS  P20
  P2SEL &= ~BV(2);//SCL P22 
  P2SEL &= ~BV(1);//SDA P21
  
#if (ZIGBEE_MODEL_TYP==0)  
  P1SEL &= ~BV(4);//FCS P14
  P1DIR |= BV(4); //FCS��� 
#elif(ZIGBEE_MODEL_TYP==1)  
  P1SEL &= ~BV(3);//FCS P14
  P1DIR |= BV(3); //FCS���   
#endif
  //  P1DIR |= BV(4);//���,���IO��Ҫ��
  SDA_OUT();//SDA���
  P2DIR |= BV(2);//SCL���
  P2DIR |= BV(0);//CS���
  
  RFM_SDA = 1;
  RFM_CS = 1;
  RFM_FCS = 1;//
  RFM_SCL = 0; 
#endif  
}

void SpiWriteByte(byte data)//����һ���ֽ�
{
  byte i;
  RFM_FCS =1;
  SDA_OUT();
  RFM_SDA = 1;
  
  RFM_SCL = 0;
  RFM_CS = 0;
  for(i=0;i<8;i++)
  {
    RFM_SCL = 0;
    
    //������Ҫ��ʱ��
    delay_nus(SPISPEED);
    if(data&0x80)
    {
      RFM_SDA = 1;
    }
    else
    {
      RFM_SDA = 0;
    }
    RFM_SCL = 1;
    data <<= 1;
    //������Ҫ�ӳ٣� 
    delay_nus(SPISPEED);
  }
  RFM_SCL = 0; 
  RFM_SDA = 1; 
}


byte SpiReadByte(void)//��һ���ֽ�
{
  byte Rcv = 0;
  byte i;
  
  RFM_FCS = 0;
  SDA_IN();//����

  for(i=0;i<8;i++)
  {
    RFM_SCL = 0;
    Rcv <<= 1;
    //������Ҫ�ӳ�
    delay_nus(SPISPEED);
    RFM_SCL = 1;
    //������Ҫ�ӳ�
    delay_nus(SPISPEED);
    if(RFM_SDA)
    {
      Rcv |= 1;
    }
    else
    {
      Rcv |= 0;
    }
  }
  RFM_SCL = 0;
  delay_nus(SPISPEED);
  RFM_FCS = 1;
  delay_nus(4);
  SDA_OUT();
  RFM_SDA = 1;
  RFM_CS = 1;
  
  return Rcv;
}


void SpiWrite(word data)//дһ���ֽڵ�ָ����ַ
{
  SpiWriteByte((byte)(data>>8)&0x7f);
  SpiWriteByte((byte)data);
  RFM_CS = 1;
}
byte SpiRead(byte addr)//��ָ����ַ����һ���ֽ�
{
  SpiWriteByte(addr|0x80);
  return (SpiReadByte());
}

void delay_nus(uint16 timeout)//��ʱ΢�뺯��
{
  while(timeout--)
  {
    asm("nop");
    asm("nop");
    asm("nop");
  }
  asm("nop");
}


/**********************************************************
**Name:	 	vSpi3WriteFIFO
**Func: 	SPI-3 send one byte to FIFO
**Input: 	one byte buffer
**Output:	none
**********************************************************/
void SpiWriteFIFO(byte dat)
{
  byte bitcnt;	
  
  RFM_CS = 1;	
  SDA_OUT();	
  RFM_SCL = 0;
  RFM_FCS = 0;//FCS = 0
  for(bitcnt=8; bitcnt!=0; bitcnt--)
  {
    RFM_SCL = 0;		
    if(dat&0x80)
      RFM_SDA = 1;		
    else
      RFM_SDA = 0;
    delay_nus(SPISPEED);
    RFM_SCL = 1;
    delay_nus(SPISPEED);
    dat <<= 1;
  }
  RFM_SCL = 0;	
  delay_nus(SPISPEED);		//Time-Critical
//  delay_nus(SPISPEED);		//Time-Critical
  RFM_FCS = 1;
  RFM_SDA = 1;
  delay_nus(SPISPEED);		//Time-Critical
//  delay_nus(SPISPEED);		//Time-Critical
}

/**********************************************************
**Name:	 	bSpi3ReadFIFO
**Func: 	SPI-3 read one byte to FIFO
**Input: 	none
**Output:	one byte buffer
**********************************************************/
byte SpiReadFIFO(void)
{
  byte RdPara;
  uint8 bitcnt=0;	

  RFM_CS = 1;
  SDA_IN();//����
  RFM_SCL = 0;	
  RFM_FCS = 0;	
  for(bitcnt=0; bitcnt<8; bitcnt++)
  {
    RFM_SCL = 0;	
    RdPara <<= 1;
    delay_nus(SPISPEED);
    RFM_SCL = 1;
    delay_nus(SPISPEED);
    if(RFM_SDA)
      RdPara |= 0x01;		//NRZ MSB
    else
      RdPara |= 0x00;		//NRZ MSB
  }

  
  RFM_SCL = 0;
  delay_nus(SPISPEED);		//Time-Critical
//  delay_nus(SPISPEED);		//Time-Critical
  RFM_FCS = 1;	
  SDA_OUT();	
  RFM_SDA = 1;
  delay_nus(SPISPEED);		//Time-Critical
//  delay_nus(SPISPEED);		//Time-Critical
  return(RdPara);
}

/**********************************************************
**Name:	 	vSpi3BurstWriteFIFO
**Func: 	burst wirte N byte to FIFO
**Input: 	array length & head pointer
**Output:	none
**********************************************************/
void SpiBurstWriteFIFO(byte ptr[], byte length)
{
  byte i;
  if(length!=0x00)
  {
    for(i=0;i<length;i++)
      SpiWriteFIFO(ptr[i]);
  }
  return;
}

/**********************************************************
**Name:	 	vSpiBurstRead
**Func: 	burst wirte N byte to FIFO
**Input: 	array length  & head pointer
**Output:	none
**********************************************************/
void SpiBurstReadFIFO(byte ptr[], byte length)
{
  byte i;
  if(length!=0)
  {
    for(i=0;i<length;i++)
      ptr[i] = SpiReadFIFO();   
  }	
  return;
}
