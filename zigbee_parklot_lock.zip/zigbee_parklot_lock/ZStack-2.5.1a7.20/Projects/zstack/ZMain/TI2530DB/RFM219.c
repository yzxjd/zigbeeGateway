#include "RFM219.h"
#include "hmc5883l.h"
#include "hal_uart.h"
#include <string.h>
//#include "npi.h"
//ֱ��ģʽ
#if 0
byte CfgTbl[62] = {
  0x01,
  0x21,
  0x66,
  0x66,
  0x06,
  0x00,
  0x00,
  0x00,
  0x00,
  0xA5,
  0x02,
  0x00,
  0x00,
  0x18,
  0x00,
  0x00,
  0x00,
  0x64,
  0x2F,
  0x36,
  0x20,
  0x9F,
  0x00,
  0x00,
  0x01,
  0x00,
  0x00,
  0x14,
  0x00,
  0x01,
  0x10,
  0x21,
  0x00,
  0x00,
  0x00,
  0x00,
  0x19,
  0x00,
  0x30,
  0x00,
  0xAC,
  0x56,
  0x53,
  0xD4,
  0x40,
  0x49,
  0x05,
  0x2D,
  0x18,
  0x03,
  0x10,
  0xFA,
  0x00,
  0x00,
  0x40,
  0xC0,
  0x00,
  0x00,
  0x00,
  0xEB,
  0x00,
  0x00,
};
#endif

//����+ͬ����+����
#if 1
byte CfgTbl[62] = {    			
  0x11,
  0x21,
  0x66,
  0x66,
  0x06,
  0x00,
  0x00,
  0x00,
  0x00,
  0xA2,
  0x00,
  0x00,
  0x00,
  0x28,
  0x00,
  0x00,
  0x00,
  0x64,
  0x2F,
  0x36,
  0x20,
  0x9F,
  0x00,
  0xD4,
  0x2D,
  0xAA,
  0x00,
  0xBA,
  0x01,
  0x01,
  0x04,
  0x21,
  0x00,
  0x00,
  0x00,
  0x00,
  0x19,
  0x00,
  0x30,
  0x00,
  0xAC,
  0x56,
  0x53,
  0xD4,
  0x40,
  0x49,
  0x05,
  0x2B,
  0x18,
  0x03,
  0x10,
  0xFA,
  0x00,
  0x00,
  0x40,
  0xC0,
  0x00,
  0x00,
  0x00,
  0xEB,
  0x00,
  0x00
    
};
#endif
/**********************************************************
**Name:     vGoRx
**Function: Entry Rx Mode
**Input:    none
**Output:   none
**********************************************************/
void vGoRx(void)
{
  byte tmp;
  tmp = SpiRead((byte)(OP_MODE>>8));		//��������
  tmp &= OP_MASK;
  SpiWrite(OP_MODE+tmp+OP_RX);
}

/**********************************************************
**Name:     vGoSleep
**Function: Entry Sleep Mode
**Input:    none
**Output:   none
**********************************************************/
void vGoSleep(void)
{
  byte tmp;	
  tmp = SpiRead((byte)(OP_MODE>>8));
  tmp &= OP_MASK;
  SpiWrite(OP_MODE+tmp+OP_SLEEP);
}

/**********************************************************
**Name:     vGoStandby
**Function: Entry Standby Mode
**Input:    none
**Output:   none
**********************************************************/
void vGoStandby(void)
{
  byte tmp;	
  tmp = SpiRead((byte)(OP_MODE>>8));
  tmp &= OP_MASK;
  SpiWrite(OP_MODE+tmp+OP_STANDBY);	
}

/**********************************************************
**Name:     vSoftReset
**Function: Software reset Chipset
**Input:    none
**Output:   none
**********************************************************/
void vSoftReset(void)
{
  SpiWrite(SOFT_RST); 
}

/**********************************************************
**Name:     vClearIntFlag
**Function: clear all irq flag
**Input:    none
**Output:   none
**********************************************************/
void vClearIntFlag(void)
{
  SpiWrite(INTCTL_B+0xFF);
}

/**********************************************************
**Name:     vClearFIFO
**Function: clear FIFO buffer
**Input:    none
**Output:   none
**********************************************************/
void vClearFIFO(void)
{
  byte tmp;	
  tmp = SpiRead((byte)(INTCTL_D>>8));
  SpiWrite(INTCTL_D+tmp+FIFO_CLR);
}

/**********************************************************
**Name:     bReadStatus
**Function: read chipset status
**Input:    none
**Output:   none
**********************************************************/
byte bReadStatus(void)
{
  return(0xE0&(SpiRead((byte)(OP_MODE>>8))));
}

/**********************************************************
**Name:     vInit
**Function: Init. CMT2119A
**Input:    none
**Output:   none
**********************************************************/
void vInit(byte cfg[])
{
  byte i;
  SpiInit();
  vGoSleep();					//
//  simpleBLE_Delay_1ms(10);			//����д	
//  delay_nus(10000);
  Delay5ms();
  Delay5ms();
  vGoStandby();
  
  for(i=0; i<62; i++)			//exp file have 62
    SpiWrite(((word)i<<8)|cfg[i]);
  
  vClearIntFlag();
  vGoStandby();					//����STB״̬
}

/**********************************************************
**Name:     vGpioFuncCfg
**Function: GPIO Function config
**Input:    none
**Output:   none
**********************************************************/
void vGpioFuncCfg(byte io_cfg)
{
  SpiWrite(IO_SEL+io_cfg);
}

/**********************************************************
**Name:     vIntSourceCfg
**Function: config 
**Input:    int_1, int_2
**Output:   none
**********************************************************/
void vIntSourcCfg(byte int_1, byte int_2)
{
  SpiWrite(INTCTL_A+int_2+((int_1)>>4));
}

/**********************************************************
**Name:     vEnableIntSource
**Function: enable interrupt source 
**Input:    en_int
**Output:   none
**********************************************************/
void vEnableIntSource(byte en_int)
{
  SpiWrite(INT_EN+en_int);				
}

/**********************************************************
**Name:     bReadIngFlag
**Function: Read interrupt flag(INTCTL_C)
**Input:    none
**Output:   interrupt flag
**********************************************************/
byte bReadIngFlag(void)
{
  return(SpiRead((byte)(INTCTL_C>>8)));
}	

/**********************************************************
**Name:     bReadRssi
**Function: Read Rssi
**Input:    none
**Output:   none
**********************************************************/
byte bReadRssi(void)
{
  return(SpiRead((byte)(RSSI_ADDR>>8)));
}


void setup(void)
{
  //char str[50]={0};
  vInit(CfgTbl);//����
  vGpioFuncCfg(GPIO1_POR|GPIO2_INT1|GPIO3_CLK|GPIO4_Dout);//GPIO4�����GPIO2��3�ж�
  //   vIntSourcCfg((FIFO_WBYTE+OFFSET), 0);//GPIO2�ж�
  //    vIntSourcCfg((SYNC_PS), 0);//GPIO2�ж�
  vIntSourcCfg((RX_DONE), 0);//GPIO2�ж�
  vEnableIntSource(0xFF);//�ж�ʹ��
  //   vGoSleep();//��������
  vGoRx();
  
 // sprintf(str,"RFM SET OVER\r\n");
 // HalUARTWrite(0,(uint8 *)str,strlen(str));	
  
}
/******************************************************************************
**�������ƣ�vbGetMessage
**�������ܣ�����һ������
**�����������
**���������1�������ճɹ�
**          0��������ʧ��
******************************************************************************/
//byte bGetMessage(byte msg[])
//{
// byte tmp;
// byte length=0;
// 
// 
// tmp = bReadIngFlag();
// if(CrcDisable)
// 	{
// 	if(tmp&RX_DONE_FLG)		
// 		{
// 		if(FixedPktLength)
// 			length = PktLength;
// 		else
// 			length = Spi3.bSpi3ReadFIFO();
//		Spi3.vSpi3BurstReadFIFO(msg, length);
//		vClearIntFlag();
//		vClearFIFO();
//		return(length);
// 		}
// 	}
// else
// 	{
// 	if(tmp&CRC_PS_FLG)
// 		{
//		if(FixedPktLength)
// 			length = PktLength;
// 		else
// 			length = Spi3.bSpi3ReadFIFO();
//		Spi3.vSpi3BurstReadFIFO(msg, length);
//		vClearIntFlag();
//		vClearFIFO();
//		return(length);
// 		}
// 	}
// return(0);
//}

